//�ļ�����Ȩ��Ϣ------------------
/*
 * ���ļ������п���ͼ���¿Ƽ����޹�˾����ҵ����ƽ̨����ɲ���
 * δ���������ÿ���������������������ҵ��;
 * ��Ȩ���У��п���ͼ���¿Ƽ����޹�˾(http://www.mapuni.com/) 
 * �������ߣ�������   chqzeng@163.com 
 * ��дʱ�䣺2010-09-01
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using GPSManager;

using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.InteropServices;

using ESRI.ArcGIS.esriSystem;
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.Geodatabase;
using ESRI.ArcGIS.Geometry;
using ESRI.ArcGIS.DataSourcesGDB;
using ESRI.ArcGIS.DataSourcesFile;
using ESRI.ArcGIS.Display;

namespace YuTuSurveyPlatform
{

    /// <summary>
    /// ���ļ���Ҫ������ϵͳ�����ļ��Ĺ����������򿪡��½����رա����湤���ļ����Լ��˳�ϵͳ�Ȳ�����
    /// ������������غ�����һ����
    /// </summary>
    /// 
    public partial class MainInterface : Form
    {
        string m_CurOpenFilePath = "";
     
        /// <summary>
        /// 	<Description>�½����� �˵���Ϣ��Ӧ����: ID_MENU_FILE_NEW_Click</Description>
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
       private void ID_MENU_FILE_NEW_Click(object sender, EventArgs e)
        {
            if (this.axMapControl1.LayerCount > 0) ResetProject();
            return;

            //ѯ���Ƿ񱣴浱ǰ��ͼ
            DialogResult res = DialogResult.None;
            if (this.axMapControl1.LayerCount > 0)
                res = MessageBox.Show("�Ƿ񱣴浱ǰ����?", "��ʾ", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (res == DialogResult.Yes)
            {
                ID_MENU_FILE_SAVE_Click(null, null);
            }

            //��������ͼ��
            m_CurLayerList.Clear();
            m_CurRSTFileList.Clear();
            m_CurSHPFileList.Clear();
            m_CurYVTFileList.Clear();

            m_strProjectFilePath = "";

            this.axMapControl1.ClearLayers();
            this.axMapControl1.ActiveView.ContentsChanged();
            this.axMapControl1.Refresh();
        }

        /// <summary>
        /// 	<Description>�򿪹��� �˵���Ϣ��Ӧ����: ID_MENU_FILE_OPEN_Click</Description>
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void ID_MENU_FILE_OPEN_Click(object sender, EventArgs e)
        {
            OpenExistDocument();
        }

        /// <summary>
        /// 	<Description>�˵���Ϣ��Ӧ����: ID_MENU_FILE_SAVE_Click</Description>
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void ID_MENU_FILE_SAVE_Click(object sender, EventArgs e)
        {
            SaveMapDocument();
        }

        /// <summary>
        /// 	<Description>���湤�� �˵���Ϣ��Ӧ����: ID_MENU_FILE_SAVEAS_Click</Description>
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void ID_MENU_FILE_SAVEAS_Click(object sender, EventArgs e)
        {
            string strSaveFile = "";
            if (strSaveFile == "")
            {
                if (this.axMapControl1.ActiveView.FocusMap.LayerCount <= 0) return;
                SaveFileDialog dlg = new SaveFileDialog();
                dlg.Filter = "Yutu Project File (*.yut)|*.yut";
                dlg.Title = "������ͼ��ʽ�����ļ�";
                if (dlg.ShowDialog() != DialogResult.OK) return;

                strSaveFile = dlg.FileName;
            }

            SaveProjectFile(strSaveFile);
            m_strProjectFilePath = strSaveFile;
        }

        /// <summary>
        /// 	<Description>�رչ��� �˵���Ϣ��Ӧ����: ID_MENU_FILE_CLOSE_Click</Description>
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void ID_MENU_FILE_CLOSE_Click(object sender, EventArgs e)
        {
            //ѯ���Ƿ񱣴浱ǰ��ͼ
            DialogResult res = DialogResult.None;
            if (this.axMapControl1.LayerCount > 0)
                res = MessageBox.Show("�Ƿ񱣴浱ǰ����?", "��ʾ", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (res == DialogResult.Yes)
            {
                ID_MENU_FILE_SAVE_Click(null, null);
            }

            //��������ͼ��
            m_CurLayerList.Clear();
            m_CurRSTFileList.Clear();
            m_CurSHPFileList.Clear();
            m_CurYVTFileList.Clear();

            m_strProjectFilePath = "";

            this.axMapControl1.ClearLayers();
            this.axMapControl1.ActiveView.ContentsChanged();
            this.axMapControl1.Refresh();

        }


        /// <summary>
        /// 	<Description>�˳�ϵͳ �˵���Ϣ��Ӧ����: ID_MENU_FILE_EXIT_Click</Description>
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void ID_MENU_FILE_EXIT_Click(object sender, EventArgs e)
        {

            //string pathToWorkspace = @"D:\zeng\TestData\enrypted\pafpscrx";
            //Marshal.FinalReleaseComObject(this.axMapControl1.get_Layer(0));
            //System.IO.Directory.Delete(pathToWorkspace,true);
            //return;

            //IMap map = new MapClass();
            //map.Name = "��ͼ";
            //this.axMapControl1.Map = map;
            //this.axMapControl1.ActiveView.ContentsChanged();
            //this.axMapControl1.Refresh();

            

            if (this.axMapControl1.LayerCount > 0) ResetProject();
            dlgVideoL.ExitWindow(true);
            dlgVideoR.ExitWindow(true);
            m_InputAttrDlg.ExitWindow(true);


            //ɾ����ʱ�ļ�
            string strDelPath = m_GeoEnctry.strTempFilePath;
            try
            {
                if (System.IO.Directory.Exists(strDelPath)) System.IO.Directory.Delete(strDelPath, true);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            //System.Environment.Exit(System.Environment.ExitCode);
            this.Dispose();
            this.Close();
            Application.Exit();
            //MessageBox.Show("1");
        }

        /// <summary>
        /// Gets the name of the path by layer.���ݲ������������Ĵ洢·��
        /// </summary>
        /// <param name="shpName">Name of the SHP �ļ���.</param>
        /// <returns></returns>
        public string GetPathByLayerName(string shpName)
        {
            for (int index = 0; index < m_CurLayerList.Count; index++)
                if (m_CurLayerList[index].LayerName == shpName) return m_CurLayerList[index].FilePath;
            return null;
        }

        /// <summary>
        /// Saves the project file. ���湤���ļ������Ĳ���
        /// </summary>
        /// <param name="strSaveFile">The STR save file.</param>
        private void SaveProjectFile(string strSaveFile)
        {
            m_CurYVTFileList.Clear();
            m_CurRSTFileList.Clear();
            m_CurSHPFileList.Clear();

            if (!strSaveFile.Contains(".yut")) strSaveFile = strSaveFile + ".yut";

            if (System.IO.File.Exists(strSaveFile)) System.IO.File.Delete(strSaveFile);

            int LyrCount = this.axMapControl1.LayerCount;
            for (int index = 0; index < LyrCount; index++)
            {

                ILayer lyr = this.axMapControl1.get_Layer(index);
                IRasterLayer rst = lyr as IRasterLayer;
                if (rst != null) //raster layer
                {
                    string strPath = GetPathByLayerName(rst.Name);
                    if (strPath == null) continue;
                    m_CurRSTFileList.Add(strPath); //rst.FilePath + ".bcg"
                }
                else
                {
                    IFeatureLayer shp = lyr as IFeatureLayer;
                    string strPath = GetPathByLayerName(shp.Name);

                    if (strPath == null || shp.Name.Contains(m_strEditLayerNameList[1]) || shp.Name.Contains("GPS")) continue;

                    if (shp.Name.Contains(".yvt")) //yutu format files
                    {
                        m_CurYVTFileList.Add(strPath);
                    }
                    else
                    {
                        m_CurSHPFileList.Add(strPath);
                    }
                }
            }

            IEnvelope env = this.axMapControl1.ActiveView.Extent;
            double MinX, MinY, MaxX, MaxY;
            env.QueryCoords(out MinX, out MinY, out MaxX, out  MaxY);//"ProjectInfo.yut"  dlg.FileName
            ProjectInfoMng.WriteProjectFileInfo(strSaveFile, m_CurRSTFileList, m_CurSHPFileList, m_CurYVTFileList, MinX, MinY, MaxX, MaxY);

        }

        /// <summary>
        /// <remark>���Ѿ����ڵĹ����ļ�</remark>
        /// </summary>
        public void OpenExistDocument()
        {
            //ѯ���Ƿ񱣴浱ǰ��ͼ
            //DialogResult res = DialogResult.None;
            //if (this.axMapControl1.LayerCount > 0)
            //    res = MessageBox.Show("�Ƿ񱣴浱ǰ����?", "��ʾ", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            //if (res == DialogResult.Yes)
            //{
            //    ID_MENU_FILE_SAVE_Click(null, null);
            //}

            if(this.axMapControl1.LayerCount >0)ResetProject();

            OpenMapDocument();
        }
          /// <summary>
        /// <remark>���Ѿ����ڵĹ����ļ����ĺ���</remark>
        /// </summary>
        public void OpenMapDocument()
        {
            //pictureBox1.Visible = true;

            //�� �����ļ�
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Filter = "��ͼ�����ļ� (*.yut)|*.yut";
            dlg.Title = "����ͼ��ʽ�����ļ�";
            if (dlg.ShowDialog() != DialogResult.OK) return;
            //m_CurOpenFilePath = dlg.FileName;
            //m_strProjectFilePath = dlg.FileName;

            //this.pictureBox1.Image = Image.FromFile(@"F:\YuTuSurveyPlatform\YuTuSurveyPlatform\Resources\LoadData.gif");
            //this.pictureBox1.Visible = true;
            OpenMapCore(dlg.FileName);

            //this.backgroundWorker1.RunWorkerAsync();
            //this.progressBar1.Visible = true;
            //this.axMapControl1.Refresh();
            


            //pictureBox1.Visible = false;
            //this.backgroundWorker1.CancelAsync();
           
        }
        public void OpenMapCore(string FileName)
        {
            try
            {
                double MinX, MinY, MaxX, MaxY;

                //��������ͼ��
                m_CurLayerList.Clear();
                this.axMapControl1.ClearLayers();
                m_CurYVTFileList.Clear();
                m_CurSHPFileList.Clear();
                m_CurRSTFileList.Clear();


                bool rst = ProjectInfoMng.ReadProjectFileInfo(FileName, out  m_CurRSTFileList, out  m_CurSHPFileList, out  m_CurYVTFileList,
                    out  MinX, out  MinY, out  MaxX, out  MaxY);
                if (rst == false) return;

                System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor;

                //�������е����ݣ�դ��SHAPE�ļ����Լ�YUTU���ݸ�ʽ�� 
                //Geometry_Encrypt cls = new Geometry_Encrypt(this.axMapControl1.Object as IMapControl2);
                OpenYVTvectorData(m_CurYVTFileList, ref  m_CurLayerList);
                m_GeoEnctry.OpenShapeBackGround(m_CurSHPFileList, ref  m_CurLayerList);
                m_GeoEnctry.OpenRasterBackGround(m_CurRSTFileList, ref  m_CurLayerList);

                m_CurRSTFileList.Clear();
                m_CurSHPFileList.Clear();
                m_CurYVTFileList.Clear();

                //���÷�Χ��С
                IEnvelope env = new EnvelopeClass();
                env.PutCoords(MinX, MinY, MaxX, MaxY);
                this.axMapControl1.Extent = env;
                this.axMapControl1.Refresh();

                System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default;

                m_strProjectFilePath = FileName;
            }
            catch (Exception ex)
            {
                MessageBox.Show("�������ݳ��ִ���\r\n" + ex.Message);
            }
        }


        /// <summary>
        /// <remark>���湤���ļ�</remark>
        /// </summary>
        public void SaveMapDocument()
        {
            string strSaveFile = m_strProjectFilePath;
            if (strSaveFile == "")
            {
                if (this.axMapControl1.ActiveView.FocusMap.LayerCount <= 0) return;
                SaveFileDialog dlg = new SaveFileDialog();
                dlg.Filter = "Yutu Project File (*.yut)|*.yut";
                dlg.Title = "������ͼ��ʽ�����ļ�";
                if (dlg.ShowDialog() != DialogResult.OK) return;

                strSaveFile = dlg.FileName;
            }

            SaveProjectFile(strSaveFile);
            m_strProjectFilePath = strSaveFile;
        }

        /// <summary>
        /// <remark>�������еĲ��������´򿪹����ļ�֮ǰ������Դ</remark>
        /// </summary>
        private void ResetProject()
        {

            //�������� 
            try
            {
                BTN_SAVE_YUTU_Click(null, null);
                if (m_SaveGPSTimer!=null) m_SaveGPSTimer.Enabled = false;
                if (GPSMng!=null&&GPSMng.m_SerialPort.IsOpen) ID_MENU_GPS_STOP_Click(null, null);
                BTN_VIDEO_STOP_Click(null, null);
                
            }
            catch (Exception ex)
            {
                MessageBox.Show("����ϵͳ��Դ���ִ���\r\n" + ex.Message);
            }

            string strDelPath = m_GeoEnctry.strTempFilePath;

            try
            {
                //ѯ���Ƿ񱣴浱ǰ��ͼ
                DialogResult res = DialogResult.None;
                if (this.axMapControl1.LayerCount > 0)
                    res = MessageBox.Show("�Ƿ񱣴浱ǰ����?", "��ʾ", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (res == DialogResult.Yes)
                {
                    ID_MENU_FILE_SAVE_Click(null, null);
                }

                //very important: to sort the FID in yvt files
                UpdateFIDSequence();

                //��������ͼ��
                m_CurLayerList.Clear();
                m_CurRSTFileList.Clear();
                m_CurSHPFileList.Clear();
                m_CurYVTFileList.Clear();

                m_strProjectFilePath = "";
                int lyrNum = this.axMapControl1.LayerCount;
                for (int index = lyrNum - 1; index >= 0; index--)
                {
                    DeleteLayer(this.axMapControl1.get_Layer(index), m_CurLayerList);
                }
                this.axMapControl1.ClearLayers();
                this.axMapControl1.ActiveView.ContentsChanged();
                this.axMapControl1.Refresh();
            }
            catch (Exception ex)
            {
                MessageBox.Show("�˳�ϵͳ���ִ���\r\n" + ex.Message);
            }
            #region unused
            /*
            if (this.axMapControl1.LayerCount == 0) return;

            //�������� 
            BTN_SAVE_YUTU_Click(null, null);
            ID_MENU_GPS_STOP_Click(null, null);
            BTN_VIDEO_STOP_Click(null, null);

            ///dlgVideoL.ExitWindow(true);
            //m_InputAttrDlg.Dispose();

            string strDelPath = m_GeoEnctry.strTempFilePath;

            //ѯ���Ƿ񱣴浱ǰ��ͼ
            DialogResult res = DialogResult.None;
            if (this.axMapControl1.LayerCount > 0)
                res = MessageBox.Show("�Ƿ񱣴浱ǰ����?", "��ʾ", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (res == DialogResult.Yes)
            {
                ID_MENU_FILE_SAVE_Click(null, null);
            }

            //��������ͼ��
            m_CurLayerList.Clear();
            m_CurRSTFileList.Clear();
            m_CurSHPFileList.Clear();
            m_CurYVTFileList.Clear();

            m_strProjectFilePath = "";
            int lyrNum = this.axMapControl1.LayerCount;
            for (int index = lyrNum - 1; index >= 0; index--)
            {
                DeleteLayer(this.axMapControl1.get_Layer(index), m_CurLayerList);
            }
            this.axMapControl1.ClearLayers();
            this.axMapControl1.ActiveView.ContentsChanged();
            this.axMapControl1.Refresh();
 */
            #endregion
        }

        /// <summary>
        /// <remark>�˳������ļ�ʱ����Ҫ���������޸ĺ��YVT �ļ�����FID˳��</remark>
        /// </summary>
        private void UpdateFIDSequence()
        {
            for (int index = 0; index < m_EditLayerNum; index++) //���������
            {
                string strPath = "";
                try
                {
                    IFeatureLayer m_POILayer = m_EditLayerList[index];
                    if (m_POILayer == null) continue;
                    strPath = GetPathByLayerName(m_POILayer.Name);
                    Geometry_IO.Geometry_Attribute.TestIncreasmentEx(strPath, Geometry_IO.Geometry_Attribute.m_strConstTableName);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("���������ļ�ʱ���ִ���!\r\n�ļ�����\r\n" + strPath + "ԭ��:" + ex.Message);
                }      
            }
        }
    }
}