using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace YuTuSurveyPlatform
{
    /// <summary>
    /// �汾�͹�˾��Ϣ
    /// </summary>
    public partial class VersionDlg : Form
    {
        string strPath = "";
        public VersionDlg(string path)
        {
            InitializeComponent();
            strPath = path;
        }

        /// <summary>
        /// 	<Description>�� ��ʼ���� ��Ϣ��Ӧ����: VersionDlg_Load</Description>
        /// ��������ͼƬ
        /// </summary>
        /// <param name="sender">��Ϣ��Դ������</param>
        /// <param name="e">���͵���Ϣ����</param>
        private void VersionDlg_Load(object sender, EventArgs e)
        {
            //System.Windows.Forms.Application.StartupPath + 
            try
            {
                this.pictureBox1.Image = Image.FromFile(strPath);
            }
            catch{}
        }
    }
}