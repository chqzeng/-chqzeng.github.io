//�ļ�����Ȩ��Ϣ------------------
/*
 * ���ļ������п���ͼ���¿Ƽ����޹�˾����ҵ����ƽ̨����ɲ���
 * δ���������ÿ���������������������ҵ��;
 * ��Ȩ���У��п���ͼ���¿Ƽ����޹�˾(http://www.mapuni.com/) 
 * �������ߣ�������   chqzeng@163.com 
 * ��дʱ�䣺2010-09-01
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Diagnostics;
//arcGIS reference
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.Controls;
using ESRI.ArcGIS.esriSystem;
using ESRI.ArcGIS.Display;
using ESRI.ArcGIS.Geometry;
using ESRI.ArcGIS.SystemUI;
using ESRI.ArcGIS.Geodatabase;
using ESRI.ArcGIS.Output;
using ESRI.ArcGIS.DataSourcesRaster;

using ESRI.ArcGIS.DataSourcesFile;
using ESRI.ArcGIS.DataSourcesGDB;
using System.Threading;

namespace YuTuSurveyPlatform
{
    
    /// <summary>
    /// �ļ��ṹ��Ϣ�壬���ڹ���ÿһ�������Ϣ
    /// ������������չ YUT�����ļ����������û��������ص���Ϣ��
    /// </summary>
    public struct MyLayerInfo
    {
        public string FilePath; 
        public string LayerName;
        public int LayerIndex;
        public int type; //1: raster  2: shape ; 3 yutu vector file
        public bool m_bVisible;

        //public MyLayerInfo()
        //{
        //    FilePath = "";
        //    LayerName = "";
        //    LayerIndex = -1;
        //    type = -1;
        //    m_bVisible = false;
        //}
    }

    /// <summary>
    /// ���ļ���Ҫ������ϵͳ�����Ĺ�����������ʼ�������������ڣ��Լ��˳�������
    /// ���ڱ༭Ƶ�����漰��Ӧ����˽���Ҫ�ı༭��صĺ������ڱ��ĵ�
    /// ������������غ�����һ����
    /// </summary>
    public partial class MainInterface : Form
    {
 #region  private variants
        //MainInterface map control and pageout control
        /// <summary>
        /// ��ͼ��صı�������
        /// </summary>
        //����ͼ����
        public IMapControl3 m_mapControl = null;
        //private IPageLayoutControl2 m_pageLayoutControl = null;
        //TOCControl�ؼ�����
        //ͼ����
        private ITOCControl2 m_tocControl = null;
        //TOCControl��Map�˵�
        private IToolbarMenu m_menuMap = null;

        
        /// <summary>
        /// ���ֲ˵� ��������
        /// </summary>
        //TOCControl��ͼ��˵�
        private IToolbarMenu m_menuLayer = null;
        //�༭������
        private IToolbarMenu m_EdittoolbarMenu;
        //��ǰ�ı༭����
        private IToolbarItem m_CurEditItem = null;
        //�Ƿ�Ϊ�༭���ߣ����Ǵ��� ����
        private bool m_bCurEditToolEdit = false;
        //��ǰ�����
        private IPoint pCurEditPoint = null;

        IFeatureWorkspace m_MemWorkspace = null;
        //δʹ��
        System.Timers.Timer timersTimer = null;

        //��ͼ��λ����
        private string sMapUnits;

        //private double m_curLayeOutScale;

        //�༭��ز���
        bool b_IsEditMode = false;
        bool b_IsMsgSaveEdit = false;
        bool b_IsAddVertex = false;
        //�Ƿ����Ѿ�ֹͣ�༭״̬
        bool b_IsStopOperation = false;

        //��Ϣ��������
        Events.EventListener eventListener;
        private EngineEditor m_EngineEditor = new EngineEditorClass();
        //private IEngineEditEvents_Event m_EngineEditEvents;
        
        //file list
        
        //ͼ���ļ����� LIST
        public List<string> m_CurRSTFileList = null;
        public List<string> m_CurSHPFileList = null;
        public List<string> m_CurYVTFileList = null;
        //ͼ����ϢLIST
        public List<MyLayerInfo> m_CurLayerList = null;
        //�����ļ�·�� 
        public string m_strProjectFilePath = "";
        //string m_strTempFilePath = "";
        public Geometry_Encrypt m_GeoEnctry=null;


        //�ض��༭ ���� ��ַ�룬POI ��·��
        Survey_InputAttrDlg m_InputAttrDlg = null;
        //IFeatureLayer m_POILayer =null;
        //IFeatureLayer m_AddressLayer = null;
        //IFeatureLayer m_PathLayer = null;
        //public const string m_strPOIFileName = "POI";
        //public const string m_strAdressFileName = "ADRESS";
        //public const string m_strPathFileName = "PATH";

        public const string m_strOIDName = "FID";
        public int m_CurToolSet = -1;

        //�ܹ��е���Ҫ�༭�Ĳ㳣�� 
        public const int m_EditLayerNum = 5;
        //������Ҫ�༭�Ĳ�
        public IFeatureLayer[] m_EditLayerList = null;
        //��Ӧ�����ֲ�Ĳ���
        public List<string> m_strEditLayerNameList=null;
        //������е��Ѿ��༭�Ĳ�
        public bool[] m_bEditLayer = null;


        //GPS������صĲ�
        public IFeatureLayer m_GPSPathLayer = null;
        public IFeatureLayer m_GPSMarkerLayer = null;
        //�Ƿ���Ҫ�½� GPS��¼
        public bool m_bIsNewGpsPath = true;
        //��ǰGPS·����¼��ID
        public int m_GPSCurOID=0;

        MVDoubleVD.MVDoubleVD dlgVideoL = null ;//new MVDoubleVD.MVDoubleVD(this);
        MVDoubleVD.MVDoubleVD dlgVideoR = null;
 #endregion

        IDisplayFeedback mFeedback = null;

        /// <summary>
        /// Initializes a new instance of the <see cref="MainInterface"/> class.
        /// �����溯�������ڼ��ظ���Դ
        /// </summary>
        public MainInterface()
        {
            //MessageBox.Show("before Init");
            InitializeComponent();
            //MessageBox.Show("after Init");
        }

        
        /// <summary>
        /// Handles the Load event of the MainInterface control.
        /// //��ʼ������
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void MainInterface_Load(object sender, EventArgs e)
        {
            //string mdbPath = @"F:\Temp\��·road.mdb";
            //Geometry_IO.Geometry_Attribute.TestIncreasmentEx(mdbPath, Geometry_IO.Geometry_Attribute.m_strConstTableName);
            //return;

            dlgVideoL = new MVDoubleVD.MVDoubleVD(this);
            dlgVideoR = new MVDoubleVD.MVDoubleVD(this);
            InitializeSnapSelection();

            //MessageBox.Show("before LOad");
            m_EditLayerList = new IFeatureLayer[m_EditLayerNum];
            m_bEditLayer = new bool[m_EditLayerNum];
            for (int i = 0; i < m_EditLayerNum; i++)
            { m_EditLayerList[i] = null; m_bEditLayer[i] = false; }

            m_strEditLayerNameList = new List<string>();
            m_strEditLayerNameList.Add("POI");
            m_strEditLayerNameList.Add("�½���");//NEW
            m_strEditLayerNameList.Add("ROAD");
            m_strEditLayerNameList.Add("BUILDINGS");
            m_strEditLayerNameList.Add("AREA");

           timersTimer = new System.Timers.Timer();
           timersTimer.Interval = 10 * 60 * 1000;  //10����Ϊ���  
            timersTimer.Elapsed += new System.Timers.ElapsedEventHandler(timersTimer_Elapsed);
            timersTimer.SynchronizingObject = this;


            //MessageBox.Show("LOad_1");

           m_CurRSTFileList = new List<string>();
           m_CurSHPFileList = new List<string>();
           m_CurYVTFileList = new List<string>();
           m_CurLayerList = new List<MyLayerInfo>();
           sMapUnits = "δ֪��λ";
           //������������
           comboBox_scalebox.Items.AddRange(new object[] { "1:5,000", "1:50,000", "1:500,000", "1:5,000,000", "1:50,000,000", "1:500,000,000" });

            // ȡ�� MapControl �� PageLayoutControl ������
            m_mapControl = (IMapControl3)this.axMapControl1.Object;
           // m_pageLayoutControl = (IPageLayoutControl2)this.axPageLayoutControl1.Object;
            m_tocControl = (ITOCControl2)this.axTOCControl1.Object;

           //MessageBox.Show("LOad_2");

            SaveMapDocument saveMapDoc = new SaveMapDocument(this);
            axToolbarControl1.AddItem(saveMapDoc, -1, 0, false, -1, esriCommandStyles.esriCommandStyleIconOnly);
            OpenMapDocument openMapDoc = new OpenMapDocument(this);
            axToolbarControl1.AddItem(openMapDoc, -1, 0, false, -1, esriCommandStyles.esriCommandStyleIconOnly);
            AddDataDialog addData = new AddDataDialog(this);
            axToolbarControl1.AddItem(addData, -1, 0, false, -1, esriCommandStyles.esriCommandStyleIconOnly);

            //���ӱ༭�Ի���
            //EditHelper.TheMainForm = this;
            //EditHelper.IsEditorFormOpen = false;
            //axToolbarControl1.AddItem(new EditCmd(), 0, -1, false, 0, esriCommandStyles.esriCommandStyleIconOnly);
            //axToolbarControl1.AddItem("esriControls.ControlsFeatureSelectionMenu", 0, -1, false, 0, esriCommandStyles.esriCommandStyleIconOnly);

            //MessageBox.Show("LOad_3");

            m_menuMap = new ToolbarMenuClass();
            //m_menuLayer = new ToolbarMenuClass();

            //�����Զ���˵��TOCCOntrol��Map�˵���
            //���ĵ��˵�
            m_menuMap.AddItem(openMapDoc, -1, 0, false, esriCommandStyles.esriCommandStyleIconAndText);
            //�������ݲ˵�
            m_menuMap.AddItem(addData, -1, 1, false, esriCommandStyles.esriCommandStyleIconAndText);
            //��ȫ��ͼ��˵�
            m_menuMap.AddItem(new RMenu_LayerVisibility(), 1, 2, false, esriCommandStyles.esriCommandStyleTextOnly);
            //�ر�ȫ��ͼ��˵�
            m_menuMap.AddItem(new RMenu_LayerVisibility(), 2, 3, false, esriCommandStyles.esriCommandStyleTextOnly);
            //�Զ����˵�����ʽ�������õġ�ѡ�񡱲˵�
            m_menuMap.AddSubMenu("esriControls.ControlsFeatureSelectionMenu", 4, true);
            //�Զ����˵�����ʽ�������õġ���ͼ������˵�
            m_menuMap.AddSubMenu("esriControls.ControlsMapViewMenu", 5, true);

            //�����Զ���˵��TOCCOntrol��ͼ��˵���
            m_menuLayer = new ToolbarMenuClass();
                        //���ӡ��Ŵ�����ͼ�㡱�˵���
            m_menuLayer.AddItem(new RMenu_ZoomToLayer(), -1, 0, true, esriCommandStyles.esriCommandStyleTextOnly);
            
            //���ӡ��Ƴ�ͼ�㡱�˵���
            m_menuLayer.AddItem(new RMenu_RemoveLayer(ref m_CurLayerList), -1, -1, true, esriCommandStyles.esriCommandStyleTextOnly);

            //���ӡ����ѡ�񼯡��˵���
            //m_menuLayer.AddItem(new RMenu_RemoveLayerSelection(), -1, 2, true, esriCommandStyles.esriCommandStyleTextOnly);

            //���ӡ�label���˵���
            m_menuLayer.AddItem(new RMenu_AddLabel(), -1, -1, true, esriCommandStyles.esriCommandStyleTextOnly);

            //�Ƴ���label���˵���
            m_menuLayer.AddItem(new RMenu_RemoveLabel(), -1, -1, true, esriCommandStyles.esriCommandStyleTextOnly);

            //�������
            //m_menuLayer.AddItem(new RMenu_ViewLayerInfo(), -1, 5, true, esriCommandStyles.esriCommandStyleTextOnly);

            //��������
            m_menuLayer.AddItem(new RMenu_ExportDataAs(), -1, -1, true, esriCommandStyles.esriCommandStyleTextOnly);

            //ͼ������
            //m_menuLayer.AddItem(new RMenu_MapRender(), -1, 7, true, esriCommandStyles.esriCommandStyleTextOnly);

            //MessageBox.Show("LOad_4");

            //���ò˵���Hook
            m_menuLayer.SetHook(m_mapControl);
            m_menuMap.SetHook(m_mapControl);

            m_GeoEnctry = new Geometry_Encrypt(this.axMapControl1.Object as IMapControl2);

            //MessageBox.Show("LOad_5");

            //��ʼ���༭ �˵� 
            InitEditToolBar(this.axToolbarControlEdit);
           // MessageBox.Show("LOad_1");
            eventListener = new Events.EventListener(new EngineEditorClass());
            for (int index = 0; index < 22; index++)  //��22����Ϣ��Ҫ����
                eventListener.ListenToEvents((Events.EventListener.EditorEvent)index, true);
            eventListener.Changed += new Events.ChangedEventHandler(eventListener_Changed);

            EngineEditor m_EngineEditor = new EngineEditorClass();
            IEngineEditEvents_Event m_EngineEditEvents = (IEngineEditEvents_Event)m_EngineEditor;
            m_EngineEditEvents.OnStopOperation += new IEngineEditEvents_OnStopOperationEventHandler(Event_OnStopOperationMethod);
            m_EngineEditEvents.OnSelectionChanged += new IEngineEditEvents_OnSelectionChangedEventHandler(Event_OnSelectionChangedMethod);
            //m_EngineEditEvents.OnStartOperation += new IEngineEditEvents_OnStartOperationEventHandler(Event_OnStartOperationMethod);
            
            m_InputAttrDlg = new Survey_InputAttrDlg();

           // MessageBox.Show("LOad_3");
            //IntPtr hwnd = this.Handle;
            //GPSMng = new GPSManager.GPSManagerCore(this.Handle, "COM1", 57600);
            //GPSMng.OpenPort();
        }

        /// <summary>
        /// Inits the edit tool bar.
        /// //���ر༭�˵� 
        /// </summary>
        /// <param name="m_ToolbarControl">The m_ toolbar control.</param>
        private void InitEditToolBar(AxToolbarControl m_ToolbarControl)
        {
            //MessageBox.Show("LOad_1");

            m_ToolbarControl.SetBuddyControl(this.axMapControl1);
            //Add items to the ToolbarControl
            //m_ToolbarControl.AddItem(new EditCmd(), 0, -1, false, 0, esriCommandStyles.esriCommandStyleIconOnly);

            //IToolbarMenu m_menuEdit = new ToolbarMenuClass();
            //m_menuEdit.Caption = "�༭q";
            //m_menuMap.AddItem(new MenuStrip_EditMenu(), 1, 0, false, esriCommandStyles.esriCommandStyleTextOnly);
            //m_menuMap.AddItem(new MenuStrip_EditMenu(), 2, 1, false, esriCommandStyles.esriCommandStyleTextOnly);
            //m_menuMap.AddItem(new MenuStrip_EditMenu(), 3, 2, false, esriCommandStyles.esriCommandStyleTextOnly);

           // MessageBox.Show("LOad_2");

            IToolbarPalette toolbarPalette = new ToolbarPalette();
            IMapControl2 map = this.axMapControl1.Object as IMapControl2;
            toolbarPalette.SetHook(m_mapControl);
            //toolbarPalette.Caption = "�༭";
            toolbarPalette.IconSize = 32;
            //toolbarPalette.AddItem(new MenuStrip_EditMenu(1, this), 1, -1);//m_pageLayoutControl
            //toolbarPalette.AddItem(new MenuStrip_EditMenu(2, this), 2, -1);
            //toolbarPalette.AddItem(new MenuStrip_EditMenu(3, this), 3, -1);

            //MessageBox.Show("LOad_3");

            //m_ToolbarControl.AddItem(toolbarPalette, 0, -1, false, 0, esriCommandStyles.esriCommandStyleIconAndText);

            //m_ToolbarControl.AddItem("esriControls.ControlsEditingEditorMenu", 0, -1, false, 0, esriCommandStyles.esriCommandStyleIconOnly);
           
            
            m_ToolbarControl.AddItem("esriControls.ControlsEditingEditTool", 0, -1, true, 0, esriCommandStyles.esriCommandStyleIconOnly);
            m_ToolbarControl.AddItem("esriControls.ControlsEditingSketchTool", 0, -1, false, 0, esriCommandStyles.esriCommandStyleIconOnly);
            //m_ToolbarControl.AddItem("VertexCommands_CS.VertexCommandsMenu", 0, -1, false, 0, esriCommandStyles.esriCommandStyleIconAndText);//

            m_ToolbarControl.AddItem(new Editor.SnapSettingsCommand(), 0, -1, true, 0, esriCommandStyles.esriCommandStyleTextOnly);
            
            //m_ToolbarControl.AddItem(new ControlsEditingSnappingCommandClass(), 0, -1, true, 0, esriCommandStyles.esriCommandStyleTextOnly);
            //m_ToolbarControl.AddItem(new Editor.VertexCommandsMenu(), 0, -1, true, 0, esriCommandStyles.esriCommandStyleTextOnly);

            //m_ToolbarControl.AddItem(new Editor.CustomVertexCommands(), 1, -1, true, 0, esriCommandStyles.esriCommandStyleTextOnly);
            //m_ToolbarControl.AddItem(new Editor.CustomVertexCommands(), 2, -1, true, 0, esriCommandStyles.esriCommandStyleTextOnly);

            //tools
            //m_ToolbarControl.AddItem("Commands.VertexAndReshapeCommandsMenu", 0, -1, false, 0, esriCommandStyles.esriCommandStyleIconAndText);
            //MessageBox.Show("LOad_4");
            
            m_ToolbarControl.AddItem(new RMenu_DeleteFeature(this), 0, -1, true, 0, esriCommandStyles.esriCommandStyleIconOnly);

            m_ToolbarControl.AddItem("esriControls.ControlsEditingAttributeCommand", 0, -1, true, 0, esriCommandStyles.esriCommandStyleIconOnly);
            m_ToolbarControl.AddItem("esriControls.ControlsEditingSketchPropertiesCommand", 0, -1, false, 0, esriCommandStyles.esriCommandStyleIconOnly);
            m_ToolbarControl.AddItem("esriControls.ControlsEditingTargetToolControl", 0, -1, true, 0, esriCommandStyles.esriCommandStyleIconOnly);
            m_ToolbarControl.AddItem("esriControls.ControlsEditingTaskToolControl", 0, -1, false, 0, esriCommandStyles.esriCommandStyleIconOnly);

            //m_ToolbarControl.AddItem("esriControls.ControlsUndoCommand", 0, -1, true, 0, esriCommandStyles.esriCommandStyleIconOnly);
            //m_ToolbarControl.AddItem("esriControls.ControlsRedoCommand", 0, -1, false, 0, esriCommandStyles.esriCommandStyleIconOnly);

            //MessageBox.Show("LOad_5");

            //m_ToolbarControl.AddItem("SnapCommands_CS.SnapSettingsCommand", 0, -1, true, 0, esriCommandStyles.esriCommandStyleIconAndText);


            //m_ToolbarControl.AddItem("esriControls.ControlsEditingCutCommand", 0, -1, true, 0, esriCommandStyles.esriCommandStyleIconOnly);
            //m_ToolbarControl.AddItem("esriControls.ControlsEditingPasteCommand", 0, -1, false, 0, esriCommandStyles.esriCommandStyleIconOnly);
            //m_ToolbarControl.AddItem("esriControls.ControlsEditingCopyCommand", 0, -1, false, 0, esriCommandStyles.esriCommandStyleIconOnly);
            //m_ToolbarControl.AddItem("esriControls.ControlsEditingClearCommand", 0, -1, false, 0, esriCommandStyles.esriCommandStyleIconOnly);

            //m_ToolbarControl.Visible = false;

            //Create a popup menu
            m_EdittoolbarMenu = new ToolbarMenuClass();
            m_EdittoolbarMenu.AddItem("esriControls.ControlsEditingSketchContextMenu", 0, 0, false, esriCommandStyles.esriCommandStyleTextOnly);
            //MessageBox.Show("LOad_6");

            //Share command pools
            this.axToolbarControl1.CommandPool = m_ToolbarControl.CommandPool;
            m_EdittoolbarMenu.CommandPool = m_ToolbarControl.CommandPool;
            //MessageBox.Show("LOad_7");

        }



        /// <summary>
        /// Handles the FormClosed event of the MainInterface control.
        /// //�رմ��ں���
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.Windows.Forms.FormClosedEventArgs"/> instance containing the event data.</param>
        private void MainInterface_FormClosed(object sender, FormClosedEventArgs e)
        {
            ID_MENU_FILE_EXIT_Click(null, null);
        }

        /// <summary>
        /// Deletes the layer.
        /// ɾ��ͼ��
        /// </summary>
        /// <param name="layer">The layer.ͼ��</param>
        /// <param name="m_LayerList">The m_ layer list.��Ӧ��Ҫ����ͼ����Ϣ�б�</param>
        private void DeleteLayer(ILayer layer, List<MyLayerInfo> m_LayerList)
        {
            //ILayer layer = (ILayer)m_mapControl.CustomProperty;

            for (int index = 0; index < m_LayerList.Count; index++)
            {
                if (layer.Name == m_LayerList[index].LayerName)
                {
                    m_LayerList.RemoveAt(index);
                    break;
                }
            }
            IFeatureLayer ftLyr = layer as IFeatureLayer;
            IRasterLayer rstLyr = layer as IRasterLayer;
            IWorkspace pWs = null;
            if (rstLyr != null) pWs = (rstLyr as IDataset).Workspace;

            m_mapControl.Map.DeleteLayer(layer);

            if (ftLyr != null && ftLyr.Name.Contains(".yvt"))  //yutu ��ʽ���� �����
            {
                IDataset curDS = ftLyr.FeatureClass as IDataset;
                if (curDS != null)
                {
                    curDS.Delete();
                }
            }
            else if (rstLyr != null)
            {
                IRasterWorkspace pRWS = pWs as IRasterWorkspace;
                IRasterDataset pRasterDataset = pRWS.OpenRasterDataset(rstLyr.Name);
                IDataset pDataset = pRasterDataset as IDataset;
                if (pDataset.CanDelete())
                {
                    pDataset.Delete();
                }
            }
            //Marshal.FinalReleaseComObject(layer);
        }

        /// <summary>
        /// Handles the SelectedIndexChanged event of the comboBox_scalebox control.
        /// �������ú���ʾ
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void comboBox_scalebox_SelectedIndexChanged(object sender, EventArgs e)
        {
            double scale = 0D;
            switch (comboBox_scalebox.SelectedIndex)
            {
                case 0:
                    scale = 5000.0d;
                    break;
                case 1:
                    scale = 50000.0d;
                    break;
                case 2:
                    scale = 500000.0d;
                    break;
                case 3:
                    scale = 5000000.0d;
                    break;
                case 4:
                    scale = 50000000.0d;
                    break;
                case 5:
                    scale = 500000000.0d;
                    break;
            }
            this.axMapControl1.MapScale = scale;
            this.axMapControl1.ActiveView.Refresh();

            this.axMapControl1.MapScale = scale;
            this.axMapControl1.ActiveView.Refresh();
        }

        /// <summary>
        /// Handles the KeyPress event of the comboBox_scalebox control.
        /// �������ã�ͨ�����س���ʵ��
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.Windows.Forms.KeyPressEventArgs"/> instance containing the event data.</param>
        private void comboBox_scalebox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                string str = comboBox_scalebox.Text;
                int pos = str.IndexOf("1:");
                if (pos != 0)
                {
                    MessageBox.Show("�����ߴ�����������1:5000 ���Ƶı�����", "��ʾ",
                        MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }
                pos = str.LastIndexOf(",");
                while (pos >= 0)
                {
                    str = str.Remove(pos, 1);
                    pos = str.LastIndexOf(",");
                }

                double scale = Convert.ToDouble(str.Substring(2));
                this.axMapControl1.MapScale = scale;
                this.axMapControl1.ActiveView.Refresh();
                this.axMapControl1.MapScale = scale;
                this.axMapControl1.ActiveView.Refresh();
            }
        }

        /// <summary>
        /// Handles the Elapsed event of the timersTimer control.
        /// δʹ�ã�������
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void timersTimer_Elapsed(object sender, EventArgs e)
        {

            IEngineEditLayers editor = new EngineEditorClass();
            IEngineEditor m_engineEditor = editor as IEngineEditor;
            if (m_engineEditor.EditState == esriEngineEditState.esriEngineStateNotEditing) return;

            ICommand pCommand = new ControlsEditingSaveCommandClass();
            pCommand.OnCreate(this.axToolbarControl1.Object);
            pCommand.OnClick();

            //Type t = null;
            //object o = null;
            //t = Type.GetTypeFromProgID("esriControls.ControlsEditingSaveCommand.1");
            //o = Activator.CreateInstance(t);
            //ICommand SaveEditCommand = o as ICommand;
            //SaveEditCommand.OnClick();

            //string mdbPath, tableName;
            //Survey_RecordMng mng = new Survey_RecordMng();
            //IFeatureLayer pLayer = editor.TargetLayer;
            //tableName = pLayer.Name;
            //mdbPath = GetPathByLayerName(tableName);
            //ExportYutuVectorData(mdbPath, pLayer);
        }


        /// <summary>
        /// Deletes the record.
        /// ɾ����¼
        /// </summary>
        /// <param name="pLayer">The p layer.��Ӧ�Ĳ�</param>
        /// <param name="strSQL">The STR SQL.ɾ����SQL���</param>
        private void DeleteRecord(ILayer pLayer, string strSQL)
        {
            IQueryFilter queryFilter = new QueryFilterClass();
            queryFilter.WhereClause = strSQL;
            // Create insert feature cursor using buffering.
            IFeatureClass featureClass = ((IFeatureLayer)pLayer).FeatureClass;
            IFeatureCursor featureCursor = featureClass.Update(queryFilter, false);
            IFeature feature = featureCursor.NextFeature();
            try
            {
                if (feature != null)
                {
                    featureCursor.DeleteFeature();
                }
            }
            catch //(COMException comExc)
            {
                // Handle any errors that may occur on NextFeature().
            }


            //featureCursor.DeleteFeature();
            //IFields fields = featureCursor.Fields;
            //if (feature != null) feature.Delete();

            //featureCursor.UpdateFeature(feature);
            Marshal.ReleaseComObject(featureCursor);
        }

//������Ҫ��Ӧ�ڱ༭��ص���Ϣ�ͺ���
#region  �˵��� С�ؼ� �༭����

        /// <summary>
        /// Handles the Changed event of the eventListener control
        /// //ȫ����Ϣ�������������ڲ�׽�༭������Ϣ.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="Events.EditorEventArgs"/> instance containing the event data.</param>
        public void eventListener_Changed(object sender, Events.EditorEventArgs e)
        {
            return;

            Survey_RecordMng mng = new Survey_RecordMng();
            IEngineEditLayers editor = new EngineEditorClass();
            string mdbPath, tableName;
            IFeatureLayer pLayer = editor.TargetLayer;
            tableName = pLayer.Name;
            mdbPath = GetPathByLayerName(tableName);

            //MessageBox.Show("EventList" + e.eventType);

            //MessageBox.Show(e.eventType.ToString());

            try
            {
                //string str =e.eventType.ToString();
                //�������ֱ༭��Ϣ  //OnStartEditing,      OnStartOperation,      OnStopEditing,      OnStopOperation,
                switch (e.eventType)
                {
                    case "OnStartEditing":
                        b_IsEditMode = true;

                        //timersTimer.Enabled = true;

                        break;
                    case "OnSaveEdits":
                        //IDataset dataset = editor.TargetLayer.FeatureClass as IDataset;
                        //IWorkspace workspace = dataset.Workspace;
                        List<int> OIDList = new List<int>();
                        int curID = 64;
                        OIDList.Add(curID);
                        if (tableName.Contains(".yvt")) tableName.Replace(".yvt", "");

                        b_IsMsgSaveEdit = true;
                        //ExportYutuVectorData(mdbPath, pLayer);

                        //ManageDifferentLayerSave(m_CurToolSet - 100);

                        //mng.Suvery_Record_Insert(OIDList, mdbPath, tableName, pLayer);
                        //mng.Suvery_Record_Delete(OIDList, mdbPath, tableName, pLayer);
                        //mng.UpdatgeChangesForScope( mdbPath,  tableName,  pLayer, esriEditDataChangesType.esriEditDataChangesWithinSession);
                        break;
                    case "OnStopEditing":
                        //ExportYutuVectorData(mdbPath, pLayer);

                        //ManageDifferentLayerSave(m_CurToolSet-100);

                        if (b_IsMsgSaveEdit == false) timersTimer.Enabled = false;
                        b_IsMsgSaveEdit = false;

                        b_IsEditMode = false;
                        break;
                    case "OnVertexAdded":  //ѡ�����ʱ
                        //if (m_EngineEditor.CurrentTask.UniqueName == "ControlToolsEditing_CreateNewFeatureTask")
                        b_IsAddVertex = true;
                        break;
                    case "OnStopOperation":   //Add ����ʱ
                        b_IsStopOperation = true;
                        break;
                        //if (b_IsAddVertex)
                        //{
                        //    b_IsAddVertex = false;
                        //    ICommand pCommand = new ControlsEditingAttributeCommandClass();
                        //    pCommand.OnCreate(this.axToolbarControlEdit.Object);
                        //    pCommand.OnClick();
                        //}
                        //break;
                    case "OnAfterDrawSketch":
                        break;
                    case "OnSelectionChanged":
                        //if (b_IsStopOperation) b_IsStopOperation = false;
                        //else break;
                        
                        ManageDifferentLayerEdit();//m_CurToolSet - 100
                        break;
                    default:
                        string str = e.eventType.ToString();
                        break;
                }
            }
            catch (Exception ex)
            {
                //((IEngineEditor)editor).StopEditing(true);
                MessageBox.Show("�༭����������ԭ�������" + ex.Message);
            }

        }


        /// <summary>
        /// Manages the different layer edit.
        /// //������ͬ��ı༭
        /// </summary>
        private void ManageDifferentLayerEdit()//int index
        {
            if (!m_bCurEditToolEdit && b_IsStopOperation == false) return;

            IEngineEditor EngineEdit = new EngineEditorClass();
            long strOIDValue = 0;
            string strOIDName = "";
            //switch (index)
            {
                #region  unused codes
                //case 11: //add POI
                //    if (EngineEdit.SelectionCount >= 1)  //��ǰ��ѡ��Ķ���
                //    {
                //        IEnumFeature enumFeature = EngineEdit.EditSelection;
                //        enumFeature.Reset();
                //        IFeature selFeature = enumFeature.Next();
                //        strOIDValue = selFeature.OID;

                //        m_InputAttrDlg.m_bIsAddRecord = true;
                //        m_InputAttrDlg.SetParams(m_POILayer, m_strOIDName, strOIDValue);
                //        m_InputAttrDlg.ShowDialog(this);  //Dialog
                //    }
                //    break;
                //case 12:
                //    if (EngineEdit.SelectionCount >= 1)  //��ǰ��ѡ��Ķ���
                //    {
                //        IEnumFeature enumFeature = EngineEdit.EditSelection;
                //        enumFeature.Reset();
                //        IFeature selFeature = enumFeature.Next();
                //        strOIDValue = selFeature.OID;
                //        m_InputAttrDlg.SetParams(m_POILayer, m_strOIDName, strOIDValue);
                //        if (m_InputAttrDlg.Visible) m_InputAttrDlg.Update();
                //        else   m_InputAttrDlg.Show(this);  //Dialog
                //    }
                //    break;
                //case 13:
                //    if (EngineEdit.SelectionCount >= 1)  //��ǰ��ѡ��Ķ���
                //    {
                //        IEnumFeature enumFeature = EngineEdit.EditSelection;
                //        enumFeature.Reset();
                //        IFeature selFeature = enumFeature.Next();
                //        strOIDValue = selFeature.OID;
                //        string strSQL = " " + m_strOIDName + " = " + strOIDValue.ToString();
                //        DeleteRecord(m_POILayer, strSQL);
                //    }
                //    break;
                #endregion
                //case 0: //POI
                    if (EngineEdit.SelectionCount == 1)  //��ǰ��ѡ��Ķ���,��ֻ��һ��
                    {
                        IEnumFeature enumFeature = EngineEdit.EditSelection;
                        enumFeature.Reset();
                        IFeature selFeature = enumFeature.Next();
                        strOIDValue = selFeature.OID;
                        strOIDName = selFeature.Table.OIDFieldName;

                        IFeatureLayer lyr = (EngineEdit as IEngineEditLayers).TargetLayer;

                        //MessageBox.Show(EngineEdit.CurrentTask.UniqueName);
                        try
                        {
                            if (!m_bCurEditToolEdit)//(EngineEdit.CurrentTask.UniqueName == "ControlToolsEditing_CreateNewFeatureTask")
                            {
                                m_InputAttrDlg.m_bIsAddRecord = true;
                                m_InputAttrDlg.SetParams(lyr, strOIDName, strOIDValue);//m_EditLayerList[index]
                                DialogResult rs = m_InputAttrDlg.ShowDialog(this);  //Dialog
                                if (rs == DialogResult.OK) m_bEditLayer[m_CurToolSet - 100] = true;
                            }
                            else //if (m_InputAttrDlg.Visible == false) 
                            {
                                m_InputAttrDlg.m_bIsAddRecord = false;
                                if (m_InputAttrDlg.Visible) m_InputAttrDlg.Hide();

                                m_InputAttrDlg.SetParams(lyr, strOIDName, strOIDValue);
                                m_InputAttrDlg.Show(this);
                                m_bEditLayer[m_CurToolSet - 100] = true;
                            }
                        }
                        catch
                        {
                            m_InputAttrDlg=null;
                            m_InputAttrDlg=new Survey_InputAttrDlg();
                            m_InputAttrDlg.SetParams(lyr, strOIDName, strOIDValue);
                            m_InputAttrDlg.Show(this);
                        }

                        b_IsStopOperation = true;

                        IEnvelope envExt = new EnvelopeClass();
                        this.axMapControl1.ActiveView.PartialRefresh(esriViewDrawPhase.esriViewGeography, lyr, selFeature.Shape.Envelope);
                    }

                    //break;
            }

            
            //this.axMapControl1.ActiveView.PartialRefresh(esriViewDrawPhase.esriViewGeography, m_POILayer, null);

        }


        /// <summary>
        /// Manages the different layer save.
        /// //������ͬ��ı���
        /// </summary>
        /// <param name="index">The index.</param>
        private void ManageDifferentLayerSave(int index)
        {
            IEngineEditor EngineEdit = new EngineEditorClass();
            if (EngineEdit.EditState != esriEngineEditState.esriEngineStateNotEditing && EngineEdit.HasEdits()) //�༭״̬�����иĶ�
            {
               // EngineEdit.StopEditing(true);
                m_bEditLayer[index] = true;
            }
        }


        /// <summary>
        /// Sets the current edit layer.
        /// //����ͬ�Ĺ���֮���л�ʱ
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="index">The index.</param>
        /// <returns></returns>
        private bool SetCurrentEditLayer(object sender, int index)
        {
            //IEngineEditor editor = new EngineEditorClass();
            //IMap map = editor.Map;
            //IEngineEditLayers Elyr = editor as IEngineEditLayers;
            //IFeatureLayer pLayer = Elyr.TargetLayer;
            //IDataset m_Dataset = (IDataset)pLayer.FeatureClass;

            ////�ر�EDIT
            //if (editor.EditState != esriEngineEditState.esriEngineStateNotEditing)
            //{
            //    editor.StopEditing(true);
            //    //����EDIT
            //    editor.StartEditing(m_Dataset.Workspace, map);
            //}

            //ת���µı༭��
            IFeatureLayer m_POILayer = m_EditLayerList[index];
            if (m_POILayer == null) return false;

            //���浱ǰ�༭���
            IEngineEditor editor = new EngineEditorClass();
            if (editor.EditState == esriEngineEditState.esriEngineStateEditing && editor.HasEdits())
            {
                IMap EditMap = editor.Map;
                IEngineEditLayers Elyr = editor as IEngineEditLayers;
                string mdbPath, tableName;
                IFeatureLayer pLayer = Elyr.TargetLayer;
                tableName = pLayer.Name;
                mdbPath = GetPathByLayerName(tableName);

                //�������� 
                editor.StopEditing(true);
                //ExportYutuVectorData(mdbPath, pLayer);
                m_bEditLayer[index] = true;

                //��������EDIT
                IDataset m_Dataset = (IDataset)m_POILayer.FeatureClass;
                //IWorkspaceEdit m_WorkspaceEdit = (IWorkspaceEdit)m_Dataset.Workspace;
                editor.StartEditing(m_Dataset.Workspace, EditMap);
                ((IEngineEditLayers)editor).SetTargetLayer(m_POILayer, 0);
                //IEngineEditTask editTask = editor.GetTaskByUniqueName("ControlToolsEditing_CreateNewFeatureTask");
                //editor.CurrentTask = editTask;
            }
            else //if (editor.EditState == esriEngineEditState.esriEngineStateNotEditing)
            {
                //�������� 
                editor.StopEditing(true);  //����GPS����

                IDataset dataset = m_POILayer.FeatureClass as IDataset;
                editor.StartEditing(dataset.Workspace, this.axMapControl1.Map);
                ((IEngineEditLayers)editor).SetTargetLayer(m_POILayer, 0);
                //IEngineEditTask editTask = editor.GetTaskByUniqueName("ControlToolsEditing_CreateNewFeatureTask");
                //editor.CurrentTask = editTask;
            }

            //ֻ�е�ǰ�����ѡ��
            for (int i = 0; i < this.axMapControl1.LayerCount; i++)
            {
                IFeatureLayer lyr=this.axMapControl1.get_Layer(i) as IFeatureLayer;
                if (lyr != null) lyr.Selectable = false;
            }
            (editor as IEngineEditLayers).TargetLayer.Selectable = true;

            m_CurToolSet = 100 + index; //���õ�ǰ�Ĺ���
            ToolStripButton btn = sender as ToolStripButton;

            //un check all buttons
            BTN_CLS_POI.Checked = false;
            BTN_CLS_NEWPOI.Checked = false;
            BTN_CLS_PATH.Checked = false;
            BTN_CLS_BUILDINGS.Checked = false;
            BTN_CLS_BACKGROUND.Checked = false;

            btn.Checked = true;

            return true;
        }


        /// <summary>
        /// Handles the Click event of the BTN_SAVE_YUTU control.
        /// //���水ť��Ϣ
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void BTN_SAVE_YUTU_Click(object sender, EventArgs e)
        {
            //SaveEdit();
            //return;

            //IEngineEditor editor = new EngineEditorClass();
            //if (editor.EditState != esriEngineEditState.esriEngineStateNotEditing)
            //{
            //    editor.StopEditing(true);
            //}
            if (this.axMapControl1.LayerCount == 0) return;

            this.Cursor = Cursors.WaitCursor;
            SaveAllEditLayers();
            
            //m_CurToolSet = -1;
            this.axMapControl1.Refresh();

            this.Cursor = Cursors.Default;
        }
        public void SaveAllEditLayers()
        {
            //BTN_TOOL_IDLE_Click(null, null);
            IEngineEditor editor = new EngineEditorClass();
            if (editor.EditState == esriEngineEditState.esriEngineStateEditing && editor.HasEdits())
            {
                //�������� 
                editor.StopEditing(true);
                //ExportYutuVectorData(mdbPath, pLayer);
                if (m_CurToolSet >= 100)
                    m_bEditLayer[m_CurToolSet - 100] = true;
            }

            // this.Cursor = Cursors.WaitCursor;
            Survey_RecordMng manger = new Survey_RecordMng();

            for (int index = 0; index < m_EditLayerNum; index++) //���������
            {
                if (m_bEditLayer[index])
                {
                    string strPath = "";
                    try
                    {
                        IFeatureLayer m_POILayer = m_EditLayerList[index];
                        if (m_POILayer == null) continue;
                        strPath = GetPathByLayerName(m_POILayer.Name);

                        //ExportYutuVectorData(strPath, m_POILayer);
                        manger.UpdatgeChangesForLayer(strPath, Geometry_IO.Geometry_Attribute.m_strConstTableName, m_POILayer);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("���ݴ洢���ļ�ʱ���ִ���!\r\n�ļ�����" + strPath + "\r\nԭ��:" + ex.Message);
                    }
                    m_bEditLayer[index] = false;
                }
            }

            //���� GPS ���� 
            if (GPSMng != null)
            {
                m_SaveGPSTimer.Enabled = false;
                MENU_GPS_SAVE_Click(null, null);
                m_SaveGPSTimer.Enabled = true;
            }
        }

        /// <summary>
        /// Handles the Click event of the BTN_TOOL_IDLE control.
        /// //ȡ�����в��� ��ť��Ϣ
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void BTN_TOOL_IDLE_Click(object sender, EventArgs e)
        {
            //this.axMapControl1.MousePointer = esriControlsMousePointer.esriPointerArrow;
            IEngineEditor editor = new EngineEditorClass();
            if (editor.EditState == esriEngineEditState.esriEngineStateEditing && editor.HasEdits())
            {
                //�������� 
                editor.StopEditing(true);
                //ExportYutuVectorData(mdbPath, pLayer);
                if(m_CurToolSet>=100)
                    m_bEditLayer[m_CurToolSet-100] = true;
            }
            m_CurToolSet = -1; //���õ�ǰ�Ĺ���
        }

        /// <summary>
        /// Handles the KeyDown event of the MainInterface control.
        /// //�ȼ����� 
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.Windows.Forms.KeyEventArgs"/> instance containing the event data.</param>
        private void MainInterface_KeyDown(object sender, KeyEventArgs e)
        {
            if(!e.Alt) return;
            switch (e.KeyCode) 
            {
                case Keys.S:   //Ctrl + Alt +S  ���浱ǰ��
                    if (e.Control && e.Alt) BTN_SAVE_YUTU_Click(null, null);
                    break;
                case Keys.D:  //ALT +F3  ɾ����ǰ ѡ�ж���
                    DeleteSelectedFeature();
                    break;
//�༭��
                case Keys.Q:   //ALT +F1  ���ӵ�ǰ POI
                    BTN_CLS_POI_Click(BTN_CLS_POI, null);
                    break;
                //case Keys.W:  //ALT +F2  �༭��ǰ POI
                //    BTN_CLS_NEWPOI_Click(BTN_CLS_NEWPOI, null);
                //    break;
                case Keys.W:  //ALT +F3  �༭��ǰ ROAD
                    //BTN_PT_del_Click(null, null);
                    BTN_CLS_PATH_Click(BTN_CLS_PATH, null);
                    break;
                case Keys.E:  //ALT +F3  �༭��ǰ BUILDINGS
                    //BTN_PT_del_Click(null, null);
                    BTN_CLS_BUILDINGS_Click(BTN_CLS_BUILDINGS, null);
                    break;
                case Keys.R:  //ALT +F3  �༭��ǰ AREA
                    //BTN_PT_del_Click(null, null);
                    BTN_CLS_BACKGROUND_Click(BTN_CLS_BACKGROUND, null);
                    break;
//GPS
                case Keys.D1:  //ALT +1  GPS ����
                    ID_MENU_GPS_CONNECT_Click(null,null);
                    break;
                case Keys.D2:  //ALT +2  GPS �Ͽ�
                    ID_MENU_GPS_STOP_Click(null, null);
                    break;
                case Keys.D3:  //ALT +3  GPS ����
                    BTN_GPS_NAVG_Click(null, null);
                    break;
//VIDEO 
                case Keys.D4:  //ALT +4  ��Ƶ ����
                    BTN_VIDEO_SET_Click(null, null);
                    break;
                case Keys.D5:  //ALT +5 ��Ƶ �ɼ�
                    BTN_VIDEO_START_Click(null, null);
                    break;
                case Keys.D6:  //ALT +6 ��Ƶ ��ͣ�ɼ�
                    BTN_VIDEO_STOP_Click(null, null);
                    break;
                case Keys.D7:  //ALT +7  ��Ƶ ��ʾ�󴰿�
                    MENU_VEDIO_WINDOW_Click(null, null);
                    break;
                    
            }
        }


        #region unused
        //private void BTN_PT_ADD_Click(object sender, EventArgs e)
        //{
        //    if (this.m_POILayer == null) return;
        //    IEngineEditor editor = new EngineEditorClass();
        //    if (editor.EditState == esriEngineEditState.esriEngineStateNotEditing)
        //    {
        //        IDataset dataset = m_POILayer.FeatureClass as IDataset;
        //        editor.StartEditing(dataset.Workspace, this.axMapControl1.Map);
        //        ((IEngineEditLayers)editor).SetTargetLayer(m_POILayer,0);
        //    }
        //    IEngineEditTask editTask = editor.GetTaskByUniqueName("ControlToolsEditing_CreateNewFeatureTask");
        //    editor.CurrentTask = editTask;
        //    //ControlsEditingSketchAbsoluteXYCommand
        //    ICommand pCommand = new ControlsEditingSketchToolClass();
        //    pCommand.OnCreate(this.axMapControl1.Object); //axToolbarControlEdit
        //    pCommand.OnClick();
        //    //this.axMapControl1.MousePointer = esriControlsMousePointer.esriPointerCrosshair;

        //    m_CurToolSet = 11; //���õ�ǰ�Ĺ���
        //}
        //private void BTN_PT_EDIT_Click(object sender, EventArgs e)
        //{
        //    if (this.m_POILayer == null) return;
           
        //    //IFeatureLayer lyr = m_POILayer;// this.axMapControl1.get_Layer(0) as IFeatureLayer;
        //    //string strOIDName="FID";

        //    IEngineEditor editor = new EngineEditorClass();
        //    long strOIDValue=0;
        //    if (editor.EditState != esriEngineEditState.esriEngineStateNotEditing)  //�༭״̬
        //    {
        //        if (editor.SelectionCount >= 1)  //��ǰ��ѡ��Ķ���
        //        {
        //            IEnumFeature enumFeature = editor.EditSelection;
        //            enumFeature.Reset();
        //            IFeature selFeature = enumFeature.Next();
        //            strOIDValue = selFeature.OID;
        //        }
        //    }
        //    else
        //    {
        //        IDataset dataset = m_POILayer.FeatureClass as IDataset;
        //        editor.StartEditing( dataset.Workspace, this.axMapControl1.Map);
        //        ((IEngineEditLayers)editor).SetTargetLayer(m_POILayer, 0);
        //    }

        //    IEngineEditTask editTask = editor.GetTaskByUniqueName("ControlToolsEditing_ModifyFeatureTask");
        //    editor.CurrentTask = editTask;

        //    //m_InputAttrDlg = new Survey_InputAttrDlg(lyr, strOIDName, strOIDValue);
        //    m_InputAttrDlg.SetParams(m_POILayer, m_strOIDName, strOIDValue);
        //    if (m_InputAttrDlg.Visible) m_InputAttrDlg.Update();
        //    else m_InputAttrDlg.Show(this);  //Dialog
        //    //m_InputAttrDlg.ShowDialog(this);

        //    m_CurToolSet = 12; //���õ�ǰ�Ĺ���
        //}

        //private void BTN_PT_del_Click(object sender, EventArgs e)
        //{
        //    if (this.m_POILayer == null) return;
        //    IEngineEditor editor = new EngineEditorClass();
        //    if (editor.EditState == esriEngineEditState.esriEngineStateNotEditing)
        //    {
        //        IDataset dataset = m_POILayer.FeatureClass as IDataset;
        //        editor.StartEditing(dataset.Workspace, this.axMapControl1.Map);
                
        //    }
        //    IEngineEditTask editTask = editor.GetTaskByUniqueName("ControlToolsEditing_ModifyFeatureTask");
        //    editor.CurrentTask = editTask;
        //    this.axMapControl1.MousePointer = esriControlsMousePointer.esriPointerCrosshair;
        //    m_CurToolSet = 13; //���õ�ǰ�Ĺ���
        //}

        //private void BTN_LOC_ADD_Click(object sender, EventArgs e)
        //{

        //}

        //private void BTN_LOC_EDIT_Click(object sender, EventArgs e)
        //{

        //}

        //private void BTN_LOC_DEL_Click(object sender, EventArgs e)
        //{

        //}

        //private void BTN_PATH_ADD_Click(object sender, EventArgs e)
        //{

        //}

        //private void BTN_PATH_EDIT_Click(object sender, EventArgs e)
        //{

        //}

        //private void BTN_PATH_DEL_Click(object sender, EventArgs e)
        //{

        //}
        #endregion
 #region �༭��Ϣ��Ӧ����

        /// <summary>
        /// Event_s the on start editing method.
        /// �����༭��Ӧ����Ϣ��StartEditing ��δʹ�ã�
        /// </summary>
        private void Event_OnStartEditingMethod()
        {
            b_IsEditMode = true;

            //timersTimer.Enabled = true;
        }

        /// <summary>
        /// Event_s the on start editing method.
        /// �����༭��Ӧ����Ϣ��StopEditing ��δʹ�ã�
        /// </summary>
        private void Event_OnStopEditingMethod(bool isSave)
        {
            return;
            //Survey_RecordMng mng = new Survey_RecordMng();
            //IEngineEditLayers editor = new EngineEditorClass();
            //string mdbPath, tableName;
            //IFeatureLayer pLayer = editor.TargetLayer;
            //tableName = pLayer.Name;
            //mdbPath = GetPathByLayerName(tableName);

            //ExportYutuVectorData(mdbPath, pLayer);

            //if (b_IsMsgSaveEdit == false) timersTimer.Enabled = false;
            //b_IsMsgSaveEdit = false;

            //b_IsEditMode = false;
        }

        /// <summary>
        /// Event_s the on start editing method.
        /// �����༭��Ӧ����Ϣ��SavetEditing ��δʹ�ã�
        /// </summary>
        private void Event_OnSavetEditingMethod()
        {
            b_IsMsgSaveEdit = true;
        }

        /// <summary>
        /// Event_s the on start editing method.
        /// �����༭��Ӧ����Ϣ��VertexAdded ��δʹ�ã�
        /// </summary>
        private void Event_OnVertexAddedMethod(IPoint pt)
        {
            if(m_EngineEditor.CurrentTask.UniqueName=="ControlToolsEditing_CreateNewFeatureTask")
                b_IsAddVertex = true;
            else
                b_IsAddVertex = false;
        }

        /// <summary>
        /// Event_s the on start editing method.
        /// �����༭��Ӧ����Ϣ��StopOperation 
        /// </summary>
        private void Event_OnStopOperationMethod()
        {
            IEngineEditLayers EditLyr = new EngineEditorClass();
            if (EditLyr.TargetLayer.Name.ToUpper().Contains("GPS")) return;

            b_IsStopOperation = true;
            //MessageBox.Show("stop operation");
            return;
            if (b_IsAddVertex)
            {
                b_IsAddVertex = false;
                ICommand pCommand = new ControlsEditingAttributeCommandClass();
                pCommand.OnCreate(this.axToolbarControl1.Object);
                pCommand.OnClick();
            }
        }
        /// <summary>
        /// Event_s the on start editing method.
        /// �����༭��Ӧ����Ϣ��SelectionChanged 
        /// </summary>
        private void Event_OnSelectionChangedMethod()
        {
            //MessageBox.Show("SelectionChange");
            IEngineEditLayers EditLyr = new EngineEditorClass();
            if (EditLyr.TargetLayer.Name.ToUpper().Contains("GPS")) return;

            ManageDifferentLayerEdit();
        }

        /// <summary>
        /// Event_s the on start editing method.
        /// �����༭��Ӧ����Ϣ��StartOperation 
        /// </summary>
        private void Event_OnStartOperationMethod()
        {
            IEngineEditor editor = new EngineEditorClass();
            IMap map = editor.Map;
            IEngineEditLayers Elyr = editor as IEngineEditLayers;
            IFeatureLayer pLayer = Elyr.TargetLayer;
            IDataset m_Dataset = (IDataset)pLayer.FeatureClass;

            //�ر�EDIT
            if (editor.EditState != esriEngineEditState.esriEngineStateNotEditing)
            {
                editor.StopEditing(true);
                //����EDIT
                editor.StartEditing(m_Dataset.Workspace, map);
            }
        }
        
        //δʹ��
        public void StopEdit()
        {
            IEngineEditor editor = new EngineEditorClass();
            DialogResult result = MessageBox.Show("��Ҫ���浱ǰ�ı༭��", "����",
                         MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
            //DialogResult result = MessageBox.Show(this, "��Ҫ���浱ǰ�ı༭��", "����", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
            if (DialogResult.Yes == result)  //��Ҫ����
            {
                IEngineEditLayers Elyr = new EngineEditorClass();
                string mdbPath, tableName;
                IFeatureLayer pLayer = Elyr.TargetLayer;
                tableName = pLayer.Name;
                mdbPath = GetPathByLayerName(tableName);

                editor.StopEditing(true); //�ȱ��浽SHAPE
                ExportYutuVectorData(mdbPath, pLayer);
            }
            else if (DialogResult.No == result)
            {
                editor.StopEditing(false); //�����浽SHAPE
            }
            else if (DialogResult.Cancel == result)
                return;
        }
        //δʹ��
        public void SaveEdit()
        {
            IEngineEditor editor = new EngineEditorClass();
            if (editor.EditState == esriEngineEditState.esriEngineStateEditing && editor.HasEdits())
            {
                IMap EditMap = editor.Map;
                IEngineEditLayers Elyr = editor as IEngineEditLayers;
                string mdbPath, tableName;
                IFeatureLayer pLayer = Elyr.TargetLayer;
                tableName = pLayer.Name;
                mdbPath = GetPathByLayerName(tableName);

                //�������� 
                editor.StopEditing(true);
                ExportYutuVectorData(mdbPath, pLayer);

                //��������EDIT
                IDataset m_Dataset = (IDataset)pLayer.FeatureClass;
                //IWorkspaceEdit m_WorkspaceEdit = (IWorkspaceEdit)m_Dataset.Workspace;
                editor.StartEditing(m_Dataset.Workspace, EditMap);
            }
        }
#endregion        

#region 5����Ҫ�༭�Ĳ�

        /// <summary>
        /// 	<Description>��������Ӧ��Ϣ��BTN_CLS_POI_Click</Description>
        /// �༭POI ��
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void BTN_CLS_POI_Click(object sender, EventArgs e)
        {
            //int index = 0;
            bool rst = SetCurrentEditLayer(sender,0); //������Ӧ����
            //if (rst)
            //{
            //    m_CurToolSet = 100 + index; //���õ�ǰ�Ĺ���
            //    ToolStripButton btn = sender as ToolStripButton;
            //    btn.Checked = true;
            //}
        }

        /// <summary>
        /// 	<Description>��������Ӧ��Ϣ��BTN_CLS_NEWPOI_Click</Description>
        /// �༭ ��POI �㣨������
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void BTN_CLS_NEWPOI_Click(object sender, EventArgs e)
        {
            SetCurrentEditLayer(sender, 1);
        }

        /// <summary>
        /// 	<Description>��������Ӧ��Ϣ��BTN_CLS_PATH_Click</Description>
        /// �༭��· ��
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void BTN_CLS_PATH_Click(object sender, EventArgs e)
        {
            SetCurrentEditLayer(sender, 2);
        }

        /// <summary>
        /// 	<Description>��������Ӧ��Ϣ��BTN_CLS_BUILDINGS_Click</Description>
        /// �༭���� ��
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void BTN_CLS_BUILDINGS_Click(object sender, EventArgs e)
        {
            SetCurrentEditLayer(sender, 3);
        }

        /// <summary>
        /// 	<Description>��������Ӧ��Ϣ��BTN_CLS_BACKGROUND_Click</Description>
        /// �༭������
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void BTN_CLS_BACKGROUND_Click(object sender, EventArgs e)
        {
            SetCurrentEditLayer(sender, 4);
        }
#endregion

#endregion
        
#region ��׽  ��Щ������δʹ��
        public void InitializeSnapSelection()
        {
            IMovePointFeedback m_pMovePtFeed = new MovePointFeedback();   
            mFeedback = (IDisplayFeedback)m_pMovePtFeed;   
            ISimpleMarkerSymbol simpleMarkerSymbol = new SimpleMarkerSymbolClass();   
            IRgbColor pRGBColor = new RgbColorClass();   
            pRGBColor.Red = 255;   
            pRGBColor.Green = 0;   
            pRGBColor.Blue = 0;   
            simpleMarkerSymbol.Color = pRGBColor;   
            simpleMarkerSymbol.Size =5;   
            simpleMarkerSymbol.Style = ESRI.ArcGIS.Display.esriSimpleMarkerStyle.esriSMSSquare;   
            ISymbol symbol = simpleMarkerSymbol as ISymbol;   
            symbol.ROP2 = esriRasterOpCode.esriROPNotXOrPen;   
            //symbol.ROP2 = esriRasterOpCode.;   
            m_pMovePtFeed.Symbol = (ISymbol)simpleMarkerSymbol;

            IPoint tmpPoint = new PointClass();
            IMapControl2 pMap = this.axMapControl1.Object as IMapControl2;
            tmpPoint.PutCoords(pMap.Extent.XMin - 1, pMap.Extent.YMin - 1); 
            m_pMovePtFeed.Display = this.axMapControl1.ActiveView.ScreenDisplay;
            m_pMovePtFeed.Start(tmpPoint, tmpPoint);  

       }
        public void TrackMapSnapSelection(IFeatureLayer targetLayer,int x,int y)
        {
            IPoint pPoint2 = null;
            IMapControl2 pMap = this.axMapControl1.Object as IMapControl2;
            IPoint pPoint = pMap.ActiveView.ScreenDisplay.DisplayTransformation.ToMapPoint(x, y);
            pPoint2 = Snapping(pPoint.X, pPoint.Y, targetLayer, pMap, 20);
            if (pPoint2 == null)
                pPoint2 = pPoint;
            ((IMovePointFeedback)mFeedback).MoveTo(pPoint2);
        }
        public IPoint Snapping(double x, double y, IFeatureLayer iFeatureLyr, IMapControl2 axMapControl1,double snappingDis)  
 
        {   
            IPoint iHitPoint = null;   
            IMap iMap = axMapControl1.Map;   
            IActiveView iView = axMapControl1.ActiveView;   
            IFeatureClass iFClss = iFeatureLyr.FeatureClass;   
            IPoint point = new PointClass();   
            point.PutCoords(x, y);   
            double length = ConvertPixelsToMapUnits(axMapControl1.ActiveView, snappingDis);   
            ITopologicalOperator pTopo = point as ITopologicalOperator;   
            IGeometry pGeometry = pTopo.Buffer(length).Envelope as IGeometry;   
            ISpatialFilter spatialFilter = new SpatialFilterClass();   
            spatialFilter.GeometryField = iFeatureLyr.FeatureClass.ShapeFieldName;   
            spatialFilter.SpatialRel = esriSpatialRelEnum.esriSpatialRelIntersects;   
            spatialFilter.Geometry = pGeometry;   
            IFeatureCursor cursor = iFClss.Search(spatialFilter, false);   
            IFeature iF = cursor.NextFeature();   
            if (iF == null) return null;   
            IPoint iHitPt = new ESRI.ArcGIS.Geometry.Point();   
            IHitTest iHitTest = iF.Shape as IHitTest;   
            double hitDist = 0;   
            int partIndex = 0;   
            int vertexIndex = 0;   
            bool bVertexHit = false;   
            // Tolerance in pixels for line hits   
            double tol = ConvertPixelsToMapUnits(iView, snappingDis);   
            if (iHitTest.HitTest(point, tol, esriGeometryHitPartType.esriGeometryPartBoundary,   
                iHitPt, ref hitDist, ref partIndex, ref vertexIndex, ref bVertexHit))   
            {   
                iHitPoint = iHitPt;   
            }   
            //axMapControl1.ActiveView.Refresh();   
            return iHitPoint;   
        }   
        public double ConvertPixelsToMapUnits(IActiveView pActiveView, double pixelUnits)   
        {   
            double realWorldDisplayExtent;   
            int pixelExtent;   
            double sizeOfOnePixel;   
            pixelExtent = pActiveView.ScreenDisplay.DisplayTransformation.get_DeviceFrame().right - pActiveView.ScreenDisplay.DisplayTransformation.get_DeviceFrame().left;   
            realWorldDisplayExtent = pActiveView.ScreenDisplay.DisplayTransformation.VisibleBounds.Width;   
            sizeOfOnePixel = realWorldDisplayExtent / pixelExtent;   
            return pixelUnits * sizeOfOnePixel;   
        }
        public void RestartSnapSelection(IMapControl2 pMap)
        {
            //IPoint pPoint = ((IMovePointFeedback)mFeedback).Stop();  

            //���¿�ʼSnap   
            IPoint tmpPoint = new PointClass();
            tmpPoint.PutCoords(pMap.Extent.XMin - 1, pMap.Extent.YMin - 1);
            IMovePointFeedback m_pMovePtFeed = (IMovePointFeedback)mFeedback;
            m_pMovePtFeed.Display = pMap.ActiveView.ScreenDisplay;
            m_pMovePtFeed.Start(tmpPoint, tmpPoint);
        }
        public void SelectLayerByPT(IMapControl2 mapControl, int x, int y, int pixelTol)
        {
            IEngineEditLayers editor = new EngineEditorClass();
            IFeatureLayer lyr = editor.TargetLayer;
            IFeatureSelection pFeatureSelection = lyr as IFeatureSelection;

            ISpatialFilter spatialFilter = new SpatialFilterClass();
          
            //Transform the device rectangle into a geographic rectangle via the display transformation.  
            IEnvelope pEnvelope = new EnvelopeClass();
            //pEnvelope.XMin=


            spatialFilter.Geometry = pEnvelope;
            spatialFilter.GeometryField = lyr.FeatureClass.ShapeFieldName;
            spatialFilter.SpatialRel = esriSpatialRelEnum.esriSpatialRelIntersects;

            //pFeatureSelection.SelectFeatures(spatialFilter, esriSelectionResultEnum.esriSelectionResultNew, true);
            //pFeatureSelection.SelectFeatures(spatialFilter, esriSelectionResultEnum.esriSelectionResultAdd, false);
            //pFeatureSelection.SelectionChanged();
            IFeatureCursor featureCursor = lyr.FeatureClass.Search(spatialFilter, true);
            IFeature InFeature = featureCursor.NextFeature();
            pFeatureSelection.Clear();
            if (InFeature != null)
            {
                pFeatureSelection.Add(InFeature);
                //InFeature = featureCursor.NextFeature();
            }
            mapControl.ActiveView.PartialRefresh(esriViewDrawPhase.esriViewGeography, lyr, pEnvelope);
            //this.axMapControl1.Refresh();
        }
#endregion


        /// <summary>
        /// Axes the toolbar control edit_ on item click.
        /// ����༭������ʱ����Ҫ���� �Ƿ�ѡ���� ���༭�� ����
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The e.</param>
        private void axToolbarControlEdit_OnItemClick(object sender, IToolbarControlEvents_OnItemClickEvent e)
        {
            int index = e.index;
            //IToolbarItem item = this.axToolbarControlEdit.GetItem(index);
            m_CurEditItem = this.axToolbarControlEdit.GetItem(index);
            if (m_CurEditItem.Command == null) return;
            if (m_CurEditItem.Command.Name == "ControlToolsEditing_Edit")
            {
                m_bCurEditToolEdit = true;
                //TestSelection();
            }
            else if (m_CurEditItem.Command.Name == "ControlToolsEditing_Sketch")
            {
                m_bCurEditToolEdit = false;
            }
            return;
        }

        /// <summary>
        /// Deletes the selected feature.
        /// ɾ�������������û�ѡ����󲢰��� ALT+Dʱ������������Ϊ�༭״̬��һ��������ִ����Щ����
        /// �˴����ǽ����� ��������Ϊ1
        /// </summary>
        public void DeleteSelectedFeature()
        {
            if (m_CurToolSet < 100) return;

            IEngineEditor EngineEdit = new EngineEditorClass();
            long strOIDValue = 0;
            string strOIDName = "";
            
           //
            if (EngineEdit.SelectionCount >= 1)  //��ǰ��ѡ��Ķ���
            {
                IFeatureLayer lyr = (EngineEdit as IEngineEditLayers).TargetLayer;
                IEnumFeature enumFeature = EngineEdit.EditSelection;
                enumFeature.Reset();
                IFeature selFeature = enumFeature.Next();
                strOIDName = selFeature.Table.OIDFieldName;
                try
                {
                    while (selFeature != null)
                    {
                        strOIDValue = selFeature.OID;

                        try
                        {
                            IQueryFilter queryFilter = new QueryFilterClass();
                            queryFilter.WhereClause = strOIDName + " = " + strOIDValue.ToString();
                            // Create insert feature cursor using buffering.
                            IFeatureClass featureClass = ((IFeatureLayer)lyr).FeatureClass;
                            IFeatureCursor featureCursor = featureClass.Update(queryFilter, false);
                            IFeature feature = featureCursor.NextFeature();
                            if (feature != null)
                            {
                                int index = featureClass.FindField(Geometry_IO.Geometry_Attribute.m_strConstFieldChange);
                                //featureCursor.DeleteFeature(index,1); //���Ϊ1����ɾ���ü�¼
                                feature.set_Value(index, 1);
                                featureCursor.UpdateFeature(feature);
                                featureCursor.Flush();
                            }
                            
                        }
                        catch { }

                        selFeature = enumFeature.Next();
                    }
                }
                catch (Exception ex) { MessageBox.Show(ex.Message); }

                m_bEditLayer[m_CurToolSet-100] = true;
            }

        }

 


        /// <summary>
        /// 	<Description>�������ĵ� �� ��Ϣ��Ӧ����: MENU_HELP_DOCS_Click</Description>
        /// </summary>
        /// <param name="sender">��Ϣ��Դ������</param>
        /// <param name="e">���͵���Ϣ����</param>
        private void MENU_HELP_DOCS_Click(object sender, EventArgs e)
        {
            Process pro;
            ProcessStartInfo info = new ProcessStartInfo();
            info.FileName = System.Windows.Forms.Application.StartupPath + "\\Help.chm";
            try
            {
                pro = Process.Start(info);
            }
            catch (Win32Exception ex)
            {
                MessageBox.Show("δ�ܴ򿪰����ļ���\r\n" + ex.Message);
                return;
            }

            //pro.Kill();
        }

        /// <summary>
        /// 	<Description>�� �汾�͹�˾��Ϣ�� ��Ϣ��Ӧ����: MENU_HELP_ABOUT_Click</Description>
        /// </summary>
        /// <param name="sender">��Ϣ��Դ������</param>
        /// <param name="e">���͵���Ϣ����</param>
        private void MENU_HELP_ABOUT_Click(object sender, EventArgs e)
        {
            VersionDlg dlg = new VersionDlg(System.Windows.Forms.Application.StartupPath + "\\VersionLogo.JPG");
            dlg.ShowDialog();
        }


       

       

    }
}