namespace YuTuSurveyPlatform
{
    partial class MainInterface
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainInterface));
            this.MENU_FILE_NEW = new System.Windows.Forms.ToolStripMenuItem();
            this.MENU_FILE_0PEN = new System.Windows.Forms.ToolStripMenuItem();
            this.MENU_FILE_OPENIMAGE = new System.Windows.Forms.ToolStripMenuItem();
            this.MENU_FILE_VERCTOR = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.MENU_FILE_SAVE = new System.Windows.Forms.ToolStripMenuItem();
            this.MENU_FILE_SVAEAS = new System.Windows.Forms.ToolStripMenuItem();
            this.MENU_FILE_CLOSE = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.MENU_FILE_IMPORT = new System.Windows.Forms.ToolStripMenuItem();
            this.MENU_FILE_EXPORT = new System.Windows.Forms.ToolStripMenuItem();
            this.MENU_FILE_FORMATCON = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.MENU_FILE_PRINTSETTING = new System.Windows.Forms.ToolStripMenuItem();
            this.MENU_FILE_PREPRINT = new System.Windows.Forms.ToolStripMenuItem();
            this.MENU_FILE_PRINT = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.MENU_FILE_EXIT = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripLabel2 = new System.Windows.Forms.ToolStripLabel();
            this.comboBox_scalebox = new System.Windows.Forms.ToolStripComboBox();
            this.MessageLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.blank = new System.Windows.Forms.ToolStripStatusLabel();
            this.ScaleLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.CoordinatesLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.ID_MENU_FILE = new System.Windows.Forms.ToolStripMenuItem();
            this.ID_MENU_FILE_NEW = new System.Windows.Forms.ToolStripMenuItem();
            this.ID_MENU_FILE_OPEN = new System.Windows.Forms.ToolStripMenuItem();
            this.ID_MENU_FILE_SAVE = new System.Windows.Forms.ToolStripMenuItem();
            this.ID_MENU_FILE_SAVEAS = new System.Windows.Forms.ToolStripMenuItem();
            this.ID_MENU_FILE_CLOSE = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.ID_MENU_FILE_PRINTSET = new System.Windows.Forms.ToolStripMenuItem();
            this.ID_MENU_FILE_PRINTPRE = new System.Windows.Forms.ToolStripMenuItem();
            this.ID_MENU_FILE_PRINT = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
            this.ID_MENU_FILE_EXIT = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.ID_MENU_DATAMNG = new System.Windows.Forms.ToolStripMenuItem();
            this.ID_MENU_DATAMNG_IMG = new System.Windows.Forms.ToolStripMenuItem();
            this.ID_MENU_DATAMNG_SHP = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.ID_MENU_DATAMNG_YUT_IN = new System.Windows.Forms.ToolStripMenuItem();
            this.ID_MENU_DATAMNG_YUT_OUT = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator20 = new System.Windows.Forms.ToolStripSeparator();
            this.ID_MENU_DATAMNG_CONV = new System.Windows.Forms.ToolStripMenuItem();
            this.ID_MENU_DATAMNG_SYMBOL = new System.Windows.Forms.ToolStripMenuItem();
            this.MENU_EDIT = new System.Windows.Forms.ToolStripMenuItem();
            this.MENU_EDIT_PROPERTY = new System.Windows.Forms.ToolStripMenuItem();
            this.MENU_EDIT_GPS = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator11 = new System.Windows.Forms.ToolStripSeparator();
            this.MENU_EDIT_SEL_ALL = new System.Windows.Forms.ToolStripMenuItem();
            this.MENU_EDIT_SEL_INV = new System.Windows.Forms.ToolStripMenuItem();
            this.MENU_EDIT_SEL_RECT = new System.Windows.Forms.ToolStripMenuItem();
            this.MENU_EDIT_SEL_POLY = new System.Windows.Forms.ToolStripMenuItem();
            this.MENU_EDIT_SEL_CANCEL = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator12 = new System.Windows.Forms.ToolStripSeparator();
            this.MENU_EDIT_OBJ_MOVE = new System.Windows.Forms.ToolStripMenuItem();
            this.MENU_EDIT_OBJ_COPY = new System.Windows.Forms.ToolStripMenuItem();
            this.MENU_EDIT_OBJ_PASTE = new System.Windows.Forms.ToolStripMenuItem();
            this.MENU_EDIT_OBJ_DEL = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator9 = new System.Windows.Forms.ToolStripSeparator();
            this.MENU_EDIT_PT_SEL = new System.Windows.Forms.ToolStripMenuItem();
            this.MENU_EDIT_PT_DEL = new System.Windows.Forms.ToolStripMenuItem();
            this.MENU_EDIT_PT_MOVE = new System.Windows.Forms.ToolStripMenuItem();
            this.MENU_EDIT_PT_ADD = new System.Windows.Forms.ToolStripMenuItem();
            this.MENU_EDIT_PT_EDIT = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator16 = new System.Windows.Forms.ToolStripSeparator();
            this.ͼ��ѡ��ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ͼ��ɾ��ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ͼ������ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ͼ��༭ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.��ͼToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MENU_VIEW_GLOBAL = new System.Windows.Forms.ToolStripMenuItem();
            this.MENU_VIEW_ZOOMIN = new System.Windows.Forms.ToolStripMenuItem();
            this.MENU_VIEW_ZOOMOUT = new System.Windows.Forms.ToolStripMenuItem();
            this.MENU_VIEW_ZOOMRECT = new System.Windows.Forms.ToolStripMenuItem();
            this.MENU_VIEW_ZOOMEQUAL = new System.Windows.Forms.ToolStripMenuItem();
            this.MENU_VIEW_PAN = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator18 = new System.Windows.Forms.ToolStripSeparator();
            this.MENU_VIEW_SETSCALE = new System.Windows.Forms.ToolStripMenuItem();
            this.MENU_VIEW_SETPOINT = new System.Windows.Forms.ToolStripMenuItem();
            this.MENU_EDIT_SpacialSearch = new System.Windows.Forms.ToolStripMenuItem();
            this.MENU_EDIT_SpacialSearch_Identify = new System.Windows.Forms.ToolStripMenuItem();
            this.MENU_EDIT_SpacialSearch_Attributes = new System.Windows.Forms.ToolStripMenuItem();
            this.MENU_EDIT_SpacialSearch_Location = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator19 = new System.Windows.Forms.ToolStripSeparator();
            this.�������ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.��������ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.�ܳ�����ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gPS�豸ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ID_MENU_GPS_CONNECT = new System.Windows.Forms.ToolStripMenuItem();
            this.ID_MENU_GPS_STOP = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator13 = new System.Windows.Forms.ToolStripSeparator();
            this.MENU_GPS_SAVE = new System.Windows.Forms.ToolStripMenuItem();
            this.MENU_GPS_NAVG = new System.Windows.Forms.ToolStripMenuItem();
            this.MENU_GPS_NAVG_ON = new System.Windows.Forms.ToolStripMenuItem();
            this.MENU_GPS_NAVG_OFF = new System.Windows.Forms.ToolStripMenuItem();
            this.MENU_GPS_SigalSimu = new System.Windows.Forms.ToolStripMenuItem();
            this.MENU_GPS_SigalSimu_on = new System.Windows.Forms.ToolStripMenuItem();
            this.MENU_GPS_SigalSimu_off = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator14 = new System.Windows.Forms.ToolStripSeparator();
            this.MENU_GPS_SETTING = new System.Windows.Forms.ToolStripMenuItem();
            this.MENU_VEDIOl = new System.Windows.Forms.ToolStripMenuItem();
            this.MENU_VEDIO_SETTING = new System.Windows.Forms.ToolStripMenuItem();
            this.MENU_VEDIO_WINDOW = new System.Windows.Forms.ToolStripMenuItem();
            this.MENU_VEDIO_START = new System.Windows.Forms.ToolStripMenuItem();
            this.MENU_VEDIO_STOP = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator17 = new System.Windows.Forms.ToolStripSeparator();
            this.MENU_VEDIO_PICTURE = new System.Windows.Forms.ToolStripMenuItem();
            this.MENU_VEDIO_TIMESERIAL = new System.Windows.Forms.ToolStripMenuItem();
            this.MENU_VEDIO_TIMESERIAL_STOP = new System.Windows.Forms.ToolStripMenuItem();
            this.MENU_VEDIO_VEDIO = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator24 = new System.Windows.Forms.ToolStripSeparator();
            this.MENU_VEDIO_TIME_PRO = new System.Windows.Forms.ToolStripMenuItem();
            this.MENU_VEDIOr = new System.Windows.Forms.ToolStripMenuItem();
            this.MENU_VEDIOr_SETTING = new System.Windows.Forms.ToolStripMenuItem();
            this.MENU_VEDIOr_WINDOW = new System.Windows.Forms.ToolStripMenuItem();
            this.MENU_VEDIOr_START = new System.Windows.Forms.ToolStripMenuItem();
            this.MENU_VEDIOr_STOP = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator25 = new System.Windows.Forms.ToolStripSeparator();
            this.MENU_VEDIOr_CAPTURE = new System.Windows.Forms.ToolStripMenuItem();
            this.MENU_VEDIOr_SERIAL_S = new System.Windows.Forms.ToolStripMenuItem();
            this.MENU_VEDIOr_SERIAL_T = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator26 = new System.Windows.Forms.ToolStripSeparator();
            this.MENU_VEDIOr_VEDIO = new System.Windows.Forms.ToolStripMenuItem();
            this.ʱ���������ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MENU_GPS_SETTING2 = new System.Windows.Forms.ToolStripMenuItem();
            this.MENU_VEDIO_TIME_PRO2 = new System.Windows.Forms.ToolStripMenuItem();
            this.����ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.������Ϣ�趨ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.������Ϣ��ʾToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.ע����Ϣ����ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.���Թ���ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator10 = new System.Windows.Forms.ToolStripSeparator();
            this.ϵͳ����ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MENU_HELP = new System.Windows.Forms.ToolStripMenuItem();
            this.MENU_HELP_DOCS = new System.Windows.Forms.ToolStripMenuItem();
            this.MENU_HELP_ABOUT = new System.Windows.Forms.ToolStripMenuItem();
            this.BottomToolStripPanel = new System.Windows.Forms.ToolStripPanel();
            this.TopToolStripPanel = new System.Windows.Forms.ToolStripPanel();
            this.RightToolStripPanel = new System.Windows.Forms.ToolStripPanel();
            this.LeftToolStripPanel = new System.Windows.Forms.ToolStripPanel();
            this.ContentPanel = new System.Windows.Forms.ToolStripContentPanel();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.BTN_SAVE_YUTU = new System.Windows.Forms.ToolStripButton();
            this.BTN_TOOL_IDLE = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator22 = new System.Windows.Forms.ToolStripSeparator();
            this.BTN_CLS_POI = new System.Windows.Forms.ToolStripButton();
            this.BTN_CLS_NEWPOI = new System.Windows.Forms.ToolStripButton();
            this.BTN_CLS_PATH = new System.Windows.Forms.ToolStripButton();
            this.BTN_CLS_BUILDINGS = new System.Windows.Forms.ToolStripButton();
            this.BTN_CLS_BACKGROUND = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator23 = new System.Windows.Forms.ToolStripSeparator();
            this.BTN_GPS_ON = new System.Windows.Forms.ToolStripButton();
            this.BTN_GPS_OFF = new System.Windows.Forms.ToolStripButton();
            this.BTN_GPS_NAVG = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator15 = new System.Windows.Forms.ToolStripSeparator();
            this.BTN_VIDEO_SET = new System.Windows.Forms.ToolStripButton();
            this.BTN_VIDEO_START = new System.Windows.Forms.ToolStripButton();
            this.BTN_VIDEO_STOP = new System.Windows.Forms.ToolStripButton();
            this.BTN_VIDEO_WINDOW = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator21 = new System.Windows.Forms.ToolStripSeparator();
            this.BTN_PATH_EDIT = new System.Windows.Forms.ToolStripButton();
            this.BTN_PATH_DEL = new System.Windows.Forms.ToolStripButton();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPageLayer = new System.Windows.Forms.TabPage();
            this.axTOCControl1 = new ESRI.ArcGIS.Controls.AxTOCControl();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPageMap = new System.Windows.Forms.TabPage();
            this.axToolbarControlEdit = new ESRI.ArcGIS.Controls.AxToolbarControl();
            this.axMapControl1 = new ESRI.ArcGIS.Controls.AxMapControl();
            this.axLicenseControl1 = new ESRI.ArcGIS.Controls.AxLicenseControl();
            this.axToolbarControl1 = new ESRI.ArcGIS.Controls.AxToolbarControl();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.statusStrip1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPageLayer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.axTOCControl1)).BeginInit();
            this.tabControl2.SuspendLayout();
            this.tabPageMap.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.axToolbarControlEdit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axMapControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axLicenseControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axToolbarControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // MENU_FILE_NEW
            // 
            this.MENU_FILE_NEW.Name = "MENU_FILE_NEW";
            this.MENU_FILE_NEW.Size = new System.Drawing.Size(142, 22);
            this.MENU_FILE_NEW.Text = "�½��ĵ�";
            // 
            // MENU_FILE_0PEN
            // 
            this.MENU_FILE_0PEN.Name = "MENU_FILE_0PEN";
            this.MENU_FILE_0PEN.Size = new System.Drawing.Size(142, 22);
            this.MENU_FILE_0PEN.Text = "���ĵ�";
            // 
            // MENU_FILE_OPENIMAGE
            // 
            this.MENU_FILE_OPENIMAGE.Name = "MENU_FILE_OPENIMAGE";
            this.MENU_FILE_OPENIMAGE.Size = new System.Drawing.Size(142, 22);
            this.MENU_FILE_OPENIMAGE.Text = "����Ӱ��";
            // 
            // MENU_FILE_VERCTOR
            // 
            this.MENU_FILE_VERCTOR.Name = "MENU_FILE_VERCTOR";
            this.MENU_FILE_VERCTOR.Size = new System.Drawing.Size(142, 22);
            this.MENU_FILE_VERCTOR.Text = "����ʸ��";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(139, 6);
            // 
            // MENU_FILE_SAVE
            // 
            this.MENU_FILE_SAVE.Name = "MENU_FILE_SAVE";
            this.MENU_FILE_SAVE.Size = new System.Drawing.Size(142, 22);
            this.MENU_FILE_SAVE.Text = "����";
            // 
            // MENU_FILE_SVAEAS
            // 
            this.MENU_FILE_SVAEAS.Name = "MENU_FILE_SVAEAS";
            this.MENU_FILE_SVAEAS.Size = new System.Drawing.Size(142, 22);
            this.MENU_FILE_SVAEAS.Text = "����Ϊ";
            // 
            // MENU_FILE_CLOSE
            // 
            this.MENU_FILE_CLOSE.Name = "MENU_FILE_CLOSE";
            this.MENU_FILE_CLOSE.Size = new System.Drawing.Size(142, 22);
            this.MENU_FILE_CLOSE.Text = "�ر�";
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(139, 6);
            // 
            // MENU_FILE_IMPORT
            // 
            this.MENU_FILE_IMPORT.Name = "MENU_FILE_IMPORT";
            this.MENU_FILE_IMPORT.Size = new System.Drawing.Size(142, 22);
            this.MENU_FILE_IMPORT.Text = "����";
            this.MENU_FILE_IMPORT.Visible = false;
            // 
            // MENU_FILE_EXPORT
            // 
            this.MENU_FILE_EXPORT.Name = "MENU_FILE_EXPORT";
            this.MENU_FILE_EXPORT.Size = new System.Drawing.Size(142, 22);
            this.MENU_FILE_EXPORT.Text = "����";
            // 
            // MENU_FILE_FORMATCON
            // 
            this.MENU_FILE_FORMATCON.Name = "MENU_FILE_FORMATCON";
            this.MENU_FILE_FORMATCON.Size = new System.Drawing.Size(142, 22);
            this.MENU_FILE_FORMATCON.Text = "Ӱ���ʽת��";
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(139, 6);
            // 
            // MENU_FILE_PRINTSETTING
            // 
            this.MENU_FILE_PRINTSETTING.Name = "MENU_FILE_PRINTSETTING";
            this.MENU_FILE_PRINTSETTING.Size = new System.Drawing.Size(142, 22);
            this.MENU_FILE_PRINTSETTING.Text = "��ӡ����";
            // 
            // MENU_FILE_PREPRINT
            // 
            this.MENU_FILE_PREPRINT.Name = "MENU_FILE_PREPRINT";
            this.MENU_FILE_PREPRINT.Size = new System.Drawing.Size(142, 22);
            this.MENU_FILE_PREPRINT.Text = "��ӡԤ��";
            this.MENU_FILE_PREPRINT.Visible = false;
            // 
            // MENU_FILE_PRINT
            // 
            this.MENU_FILE_PRINT.Name = "MENU_FILE_PRINT";
            this.MENU_FILE_PRINT.Size = new System.Drawing.Size(142, 22);
            this.MENU_FILE_PRINT.Text = "��ӡ";
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(139, 6);
            // 
            // MENU_FILE_EXIT
            // 
            this.MENU_FILE_EXIT.Name = "MENU_FILE_EXIT";
            this.MENU_FILE_EXIT.Size = new System.Drawing.Size(142, 22);
            this.MENU_FILE_EXIT.Text = "�˳�";
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripLabel2,
            this.comboBox_scalebox,
            this.MessageLabel,
            this.blank,
            this.ScaleLabel,
            this.CoordinatesLabel});
            this.statusStrip1.Location = new System.Drawing.Point(0, 544);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(792, 22);
            this.statusStrip1.TabIndex = 1;
            this.statusStrip1.Text = "����";
            // 
            // toolStripLabel2
            // 
            this.toolStripLabel2.Name = "toolStripLabel2";
            this.toolStripLabel2.Size = new System.Drawing.Size(41, 20);
            this.toolStripLabel2.Text = "������";
            // 
            // comboBox_scalebox
            // 
            this.comboBox_scalebox.Name = "comboBox_scalebox";
            this.comboBox_scalebox.Size = new System.Drawing.Size(121, 22);
            // 
            // MessageLabel
            // 
            this.MessageLabel.Name = "MessageLabel";
            this.MessageLabel.Size = new System.Drawing.Size(29, 17);
            this.MessageLabel.Text = "����";
            // 
            // blank
            // 
            this.blank.Name = "blank";
            this.blank.Size = new System.Drawing.Size(490, 17);
            this.blank.Spring = true;
            // 
            // ScaleLabel
            // 
            this.ScaleLabel.Name = "ScaleLabel";
            this.ScaleLabel.Size = new System.Drawing.Size(41, 17);
            this.ScaleLabel.Text = "������";
            // 
            // CoordinatesLabel
            // 
            this.CoordinatesLabel.Name = "CoordinatesLabel";
            this.CoordinatesLabel.Size = new System.Drawing.Size(53, 17);
            this.CoordinatesLabel.Text = "��ǰ����";
            // 
            // ID_MENU_FILE
            // 
            this.ID_MENU_FILE.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ID_MENU_FILE_NEW,
            this.ID_MENU_FILE_OPEN,
            this.ID_MENU_FILE_SAVE,
            this.ID_MENU_FILE_SAVEAS,
            this.ID_MENU_FILE_CLOSE,
            this.toolStripSeparator5,
            this.ID_MENU_FILE_PRINTSET,
            this.ID_MENU_FILE_PRINTPRE,
            this.ID_MENU_FILE_PRINT,
            this.toolStripSeparator8,
            this.ID_MENU_FILE_EXIT});
            this.ID_MENU_FILE.Name = "ID_MENU_FILE";
            this.ID_MENU_FILE.Size = new System.Drawing.Size(41, 20);
            this.ID_MENU_FILE.Text = "�ļ�";
            // 
            // ID_MENU_FILE_NEW
            // 
            this.ID_MENU_FILE_NEW.Name = "ID_MENU_FILE_NEW";
            this.ID_MENU_FILE_NEW.Size = new System.Drawing.Size(142, 22);
            this.ID_MENU_FILE_NEW.Text = "�½������ļ�";
            this.ID_MENU_FILE_NEW.Click += new System.EventHandler(this.ID_MENU_FILE_NEW_Click);
            // 
            // ID_MENU_FILE_OPEN
            // 
            this.ID_MENU_FILE_OPEN.Name = "ID_MENU_FILE_OPEN";
            this.ID_MENU_FILE_OPEN.Size = new System.Drawing.Size(142, 22);
            this.ID_MENU_FILE_OPEN.Text = "�򿪹����ļ�";
            this.ID_MENU_FILE_OPEN.Click += new System.EventHandler(this.ID_MENU_FILE_OPEN_Click);
            // 
            // ID_MENU_FILE_SAVE
            // 
            this.ID_MENU_FILE_SAVE.Name = "ID_MENU_FILE_SAVE";
            this.ID_MENU_FILE_SAVE.Size = new System.Drawing.Size(142, 22);
            this.ID_MENU_FILE_SAVE.Text = "���湤���ļ�";
            this.ID_MENU_FILE_SAVE.Click += new System.EventHandler(this.ID_MENU_FILE_SAVE_Click);
            // 
            // ID_MENU_FILE_SAVEAS
            // 
            this.ID_MENU_FILE_SAVEAS.Name = "ID_MENU_FILE_SAVEAS";
            this.ID_MENU_FILE_SAVEAS.Size = new System.Drawing.Size(142, 22);
            this.ID_MENU_FILE_SAVEAS.Text = "���湤���ļ�";
            this.ID_MENU_FILE_SAVEAS.Click += new System.EventHandler(this.ID_MENU_FILE_SAVEAS_Click);
            // 
            // ID_MENU_FILE_CLOSE
            // 
            this.ID_MENU_FILE_CLOSE.Name = "ID_MENU_FILE_CLOSE";
            this.ID_MENU_FILE_CLOSE.Size = new System.Drawing.Size(142, 22);
            this.ID_MENU_FILE_CLOSE.Text = "�رչ����ļ�";
            this.ID_MENU_FILE_CLOSE.Click += new System.EventHandler(this.ID_MENU_FILE_CLOSE_Click);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(139, 6);
            // 
            // ID_MENU_FILE_PRINTSET
            // 
            this.ID_MENU_FILE_PRINTSET.Name = "ID_MENU_FILE_PRINTSET";
            this.ID_MENU_FILE_PRINTSET.Size = new System.Drawing.Size(142, 22);
            this.ID_MENU_FILE_PRINTSET.Text = "��ӡ����";
            this.ID_MENU_FILE_PRINTSET.Visible = false;
            // 
            // ID_MENU_FILE_PRINTPRE
            // 
            this.ID_MENU_FILE_PRINTPRE.Name = "ID_MENU_FILE_PRINTPRE";
            this.ID_MENU_FILE_PRINTPRE.Size = new System.Drawing.Size(142, 22);
            this.ID_MENU_FILE_PRINTPRE.Text = "��ӡԤ��";
            this.ID_MENU_FILE_PRINTPRE.Visible = false;
            // 
            // ID_MENU_FILE_PRINT
            // 
            this.ID_MENU_FILE_PRINT.Name = "ID_MENU_FILE_PRINT";
            this.ID_MENU_FILE_PRINT.Size = new System.Drawing.Size(142, 22);
            this.ID_MENU_FILE_PRINT.Text = "��ӡ";
            this.ID_MENU_FILE_PRINT.Visible = false;
            // 
            // toolStripSeparator8
            // 
            this.toolStripSeparator8.Name = "toolStripSeparator8";
            this.toolStripSeparator8.Size = new System.Drawing.Size(139, 6);
            this.toolStripSeparator8.Visible = false;
            // 
            // ID_MENU_FILE_EXIT
            // 
            this.ID_MENU_FILE_EXIT.Name = "ID_MENU_FILE_EXIT";
            this.ID_MENU_FILE_EXIT.Size = new System.Drawing.Size(142, 22);
            this.ID_MENU_FILE_EXIT.Text = "�˳�";
            this.ID_MENU_FILE_EXIT.Click += new System.EventHandler(this.ID_MENU_FILE_EXIT_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ID_MENU_FILE,
            this.ID_MENU_DATAMNG,
            this.MENU_EDIT,
            this.��ͼToolStripMenuItem,
            this.MENU_EDIT_SpacialSearch,
            this.gPS�豸ToolStripMenuItem,
            this.MENU_VEDIOl,
            this.MENU_VEDIOr,
            this.ʱ���������ToolStripMenuItem,
            this.����ToolStripMenuItem,
            this.MENU_HELP});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(792, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // ID_MENU_DATAMNG
            // 
            this.ID_MENU_DATAMNG.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ID_MENU_DATAMNG_IMG,
            this.ID_MENU_DATAMNG_SHP,
            this.toolStripSeparator7,
            this.ID_MENU_DATAMNG_YUT_IN,
            this.ID_MENU_DATAMNG_YUT_OUT,
            this.toolStripSeparator20,
            this.ID_MENU_DATAMNG_CONV,
            this.ID_MENU_DATAMNG_SYMBOL});
            this.ID_MENU_DATAMNG.Name = "ID_MENU_DATAMNG";
            this.ID_MENU_DATAMNG.Size = new System.Drawing.Size(65, 20);
            this.ID_MENU_DATAMNG.Text = "���ݹ���";
            // 
            // ID_MENU_DATAMNG_IMG
            // 
            this.ID_MENU_DATAMNG_IMG.Name = "ID_MENU_DATAMNG_IMG";
            this.ID_MENU_DATAMNG_IMG.Size = new System.Drawing.Size(178, 22);
            this.ID_MENU_DATAMNG_IMG.Text = "���ؼ���Ӱ��";
            this.ID_MENU_DATAMNG_IMG.Click += new System.EventHandler(this.ID_MENU_DATAMNG_IMG_Click);
            // 
            // ID_MENU_DATAMNG_SHP
            // 
            this.ID_MENU_DATAMNG_SHP.Name = "ID_MENU_DATAMNG_SHP";
            this.ID_MENU_DATAMNG_SHP.Size = new System.Drawing.Size(178, 22);
            this.ID_MENU_DATAMNG_SHP.Text = "���ؼ���ʸ��";
            this.ID_MENU_DATAMNG_SHP.Click += new System.EventHandler(this.ID_MENU_DATAMNG_SHP_Click);
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(175, 6);
            // 
            // ID_MENU_DATAMNG_YUT_IN
            // 
            this.ID_MENU_DATAMNG_YUT_IN.Name = "ID_MENU_DATAMNG_YUT_IN";
            this.ID_MENU_DATAMNG_YUT_IN.Size = new System.Drawing.Size(178, 22);
            this.ID_MENU_DATAMNG_YUT_IN.Text = "����Yvt����";
            this.ID_MENU_DATAMNG_YUT_IN.Click += new System.EventHandler(this.ID_MENU_DATAMNG_YUT_IN_Click);
            // 
            // ID_MENU_DATAMNG_YUT_OUT
            // 
            this.ID_MENU_DATAMNG_YUT_OUT.Name = "ID_MENU_DATAMNG_YUT_OUT";
            this.ID_MENU_DATAMNG_YUT_OUT.Size = new System.Drawing.Size(178, 22);
            this.ID_MENU_DATAMNG_YUT_OUT.Text = "����Yvt����(����)";
            this.ID_MENU_DATAMNG_YUT_OUT.Click += new System.EventHandler(this.ID_MENU_DATAMNG_YUT_OUT_Click);
            // 
            // toolStripSeparator20
            // 
            this.toolStripSeparator20.Name = "toolStripSeparator20";
            this.toolStripSeparator20.Size = new System.Drawing.Size(175, 6);
            this.toolStripSeparator20.Visible = false;
            // 
            // ID_MENU_DATAMNG_CONV
            // 
            this.ID_MENU_DATAMNG_CONV.Name = "ID_MENU_DATAMNG_CONV";
            this.ID_MENU_DATAMNG_CONV.Size = new System.Drawing.Size(178, 22);
            this.ID_MENU_DATAMNG_CONV.Text = "Ӱ���ʽת��";
            this.ID_MENU_DATAMNG_CONV.Visible = false;
            // 
            // ID_MENU_DATAMNG_SYMBOL
            // 
            this.ID_MENU_DATAMNG_SYMBOL.Name = "ID_MENU_DATAMNG_SYMBOL";
            this.ID_MENU_DATAMNG_SYMBOL.Size = new System.Drawing.Size(178, 22);
            this.ID_MENU_DATAMNG_SYMBOL.Text = "ͼ����Ź���(����)";
            this.ID_MENU_DATAMNG_SYMBOL.Visible = false;
            // 
            // MENU_EDIT
            // 
            this.MENU_EDIT.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MENU_EDIT_PROPERTY,
            this.MENU_EDIT_GPS,
            this.toolStripSeparator11,
            this.MENU_EDIT_SEL_ALL,
            this.MENU_EDIT_SEL_INV,
            this.MENU_EDIT_SEL_RECT,
            this.MENU_EDIT_SEL_POLY,
            this.MENU_EDIT_SEL_CANCEL,
            this.toolStripSeparator12,
            this.MENU_EDIT_OBJ_MOVE,
            this.MENU_EDIT_OBJ_COPY,
            this.MENU_EDIT_OBJ_PASTE,
            this.MENU_EDIT_OBJ_DEL,
            this.toolStripSeparator9,
            this.MENU_EDIT_PT_SEL,
            this.MENU_EDIT_PT_DEL,
            this.MENU_EDIT_PT_MOVE,
            this.MENU_EDIT_PT_ADD,
            this.MENU_EDIT_PT_EDIT,
            this.toolStripSeparator16,
            this.ͼ��ѡ��ToolStripMenuItem,
            this.ͼ��ɾ��ToolStripMenuItem,
            this.ͼ������ToolStripMenuItem,
            this.ͼ��༭ToolStripMenuItem});
            this.MENU_EDIT.Name = "MENU_EDIT";
            this.MENU_EDIT.Size = new System.Drawing.Size(65, 20);
            this.MENU_EDIT.Text = "���ݱ༭";
            this.MENU_EDIT.Visible = false;
            // 
            // MENU_EDIT_PROPERTY
            // 
            this.MENU_EDIT_PROPERTY.Name = "MENU_EDIT_PROPERTY";
            this.MENU_EDIT_PROPERTY.Size = new System.Drawing.Size(142, 22);
            this.MENU_EDIT_PROPERTY.Text = "�������Ա༭";
            // 
            // MENU_EDIT_GPS
            // 
            this.MENU_EDIT_GPS.Name = "MENU_EDIT_GPS";
            this.MENU_EDIT_GPS.Size = new System.Drawing.Size(142, 22);
            this.MENU_EDIT_GPS.Text = "GPS�㵼��";
            // 
            // toolStripSeparator11
            // 
            this.toolStripSeparator11.Name = "toolStripSeparator11";
            this.toolStripSeparator11.Size = new System.Drawing.Size(139, 6);
            // 
            // MENU_EDIT_SEL_ALL
            // 
            this.MENU_EDIT_SEL_ALL.Name = "MENU_EDIT_SEL_ALL";
            this.MENU_EDIT_SEL_ALL.Size = new System.Drawing.Size(142, 22);
            this.MENU_EDIT_SEL_ALL.Text = "ѡȡ����";
            // 
            // MENU_EDIT_SEL_INV
            // 
            this.MENU_EDIT_SEL_INV.Name = "MENU_EDIT_SEL_INV";
            this.MENU_EDIT_SEL_INV.Size = new System.Drawing.Size(142, 22);
            this.MENU_EDIT_SEL_INV.Text = "����ѡȡ";
            // 
            // MENU_EDIT_SEL_RECT
            // 
            this.MENU_EDIT_SEL_RECT.Name = "MENU_EDIT_SEL_RECT";
            this.MENU_EDIT_SEL_RECT.Size = new System.Drawing.Size(142, 22);
            this.MENU_EDIT_SEL_RECT.Text = "����ѡȡ";
            // 
            // MENU_EDIT_SEL_POLY
            // 
            this.MENU_EDIT_SEL_POLY.Name = "MENU_EDIT_SEL_POLY";
            this.MENU_EDIT_SEL_POLY.Size = new System.Drawing.Size(142, 22);
            this.MENU_EDIT_SEL_POLY.Text = "�����ѡȡ";
            // 
            // MENU_EDIT_SEL_CANCEL
            // 
            this.MENU_EDIT_SEL_CANCEL.Name = "MENU_EDIT_SEL_CANCEL";
            this.MENU_EDIT_SEL_CANCEL.Size = new System.Drawing.Size(142, 22);
            this.MENU_EDIT_SEL_CANCEL.Text = "ȡ��ѡȡ";
            // 
            // toolStripSeparator12
            // 
            this.toolStripSeparator12.Name = "toolStripSeparator12";
            this.toolStripSeparator12.Size = new System.Drawing.Size(139, 6);
            // 
            // MENU_EDIT_OBJ_MOVE
            // 
            this.MENU_EDIT_OBJ_MOVE.Name = "MENU_EDIT_OBJ_MOVE";
            this.MENU_EDIT_OBJ_MOVE.Size = new System.Drawing.Size(142, 22);
            this.MENU_EDIT_OBJ_MOVE.Text = "�ƶ���ѡ����";
            // 
            // MENU_EDIT_OBJ_COPY
            // 
            this.MENU_EDIT_OBJ_COPY.Name = "MENU_EDIT_OBJ_COPY";
            this.MENU_EDIT_OBJ_COPY.Size = new System.Drawing.Size(142, 22);
            this.MENU_EDIT_OBJ_COPY.Text = "���Ʊ�ѡ����";
            // 
            // MENU_EDIT_OBJ_PASTE
            // 
            this.MENU_EDIT_OBJ_PASTE.Name = "MENU_EDIT_OBJ_PASTE";
            this.MENU_EDIT_OBJ_PASTE.Size = new System.Drawing.Size(142, 22);
            this.MENU_EDIT_OBJ_PASTE.Text = "ճ����ѡ����";
            // 
            // MENU_EDIT_OBJ_DEL
            // 
            this.MENU_EDIT_OBJ_DEL.Name = "MENU_EDIT_OBJ_DEL";
            this.MENU_EDIT_OBJ_DEL.Size = new System.Drawing.Size(142, 22);
            this.MENU_EDIT_OBJ_DEL.Text = "ɾ����ѡ����";
            // 
            // toolStripSeparator9
            // 
            this.toolStripSeparator9.Name = "toolStripSeparator9";
            this.toolStripSeparator9.Size = new System.Drawing.Size(139, 6);
            // 
            // MENU_EDIT_PT_SEL
            // 
            this.MENU_EDIT_PT_SEL.Name = "MENU_EDIT_PT_SEL";
            this.MENU_EDIT_PT_SEL.Size = new System.Drawing.Size(142, 22);
            this.MENU_EDIT_PT_SEL.Text = "��ѡ��";
            // 
            // MENU_EDIT_PT_DEL
            // 
            this.MENU_EDIT_PT_DEL.Name = "MENU_EDIT_PT_DEL";
            this.MENU_EDIT_PT_DEL.Size = new System.Drawing.Size(142, 22);
            this.MENU_EDIT_PT_DEL.Text = "��ɾ��";
            // 
            // MENU_EDIT_PT_MOVE
            // 
            this.MENU_EDIT_PT_MOVE.Name = "MENU_EDIT_PT_MOVE";
            this.MENU_EDIT_PT_MOVE.Size = new System.Drawing.Size(142, 22);
            this.MENU_EDIT_PT_MOVE.Text = "���ƶ�";
            // 
            // MENU_EDIT_PT_ADD
            // 
            this.MENU_EDIT_PT_ADD.Name = "MENU_EDIT_PT_ADD";
            this.MENU_EDIT_PT_ADD.Size = new System.Drawing.Size(142, 22);
            this.MENU_EDIT_PT_ADD.Text = "������";
            // 
            // MENU_EDIT_PT_EDIT
            // 
            this.MENU_EDIT_PT_EDIT.Name = "MENU_EDIT_PT_EDIT";
            this.MENU_EDIT_PT_EDIT.Size = new System.Drawing.Size(142, 22);
            this.MENU_EDIT_PT_EDIT.Text = "��༭";
            // 
            // toolStripSeparator16
            // 
            this.toolStripSeparator16.Name = "toolStripSeparator16";
            this.toolStripSeparator16.Size = new System.Drawing.Size(139, 6);
            // 
            // ͼ��ѡ��ToolStripMenuItem
            // 
            this.ͼ��ѡ��ToolStripMenuItem.Name = "ͼ��ѡ��ToolStripMenuItem";
            this.ͼ��ѡ��ToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
            this.ͼ��ѡ��ToolStripMenuItem.Text = "ͼ��ѡ��";
            // 
            // ͼ��ɾ��ToolStripMenuItem
            // 
            this.ͼ��ɾ��ToolStripMenuItem.Name = "ͼ��ɾ��ToolStripMenuItem";
            this.ͼ��ɾ��ToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
            this.ͼ��ɾ��ToolStripMenuItem.Text = "ͼ��ɾ��";
            // 
            // ͼ������ToolStripMenuItem
            // 
            this.ͼ������ToolStripMenuItem.Name = "ͼ������ToolStripMenuItem";
            this.ͼ������ToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
            this.ͼ������ToolStripMenuItem.Text = "ͼ������";
            // 
            // ͼ��༭ToolStripMenuItem
            // 
            this.ͼ��༭ToolStripMenuItem.Name = "ͼ��༭ToolStripMenuItem";
            this.ͼ��༭ToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
            this.ͼ��༭ToolStripMenuItem.Text = "ͼ��༭";
            // 
            // ��ͼToolStripMenuItem
            // 
            this.��ͼToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MENU_VIEW_GLOBAL,
            this.MENU_VIEW_ZOOMIN,
            this.MENU_VIEW_ZOOMOUT,
            this.MENU_VIEW_ZOOMRECT,
            this.MENU_VIEW_ZOOMEQUAL,
            this.MENU_VIEW_PAN,
            this.toolStripSeparator18,
            this.MENU_VIEW_SETSCALE,
            this.MENU_VIEW_SETPOINT});
            this.��ͼToolStripMenuItem.Name = "��ͼToolStripMenuItem";
            this.��ͼToolStripMenuItem.Size = new System.Drawing.Size(41, 20);
            this.��ͼToolStripMenuItem.Text = "��ͼ";
            // 
            // MENU_VIEW_GLOBAL
            // 
            this.MENU_VIEW_GLOBAL.Name = "MENU_VIEW_GLOBAL";
            this.MENU_VIEW_GLOBAL.Size = new System.Drawing.Size(142, 22);
            this.MENU_VIEW_GLOBAL.Text = "ȫͼ��ʾ";
            this.MENU_VIEW_GLOBAL.Click += new System.EventHandler(this.MENU_VIEW_GLOBAL_Click);
            // 
            // MENU_VIEW_ZOOMIN
            // 
            this.MENU_VIEW_ZOOMIN.Name = "MENU_VIEW_ZOOMIN";
            this.MENU_VIEW_ZOOMIN.Size = new System.Drawing.Size(142, 22);
            this.MENU_VIEW_ZOOMIN.Text = "�����Ŵ�";
            this.MENU_VIEW_ZOOMIN.Click += new System.EventHandler(this.MENU_VIEW_ZOOMIN_Click);
            // 
            // MENU_VIEW_ZOOMOUT
            // 
            this.MENU_VIEW_ZOOMOUT.Name = "MENU_VIEW_ZOOMOUT";
            this.MENU_VIEW_ZOOMOUT.Size = new System.Drawing.Size(142, 22);
            this.MENU_VIEW_ZOOMOUT.Text = "������С";
            this.MENU_VIEW_ZOOMOUT.Click += new System.EventHandler(this.MENU_VIEW_ZOOMOUT_Click);
            // 
            // MENU_VIEW_ZOOMRECT
            // 
            this.MENU_VIEW_ZOOMRECT.Name = "MENU_VIEW_ZOOMRECT";
            this.MENU_VIEW_ZOOMRECT.Size = new System.Drawing.Size(142, 22);
            this.MENU_VIEW_ZOOMRECT.Text = "�����Ŵ�";
            this.MENU_VIEW_ZOOMRECT.Visible = false;
            // 
            // MENU_VIEW_ZOOMEQUAL
            // 
            this.MENU_VIEW_ZOOMEQUAL.Name = "MENU_VIEW_ZOOMEQUAL";
            this.MENU_VIEW_ZOOMEQUAL.Size = new System.Drawing.Size(142, 22);
            this.MENU_VIEW_ZOOMEQUAL.Text = "1��1��ʾ";
            this.MENU_VIEW_ZOOMEQUAL.Visible = false;
            // 
            // MENU_VIEW_PAN
            // 
            this.MENU_VIEW_PAN.Name = "MENU_VIEW_PAN";
            this.MENU_VIEW_PAN.Size = new System.Drawing.Size(142, 22);
            this.MENU_VIEW_PAN.Text = "����";
            this.MENU_VIEW_PAN.Click += new System.EventHandler(this.MENU_VIEW_PAN_Click);
            // 
            // toolStripSeparator18
            // 
            this.toolStripSeparator18.Name = "toolStripSeparator18";
            this.toolStripSeparator18.Size = new System.Drawing.Size(139, 6);
            this.toolStripSeparator18.Visible = false;
            // 
            // MENU_VIEW_SETSCALE
            // 
            this.MENU_VIEW_SETSCALE.Name = "MENU_VIEW_SETSCALE";
            this.MENU_VIEW_SETSCALE.Size = new System.Drawing.Size(142, 22);
            this.MENU_VIEW_SETSCALE.Text = "ָ��������";
            this.MENU_VIEW_SETSCALE.Visible = false;
            // 
            // MENU_VIEW_SETPOINT
            // 
            this.MENU_VIEW_SETPOINT.Name = "MENU_VIEW_SETPOINT";
            this.MENU_VIEW_SETPOINT.Size = new System.Drawing.Size(142, 22);
            this.MENU_VIEW_SETPOINT.Text = "�Ŵ�ָ����";
            this.MENU_VIEW_SETPOINT.Visible = false;
            // 
            // MENU_EDIT_SpacialSearch
            // 
            this.MENU_EDIT_SpacialSearch.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MENU_EDIT_SpacialSearch_Identify,
            this.MENU_EDIT_SpacialSearch_Attributes,
            this.MENU_EDIT_SpacialSearch_Location,
            this.toolStripSeparator19,
            this.�������ToolStripMenuItem1,
            this.��������ToolStripMenuItem,
            this.�ܳ�����ToolStripMenuItem});
            this.MENU_EDIT_SpacialSearch.Name = "MENU_EDIT_SpacialSearch";
            this.MENU_EDIT_SpacialSearch.Size = new System.Drawing.Size(65, 20);
            this.MENU_EDIT_SpacialSearch.Text = "�ռ��ѯ";
            this.MENU_EDIT_SpacialSearch.Visible = false;
            // 
            // MENU_EDIT_SpacialSearch_Identify
            // 
            this.MENU_EDIT_SpacialSearch_Identify.Name = "MENU_EDIT_SpacialSearch_Identify";
            this.MENU_EDIT_SpacialSearch_Identify.Size = new System.Drawing.Size(142, 22);
            this.MENU_EDIT_SpacialSearch_Identify.Text = "ͼ�β�����";
            // 
            // MENU_EDIT_SpacialSearch_Attributes
            // 
            this.MENU_EDIT_SpacialSearch_Attributes.Name = "MENU_EDIT_SpacialSearch_Attributes";
            this.MENU_EDIT_SpacialSearch_Attributes.Size = new System.Drawing.Size(142, 22);
            this.MENU_EDIT_SpacialSearch_Attributes.Text = "ͨ�����Բ�ѯ";
            // 
            // MENU_EDIT_SpacialSearch_Location
            // 
            this.MENU_EDIT_SpacialSearch_Location.Name = "MENU_EDIT_SpacialSearch_Location";
            this.MENU_EDIT_SpacialSearch_Location.Size = new System.Drawing.Size(142, 22);
            this.MENU_EDIT_SpacialSearch_Location.Text = "ͨ��λ�ò�ѯ";
            // 
            // toolStripSeparator19
            // 
            this.toolStripSeparator19.Name = "toolStripSeparator19";
            this.toolStripSeparator19.Size = new System.Drawing.Size(139, 6);
            // 
            // �������ToolStripMenuItem1
            // 
            this.�������ToolStripMenuItem1.Name = "�������ToolStripMenuItem1";
            this.�������ToolStripMenuItem1.Size = new System.Drawing.Size(142, 22);
            this.�������ToolStripMenuItem1.Text = "�������";
            // 
            // ��������ToolStripMenuItem
            // 
            this.��������ToolStripMenuItem.Name = "��������ToolStripMenuItem";
            this.��������ToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
            this.��������ToolStripMenuItem.Text = "��������";
            // 
            // �ܳ�����ToolStripMenuItem
            // 
            this.�ܳ�����ToolStripMenuItem.Name = "�ܳ�����ToolStripMenuItem";
            this.�ܳ�����ToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
            this.�ܳ�����ToolStripMenuItem.Text = "�ܳ�����";
            // 
            // gPS�豸ToolStripMenuItem
            // 
            this.gPS�豸ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ID_MENU_GPS_CONNECT,
            this.ID_MENU_GPS_STOP,
            this.toolStripSeparator13,
            this.MENU_GPS_SAVE,
            this.MENU_GPS_NAVG,
            this.MENU_GPS_SigalSimu,
            this.toolStripSeparator14,
            this.MENU_GPS_SETTING});
            this.gPS�豸ToolStripMenuItem.Name = "gPS�豸ToolStripMenuItem";
            this.gPS�豸ToolStripMenuItem.Size = new System.Drawing.Size(59, 20);
            this.gPS�豸ToolStripMenuItem.Text = "GPS�豸";
            // 
            // ID_MENU_GPS_CONNECT
            // 
            this.ID_MENU_GPS_CONNECT.Name = "ID_MENU_GPS_CONNECT";
            this.ID_MENU_GPS_CONNECT.Size = new System.Drawing.Size(142, 22);
            this.ID_MENU_GPS_CONNECT.Text = "GPS��������";
            this.ID_MENU_GPS_CONNECT.Click += new System.EventHandler(this.ID_MENU_GPS_CONNECT_Click);
            // 
            // ID_MENU_GPS_STOP
            // 
            this.ID_MENU_GPS_STOP.Name = "ID_MENU_GPS_STOP";
            this.ID_MENU_GPS_STOP.Size = new System.Drawing.Size(142, 22);
            this.ID_MENU_GPS_STOP.Text = "GPS�����Ͽ�";
            this.ID_MENU_GPS_STOP.Click += new System.EventHandler(this.ID_MENU_GPS_STOP_Click);
            // 
            // toolStripSeparator13
            // 
            this.toolStripSeparator13.Name = "toolStripSeparator13";
            this.toolStripSeparator13.Size = new System.Drawing.Size(139, 6);
            // 
            // MENU_GPS_SAVE
            // 
            this.MENU_GPS_SAVE.Name = "MENU_GPS_SAVE";
            this.MENU_GPS_SAVE.Size = new System.Drawing.Size(142, 22);
            this.MENU_GPS_SAVE.Text = "�洢GPS����";
            this.MENU_GPS_SAVE.Click += new System.EventHandler(this.MENU_GPS_SAVE_Click);
            // 
            // MENU_GPS_NAVG
            // 
            this.MENU_GPS_NAVG.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MENU_GPS_NAVG_ON,
            this.MENU_GPS_NAVG_OFF});
            this.MENU_GPS_NAVG.Name = "MENU_GPS_NAVG";
            this.MENU_GPS_NAVG.Size = new System.Drawing.Size(142, 22);
            this.MENU_GPS_NAVG.Text = "��������";
            // 
            // MENU_GPS_NAVG_ON
            // 
            this.MENU_GPS_NAVG_ON.Name = "MENU_GPS_NAVG_ON";
            this.MENU_GPS_NAVG_ON.Size = new System.Drawing.Size(82, 22);
            this.MENU_GPS_NAVG_ON.Text = "��";
            this.MENU_GPS_NAVG_ON.Click += new System.EventHandler(this.MENU_GPS_NAVG_ON_Click);
            // 
            // MENU_GPS_NAVG_OFF
            // 
            this.MENU_GPS_NAVG_OFF.Name = "MENU_GPS_NAVG_OFF";
            this.MENU_GPS_NAVG_OFF.Size = new System.Drawing.Size(82, 22);
            this.MENU_GPS_NAVG_OFF.Text = "��";
            this.MENU_GPS_NAVG_OFF.Click += new System.EventHandler(this.MENU_GPS_NAVG_OFF_Click);
            // 
            // MENU_GPS_SigalSimu
            // 
            this.MENU_GPS_SigalSimu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MENU_GPS_SigalSimu_on,
            this.MENU_GPS_SigalSimu_off});
            this.MENU_GPS_SigalSimu.Name = "MENU_GPS_SigalSimu";
            this.MENU_GPS_SigalSimu.Size = new System.Drawing.Size(142, 22);
            this.MENU_GPS_SigalSimu.Text = "GPSģ���ź�";
            this.MENU_GPS_SigalSimu.Visible = false;
            // 
            // MENU_GPS_SigalSimu_on
            // 
            this.MENU_GPS_SigalSimu_on.Name = "MENU_GPS_SigalSimu_on";
            this.MENU_GPS_SigalSimu_on.Size = new System.Drawing.Size(82, 22);
            this.MENU_GPS_SigalSimu_on.Text = "��";
            this.MENU_GPS_SigalSimu_on.Click += new System.EventHandler(this.MENU_GPS_SigalSimu_on_Click);
            // 
            // MENU_GPS_SigalSimu_off
            // 
            this.MENU_GPS_SigalSimu_off.Name = "MENU_GPS_SigalSimu_off";
            this.MENU_GPS_SigalSimu_off.Size = new System.Drawing.Size(82, 22);
            this.MENU_GPS_SigalSimu_off.Text = "��";
            this.MENU_GPS_SigalSimu_off.Click += new System.EventHandler(this.MENU_GPS_SigalSimu_off_Click);
            // 
            // toolStripSeparator14
            // 
            this.toolStripSeparator14.Name = "toolStripSeparator14";
            this.toolStripSeparator14.Size = new System.Drawing.Size(139, 6);
            this.toolStripSeparator14.Visible = false;
            // 
            // MENU_GPS_SETTING
            // 
            this.MENU_GPS_SETTING.Name = "MENU_GPS_SETTING";
            this.MENU_GPS_SETTING.Size = new System.Drawing.Size(142, 22);
            this.MENU_GPS_SETTING.Text = "ʱ���������";
            this.MENU_GPS_SETTING.Visible = false;
            this.MENU_GPS_SETTING.Click += new System.EventHandler(this.MENU_GPS_SETTING_Click);
            // 
            // MENU_VEDIOl
            // 
            this.MENU_VEDIOl.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MENU_VEDIO_SETTING,
            this.MENU_VEDIO_WINDOW,
            this.MENU_VEDIO_START,
            this.MENU_VEDIO_STOP,
            this.toolStripSeparator17,
            this.MENU_VEDIO_PICTURE,
            this.MENU_VEDIO_TIMESERIAL,
            this.MENU_VEDIO_TIMESERIAL_STOP,
            this.MENU_VEDIO_VEDIO,
            this.toolStripSeparator24,
            this.MENU_VEDIO_TIME_PRO});
            this.MENU_VEDIOl.Name = "MENU_VEDIOl";
            this.MENU_VEDIOl.Size = new System.Drawing.Size(77, 20);
            this.MENU_VEDIOl.Text = "��Ƶͼ����";
            // 
            // MENU_VEDIO_SETTING
            // 
            this.MENU_VEDIO_SETTING.Name = "MENU_VEDIO_SETTING";
            this.MENU_VEDIO_SETTING.Size = new System.Drawing.Size(148, 22);
            this.MENU_VEDIO_SETTING.Text = "��/�����豸";
            this.MENU_VEDIO_SETTING.Click += new System.EventHandler(this.MENU_VEDIO_SETTING_Click);
            // 
            // MENU_VEDIO_WINDOW
            // 
            this.MENU_VEDIO_WINDOW.Name = "MENU_VEDIO_WINDOW";
            this.MENU_VEDIO_WINDOW.Size = new System.Drawing.Size(148, 22);
            this.MENU_VEDIO_WINDOW.Text = "��Ƶ����";
            this.MENU_VEDIO_WINDOW.Click += new System.EventHandler(this.MENU_VEDIO_WINDOW_Click);
            // 
            // MENU_VEDIO_START
            // 
            this.MENU_VEDIO_START.Name = "MENU_VEDIO_START";
            this.MENU_VEDIO_START.Size = new System.Drawing.Size(148, 22);
            this.MENU_VEDIO_START.Text = "�����豸";
            this.MENU_VEDIO_START.Click += new System.EventHandler(this.MENU_VEDIO_START_Click);
            // 
            // MENU_VEDIO_STOP
            // 
            this.MENU_VEDIO_STOP.Name = "MENU_VEDIO_STOP";
            this.MENU_VEDIO_STOP.Size = new System.Drawing.Size(148, 22);
            this.MENU_VEDIO_STOP.Text = "ֹͣ�豸";
            this.MENU_VEDIO_STOP.Click += new System.EventHandler(this.MENU_VEDIO_STOP_Click);
            // 
            // toolStripSeparator17
            // 
            this.toolStripSeparator17.Name = "toolStripSeparator17";
            this.toolStripSeparator17.Size = new System.Drawing.Size(145, 6);
            // 
            // MENU_VEDIO_PICTURE
            // 
            this.MENU_VEDIO_PICTURE.Name = "MENU_VEDIO_PICTURE";
            this.MENU_VEDIO_PICTURE.Size = new System.Drawing.Size(148, 22);
            this.MENU_VEDIO_PICTURE.Text = "�����ͼ";
            this.MENU_VEDIO_PICTURE.Click += new System.EventHandler(this.MENU_VEDIO_PICTURE_Click);
            // 
            // MENU_VEDIO_TIMESERIAL
            // 
            this.MENU_VEDIO_TIMESERIAL.Name = "MENU_VEDIO_TIMESERIAL";
            this.MENU_VEDIO_TIMESERIAL.Size = new System.Drawing.Size(148, 22);
            this.MENU_VEDIO_TIMESERIAL.Text = "��ʼ���вɼ�";
            this.MENU_VEDIO_TIMESERIAL.Click += new System.EventHandler(this.MENU_VEDIO_TIMESERIAL_Click);
            // 
            // MENU_VEDIO_TIMESERIAL_STOP
            // 
            this.MENU_VEDIO_TIMESERIAL_STOP.Name = "MENU_VEDIO_TIMESERIAL_STOP";
            this.MENU_VEDIO_TIMESERIAL_STOP.Size = new System.Drawing.Size(148, 22);
            this.MENU_VEDIO_TIMESERIAL_STOP.Text = "ֹͣ���вɼ�";
            this.MENU_VEDIO_TIMESERIAL_STOP.Click += new System.EventHandler(this.MENU_VEDIO_TIMESERIAL_STOP_Click);
            // 
            // MENU_VEDIO_VEDIO
            // 
            this.MENU_VEDIO_VEDIO.Name = "MENU_VEDIO_VEDIO";
            this.MENU_VEDIO_VEDIO.Size = new System.Drawing.Size(148, 22);
            this.MENU_VEDIO_VEDIO.Text = "��Ƶ�ɼ�";
            this.MENU_VEDIO_VEDIO.Click += new System.EventHandler(this.MENU_VEDIO_VEDIO_Click);
            // 
            // toolStripSeparator24
            // 
            this.toolStripSeparator24.Name = "toolStripSeparator24";
            this.toolStripSeparator24.Size = new System.Drawing.Size(145, 6);
            this.toolStripSeparator24.Visible = false;
            // 
            // MENU_VEDIO_TIME_PRO
            // 
            this.MENU_VEDIO_TIME_PRO.Name = "MENU_VEDIO_TIME_PRO";
            this.MENU_VEDIO_TIME_PRO.Size = new System.Drawing.Size(148, 22);
            this.MENU_VEDIO_TIME_PRO.Text = "��������";
            this.MENU_VEDIO_TIME_PRO.Visible = false;
            this.MENU_VEDIO_TIME_PRO.Click += new System.EventHandler(this.MENU_VEDIO_TIME_PRO_Click);
            // 
            // MENU_VEDIOr
            // 
            this.MENU_VEDIOr.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MENU_VEDIOr_SETTING,
            this.MENU_VEDIOr_WINDOW,
            this.MENU_VEDIOr_START,
            this.MENU_VEDIOr_STOP,
            this.toolStripSeparator25,
            this.MENU_VEDIOr_CAPTURE,
            this.MENU_VEDIOr_SERIAL_S,
            this.MENU_VEDIOr_SERIAL_T,
            this.toolStripSeparator26,
            this.MENU_VEDIOr_VEDIO});
            this.MENU_VEDIOr.Name = "MENU_VEDIOr";
            this.MENU_VEDIOr.Size = new System.Drawing.Size(77, 20);
            this.MENU_VEDIOr.Text = "��Ƶͼ����";
            // 
            // MENU_VEDIOr_SETTING
            // 
            this.MENU_VEDIOr_SETTING.Name = "MENU_VEDIOr_SETTING";
            this.MENU_VEDIOr_SETTING.Size = new System.Drawing.Size(148, 22);
            this.MENU_VEDIOr_SETTING.Text = "��/�����豸";
            this.MENU_VEDIOr_SETTING.Click += new System.EventHandler(this.MENU_VEDIOr_SETTING_Click);
            // 
            // MENU_VEDIOr_WINDOW
            // 
            this.MENU_VEDIOr_WINDOW.Name = "MENU_VEDIOr_WINDOW";
            this.MENU_VEDIOr_WINDOW.Size = new System.Drawing.Size(148, 22);
            this.MENU_VEDIOr_WINDOW.Text = "��Ƶ����";
            this.MENU_VEDIOr_WINDOW.Click += new System.EventHandler(this.MENU_VEDIOr_WINDOW_Click);
            // 
            // MENU_VEDIOr_START
            // 
            this.MENU_VEDIOr_START.Name = "MENU_VEDIOr_START";
            this.MENU_VEDIOr_START.Size = new System.Drawing.Size(148, 22);
            this.MENU_VEDIOr_START.Text = "�����豸";
            this.MENU_VEDIOr_START.Click += new System.EventHandler(this.MENU_VEDIOr_START_Click);
            // 
            // MENU_VEDIOr_STOP
            // 
            this.MENU_VEDIOr_STOP.Name = "MENU_VEDIOr_STOP";
            this.MENU_VEDIOr_STOP.Size = new System.Drawing.Size(148, 22);
            this.MENU_VEDIOr_STOP.Text = "ֹͣ�豸";
            this.MENU_VEDIOr_STOP.Click += new System.EventHandler(this.MENU_VEDIOr_STOP_Click);
            // 
            // toolStripSeparator25
            // 
            this.toolStripSeparator25.Name = "toolStripSeparator25";
            this.toolStripSeparator25.Size = new System.Drawing.Size(145, 6);
            // 
            // MENU_VEDIOr_CAPTURE
            // 
            this.MENU_VEDIOr_CAPTURE.Name = "MENU_VEDIOr_CAPTURE";
            this.MENU_VEDIOr_CAPTURE.Size = new System.Drawing.Size(148, 22);
            this.MENU_VEDIOr_CAPTURE.Text = "�����ͼ";
            this.MENU_VEDIOr_CAPTURE.Click += new System.EventHandler(this.MENU_VEDIOr_CAPTURE_Click);
            // 
            // MENU_VEDIOr_SERIAL_S
            // 
            this.MENU_VEDIOr_SERIAL_S.Name = "MENU_VEDIOr_SERIAL_S";
            this.MENU_VEDIOr_SERIAL_S.Size = new System.Drawing.Size(148, 22);
            this.MENU_VEDIOr_SERIAL_S.Text = "��ʼ���вɼ�";
            this.MENU_VEDIOr_SERIAL_S.Click += new System.EventHandler(this.MENU_VEDIOr_SERIAL_S_Click);
            // 
            // MENU_VEDIOr_SERIAL_T
            // 
            this.MENU_VEDIOr_SERIAL_T.Name = "MENU_VEDIOr_SERIAL_T";
            this.MENU_VEDIOr_SERIAL_T.Size = new System.Drawing.Size(148, 22);
            this.MENU_VEDIOr_SERIAL_T.Text = "ֹͣ���вɼ�";
            this.MENU_VEDIOr_SERIAL_T.Click += new System.EventHandler(this.MENU_VEDIOr_SERIAL_T_Click);
            // 
            // toolStripSeparator26
            // 
            this.toolStripSeparator26.Name = "toolStripSeparator26";
            this.toolStripSeparator26.Size = new System.Drawing.Size(145, 6);
            // 
            // MENU_VEDIOr_VEDIO
            // 
            this.MENU_VEDIOr_VEDIO.Name = "MENU_VEDIOr_VEDIO";
            this.MENU_VEDIOr_VEDIO.Size = new System.Drawing.Size(148, 22);
            this.MENU_VEDIOr_VEDIO.Text = "��Ƶ�ɼ�";
            this.MENU_VEDIOr_VEDIO.Click += new System.EventHandler(this.MENU_VEDIOr_VEDIO_Click);
            // 
            // ʱ���������ToolStripMenuItem
            // 
            this.ʱ���������ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MENU_GPS_SETTING2,
            this.MENU_VEDIO_TIME_PRO2});
            this.ʱ���������ToolStripMenuItem.Name = "ʱ���������ToolStripMenuItem";
            this.ʱ���������ToolStripMenuItem.Size = new System.Drawing.Size(65, 20);
            this.ʱ���������ToolStripMenuItem.Text = "��������";
            // 
            // MENU_GPS_SETTING2
            // 
            this.MENU_GPS_SETTING2.Name = "MENU_GPS_SETTING2";
            this.MENU_GPS_SETTING2.Size = new System.Drawing.Size(142, 22);
            this.MENU_GPS_SETTING2.Text = "GPS��������";
            this.MENU_GPS_SETTING2.Click += new System.EventHandler(this.MENU_GPS_SETTING_Click);
            // 
            // MENU_VEDIO_TIME_PRO2
            // 
            this.MENU_VEDIO_TIME_PRO2.Name = "MENU_VEDIO_TIME_PRO2";
            this.MENU_VEDIO_TIME_PRO2.Size = new System.Drawing.Size(142, 22);
            this.MENU_VEDIO_TIME_PRO2.Text = "��Ƶ��������";
            this.MENU_VEDIO_TIME_PRO2.Click += new System.EventHandler(this.MENU_VEDIO_TIME_PRO_Click);
            // 
            // ����ToolStripMenuItem
            // 
            this.����ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.������Ϣ�趨ToolStripMenuItem,
            this.������Ϣ��ʾToolStripMenuItem,
            this.toolStripSeparator6,
            this.ע����Ϣ����ToolStripMenuItem,
            this.���Թ���ToolStripMenuItem,
            this.toolStripSeparator10,
            this.ϵͳ����ToolStripMenuItem});
            this.����ToolStripMenuItem.Name = "����ToolStripMenuItem";
            this.����ToolStripMenuItem.Size = new System.Drawing.Size(41, 20);
            this.����ToolStripMenuItem.Text = "����";
            this.����ToolStripMenuItem.Visible = false;
            // 
            // ������Ϣ�趨ToolStripMenuItem
            // 
            this.������Ϣ�趨ToolStripMenuItem.Name = "������Ϣ�趨ToolStripMenuItem";
            this.������Ϣ�趨ToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
            this.������Ϣ�趨ToolStripMenuItem.Text = "������Ϣ�趨";
            // 
            // ������Ϣ��ʾToolStripMenuItem
            // 
            this.������Ϣ��ʾToolStripMenuItem.Name = "������Ϣ��ʾToolStripMenuItem";
            this.������Ϣ��ʾToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
            this.������Ϣ��ʾToolStripMenuItem.Text = "������Ϣ��ʾ";
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(139, 6);
            // 
            // ע����Ϣ����ToolStripMenuItem
            // 
            this.ע����Ϣ����ToolStripMenuItem.Name = "ע����Ϣ����ToolStripMenuItem";
            this.ע����Ϣ����ToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
            this.ע����Ϣ����ToolStripMenuItem.Text = "ע�ǹ���";
            // 
            // ���Թ���ToolStripMenuItem
            // 
            this.���Թ���ToolStripMenuItem.Name = "���Թ���ToolStripMenuItem";
            this.���Թ���ToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
            this.���Թ���ToolStripMenuItem.Text = "���Թ���";
            // 
            // toolStripSeparator10
            // 
            this.toolStripSeparator10.Name = "toolStripSeparator10";
            this.toolStripSeparator10.Size = new System.Drawing.Size(139, 6);
            // 
            // ϵͳ����ToolStripMenuItem
            // 
            this.ϵͳ����ToolStripMenuItem.Name = "ϵͳ����ToolStripMenuItem";
            this.ϵͳ����ToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
            this.ϵͳ����ToolStripMenuItem.Text = "ϵͳ����";
            // 
            // MENU_HELP
            // 
            this.MENU_HELP.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MENU_HELP_DOCS,
            this.MENU_HELP_ABOUT});
            this.MENU_HELP.Name = "MENU_HELP";
            this.MENU_HELP.Size = new System.Drawing.Size(41, 20);
            this.MENU_HELP.Text = "����";
            // 
            // MENU_HELP_DOCS
            // 
            this.MENU_HELP_DOCS.Name = "MENU_HELP_DOCS";
            this.MENU_HELP_DOCS.Size = new System.Drawing.Size(118, 22);
            this.MENU_HELP_DOCS.Text = "�����ĵ�";
            this.MENU_HELP_DOCS.Click += new System.EventHandler(this.MENU_HELP_DOCS_Click);
            // 
            // MENU_HELP_ABOUT
            // 
            this.MENU_HELP_ABOUT.Name = "MENU_HELP_ABOUT";
            this.MENU_HELP_ABOUT.Size = new System.Drawing.Size(118, 22);
            this.MENU_HELP_ABOUT.Text = "����";
            this.MENU_HELP_ABOUT.Click += new System.EventHandler(this.MENU_HELP_ABOUT_Click);
            // 
            // BottomToolStripPanel
            // 
            this.BottomToolStripPanel.Location = new System.Drawing.Point(0, 0);
            this.BottomToolStripPanel.Name = "BottomToolStripPanel";
            this.BottomToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal;
            this.BottomToolStripPanel.RowMargin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.BottomToolStripPanel.Size = new System.Drawing.Size(0, 0);
            // 
            // TopToolStripPanel
            // 
            this.TopToolStripPanel.Location = new System.Drawing.Point(0, 0);
            this.TopToolStripPanel.Name = "TopToolStripPanel";
            this.TopToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal;
            this.TopToolStripPanel.RowMargin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.TopToolStripPanel.Size = new System.Drawing.Size(0, 0);
            // 
            // RightToolStripPanel
            // 
            this.RightToolStripPanel.Location = new System.Drawing.Point(0, 0);
            this.RightToolStripPanel.Name = "RightToolStripPanel";
            this.RightToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal;
            this.RightToolStripPanel.RowMargin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.RightToolStripPanel.Size = new System.Drawing.Size(0, 0);
            // 
            // LeftToolStripPanel
            // 
            this.LeftToolStripPanel.Location = new System.Drawing.Point(0, 0);
            this.LeftToolStripPanel.Name = "LeftToolStripPanel";
            this.LeftToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal;
            this.LeftToolStripPanel.RowMargin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.LeftToolStripPanel.Size = new System.Drawing.Size(0, 0);
            // 
            // ContentPanel
            // 
            this.ContentPanel.Size = new System.Drawing.Size(150, 150);
            // 
            // toolStrip1
            // 
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(24, 20);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.BTN_SAVE_YUTU,
            this.BTN_TOOL_IDLE,
            this.toolStripSeparator22,
            this.BTN_CLS_POI,
            this.BTN_CLS_NEWPOI,
            this.BTN_CLS_PATH,
            this.BTN_CLS_BUILDINGS,
            this.BTN_CLS_BACKGROUND,
            this.toolStripSeparator23,
            this.BTN_GPS_ON,
            this.BTN_GPS_OFF,
            this.BTN_GPS_NAVG,
            this.toolStripSeparator15,
            this.BTN_VIDEO_SET,
            this.BTN_VIDEO_START,
            this.BTN_VIDEO_STOP,
            this.BTN_VIDEO_WINDOW,
            this.toolStripSeparator21,
            this.BTN_PATH_EDIT,
            this.BTN_PATH_DEL});
            this.toolStrip1.Location = new System.Drawing.Point(0, 24);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(792, 27);
            this.toolStrip1.TabIndex = 2;
            // 
            // BTN_SAVE_YUTU
            // 
            this.BTN_SAVE_YUTU.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.BTN_SAVE_YUTU.Image = global::YuTuSurveyPlatform.Properties.Resources.WRITE_YUTU;
            this.BTN_SAVE_YUTU.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BTN_SAVE_YUTU.Name = "BTN_SAVE_YUTU";
            this.BTN_SAVE_YUTU.Size = new System.Drawing.Size(28, 24);
            this.BTN_SAVE_YUTU.Text = "���ĵ����浽�ļ�(CTRL+ALT+S)";
            this.BTN_SAVE_YUTU.Click += new System.EventHandler(this.BTN_SAVE_YUTU_Click);
            // 
            // BTN_TOOL_IDLE
            // 
            this.BTN_TOOL_IDLE.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.BTN_TOOL_IDLE.Image = global::YuTuSurveyPlatform.Properties.Resources.Arrow_idle;
            this.BTN_TOOL_IDLE.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BTN_TOOL_IDLE.Name = "BTN_TOOL_IDLE";
            this.BTN_TOOL_IDLE.Size = new System.Drawing.Size(28, 24);
            this.BTN_TOOL_IDLE.Text = "ֹͣ����";
            this.BTN_TOOL_IDLE.Click += new System.EventHandler(this.BTN_TOOL_IDLE_Click);
            // 
            // toolStripSeparator22
            // 
            this.toolStripSeparator22.Name = "toolStripSeparator22";
            this.toolStripSeparator22.Size = new System.Drawing.Size(6, 27);
            // 
            // BTN_CLS_POI
            // 
            this.BTN_CLS_POI.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.BTN_CLS_POI.Image = global::YuTuSurveyPlatform.Properties.Resources.POI;
            this.BTN_CLS_POI.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BTN_CLS_POI.Name = "BTN_CLS_POI";
            this.BTN_CLS_POI.Size = new System.Drawing.Size(28, 24);
            this.BTN_CLS_POI.Text = "�༭POI�㣨F1��";
            this.BTN_CLS_POI.Click += new System.EventHandler(this.BTN_CLS_POI_Click);
            // 
            // BTN_CLS_NEWPOI
            // 
            this.BTN_CLS_NEWPOI.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.BTN_CLS_NEWPOI.Image = global::YuTuSurveyPlatform.Properties.Resources.NEWPOI;
            this.BTN_CLS_NEWPOI.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BTN_CLS_NEWPOI.Name = "BTN_CLS_NEWPOI";
            this.BTN_CLS_NEWPOI.Size = new System.Drawing.Size(28, 24);
            this.BTN_CLS_NEWPOI.Text = "�༭�½���POI�㣨F2��";
            this.BTN_CLS_NEWPOI.Visible = false;
            this.BTN_CLS_NEWPOI.Click += new System.EventHandler(this.BTN_CLS_NEWPOI_Click);
            // 
            // BTN_CLS_PATH
            // 
            this.BTN_CLS_PATH.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.BTN_CLS_PATH.Image = global::YuTuSurveyPlatform.Properties.Resources.PATH;
            this.BTN_CLS_PATH.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BTN_CLS_PATH.Name = "BTN_CLS_PATH";
            this.BTN_CLS_PATH.Size = new System.Drawing.Size(28, 24);
            this.BTN_CLS_PATH.Text = "�༭��·�㣨F3��";
            this.BTN_CLS_PATH.Click += new System.EventHandler(this.BTN_CLS_PATH_Click);
            // 
            // BTN_CLS_BUILDINGS
            // 
            this.BTN_CLS_BUILDINGS.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.BTN_CLS_BUILDINGS.Image = global::YuTuSurveyPlatform.Properties.Resources.BUILDING;
            this.BTN_CLS_BUILDINGS.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BTN_CLS_BUILDINGS.Name = "BTN_CLS_BUILDINGS";
            this.BTN_CLS_BUILDINGS.Size = new System.Drawing.Size(28, 24);
            this.BTN_CLS_BUILDINGS.Text = "�༭���ݲ㣨F4��";
            this.BTN_CLS_BUILDINGS.Click += new System.EventHandler(this.BTN_CLS_BUILDINGS_Click);
            // 
            // BTN_CLS_BACKGROUND
            // 
            this.BTN_CLS_BACKGROUND.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.BTN_CLS_BACKGROUND.Image = global::YuTuSurveyPlatform.Properties.Resources.Polygons;
            this.BTN_CLS_BACKGROUND.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BTN_CLS_BACKGROUND.Name = "BTN_CLS_BACKGROUND";
            this.BTN_CLS_BACKGROUND.Size = new System.Drawing.Size(28, 24);
            this.BTN_CLS_BACKGROUND.Text = "�༭����㣨F5��";
            this.BTN_CLS_BACKGROUND.Click += new System.EventHandler(this.BTN_CLS_BACKGROUND_Click);
            // 
            // toolStripSeparator23
            // 
            this.toolStripSeparator23.Name = "toolStripSeparator23";
            this.toolStripSeparator23.Size = new System.Drawing.Size(6, 27);
            // 
            // BTN_GPS_ON
            // 
            this.BTN_GPS_ON.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.BTN_GPS_ON.Image = global::YuTuSurveyPlatform.Properties.Resources.GPS_Connect;
            this.BTN_GPS_ON.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BTN_GPS_ON.Name = "BTN_GPS_ON";
            this.BTN_GPS_ON.Size = new System.Drawing.Size(28, 24);
            this.BTN_GPS_ON.Text = "����GPS(&E)";
            this.BTN_GPS_ON.Click += new System.EventHandler(this.ID_MENU_GPS_CONNECT_Click);
            // 
            // BTN_GPS_OFF
            // 
            this.BTN_GPS_OFF.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.BTN_GPS_OFF.Image = global::YuTuSurveyPlatform.Properties.Resources.GPS_DisConnect;
            this.BTN_GPS_OFF.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BTN_GPS_OFF.Name = "BTN_GPS_OFF";
            this.BTN_GPS_OFF.Size = new System.Drawing.Size(28, 24);
            this.BTN_GPS_OFF.Text = "�Ͽ�GPS";
            this.BTN_GPS_OFF.Click += new System.EventHandler(this.ID_MENU_GPS_STOP_Click);
            // 
            // BTN_GPS_NAVG
            // 
            this.BTN_GPS_NAVG.Checked = true;
            this.BTN_GPS_NAVG.CheckState = System.Windows.Forms.CheckState.Checked;
            this.BTN_GPS_NAVG.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.BTN_GPS_NAVG.Image = global::YuTuSurveyPlatform.Properties.Resources.GPS_NAVG;
            this.BTN_GPS_NAVG.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BTN_GPS_NAVG.Name = "BTN_GPS_NAVG";
            this.BTN_GPS_NAVG.Size = new System.Drawing.Size(28, 24);
            this.BTN_GPS_NAVG.Text = "GPS��ͼ����";
            this.BTN_GPS_NAVG.Click += new System.EventHandler(this.BTN_GPS_NAVG_Click);
            // 
            // toolStripSeparator15
            // 
            this.toolStripSeparator15.Name = "toolStripSeparator15";
            this.toolStripSeparator15.Size = new System.Drawing.Size(6, 27);
            // 
            // BTN_VIDEO_SET
            // 
            this.BTN_VIDEO_SET.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.BTN_VIDEO_SET.Image = global::YuTuSurveyPlatform.Properties.Resources.Setting;
            this.BTN_VIDEO_SET.ImageTransparentColor = System.Drawing.Color.Linen;
            this.BTN_VIDEO_SET.Name = "BTN_VIDEO_SET";
            this.BTN_VIDEO_SET.Size = new System.Drawing.Size(28, 24);
            this.BTN_VIDEO_SET.Text = "����/������Ƶ";
            this.BTN_VIDEO_SET.Click += new System.EventHandler(this.BTN_VIDEO_SET_Click);
            // 
            // BTN_VIDEO_START
            // 
            this.BTN_VIDEO_START.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.BTN_VIDEO_START.Image = global::YuTuSurveyPlatform.Properties.Resources.tplay;
            this.BTN_VIDEO_START.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BTN_VIDEO_START.Name = "BTN_VIDEO_START";
            this.BTN_VIDEO_START.Size = new System.Drawing.Size(28, 24);
            this.BTN_VIDEO_START.Text = "�ɼ���Ƭ";
            this.BTN_VIDEO_START.Click += new System.EventHandler(this.BTN_VIDEO_START_Click);
            // 
            // BTN_VIDEO_STOP
            // 
            this.BTN_VIDEO_STOP.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.BTN_VIDEO_STOP.Image = global::YuTuSurveyPlatform.Properties.Resources.tpause;
            this.BTN_VIDEO_STOP.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BTN_VIDEO_STOP.Name = "BTN_VIDEO_STOP";
            this.BTN_VIDEO_STOP.Size = new System.Drawing.Size(28, 24);
            this.BTN_VIDEO_STOP.Text = "ֹͣ�ɼ���Ƭ";
            this.BTN_VIDEO_STOP.Click += new System.EventHandler(this.BTN_VIDEO_STOP_Click);
            // 
            // BTN_VIDEO_WINDOW
            // 
            this.BTN_VIDEO_WINDOW.Image = global::YuTuSurveyPlatform.Properties.Resources.header;
            this.BTN_VIDEO_WINDOW.Name = "BTN_VIDEO_WINDOW";
            this.BTN_VIDEO_WINDOW.Size = new System.Drawing.Size(28, 24);
            this.BTN_VIDEO_WINDOW.Click += new System.EventHandler(this.BTN_VIDEO_WINDOW_Click);
            // 
            // toolStripSeparator21
            // 
            this.toolStripSeparator21.Name = "toolStripSeparator21";
            this.toolStripSeparator21.Size = new System.Drawing.Size(6, 27);
            // 
            // BTN_PATH_EDIT
            // 
            this.BTN_PATH_EDIT.Name = "BTN_PATH_EDIT";
            this.BTN_PATH_EDIT.Size = new System.Drawing.Size(23, 24);
            // 
            // BTN_PATH_DEL
            // 
            this.BTN_PATH_DEL.Name = "BTN_PATH_DEL";
            this.BTN_PATH_DEL.Size = new System.Drawing.Size(23, 24);
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 51);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.tabControl1);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.tabControl2);
            this.splitContainer1.Size = new System.Drawing.Size(792, 493);
            this.splitContainer1.SplitterDistance = 179;
            this.splitContainer1.TabIndex = 3;
            // 
            // tabControl1
            // 
            this.tabControl1.Alignment = System.Windows.Forms.TabAlignment.Bottom;
            this.tabControl1.Controls.Add(this.tabPageLayer);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(179, 493);
            this.tabControl1.TabIndex = 1;
            // 
            // tabPageLayer
            // 
            this.tabPageLayer.Controls.Add(this.axTOCControl1);
            this.tabPageLayer.Location = new System.Drawing.Point(4, 4);
            this.tabPageLayer.Name = "tabPageLayer";
            this.tabPageLayer.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageLayer.Size = new System.Drawing.Size(171, 468);
            this.tabPageLayer.TabIndex = 0;
            this.tabPageLayer.Text = "ͼ��";
            this.tabPageLayer.UseVisualStyleBackColor = true;
            // 
            // axTOCControl1
            // 
            this.axTOCControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.axTOCControl1.Location = new System.Drawing.Point(3, 3);
            this.axTOCControl1.Name = "axTOCControl1";
            this.axTOCControl1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axTOCControl1.OcxState")));
            this.axTOCControl1.Size = new System.Drawing.Size(165, 462);
            this.axTOCControl1.TabIndex = 0;
            this.axTOCControl1.OnMouseDown += new ESRI.ArcGIS.Controls.ITOCControlEvents_Ax_OnMouseDownEventHandler(this.axTOCControl1_OnMouseDown);
            this.axTOCControl1.OnDoubleClick += new ESRI.ArcGIS.Controls.ITOCControlEvents_Ax_OnDoubleClickEventHandler(this.axTOCControl1_OnDoubleClick);
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tabPageMap);
            this.tabControl2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl2.Location = new System.Drawing.Point(0, 0);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(609, 493);
            this.tabControl2.TabIndex = 1;
            // 
            // tabPageMap
            // 
            this.tabPageMap.Controls.Add(this.axToolbarControlEdit);
            this.tabPageMap.Controls.Add(this.axMapControl1);
            this.tabPageMap.Controls.Add(this.axLicenseControl1);
            this.tabPageMap.Location = new System.Drawing.Point(4, 21);
            this.tabPageMap.Name = "tabPageMap";
            this.tabPageMap.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageMap.Size = new System.Drawing.Size(601, 468);
            this.tabPageMap.TabIndex = 0;
            this.tabPageMap.Text = "����";
            this.tabPageMap.UseVisualStyleBackColor = true;
            // 
            // axToolbarControlEdit
            // 
            this.axToolbarControlEdit.Dock = System.Windows.Forms.DockStyle.Right;
            this.axToolbarControlEdit.Location = new System.Drawing.Point(570, 3);
            this.axToolbarControlEdit.Name = "axToolbarControlEdit";
            this.axToolbarControlEdit.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axToolbarControlEdit.OcxState")));
            this.axToolbarControlEdit.Size = new System.Drawing.Size(28, 462);
            this.axToolbarControlEdit.TabIndex = 5;
            this.axToolbarControlEdit.OnItemClick += new ESRI.ArcGIS.Controls.IToolbarControlEvents_Ax_OnItemClickEventHandler(this.axToolbarControlEdit_OnItemClick);
            // 
            // axMapControl1
            // 
            this.axMapControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.axMapControl1.Location = new System.Drawing.Point(3, 3);
            this.axMapControl1.Name = "axMapControl1";
            this.axMapControl1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axMapControl1.OcxState")));
            this.axMapControl1.Size = new System.Drawing.Size(595, 462);
            this.axMapControl1.TabIndex = 1;
            this.axMapControl1.OnMouseDown += new ESRI.ArcGIS.Controls.IMapControlEvents2_Ax_OnMouseDownEventHandler(this.axMapControl1_OnMouseDown);
            this.axMapControl1.OnMouseMove += new ESRI.ArcGIS.Controls.IMapControlEvents2_Ax_OnMouseMoveEventHandler(this.axMapControl1_OnMouseMove);
            this.axMapControl1.OnMapReplaced += new ESRI.ArcGIS.Controls.IMapControlEvents2_Ax_OnMapReplacedEventHandler(this.axMapControl1_OnMapReplaced);
            this.axMapControl1.OnAfterDraw += new ESRI.ArcGIS.Controls.IMapControlEvents2_Ax_OnAfterDrawEventHandler(this.axMapControl1_OnAfterDraw);
            // 
            // axLicenseControl1
            // 
            this.axLicenseControl1.Enabled = true;
            this.axLicenseControl1.Location = new System.Drawing.Point(44, 65);
            this.axLicenseControl1.Name = "axLicenseControl1";
            this.axLicenseControl1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axLicenseControl1.OcxState")));
            this.axLicenseControl1.Size = new System.Drawing.Size(32, 32);
            this.axLicenseControl1.TabIndex = 0;
            // 
            // axToolbarControl1
            // 
            this.axToolbarControl1.Location = new System.Drawing.Point(396, 23);
            this.axToolbarControl1.Name = "axToolbarControl1";
            this.axToolbarControl1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axToolbarControl1.OcxState")));
            this.axToolbarControl1.Size = new System.Drawing.Size(395, 28);
            this.axToolbarControl1.TabIndex = 4;
            // 
            // backgroundWorker1
            // 
            this.backgroundWorker1.DoWork += new System.ComponentModel.DoWorkEventHandler(this.backgroundWorker1_DoWork);
            this.backgroundWorker1.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.backgroundWorker1_RunWorkerCompleted);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(330, 218);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(132, 131);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox1.TabIndex = 12;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Visible = false;
            // 
            // MainInterface
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(792, 566);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.axToolbarControl1);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "MainInterface";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "��ͼ��ҵ����ƽ̨�����԰棩";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.MainInterface_FormClosed);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.MainInterface_KeyDown);
            this.Load += new System.EventHandler(this.MainInterface_Load);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPageLayer.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.axTOCControl1)).EndInit();
            this.tabControl2.ResumeLayout(false);
            this.tabPageMap.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.axToolbarControlEdit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axMapControl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axLicenseControl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axToolbarControl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStripMenuItem MENU_FILE_NEW;
        private System.Windows.Forms.ToolStripMenuItem MENU_FILE_0PEN;
        private System.Windows.Forms.ToolStripMenuItem MENU_FILE_OPENIMAGE;
        private System.Windows.Forms.ToolStripMenuItem MENU_FILE_VERCTOR;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem MENU_FILE_SAVE;
        private System.Windows.Forms.ToolStripMenuItem MENU_FILE_SVAEAS;
        private System.Windows.Forms.ToolStripMenuItem MENU_FILE_CLOSE;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem MENU_FILE_IMPORT;
        private System.Windows.Forms.ToolStripMenuItem MENU_FILE_EXPORT;
        private System.Windows.Forms.ToolStripMenuItem MENU_FILE_FORMATCON;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem MENU_FILE_PRINTSETTING;
        private System.Windows.Forms.ToolStripMenuItem MENU_FILE_PREPRINT;
        private System.Windows.Forms.ToolStripMenuItem MENU_FILE_PRINT;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripMenuItem MENU_FILE_EXIT;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripMenuItem ID_MENU_FILE;
        private System.Windows.Forms.ToolStripMenuItem ID_MENU_FILE_NEW;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripMenuItem ID_MENU_FILE_PRINTSET;
        private System.Windows.Forms.ToolStripMenuItem ID_MENU_FILE_PRINTPRE;
        private System.Windows.Forms.ToolStripMenuItem ID_MENU_FILE_PRINT;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator8;
        private System.Windows.Forms.ToolStripMenuItem ID_MENU_FILE_EXIT;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripPanel BottomToolStripPanel;
        private System.Windows.Forms.ToolStripPanel TopToolStripPanel;
        private System.Windows.Forms.ToolStripPanel RightToolStripPanel;
        private System.Windows.Forms.ToolStripPanel LeftToolStripPanel;
        private System.Windows.Forms.ToolStripContentPanel ContentPanel;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripMenuItem ID_MENU_DATAMNG;
        private System.Windows.Forms.SplitContainer splitContainer1;
        public System.Windows.Forms.ToolStripStatusLabel MessageLabel;
        private System.Windows.Forms.ToolStripStatusLabel blank;
        private System.Windows.Forms.ToolStripStatusLabel ScaleLabel;
        private System.Windows.Forms.ToolStripStatusLabel CoordinatesLabel;
        private System.Windows.Forms.ToolStripMenuItem MENU_EDIT;
        private System.Windows.Forms.ToolStripMenuItem MENU_EDIT_SEL_ALL;
        private System.Windows.Forms.ToolStripMenuItem MENU_EDIT_SEL_INV;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator12;
        private System.Windows.Forms.ToolStripMenuItem MENU_EDIT_OBJ_COPY;
        private System.Windows.Forms.ToolStripMenuItem MENU_EDIT_OBJ_PASTE;
        private System.Windows.Forms.ToolStripMenuItem MENU_EDIT_OBJ_DEL;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator11;
        private System.Windows.Forms.ToolStripMenuItem MENU_EDIT_PROPERTY;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator9;
        private System.Windows.Forms.ToolStripMenuItem MENU_HELP;
        private System.Windows.Forms.ToolStripMenuItem MENU_HELP_DOCS;
        private System.Windows.Forms.ToolStripMenuItem MENU_HELP_ABOUT;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPageMap;
        private System.Windows.Forms.ToolStripMenuItem ID_MENU_FILE_OPEN;
        private System.Windows.Forms.ToolStripMenuItem ID_MENU_DATAMNG_IMG;
        private System.Windows.Forms.ToolStripMenuItem ID_MENU_FILE_SAVE;
        private System.Windows.Forms.ToolStripMenuItem ID_MENU_FILE_SAVEAS;
        private System.Windows.Forms.ToolStripMenuItem ID_MENU_FILE_CLOSE;
        private System.Windows.Forms.ToolStripMenuItem ID_MENU_DATAMNG_SHP;
        private System.Windows.Forms.ToolStripMenuItem ID_MENU_DATAMNG_CONV;
        private System.Windows.Forms.ToolStripMenuItem gPS�豸ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ����ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ������Ϣ�趨ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ������Ϣ��ʾToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripMenuItem ע����Ϣ����ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ���Թ���ToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator10;
        private System.Windows.Forms.ToolStripMenuItem ϵͳ����ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ID_MENU_GPS_CONNECT;
        private System.Windows.Forms.ToolStripMenuItem ID_MENU_GPS_STOP;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator13;
        private System.Windows.Forms.ToolStripMenuItem MENU_GPS_SAVE;
        private System.Windows.Forms.ToolStripMenuItem MENU_GPS_NAVG;
        private System.Windows.Forms.ToolStripMenuItem MENU_GPS_NAVG_ON;
        private System.Windows.Forms.ToolStripMenuItem MENU_GPS_NAVG_OFF;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator14;
        private System.Windows.Forms.ToolStripMenuItem MENU_GPS_SETTING;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
        private System.Windows.Forms.ToolStripMenuItem ID_MENU_DATAMNG_YUT_IN;
        private System.Windows.Forms.ToolStripMenuItem ID_MENU_DATAMNG_YUT_OUT;
        private System.Windows.Forms.ToolStripMenuItem MENU_EDIT_SEL_RECT;
        private System.Windows.Forms.ToolStripMenuItem MENU_EDIT_SEL_POLY;
        private System.Windows.Forms.ToolStripMenuItem MENU_EDIT_SEL_CANCEL;
        private System.Windows.Forms.ToolStripMenuItem MENU_EDIT_SpacialSearch;
        private System.Windows.Forms.ToolStripMenuItem MENU_EDIT_SpacialSearch_Identify;
        private System.Windows.Forms.ToolStripMenuItem MENU_EDIT_SpacialSearch_Attributes;
        private System.Windows.Forms.ToolStripMenuItem MENU_EDIT_SpacialSearch_Location;
        private System.Windows.Forms.ToolStripMenuItem MENU_EDIT_OBJ_MOVE;
        private System.Windows.Forms.ToolStripMenuItem MENU_EDIT_PT_SEL;
        private System.Windows.Forms.ToolStripMenuItem MENU_EDIT_PT_DEL;
        private System.Windows.Forms.ToolStripMenuItem MENU_EDIT_PT_MOVE;
        private System.Windows.Forms.ToolStripMenuItem MENU_EDIT_PT_ADD;
        private System.Windows.Forms.ToolStripMenuItem MENU_EDIT_PT_EDIT;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator16;
        private System.Windows.Forms.ToolStripMenuItem ͼ��ѡ��ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ͼ��ɾ��ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ͼ������ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ͼ��༭ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ��ͼToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem MENU_VIEW_GLOBAL;
        private System.Windows.Forms.ToolStripMenuItem MENU_VIEW_ZOOMIN;
        private System.Windows.Forms.ToolStripMenuItem MENU_VIEW_ZOOMOUT;
        private System.Windows.Forms.ToolStripMenuItem MENU_VIEW_ZOOMRECT;
        private System.Windows.Forms.ToolStripMenuItem MENU_VIEW_ZOOMEQUAL;
        private System.Windows.Forms.ToolStripMenuItem MENU_VIEW_PAN;
        private System.Windows.Forms.ToolStripMenuItem MENU_VIEW_SETSCALE;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator18;
        private System.Windows.Forms.ToolStripMenuItem MENU_VIEW_SETPOINT;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator19;
        private System.Windows.Forms.ToolStripMenuItem �������ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem ��������ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem �ܳ�����ToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator20;
        private System.Windows.Forms.ToolStripMenuItem ID_MENU_DATAMNG_SYMBOL;
        private System.Windows.Forms.ToolStripMenuItem MENU_VEDIOl;
        private System.Windows.Forms.ToolStripMenuItem MENU_VEDIO_SETTING;
        private System.Windows.Forms.ToolStripMenuItem MENU_VEDIO_START;
        private System.Windows.Forms.ToolStripMenuItem MENU_VEDIO_STOP;
        private System.Windows.Forms.ToolStripMenuItem MENU_EDIT_GPS;
        private ESRI.ArcGIS.Controls.AxMapControl axMapControl1;
        private ESRI.ArcGIS.Controls.AxLicenseControl axLicenseControl1;
        private ESRI.ArcGIS.Controls.AxToolbarControl axToolbarControl1;
        private ESRI.ArcGIS.Controls.AxToolbarControl axToolbarControlEdit;
        private System.Windows.Forms.ToolStripButton BTN_GPS_ON;
        private System.Windows.Forms.ToolStripButton BTN_GPS_OFF;
        private System.Windows.Forms.ToolStripButton BTN_GPS_NAVG;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator15;
        private System.Windows.Forms.ToolStripButton BTN_VIDEO_SET;
        private System.Windows.Forms.ToolStripButton BTN_VIDEO_START;
        private System.Windows.Forms.ToolStripButton BTN_VIDEO_STOP;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator21;
        private System.Windows.Forms.ToolStripButton BTN_VIDEO_WINDOW;
        private System.Windows.Forms.ToolStripButton BTN_PATH_EDIT;
        private System.Windows.Forms.ToolStripButton BTN_PATH_DEL;
        private System.Windows.Forms.ToolStripButton BTN_SAVE_YUTU;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator22;
        private System.Windows.Forms.ToolStripButton BTN_TOOL_IDLE;
        private System.Windows.Forms.ToolStripButton BTN_CLS_BACKGROUND;
        private System.Windows.Forms.ToolStripButton BTN_CLS_BUILDINGS;
        private System.Windows.Forms.ToolStripButton BTN_CLS_PATH;
        private System.Windows.Forms.ToolStripButton BTN_CLS_NEWPOI;
        private System.Windows.Forms.ToolStripButton BTN_CLS_POI;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator23;
        //private System.Windows.Forms.ToolBarButton toolBarButton_POI;
        //private System.Windows.Forms.ToolBarButton toolBarButton_NEWPOI;
        //private System.Windows.Forms.ToolBarButton toolBarButton_PATH;
        //private System.Windows.Forms.ToolBarButton toolBarButton_BUILD;
        //private System.Windows.Forms.ToolBarButton toolBarButton_AREA;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPageLayer;
        private ESRI.ArcGIS.Controls.AxTOCControl axTOCControl1;
        private System.Windows.Forms.ToolStripLabel toolStripLabel2;
        private System.Windows.Forms.ToolStripComboBox comboBox_scalebox;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator17;
        private System.Windows.Forms.ToolStripMenuItem MENU_VEDIO_PICTURE;
        private System.Windows.Forms.ToolStripMenuItem MENU_VEDIO_TIMESERIAL;
        private System.Windows.Forms.ToolStripMenuItem MENU_VEDIO_VEDIO;
        private System.Windows.Forms.ToolStripMenuItem MENU_VEDIO_WINDOW;
        private System.Windows.Forms.ToolStripMenuItem MENU_VEDIO_TIMESERIAL_STOP;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator24;
        private System.Windows.Forms.ToolStripMenuItem MENU_VEDIO_TIME_PRO;
        private System.Windows.Forms.ToolStripMenuItem MENU_GPS_SigalSimu;
        private System.Windows.Forms.ToolStripMenuItem MENU_GPS_SigalSimu_on;
        private System.Windows.Forms.ToolStripMenuItem MENU_GPS_SigalSimu_off;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.ToolStripMenuItem MENU_VEDIOr;
        private System.Windows.Forms.ToolStripMenuItem MENU_VEDIOr_SETTING;
        private System.Windows.Forms.ToolStripMenuItem MENU_VEDIOr_WINDOW;
        private System.Windows.Forms.ToolStripMenuItem MENU_VEDIOr_START;
        private System.Windows.Forms.ToolStripMenuItem MENU_VEDIOr_STOP;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator25;
        private System.Windows.Forms.ToolStripMenuItem MENU_VEDIOr_CAPTURE;
        private System.Windows.Forms.ToolStripMenuItem MENU_VEDIOr_SERIAL_S;
        private System.Windows.Forms.ToolStripMenuItem MENU_VEDIOr_SERIAL_T;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator26;
        private System.Windows.Forms.ToolStripMenuItem MENU_VEDIOr_VEDIO;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ToolStripMenuItem ʱ���������ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem MENU_GPS_SETTING2;
        private System.Windows.Forms.ToolStripMenuItem MENU_VEDIO_TIME_PRO2;
    }
}

