﻿namespace YuTuSurveyPlatform
{
    partial class GPS_SettingDlg
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonOK = new System.Windows.Forms.Button();
            this.buttonCANCEL = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox_sample = new System.Windows.Forms.TextBox();
            this.textBox_save = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.checkBox_navg = new System.Windows.Forms.CheckBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox_BautRate = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // buttonOK
            // 
            this.buttonOK.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.buttonOK.Location = new System.Drawing.Point(40, 217);
            this.buttonOK.Name = "buttonOK";
            this.buttonOK.Size = new System.Drawing.Size(104, 37);
            this.buttonOK.TabIndex = 0;
            this.buttonOK.Text = "确定";
            this.buttonOK.UseVisualStyleBackColor = true;
            this.buttonOK.Click += new System.EventHandler(this.buttonOK_Click);
            // 
            // buttonCANCEL
            // 
            this.buttonCANCEL.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.buttonCANCEL.Location = new System.Drawing.Point(176, 217);
            this.buttonCANCEL.Name = "buttonCANCEL";
            this.buttonCANCEL.Size = new System.Drawing.Size(104, 37);
            this.buttonCANCEL.TabIndex = 1;
            this.buttonCANCEL.Text = "取消";
            this.buttonCANCEL.UseVisualStyleBackColor = true;
            this.buttonCANCEL.Click += new System.EventHandler(this.buttonCANCEL_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(51, 119);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(131, 12);
            this.label1.TabIndex = 2;
            this.label1.Text = "GPS采集时间间隔（秒）";
            // 
            // textBox_sample
            // 
            this.textBox_sample.Location = new System.Drawing.Point(187, 116);
            this.textBox_sample.Name = "textBox_sample";
            this.textBox_sample.Size = new System.Drawing.Size(70, 21);
            this.textBox_sample.TabIndex = 3;
            this.textBox_sample.Text = "5";
            // 
            // textBox_save
            // 
            this.textBox_save.Location = new System.Drawing.Point(187, 146);
            this.textBox_save.Name = "textBox_save";
            this.textBox_save.Size = new System.Drawing.Size(70, 21);
            this.textBox_save.TabIndex = 5;
            this.textBox_save.Text = "5";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(51, 149);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(131, 12);
            this.label2.TabIndex = 4;
            this.label2.Text = "GPS存储时间间隔（分）";
            // 
            // checkBox_navg
            // 
            this.checkBox_navg.AutoSize = true;
            this.checkBox_navg.Checked = true;
            this.checkBox_navg.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox_navg.Location = new System.Drawing.Point(53, 176);
            this.checkBox_navg.Name = "checkBox_navg";
            this.checkBox_navg.Size = new System.Drawing.Size(72, 16);
            this.checkBox_navg.TabIndex = 6;
            this.checkBox_navg.Text = "导航地图";
            this.checkBox_navg.UseVisualStyleBackColor = true;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "COM1",
            "COM2",
            "COM3",
            "COM4"});
            this.comboBox1.Location = new System.Drawing.Point(120, 36);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(70, 20);
            this.comboBox1.TabIndex = 7;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(55, 39);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 12);
            this.label3.TabIndex = 8;
            this.label3.Text = "COM端口：";
            // 
            // textBox_BautRate
            // 
            this.textBox_BautRate.Location = new System.Drawing.Point(120, 65);
            this.textBox_BautRate.Name = "textBox_BautRate";
            this.textBox_BautRate.Size = new System.Drawing.Size(70, 21);
            this.textBox_BautRate.TabIndex = 10;
            this.textBox_BautRate.Text = "57600";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(55, 68);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 12);
            this.label4.TabIndex = 9;
            this.label4.Text = "比特率：";
            // 
            // GPS_SettingDlg
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(294, 266);
            this.Controls.Add(this.textBox_BautRate);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.checkBox_navg);
            this.Controls.Add(this.textBox_save);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox_sample);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buttonCANCEL);
            this.Controls.Add(this.buttonOK);
            this.Name = "GPS_SettingDlg";
            this.Text = "GPS相关参数设置窗口";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonOK;
        private System.Windows.Forms.Button buttonCANCEL;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox_sample;
        private System.Windows.Forms.TextBox textBox_save;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox checkBox_navg;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox_BautRate;
        private System.Windows.Forms.Label label4;
    }
}