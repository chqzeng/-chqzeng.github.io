﻿namespace MVDoubleVD
{
    partial class SaveSeries
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.PathtextBox = new System.Windows.Forms.TextBox();
            this.browserBtn = new System.Windows.Forms.Button();
            this.TimetextBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.OK = new System.Windows.Forms.Button();
            this.Cancel = new System.Windows.Forms.Button();
            this.folderBrowserDialog = new System.Windows.Forms.FolderBrowserDialog();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox_dist = new System.Windows.Forms.TextBox();
            this.radioButton_time = new System.Windows.Forms.RadioButton();
            this.radioButton_distance = new System.Windows.Forms.RadioButton();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "保存路径";
            // 
            // PathtextBox
            // 
            this.PathtextBox.Location = new System.Drawing.Point(74, 12);
            this.PathtextBox.Name = "PathtextBox";
            this.PathtextBox.Size = new System.Drawing.Size(156, 21);
            this.PathtextBox.TabIndex = 1;
            // 
            // browserBtn
            // 
            this.browserBtn.Location = new System.Drawing.Point(236, 12);
            this.browserBtn.Name = "browserBtn";
            this.browserBtn.Size = new System.Drawing.Size(43, 23);
            this.browserBtn.TabIndex = 2;
            this.browserBtn.Text = "浏览";
            this.browserBtn.UseVisualStyleBackColor = true;
            this.browserBtn.Click += new System.EventHandler(this.browserBtn_Click);
            // 
            // TimetextBox
            // 
            this.TimetextBox.Location = new System.Drawing.Point(182, 43);
            this.TimetextBox.Name = "TimetextBox";
            this.TimetextBox.Size = new System.Drawing.Size(62, 21);
            this.TimetextBox.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(120, 47);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 12);
            this.label2.TabIndex = 4;
            this.label2.Text = "时间间隔";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(250, 47);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 12);
            this.label3.TabIndex = 5;
            this.label3.Text = "毫秒";
            // 
            // OK
            // 
            this.OK.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.OK.Location = new System.Drawing.Point(64, 119);
            this.OK.Name = "OK";
            this.OK.Size = new System.Drawing.Size(75, 23);
            this.OK.TabIndex = 6;
            this.OK.Text = "保存";
            this.OK.UseVisualStyleBackColor = true;
            this.OK.Click += new System.EventHandler(this.OK_Click);
            // 
            // Cancel
            // 
            this.Cancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.Cancel.Location = new System.Drawing.Point(177, 119);
            this.Cancel.Name = "Cancel";
            this.Cancel.Size = new System.Drawing.Size(75, 23);
            this.Cancel.TabIndex = 7;
            this.Cancel.Text = "取消";
            this.Cancel.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(250, 82);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(17, 12);
            this.label4.TabIndex = 10;
            this.label4.Text = "米";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(120, 82);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 12);
            this.label5.TabIndex = 9;
            this.label5.Text = "距离间隔";
            // 
            // textBox_dist
            // 
            this.textBox_dist.Location = new System.Drawing.Point(182, 78);
            this.textBox_dist.Name = "textBox_dist";
            this.textBox_dist.Size = new System.Drawing.Size(62, 21);
            this.textBox_dist.TabIndex = 8;
            // 
            // radioButton_time
            // 
            this.radioButton_time.AutoSize = true;
            this.radioButton_time.Location = new System.Drawing.Point(14, 47);
            this.radioButton_time.Name = "radioButton_time";
            this.radioButton_time.Size = new System.Drawing.Size(71, 16);
            this.radioButton_time.TabIndex = 11;
            this.radioButton_time.TabStop = true;
            this.radioButton_time.Text = "时间模式";
            this.radioButton_time.UseVisualStyleBackColor = true;
            this.radioButton_time.CheckedChanged += new System.EventHandler(this.radioButton_time_CheckedChanged);
            // 
            // radioButton_distance
            // 
            this.radioButton_distance.AutoSize = true;
            this.radioButton_distance.Location = new System.Drawing.Point(14, 79);
            this.radioButton_distance.Name = "radioButton_distance";
            this.radioButton_distance.Size = new System.Drawing.Size(71, 16);
            this.radioButton_distance.TabIndex = 12;
            this.radioButton_distance.TabStop = true;
            this.radioButton_distance.Text = "距离模式";
            this.radioButton_distance.UseVisualStyleBackColor = true;
            this.radioButton_distance.CheckedChanged += new System.EventHandler(this.radioButton_distance_CheckedChanged);
            // 
            // SaveSeries
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(294, 154);
            this.Controls.Add(this.radioButton_distance);
            this.Controls.Add(this.radioButton_time);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.textBox_dist);
            this.Controls.Add(this.Cancel);
            this.Controls.Add(this.OK);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.TimetextBox);
            this.Controls.Add(this.browserBtn);
            this.Controls.Add(this.PathtextBox);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "SaveSeries";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "直接采序列";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button browserBtn;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button OK;
        private System.Windows.Forms.Button Cancel;
        public System.Windows.Forms.TextBox PathtextBox;
        public System.Windows.Forms.TextBox TimetextBox;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        public System.Windows.Forms.TextBox textBox_dist;
        public System.Windows.Forms.RadioButton radioButton_time;
        public System.Windows.Forms.RadioButton radioButton_distance;
    }
}