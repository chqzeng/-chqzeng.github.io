using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace MVDoubleVD
{
    /// <summary>
    /// ���ļ���ԭ�� ��Ƶ ���̣������򵥵��޸ģ���ϸ��鿴[��������\MV-VD VS VE Camera\SDK\SDK������\����˵��\WDMIATvb7.chm]
    /// </summary>
    /// 
    public partial class MVDoubleVD : Form
    {
        // This attribute controls whether the live display is scaled in order
        // to match the size of the WDMIAT Control window on the form.
        private bool m_bFitImageToWindow = true;
        private bool m_bLeftStart = false;
        private bool m_bRightStart = false;
        private bool m_bLeftStop = false;
        private bool m_bRightStop = false;
        private bool m_bIsLeftSaved = false;
        private bool m_bIsRightSaved = false;
        private bool m_bLeftSaveDisk = false;
        private bool m_bRightSaveDisk = false;
        private bool m_bAllSaveDisk = false;
        int leftcounter = 0;
        int rightcounter = 0;
        int singlecounter = 0;
        public string m_strLeftPath = "";
        private string m_strRightPath = "";
        private string m_strLMemTime = "";
        private string m_strRMemTime = "";

        public string m_strLDiskTime = "1000";
        public string m_strLDiskDist = "5";

        private string m_strRDiskTime = "";
        private string m_strAllDiskTime = "";
        private string m_strAllMemTime = "";
        private bool m_bIsLeftFull = false;
        private bool m_bIsRightFull = false;

        private Thread ThreadLeft;
        private Thread ThreadRight;

        SaveSeries dlg = new SaveSeries();
        public string m_strSavePath = "C:\\photo_";
        public bool m_bTimeMode = false;
        public bool m_bIsImageGrabStat = false;

        RecordVideo dlgSaveVideo = null;
        private YuTuSurveyPlatform.MainInterface m_parent = null;

        private delegate void DeviceLostDelegate();

        private delegate void ShowBufferDelegate(IAT.Imaging.ImageBuffer buffer);

        public MVDoubleVD(YuTuSurveyPlatform.MainInterface parent)
        {
            InitializeComponent();
            m_parent = parent;
        }
        public void SetParent(YuTuSurveyPlatform.MainInterface parent)
        {
            m_parent = parent;
        }

        private void MVDoubleVD_Load(object sender, EventArgs e)
        {
            // Try to load the previously used device. 
            try
            {
                //this.WindowState = FormWindowState.Maximized;
                LeftCamera.LoadDeviceStateFromFile("LeftCamera.xml", true);
                //RightCamera.LoadDeviceStateFromFile("RightCamera.xml", true);
            }
            catch
            {
                // Either the xml file does not exist or the device
                // could not be loaded. In both cases we do nothing and proceed.
            }

            if (m_bFitImageToWindow)
            {
                // Adjust live display size to the control size.
                LeftCamera.LiveDisplayDefault = false;
                LeftCamera.LiveDisplayHeight = LeftCamera.Height;
                LeftCamera.LiveDisplayWidth = LeftCamera.Width;

                RightCamera.LiveDisplayDefault = false;
                RightCamera.LiveDisplayHeight = RightCamera.Height;
                RightCamera.LiveDisplayWidth = RightCamera.Width;
            }

        }
        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            this.Hide();
        }

        public void ExitWindow(bool disposing)
        {
            Close();

            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        /// <summary>
        /// Stop the live video stream, if the application is closed.
        /// </summary>
        private void MVDoubleVD_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (LeftCamera.DeviceValid)
            {
                LeftCamera.LiveStop();
            }
            //if (RightCamera.DeviceValid)
            //{
            //    RightCamera.LiveStop();
            //}
            this.Hide();
            return;
        }
        public bool IsDeviceValid()
        {
            return LeftCamera.DeviceValid;
        }
        /// <summary>
        /// Adjust live display size to the control size.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MVDoubleVD_SizeChanged(object sender, EventArgs e)
        {
            if (m_bFitImageToWindow)
            {
                LeftCamera.Width = Width / 2 - 1;
                RightCamera.Width = Width / 2 - 1;
                LeftCamera.Height = (int)LeftCamera.Width * 3 / 4;
                RightCamera.Height = (int)RightCamera.Width * 3 / 4;
                if (LeftCamera.DeviceValid)
                {
                    LeftCamera.LiveDisplayHeight = LeftCamera.Height;
                    LeftCamera.LiveDisplayWidth = LeftCamera.Width;

                }
                if (RightCamera.DeviceValid)
                {
                    RightCamera.LiveDisplayHeight = RightCamera.Height;
                    RightCamera.LiveDisplayWidth = RightCamera.Width;

                }
            }
        }


        /// <summary>
        /// Start the live video and update the state of the start/stop button.
        /// </summary>
        private void StartLiveVideo()
        {
            try
            {
                LeftCamera.LiveStart();
                m_bLeftStart = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            //try
            //{
            //    RightCamera.LiveStart();
            //    m_bRightStart = true;
            //}
            //catch (Exception ex)
            //{
            //    MessageBox.Show(ex.Message);
            //}
            
           
        }

        /// <summary>
        /// Show the device selection dialog of WDMIAT Control.
        /// </summary>
        private void OpenNewVideoCaptureDevice()
        {
            if (LeftCamera == null)
            {
                try
                {
                    LeftCamera.LoadDeviceStateFromFile("LeftCamera.xml", true);
                }
                catch
                {
                }
            }
            if (LeftCamera.DeviceValid)
            {
                LeftCamera.LiveStop();
            }
            else
            {
                LeftCamera.Device = "";
            }
            LeftCamera.ShowDeviceSettingsDialog();
            if (LeftCamera.DeviceValid)
            {
                // Save the currently used device into a file in order to be able to open it
                // automatically at the next program start.
                LeftCamera.SaveDeviceStateToFile("LeftCamera.xml");
            }
            return;

            //if (RightCamera.DeviceValid)
            //{
            //    RightCamera.LiveStop();
            //}
            //else
            //{
            //    RightCamera.Device = "";
            //}
            //RightCamera.ShowDeviceSettingsDialog();
            //if (RightCamera.DeviceValid)
            //{
            //    // Save the currently used device into a file in order to be able to open it
            //    // automatically at the next program start.
            //    RightCamera.SaveDeviceStateToFile("RightCamera.xml");
            //}
        }

        /// <summary>
        /// Show the device's property dialog for modifying exposure, brightness etc. 
        /// All changes are saved to the file 'device.xml'.
        /// </summary>
        private void ShowDeviceProperties()
        {
            if (LeftCamera.DeviceValid)
            {
                LeftCamera.ShowPropertyDialog();
                LeftCamera.SaveDeviceStateToFile("LeftCamera.xml");
            }
        }

        /// <summary>
        /// Show the device selection dialog of WDMIAT Control.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cmdDevice_Click(object sender, EventArgs e)
        {
            OpenNewVideoCaptureDevice();
        }

        /// <summary>
        /// Show the device's property dialog for exposure, brightness etc.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cmdProperties_Click(object sender, EventArgs e)
        {
            ShowDeviceProperties();
        }


        /// <summary>
        /// Handle the DeviceLost event.
        /// </summary>
        private void DeviceLost()
        {
            MessageBox.Show("Device Lost!");
        }

        private void LeftCamera_DeviceLost(object sender, EventArgs e)
        {
            BeginInvoke(new DeviceLostDelegate(ref DeviceLost));
        }
        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenAndSettingDevice();
            //if (RightCamera.DeviceValid)
            //{
            //    rightCameraToolStripMenuItem.Enabled = true;
            //    RightRecordVideo.Enabled = true;
            //}   
        }
        public void OpenAndSettingDevice()
        {
            OpenNewVideoCaptureDevice();
            startToolStripMenuItem.Enabled = true;
            stopToolStripMenuItem.Enabled = true;
            if (LeftCamera.DeviceValid)
            {
                leftCamToolStripMenuItem.Enabled = true;
                LeftRecordVideo.Enabled = true;
            }
        }
        public void StartDevice()
        {
            StartLiveVideo();
            if (LeftCamera.DeviceValid)
            {
                leftCamToolStripMenuItem.Enabled = true;
                LeftRecordVideo.Enabled = true;

            }
            stopToolStripMenuItem.Enabled = true;
            recordVideoToolStripMenuItem.Enabled = true;
            if (m_bRightStart || m_bLeftStart)
            {
                SaveToolStripMenuItem.Enabled = true;
            }
            if (m_bLeftStart)
            {
                leftSaveToolStripMenuItem.Enabled = true;
            }
        }
        private void startToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StartDevice();
            return;

            StartLiveVideo();
            if (LeftCamera.DeviceValid)
            {
                leftCamToolStripMenuItem.Enabled = true;
                LeftRecordVideo.Enabled = true;

            }
            //if (RightCamera.DeviceValid)
            //{
            //    rightCameraToolStripMenuItem.Enabled = true;
            //    LeftRecordVideo.Enabled = true;
            //} 
            stopToolStripMenuItem.Enabled = true;
            recordVideoToolStripMenuItem.Enabled = true;
            if (m_bRightStart || m_bLeftStart)
            {
                SaveToolStripMenuItem.Enabled = true;
            }
            if (m_bLeftStart)
            {
                leftSaveToolStripMenuItem.Enabled = true;
            }
            //if (m_bRightStart)
            //{
            //    rightSaveToolStripMenuItem.Enabled = true;
            //    rightSaveToolStripMenuItem.Visible = true;
            //}
            //if (m_bRightStart && m_bLeftStart)
            //{
            //    allSaveToolStripMenuItem.Enabled = true;
            //    allSaveToolStripMenuItem.Visible = true;
            //}

        }

        private void stopToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeftCamera.LiveStop();
            RightCamera.LiveStop();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide(); 
        }
        
        private void startLeftToolStripMenuItem_Click(object sender, EventArgs e)
        {

            startToolStripMenuItem_Click(sender, e);
           
            //LeftCamera.LiveStart();
            m_bLeftStart = true;
            leftSaveToolStripMenuItem.Enabled = true;
            stopLeftToolStripMenuItem.Enabled = true;
            fullScreenLeft.Enabled = true;

            return;
            if (m_bRightStart && m_bLeftStart)
            {
                allSaveToolStripMenuItem.Enabled = true;
                allSaveToolStripMenuItem.Visible = true;
            }


        }

        public void StopDevice()
        {
            LeftCamera.LiveStop();
            m_bLeftStart = false;
            leftSaveToolStripMenuItem.Enabled = false;
            allSaveToolStripMenuItem.Enabled = false;
            allSaveToolStripMenuItem.Visible = false;
            stopLeftToolStripMenuItem.Enabled = false;
            fullScreenLeft.Enabled = false;
        }

        private void stopLeftToolStripMenuItem_Click(object sender, EventArgs e)
        {

            StopDevice();
        }

        private void setLetfToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (LeftCamera.DeviceValid)
            {
                LeftCamera.LiveStop();
                m_bLeftStop = true;
                m_bLeftStart = false;
                LeftCamera.ShowDeviceSettingsDialog();
                LeftCamera.SaveDeviceStateToFile("LeftCamera.xml");              
            }
            
            LeftCamera.LiveStart();
            m_bLeftStop = false;
            m_bLeftStart = true;

        }

        private void propertyLeftToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (LeftCamera.DeviceValid)
            {
                LeftCamera.ShowPropertyDialog();
                LeftCamera.SaveDeviceStateToFile("LeftCamera.xml");
            }
        }

        private void startRightToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RightCamera.LiveStart();
            m_bRightStart = true;
            m_bRightStop = false;
            rightSaveToolStripMenuItem.Enabled = true;
            rightSaveToolStripMenuItem.Visible = true;
            stopRightToolStripMenuItem.Enabled = true;
            fullScreenRight.Enabled = true;
            if (m_bRightStart && m_bLeftStart)
            {
                allSaveToolStripMenuItem.Enabled = true;
                allSaveToolStripMenuItem.Visible = true;
            }

        }

        private void stopRightToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RightCamera.LiveStop();
            m_bRightStart = false;
            m_bRightStop = true;
            rightSaveToolStripMenuItem.Enabled = false;
            rightSaveToolStripMenuItem.Visible = false;
            allSaveToolStripMenuItem.Enabled = false;
            allSaveToolStripMenuItem.Visible = false;
            stopRightToolStripMenuItem.Enabled = false;
            fullScreenRight.Enabled = false;
        }

        private void setRightToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (LeftCamera.DeviceValid)
            {
                RightCamera.LiveStop();
                m_bRightStop = true;
                m_bRightStart = false;
                RightCamera.ShowDeviceSettingsDialog();
                RightCamera.SaveDeviceStateToFile("RightCamera.xml");
            }
            
            RightCamera.LiveStart();
            m_bRightStop = false;
            m_bRightStart = true;
        }

        private void propertyRightToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (RightCamera.DeviceValid)
            {
                RightCamera.ShowPropertyDialog();
                RightCamera.SaveDeviceStateToFile("RightCamera.xml");
            }
        }

        private void leftSingleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }
        public void SaveCurrentWindow()
        {
            try
            {
                SaveFileDialog savefileDialog = new SaveFileDialog();
                LeftCamera.MemorySnapImage();//jpeg files (*.jpg)|*.jpg|
                savefileDialog.Filter = "bmp files (*.bmp)|*.bmp|All files (*.*)|*.*";
                savefileDialog.FilterIndex = 1;
                savefileDialog.RestoreDirectory = true;

                if (savefileDialog.ShowDialog() == DialogResult.OK)
                {
                    m_strLeftPath = savefileDialog.FileName;
                    LeftCamera.MemorySaveImage(m_strLeftPath);
                }
            }
            catch (Exception ex) { }
        }
       

        private void rightSingleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog savefileDialog = new SaveFileDialog();
            RightCamera.MemorySnapImage();
            savefileDialog.Filter = "bmp files (*.bmp)|*.bmp|All files (*.*)|*.*";
            savefileDialog.FilterIndex = 1;
            savefileDialog.RestoreDirectory = true;

            if (savefileDialog.ShowDialog() == DialogResult.OK)
            {
                m_strRightPath = savefileDialog.FileName;
                RightCamera.MemorySaveImage(m_strRightPath);
            }
        }

        private void leftDiskToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveSerialPictures();
        }
        public void SaveSerialPictures()
        {
            if (!System.IO.Directory.Exists(m_strSavePath))
                System.IO.Directory.CreateDirectory(m_strSavePath);

            //SaveSeries dlg = new SaveSeries();
            //dlg.PathtextBox.Text = m_strLeftPath;
            //dlg.TimetextBox.Text = m_strLDiskTime;
            //if (dlg.ShowDialog() == DialogResult.OK)

            if (m_bTimeMode)
            {
                m_bLeftSaveDisk = true;
                //m_strLeftPath = dlg.PathtextBox.Text;
                //m_strLDiskTime = dlg.TimetextBox.Text;\
                //m_strSavePath = System.IO.Path.GetDirectoryName(m_strSavePath);
                timerLeft.Interval = int.Parse(m_strLDiskTime);
                timerLeft.Enabled = true;
            }
            else 
            {
                m_bIsImageGrabStat = true;
            }

        }
        public bool SettingSerialTimeProperty()
        {
            dlg.PathtextBox.Text = m_strSavePath;
            dlg.TimetextBox.Text = m_strLDiskTime;
            dlg.textBox_dist.Text = m_strLDiskDist;
            if (m_bTimeMode) dlg.radioButton_time.Checked = true;
            else dlg.radioButton_distance.Checked = true;

            if (dlg.ShowDialog() == DialogResult.OK)
            {
                m_strSavePath = dlg.PathtextBox.Text;
                m_bTimeMode = dlg.m_bTimeMode;
                if (dlg.m_bTimeMode)
                    m_strLDiskTime = dlg.TimetextBox.Text;
                else
                    m_strLDiskDist = dlg.textBox_dist.Text;

                if (!System.IO.Directory.Exists(m_strSavePath))
                    System.IO.Directory.CreateDirectory(m_strSavePath);

                return true;
            }
            else return false;
        }
        private void timerLeft_Tick(object sender, EventArgs e)
        {
            if (!m_bTimeMode) return; //����ʱ�����ɼ�ģʽ 

            //string filename;
            //LeftCamera.MemorySnapImage();
            //filename = string.Format("{0:D2}", leftcounter);
            //filename = m_strSavePath + "\\MV-Left" + filename + ".bmp";
            //try
            //{
            //    LeftCamera.MemorySaveImage(filename);
            //}
            //catch { }

            //leftcounter++;
            m_parent.SaveImageFramebyTime(m_parent.curLong,m_parent.curLat);
        }
        

        public void StopTimeSerial()
        {
            if (m_bTimeMode)
            {
                timerLeft.Enabled = false;
                m_bLeftSaveDisk = false;
            }
            else
                m_bIsImageGrabStat = false;
        }
        private void lDiskStopToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StopTimeSerial();
        }

        private void rightDiskToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveSeries dlg = new SaveSeries();
            dlg.PathtextBox.Text = m_strRightPath;
            dlg.TimetextBox.Text = m_strRDiskTime;
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                m_bRightSaveDisk = true;
                m_strRightPath = dlg.PathtextBox.Text;
                m_strRDiskTime = dlg.TimetextBox.Text;
                timerRight.Interval = int.Parse(dlg.TimetextBox.Text);
                timerRight.Enabled = true;
            }
        }

        private void timerRight_Tick(object sender, EventArgs e)
        {
            string filename;
            RightCamera.MemorySnapImage();
            filename = string.Format("{0:D2}", rightcounter);
            filename = m_strLeftPath + "\\MV-Right" + filename + ".bmp";
            RightCamera.MemorySaveImage(filename);
            rightcounter++;
        }

        private void leftMemoryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveMemory saveMemory = new SaveMemory();
            string filename;
            try
            {
                saveMemory.PathtextBox.Text = m_strLeftPath;
                saveMemory.TimetextBox.Text = m_strLMemTime;
                if (saveMemory.ShowDialog() == DialogResult.OK)
                {
                    int NumberOfImages = (int)LeftCamera.DeviceFrameRate * Int32.Parse(saveMemory.TimetextBox.Text);
                    LeftCamera.LiveStop();
                    LeftCamera.ImageRingBufferSize = NumberOfImages;
                    LeftCamera.MemorySnapImageSequence(NumberOfImages);
                    LeftCamera.LiveStart();
                    m_strLeftPath = saveMemory.PathtextBox.Text;
                    m_strLMemTime = saveMemory.TimetextBox.Text;
                    filename = m_strLeftPath + "\\MV-Left*" + ".bmp";
                    LeftCamera.MemorySaveImageSequence(NumberOfImages, filename);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void righMemoryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveMemory saveMemory = new SaveMemory();
            string filename;
            try
            {
                saveMemory.PathtextBox.Text = m_strRightPath;
                saveMemory.TimetextBox.Text = m_strRMemTime;
                if (saveMemory.ShowDialog() == DialogResult.OK)
                {
                    int NumberOfImages = (int)RightCamera.DeviceFrameRate * Int32.Parse(saveMemory.TimetextBox.Text);
                    RightCamera.LiveStop();
                    RightCamera.ImageRingBufferSize = NumberOfImages;
                    RightCamera.MemorySnapImageSequence(NumberOfImages);
                    RightCamera.LiveStart();
                    m_strRightPath = saveMemory.PathtextBox.Text;
                    m_strRMemTime = saveMemory.TimetextBox.Text;
                    filename = m_strRightPath + "\\MV-Right*" + ".bmp";
                    RightCamera.MemorySaveImageSequence(NumberOfImages, filename);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void rDiskStopToolStripMenuItem_Click(object sender, EventArgs e)
        {
            timerRight.Enabled = false;
            m_bRightSaveDisk = false;
        }

        private void pathTimeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SetPathTime setpathTime = new SetPathTime();
            setpathTime.LeftPathtextBox.Text = m_strLeftPath;
            setpathTime.RightPathtextBox.Text = m_strRightPath;
            setpathTime.DiskTimetextBox.Text = m_strAllDiskTime;
            setpathTime.MemTimetextBox.Text = m_strAllMemTime;
            if (setpathTime.ShowDialog() == DialogResult.OK)
            {
                m_strLeftPath = setpathTime.LeftPathtextBox.Text;
                m_strRightPath = setpathTime.RightPathtextBox.Text;
                m_strAllDiskTime = setpathTime.DiskTimetextBox.Text;
                m_strAllMemTime = setpathTime.MemTimetextBox.Text;
            }
        }

        private void saveSingleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (m_strLeftPath == "")
            {
                MessageBox.Show("������洢·��Ϊ��");
            }
            else if (m_strRightPath == "")
            {
                MessageBox.Show("������洢·��Ϊ��");
            }
            else
            {
                LeftCamera.MemorySnapImage();
                RightCamera.MemorySnapImage();
                string filenameLeft = string.Format("\\MV-Left"+"{0:D3}"+".bmp", singlecounter);
                string filenameRight=string.Format("\\MV-Right"+"{0:D3}"+".bmp", singlecounter);
                filenameLeft = m_strLeftPath + filenameLeft;
                filenameRight = m_strRightPath + filenameRight;
                LeftCamera.MemorySaveImage(filenameLeft);
                RightCamera.MemorySaveImage(filenameRight);
                singlecounter++;
            }
        }

        private void allToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!m_bAllSaveDisk)
            {
                
                if (m_strLeftPath == "")
                {
                    MessageBox.Show("������洢·��Ϊ��");
                }
                else if (m_strRightPath == "")
                {
                    MessageBox.Show("������洢·��Ϊ��");
                }
                else if (m_strAllDiskTime == "")
                {
                    MessageBox.Show("ʱ����Ϊ��");
                }
                else
                {
                    

                    timerAll.Interval = int.Parse(m_strAllDiskTime);
                    timerAll.Enabled = true;
                    m_bAllSaveDisk = true;
                }

            }
        }

        private void LeftCameraDisk()
        {
            DateTime currentTime = new DateTime();
            currentTime = DateTime.Now;
            LeftCamera.MemorySnapImage();
            string dt = "-"+currentTime.Hour.ToString() + "-" + currentTime.Minute.ToString() + "-" + currentTime.Second.ToString() + "-" + currentTime.Millisecond.ToString() + "-";
            //,currentTime.Minute,currentTime.Second
            string filenameLeft = string.Format("\\MV-Left" + "{0:D3}" +dt+".bmp", singlecounter);
            filenameLeft = m_strLeftPath + filenameLeft;
            LeftCamera.MemorySaveImage(filenameLeft);
        }

        private void RightCameraDisk()
        {
            DateTime currentTime = new DateTime();
            currentTime = DateTime.Now;
            LeftCamera.MemorySnapImage();
            string dt = "-" + currentTime.Hour.ToString() + "-" + currentTime.Minute.ToString() + "-" + currentTime.Second.ToString() + "-" + currentTime.Millisecond.ToString() + "-";
            RightCamera.MemorySnapImage();
            string filenameRight = string.Format("\\MV-Right" + "{0:D3}" +dt+".bmp", singlecounter);
            filenameRight = m_strRightPath + filenameRight;
            RightCamera.MemorySaveImage(filenameRight);
        }

        private void timerAll_Tick(object sender, EventArgs e)
        {

            ThreadLeft = new Thread(new ThreadStart(LeftCameraDisk));
            ThreadRight = new Thread(new ThreadStart(RightCameraDisk));
            ThreadLeft.Start();
            ThreadRight.Start();
            singlecounter++;
        }

        private void aDiskStopToolStripMenuItem_Click(object sender, EventArgs e)
        {
            timerAll.Enabled = false;
            m_bAllSaveDisk = false;
            ThreadLeft.Abort();
            ThreadRight.Abort();
        }

        private void LeftCameraToMemory()
        {
            int NumImageLeft = (int)LeftCamera.DeviceFrameRate * Int32.Parse(m_strAllMemTime);
            string filenameLeft = m_strLeftPath + "\\MV-Left-*" + ".bmp";
            try
            {
                LeftCamera.LiveStop();
                LeftCamera.ImageRingBufferSize = NumImageLeft;
                LeftCamera.MemorySnapImageSequence(NumImageLeft);
                //LeftCamera.LiveStart();
                LeftCamera.MemorySaveImageSequence(NumImageLeft, filenameLeft);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            MessageBox.Show("�������,���ٴ��������");
        }
            
        private void RightCameraToMemory()
        {
            int NumImageRight = (int)RightCamera.DeviceFrameRate * Int32.Parse(m_strAllMemTime);
            string filenameRight = m_strRightPath + "\\MV-Right-*" + ".bmp";
            try
            {
                RightCamera.LiveStop();
                RightCamera.ImageRingBufferSize = NumImageRight;
                RightCamera.MemorySnapImageSequence(NumImageRight);
                //RightCamera.LiveStart();
                RightCamera.MemorySaveImageSequence(NumImageRight, filenameRight);

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
           
        }


        private void ThreadStart()
        {
            ThreadLeft.Start();
            ThreadRight.Start();
        }

        private void allToMemmoryToolStripMenuItem_Click(object sender, EventArgs e)
        {

            ThreadLeft = new Thread(new ThreadStart(LeftCameraToMemory));
            ThreadRight = new Thread(new ThreadStart(RightCameraToMemory));
            ThreadStart();
        }

              private void fullScreenLeft_Click(object sender, EventArgs e)
        {
            if (!m_bIsLeftFull)
            {
                this.WindowState = FormWindowState.Maximized;
                RightCamera.LiveStop();
                RightCamera.Enabled = false;
                RightCamera.Visible = false;

                LeftCamera.LiveStart();
                LeftCamera.Visible = true;
                LeftCamera.Enabled = true;

                LeftCamera.Width = Width;
                LeftCamera.Height = Height;
                LeftCamera.LiveDisplayHeight = LeftCamera.Height;
                LeftCamera.LiveDisplayWidth = LeftCamera.Width;
                m_bIsLeftFull = true;
                fullScreenLeft.Text = "�ָ�";
                fullScreenRight.Enabled = false;
                rightSaveToolStripMenuItem.Enabled = false;
                rightSaveToolStripMenuItem.Visible = false;
                allSaveToolStripMenuItem.Enabled = false;
                

            }
            else
            {
                if (m_bRightStart)
                {
                    RightCamera.LiveStart();
                }
                
                RightCamera.Visible = true;
                RightCamera.Enabled = true;
   
                LeftCamera.Width = Width / 2 - 1;
                LeftCamera.Height = (int)LeftCamera.Width * 3 / 4;
                LeftCamera.LiveDisplayHeight = RightCamera.Height;
                LeftCamera.LiveDisplayWidth = RightCamera.Width;
                m_bIsLeftFull = false;
                fullScreenLeft.Text = "ȫ��";
                fullScreenRight.Enabled = true;
                rightSaveToolStripMenuItem.Enabled = true;
                allSaveToolStripMenuItem.Enabled = true;

            }

        }

        private void fullScreenRight_Click(object sender, EventArgs e)
        {
            if (!m_bIsRightFull)
            {
                this.WindowState = FormWindowState.Maximized;
                LeftCamera.LiveStop();
                LeftCamera.Enabled = false;
                LeftCamera.Visible = false;

                RightCamera.LiveStart();
                RightCamera.Visible = true;
                RightCamera.Enabled = true;

                this.RightCamera.Location = new System.Drawing.Point(0, 27);
                RightCamera.Width = Width;
                RightCamera.Height = Height;
                RightCamera.LiveDisplayHeight = RightCamera.Height;
                RightCamera.LiveDisplayWidth = RightCamera.Width;
                m_bIsRightFull = true;
                fullScreenRight.Text = "�ָ�";
                fullScreenLeft.Enabled = false;
                allSaveToolStripMenuItem.Enabled = false;
                leftSaveToolStripMenuItem.Enabled = false;
            }
            else
            {
                if (m_bLeftStart)
                { 
                    LeftCamera.LiveStart(); 
                }
                
                LeftCamera.Visible = true;
                LeftCamera.Enabled = true;
                this.RightCamera.Location = new System.Drawing.Point(Width / 2 - 1, 27);
                RightCamera.Width = Width / 2 - 1;
                RightCamera.Height = (int)LeftCamera.Width * 3 / 4;
                RightCamera.LiveDisplayHeight = RightCamera.Height;
                RightCamera.LiveDisplayWidth = RightCamera.Width;
                m_bIsRightFull = false;
                fullScreenRight.Text = "ȫ��";
                fullScreenLeft.Enabled = true;
                allSaveToolStripMenuItem.Enabled = true;
                leftSaveToolStripMenuItem.Enabled = true;

            }
        }
        public void VideoObtain()
        {
            if (LeftCamera != null)
            {
                //RecordVideo dlg = new RecordVideo(LeftCamera);
                dlgSaveVideo = new RecordVideo(LeftCamera);
                dlgSaveVideo.LeftorRight = true;
                dlgSaveVideo.Text = "���¼��";
                dlgSaveVideo.ShowDialog();
            }
        }
        private void LeftRecordVideo_Click(object sender, EventArgs e)
        {
            VideoObtain();
        }

        private void RightRecordVideo_Click(object sender, EventArgs e)
        {
            if (RightCamera != null)
            {
                RecordVideo dlg = new RecordVideo(RightCamera);
                dlg.LeftorRight = false;
                dlg.Text = "¼��-�����";
                dlg.ShowDialog();

            }
        }

        private void RightCamera_DeviceLost(object sender, EventArgs e)
        {
            BeginInvoke(new DeviceLostDelegate(ref DeviceLost));
        }

        #region ������� ����
        /// <summary>
        /// Saves the current window ex.��ͼ��ǰ����
        /// </summary>
        /// <param name="strImagePath">The STR image path.���� �ļ�·�� </param>
        public void SaveCurrentWindowEx(string strImagePath)
        {
            try
            {
                LeftCamera.MemorySnapImage();
                //LeftCamera.MemorySaveImage(strImagePath);
                Bitmap bmp = LeftCamera.ImageActiveBuffer.Bitmap;
                bmp.Save(strImagePath,System.Drawing.Imaging.ImageFormat.Jpeg);
            }
            catch { }
        }
        #endregion
    }
}

