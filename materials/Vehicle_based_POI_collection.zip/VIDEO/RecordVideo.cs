﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace MVDoubleVD
{
    /// <summary>
    /// 该文件来原于 视频 产商，并作简单的修改，详细请查看[驱动光盘\MV-VD VS VE Camera\SDK\SDK开发包\开发说明\WDMIATvb7.chm]
    /// </summary>
    /// 
    public partial class RecordVideo : Form
    {
        private IAT.Imaging.WDMIAT m_CameraHandler;
        private IAT.Imaging.BaseSink m_OldSink;
        private bool m_OldLiveMode;
        private IAT.Imaging.MediaStreamSink m_Sink;
        private bool IsPause = false;
        public bool LeftorRight = true;

        public RecordVideo( IAT.Imaging.WDMIAT ic)
        {
            InitializeComponent();
            m_CameraHandler = ic;
        }

        private IAT.Imaging.MediaStreamContainer CurrentMediaStreamContainer
        {
            get
            {
                return (IAT.Imaging.MediaStreamContainer)comBoxMediaStreamContainer.SelectedItem;
            }
        }

        private IAT.Imaging.AviCompressor CurrentVideoCodec
        {
            get
            {
                if (CurrentMediaStreamContainer.IsCustomCodecSupported)
                {
                    if (comBoxVideoCodec.SelectedItem == null) comBoxVideoCodec.SelectedItem = 0;
                    return (IAT.Imaging.AviCompressor)comBoxVideoCodec.SelectedItem;
                }
                else
                {
                    return null;
                }
            }
        }

        private void RecordVideo_Load(object sender, EventArgs e)
        {
            comBoxMediaStreamContainer.DataSource = m_CameraHandler.MediaStreamContainers;
            comBoxVideoCodec.DataSource = m_CameraHandler.AviCompressors;
            if (LeftorRight)
            {
                txtFileName.Text = System.IO.Path.ChangeExtension("LeftCamera.avi", CurrentMediaStreamContainer.PreferredFileExtension);
            }
            else
            {
                txtFileName.Text = System.IO.Path.ChangeExtension("RightCamera.avi", CurrentMediaStreamContainer.PreferredFileExtension);
            }
            btnStopCapture.Enabled = false;
        }

        private void btnStartCapture_Click(object sender, EventArgs e)
        {
            m_Sink = new IAT.Imaging.MediaStreamSink();
            m_Sink.StreamContainer = CurrentMediaStreamContainer;
            m_Sink.Codec = CurrentVideoCodec;
            m_Sink.Filename = txtFileName.Text;
            m_Sink.SinkModeRunning = !IsPause;
            m_OldLiveMode = m_CameraHandler.LiveVideoRunning;
            m_OldSink = m_CameraHandler.Sink;
            m_CameraHandler.LiveStop();
            m_CameraHandler.Sink = m_Sink;
            m_CameraHandler.LiveStart();
            btnStartCapture.Enabled = false;
            btnStopCapture.Enabled = true;
            btnClose.Enabled = false;
            
        }

        private void btnStopCapture_Click(object sender, EventArgs e)
        {
            m_CameraHandler.LiveStop();
            IsPause = false;
            btnStartCapture.Enabled = true;
            btnStopCapture.Enabled = false;
            btnClose.Enabled = true;
            m_CameraHandler.Sink = m_OldSink;
            if (m_OldLiveMode)
            {
                m_CameraHandler.LiveStart();
                
            }

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnBrowser_Click(object sender, EventArgs e)
        {
            SaveFileDialog dlg = new SaveFileDialog();
            dlg.AddExtension = true;

            string ext = CurrentMediaStreamContainer.PreferredFileExtension;
            dlg.DefaultExt = ext;
            dlg.Filter = CurrentMediaStreamContainer.Name
                        + " Video Files (*." + ext + ")|*." + ext + "||";

            if (dlg.ShowDialog() == DialogResult.OK)
            {
                txtFileName.Text = dlg.FileName;
            }
        }

        private void btnProperties_Click(object sender, EventArgs e)
        {
            CurrentVideoCodec.ShowPropertyPage();
        }

        private void comBoxMediaStreamContainer_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (CurrentMediaStreamContainer.IsCustomCodecSupported)
                {
                    comBoxVideoCodec.Enabled = true;
                    btnProperties.Enabled = CurrentVideoCodec.PropertyPageAvailable;
                }
                else
                {
                    comBoxVideoCodec.Enabled = false;
                    btnProperties.Enabled = false;
                }
            }
            catch { }
            txtFileName.Text = System.IO.Path.ChangeExtension(txtFileName.Text, CurrentMediaStreamContainer.PreferredFileExtension);
        }

        private void comBoxVideoCodec_SelectedIndexChanged(object sender, EventArgs e)
        {
            btnProperties.Enabled = CurrentVideoCodec.PropertyPageAvailable;
        }

        private void btnPause_Click(object sender, EventArgs e)
        {
            
            if (!IsPause)
            {
                if (m_Sink != null)
                {
                    m_Sink.SinkModeRunning = IsPause;
                }
                btnPause.Text = "继续";
                IsPause = true;
            }
            else
            {
                btnPause.Text = "暂停";
                if (m_Sink != null)
                {
                    m_Sink.SinkModeRunning = IsPause;
                }
                IsPause = false;
            }

        }
    }
}