namespace MVDoubleVD
{
    partial class MVDoubleVD
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.deviceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.startToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.stopToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.leftCamToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.startLeftToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.stopLeftToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.setLetfToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.propertyLeftToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fullScreenLeft = new System.Windows.Forms.ToolStripMenuItem();
            this.rightCameraToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.startRightToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.stopRightToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.setRightToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.propertyRightToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fullScreenRight = new System.Windows.Forms.ToolStripMenuItem();
            this.SaveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.leftSaveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.leftSingleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.leftDiskToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.leftMemoryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lDiskStopToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rightSaveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rightSingleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rightDiskToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.righMemoryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rDiskStopToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.allSaveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pathTimeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveSingleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.allToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.allToMemmoryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aDiskStopToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.recordVideoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.LeftRecordVideo = new System.Windows.Forms.ToolStripMenuItem();
            this.RightRecordVideo = new System.Windows.Forms.ToolStripMenuItem();
            this.RightCamera = new IAT.Imaging.WDMIAT();
            this.LeftCamera = new IAT.Imaging.WDMIAT();
            this.timerLeft = new System.Windows.Forms.Timer(this.components);
            this.timerRight = new System.Windows.Forms.Timer(this.components);
            this.timerAll = new System.Windows.Forms.Timer(this.components);
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.RightCamera)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LeftCamera)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.deviceToolStripMenuItem,
            this.leftCamToolStripMenuItem,
            this.rightCameraToolStripMenuItem,
            this.SaveToolStripMenuItem,
            this.recordVideoToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(405, 24);
            this.menuStrip1.TabIndex = 15;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // deviceToolStripMenuItem
            // 
            this.deviceToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openToolStripMenuItem,
            this.startToolStripMenuItem,
            this.stopToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.deviceToolStripMenuItem.Name = "deviceToolStripMenuItem";
            this.deviceToolStripMenuItem.Size = new System.Drawing.Size(41, 20);
            this.deviceToolStripMenuItem.Text = "�豸";
            // 
            // openToolStripMenuItem
            // 
            this.openToolStripMenuItem.Name = "openToolStripMenuItem";
            this.openToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.openToolStripMenuItem.Text = "��\\����";
            this.openToolStripMenuItem.Click += new System.EventHandler(this.openToolStripMenuItem_Click);
            // 
            // startToolStripMenuItem
            // 
            this.startToolStripMenuItem.Name = "startToolStripMenuItem";
            this.startToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.startToolStripMenuItem.Text = "����";
            this.startToolStripMenuItem.Visible = false;
            this.startToolStripMenuItem.Click += new System.EventHandler(this.startToolStripMenuItem_Click);
            // 
            // stopToolStripMenuItem
            // 
            this.stopToolStripMenuItem.Enabled = false;
            this.stopToolStripMenuItem.Name = "stopToolStripMenuItem";
            this.stopToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.stopToolStripMenuItem.Text = "ֹͣ";
            this.stopToolStripMenuItem.Visible = false;
            this.stopToolStripMenuItem.Click += new System.EventHandler(this.stopToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.exitToolStripMenuItem.Text = "�˳�";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // leftCamToolStripMenuItem
            // 
            this.leftCamToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.startLeftToolStripMenuItem,
            this.stopLeftToolStripMenuItem,
            this.setLetfToolStripMenuItem,
            this.propertyLeftToolStripMenuItem,
            this.fullScreenLeft});
            this.leftCamToolStripMenuItem.Enabled = false;
            this.leftCamToolStripMenuItem.Name = "leftCamToolStripMenuItem";
            this.leftCamToolStripMenuItem.Size = new System.Drawing.Size(41, 20);
            this.leftCamToolStripMenuItem.Text = "���";
            // 
            // startLeftToolStripMenuItem
            // 
            this.startLeftToolStripMenuItem.Name = "startLeftToolStripMenuItem";
            this.startLeftToolStripMenuItem.Size = new System.Drawing.Size(94, 22);
            this.startLeftToolStripMenuItem.Text = "����";
            this.startLeftToolStripMenuItem.Click += new System.EventHandler(this.startLeftToolStripMenuItem_Click);
            // 
            // stopLeftToolStripMenuItem
            // 
            this.stopLeftToolStripMenuItem.Name = "stopLeftToolStripMenuItem";
            this.stopLeftToolStripMenuItem.Size = new System.Drawing.Size(94, 22);
            this.stopLeftToolStripMenuItem.Text = "ֹͣ";
            this.stopLeftToolStripMenuItem.Click += new System.EventHandler(this.stopLeftToolStripMenuItem_Click);
            // 
            // setLetfToolStripMenuItem
            // 
            this.setLetfToolStripMenuItem.Name = "setLetfToolStripMenuItem";
            this.setLetfToolStripMenuItem.Size = new System.Drawing.Size(94, 22);
            this.setLetfToolStripMenuItem.Text = "����";
            this.setLetfToolStripMenuItem.Click += new System.EventHandler(this.setLetfToolStripMenuItem_Click);
            // 
            // propertyLeftToolStripMenuItem
            // 
            this.propertyLeftToolStripMenuItem.Name = "propertyLeftToolStripMenuItem";
            this.propertyLeftToolStripMenuItem.Size = new System.Drawing.Size(94, 22);
            this.propertyLeftToolStripMenuItem.Text = "����";
            this.propertyLeftToolStripMenuItem.Click += new System.EventHandler(this.propertyLeftToolStripMenuItem_Click);
            // 
            // fullScreenLeft
            // 
            this.fullScreenLeft.Name = "fullScreenLeft";
            this.fullScreenLeft.Size = new System.Drawing.Size(94, 22);
            this.fullScreenLeft.Text = "ȫ��";
            this.fullScreenLeft.Visible = false;
            this.fullScreenLeft.Click += new System.EventHandler(this.fullScreenLeft_Click);
            // 
            // rightCameraToolStripMenuItem
            // 
            this.rightCameraToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.startRightToolStripMenuItem,
            this.stopRightToolStripMenuItem,
            this.setRightToolStripMenuItem,
            this.propertyRightToolStripMenuItem,
            this.fullScreenRight});
            this.rightCameraToolStripMenuItem.Enabled = false;
            this.rightCameraToolStripMenuItem.Name = "rightCameraToolStripMenuItem";
            this.rightCameraToolStripMenuItem.Size = new System.Drawing.Size(53, 20);
            this.rightCameraToolStripMenuItem.Text = "�����";
            this.rightCameraToolStripMenuItem.Visible = false;
            // 
            // startRightToolStripMenuItem
            // 
            this.startRightToolStripMenuItem.Name = "startRightToolStripMenuItem";
            this.startRightToolStripMenuItem.Size = new System.Drawing.Size(94, 22);
            this.startRightToolStripMenuItem.Text = "����";
            this.startRightToolStripMenuItem.Click += new System.EventHandler(this.startRightToolStripMenuItem_Click);
            // 
            // stopRightToolStripMenuItem
            // 
            this.stopRightToolStripMenuItem.Name = "stopRightToolStripMenuItem";
            this.stopRightToolStripMenuItem.Size = new System.Drawing.Size(94, 22);
            this.stopRightToolStripMenuItem.Text = "ֹͣ";
            this.stopRightToolStripMenuItem.Click += new System.EventHandler(this.stopRightToolStripMenuItem_Click);
            // 
            // setRightToolStripMenuItem
            // 
            this.setRightToolStripMenuItem.Name = "setRightToolStripMenuItem";
            this.setRightToolStripMenuItem.Size = new System.Drawing.Size(94, 22);
            this.setRightToolStripMenuItem.Text = "����";
            this.setRightToolStripMenuItem.Click += new System.EventHandler(this.setRightToolStripMenuItem_Click);
            // 
            // propertyRightToolStripMenuItem
            // 
            this.propertyRightToolStripMenuItem.Name = "propertyRightToolStripMenuItem";
            this.propertyRightToolStripMenuItem.Size = new System.Drawing.Size(94, 22);
            this.propertyRightToolStripMenuItem.Text = "����";
            this.propertyRightToolStripMenuItem.Click += new System.EventHandler(this.propertyRightToolStripMenuItem_Click);
            // 
            // fullScreenRight
            // 
            this.fullScreenRight.Name = "fullScreenRight";
            this.fullScreenRight.Size = new System.Drawing.Size(94, 22);
            this.fullScreenRight.Text = "ȫ��";
            this.fullScreenRight.Click += new System.EventHandler(this.fullScreenRight_Click);
            // 
            // SaveToolStripMenuItem
            // 
            this.SaveToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.leftSaveToolStripMenuItem,
            this.rightSaveToolStripMenuItem,
            this.allSaveToolStripMenuItem});
            this.SaveToolStripMenuItem.Enabled = false;
            this.SaveToolStripMenuItem.Name = "SaveToolStripMenuItem";
            this.SaveToolStripMenuItem.Size = new System.Drawing.Size(41, 20);
            this.SaveToolStripMenuItem.Text = "����";
            this.SaveToolStripMenuItem.Visible = false;
            // 
            // leftSaveToolStripMenuItem
            // 
            this.leftSaveToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.leftSingleToolStripMenuItem,
            this.leftDiskToolStripMenuItem,
            this.leftMemoryToolStripMenuItem,
            this.lDiskStopToolStripMenuItem});
            this.leftSaveToolStripMenuItem.Enabled = false;
            this.leftSaveToolStripMenuItem.Name = "leftSaveToolStripMenuItem";
            this.leftSaveToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.leftSaveToolStripMenuItem.Text = "���";
            // 
            // leftSingleToolStripMenuItem
            // 
            this.leftSingleToolStripMenuItem.Name = "leftSingleToolStripMenuItem";
            this.leftSingleToolStripMenuItem.Size = new System.Drawing.Size(130, 22);
            this.leftSingleToolStripMenuItem.Text = "ץͼ";
            this.leftSingleToolStripMenuItem.Click += new System.EventHandler(this.leftSingleToolStripMenuItem_Click);
            // 
            // leftDiskToolStripMenuItem
            // 
            this.leftDiskToolStripMenuItem.Name = "leftDiskToolStripMenuItem";
            this.leftDiskToolStripMenuItem.Size = new System.Drawing.Size(130, 22);
            this.leftDiskToolStripMenuItem.Text = "ֱ�Ӳ�����";
            this.leftDiskToolStripMenuItem.Click += new System.EventHandler(this.leftDiskToolStripMenuItem_Click);
            // 
            // leftMemoryToolStripMenuItem
            // 
            this.leftMemoryToolStripMenuItem.Name = "leftMemoryToolStripMenuItem";
            this.leftMemoryToolStripMenuItem.Size = new System.Drawing.Size(130, 22);
            this.leftMemoryToolStripMenuItem.Text = "��Ӳ�����";
            this.leftMemoryToolStripMenuItem.Click += new System.EventHandler(this.leftMemoryToolStripMenuItem_Click);
            // 
            // lDiskStopToolStripMenuItem
            // 
            this.lDiskStopToolStripMenuItem.Name = "lDiskStopToolStripMenuItem";
            this.lDiskStopToolStripMenuItem.Size = new System.Drawing.Size(130, 22);
            this.lDiskStopToolStripMenuItem.Text = "ֹͣ";
            this.lDiskStopToolStripMenuItem.Click += new System.EventHandler(this.lDiskStopToolStripMenuItem_Click);
            // 
            // rightSaveToolStripMenuItem
            // 
            this.rightSaveToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.rightSingleToolStripMenuItem,
            this.rightDiskToolStripMenuItem,
            this.righMemoryToolStripMenuItem,
            this.rDiskStopToolStripMenuItem});
            this.rightSaveToolStripMenuItem.Enabled = false;
            this.rightSaveToolStripMenuItem.Name = "rightSaveToolStripMenuItem";
            this.rightSaveToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.rightSaveToolStripMenuItem.Text = "�����";
            this.rightSaveToolStripMenuItem.Visible = false;
            // 
            // rightSingleToolStripMenuItem
            // 
            this.rightSingleToolStripMenuItem.Name = "rightSingleToolStripMenuItem";
            this.rightSingleToolStripMenuItem.Size = new System.Drawing.Size(130, 22);
            this.rightSingleToolStripMenuItem.Text = "ץͼ";
            this.rightSingleToolStripMenuItem.Click += new System.EventHandler(this.rightSingleToolStripMenuItem_Click);
            // 
            // rightDiskToolStripMenuItem
            // 
            this.rightDiskToolStripMenuItem.Name = "rightDiskToolStripMenuItem";
            this.rightDiskToolStripMenuItem.Size = new System.Drawing.Size(130, 22);
            this.rightDiskToolStripMenuItem.Text = "ֱ�Ӳ�����";
            this.rightDiskToolStripMenuItem.Click += new System.EventHandler(this.rightDiskToolStripMenuItem_Click);
            // 
            // righMemoryToolStripMenuItem
            // 
            this.righMemoryToolStripMenuItem.Name = "righMemoryToolStripMenuItem";
            this.righMemoryToolStripMenuItem.Size = new System.Drawing.Size(130, 22);
            this.righMemoryToolStripMenuItem.Text = "��Ӳ�����";
            this.righMemoryToolStripMenuItem.Click += new System.EventHandler(this.righMemoryToolStripMenuItem_Click);
            // 
            // rDiskStopToolStripMenuItem
            // 
            this.rDiskStopToolStripMenuItem.Name = "rDiskStopToolStripMenuItem";
            this.rDiskStopToolStripMenuItem.Size = new System.Drawing.Size(130, 22);
            this.rDiskStopToolStripMenuItem.Text = "ֹͣ";
            this.rDiskStopToolStripMenuItem.Click += new System.EventHandler(this.rDiskStopToolStripMenuItem_Click);
            // 
            // allSaveToolStripMenuItem
            // 
            this.allSaveToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pathTimeToolStripMenuItem,
            this.saveSingleToolStripMenuItem,
            this.allToolStripMenuItem,
            this.allToMemmoryToolStripMenuItem,
            this.aDiskStopToolStripMenuItem});
            this.allSaveToolStripMenuItem.Enabled = false;
            this.allSaveToolStripMenuItem.Name = "allSaveToolStripMenuItem";
            this.allSaveToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.allSaveToolStripMenuItem.Text = "ͬʱ����";
            this.allSaveToolStripMenuItem.Visible = false;
            // 
            // pathTimeToolStripMenuItem
            // 
            this.pathTimeToolStripMenuItem.Name = "pathTimeToolStripMenuItem";
            this.pathTimeToolStripMenuItem.Size = new System.Drawing.Size(130, 22);
            this.pathTimeToolStripMenuItem.Text = "·��/ʱ��";
            this.pathTimeToolStripMenuItem.Click += new System.EventHandler(this.pathTimeToolStripMenuItem_Click);
            // 
            // saveSingleToolStripMenuItem
            // 
            this.saveSingleToolStripMenuItem.Name = "saveSingleToolStripMenuItem";
            this.saveSingleToolStripMenuItem.Size = new System.Drawing.Size(130, 22);
            this.saveSingleToolStripMenuItem.Text = "ͬʱץͼ";
            this.saveSingleToolStripMenuItem.Click += new System.EventHandler(this.saveSingleToolStripMenuItem_Click);
            // 
            // allToolStripMenuItem
            // 
            this.allToolStripMenuItem.Name = "allToolStripMenuItem";
            this.allToolStripMenuItem.Size = new System.Drawing.Size(130, 22);
            this.allToolStripMenuItem.Text = "ֱ�Ӳ�����";
            this.allToolStripMenuItem.Click += new System.EventHandler(this.allToolStripMenuItem_Click);
            // 
            // allToMemmoryToolStripMenuItem
            // 
            this.allToMemmoryToolStripMenuItem.Name = "allToMemmoryToolStripMenuItem";
            this.allToMemmoryToolStripMenuItem.Size = new System.Drawing.Size(130, 22);
            this.allToMemmoryToolStripMenuItem.Text = "��Ӳ�����";
            this.allToMemmoryToolStripMenuItem.Click += new System.EventHandler(this.allToMemmoryToolStripMenuItem_Click);
            // 
            // aDiskStopToolStripMenuItem
            // 
            this.aDiskStopToolStripMenuItem.Name = "aDiskStopToolStripMenuItem";
            this.aDiskStopToolStripMenuItem.Size = new System.Drawing.Size(130, 22);
            this.aDiskStopToolStripMenuItem.Text = "ֹͣ";
            this.aDiskStopToolStripMenuItem.Click += new System.EventHandler(this.aDiskStopToolStripMenuItem_Click);
            // 
            // recordVideoToolStripMenuItem
            // 
            this.recordVideoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.LeftRecordVideo,
            this.RightRecordVideo});
            this.recordVideoToolStripMenuItem.Enabled = false;
            this.recordVideoToolStripMenuItem.Name = "recordVideoToolStripMenuItem";
            this.recordVideoToolStripMenuItem.Size = new System.Drawing.Size(41, 20);
            this.recordVideoToolStripMenuItem.Text = "¼��";
            this.recordVideoToolStripMenuItem.Visible = false;
            // 
            // LeftRecordVideo
            // 
            this.LeftRecordVideo.Enabled = false;
            this.LeftRecordVideo.Name = "LeftRecordVideo";
            this.LeftRecordVideo.Size = new System.Drawing.Size(152, 22);
            this.LeftRecordVideo.Text = "���";
            this.LeftRecordVideo.Click += new System.EventHandler(this.LeftRecordVideo_Click);
            // 
            // RightRecordVideo
            // 
            this.RightRecordVideo.Enabled = false;
            this.RightRecordVideo.Name = "RightRecordVideo";
            this.RightRecordVideo.Size = new System.Drawing.Size(152, 22);
            this.RightRecordVideo.Text = "�����";
            this.RightRecordVideo.Visible = false;
            this.RightRecordVideo.Click += new System.EventHandler(this.RightRecordVideo_Click);
            // 
            // RightCamera
            // 
            this.RightCamera.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.RightCamera.DeBayerMode = IAT.Imaging.DeBayerModes.Edgesensing;
            this.RightCamera.DeBayerStartPattern = IAT.Imaging.DeBayerStartPatterns.BG;
            this.RightCamera.ImageRingBufferSize = 5;
            this.RightCamera.LiveDisplayHeight = 480;
            this.RightCamera.LiveDisplayWidth = 640;
            this.RightCamera.LiveShowLastBuffer = true;
            this.RightCamera.Location = new System.Drawing.Point(203, 27);
            this.RightCamera.MemoryCurrentGrabberColorformat = IAT.Imaging.WDMIATControlColorformats.IATRGB24;
            this.RightCamera.Name = "RightCamera";
            this.RightCamera.OverlayBitmapPosition = IAT.Imaging.PathPositions.Device;
            this.RightCamera.SinkCompatibilityMode = true;
            this.RightCamera.Size = new System.Drawing.Size(65, 98);
            this.RightCamera.TabIndex = 16;
            this.RightCamera.Visible = false;
            this.RightCamera.DeviceLost += new IAT.Imaging.WDMIAT.DeviceLostHandler(this.RightCamera_DeviceLost);
            // 
            // LeftCamera
            // 
            this.LeftCamera.DeBayerMode = IAT.Imaging.DeBayerModes.Edgesensing;
            this.LeftCamera.DeBayerStartPattern = IAT.Imaging.DeBayerStartPatterns.BG;
            this.LeftCamera.Dock = System.Windows.Forms.DockStyle.Fill;
            this.LeftCamera.ImageRingBufferSize = 5;
            this.LeftCamera.LiveDisplayHeight = 480;
            this.LeftCamera.LiveDisplayWidth = 640;
            this.LeftCamera.LiveShowLastBuffer = true;
            this.LeftCamera.Location = new System.Drawing.Point(0, 24);
            this.LeftCamera.MemoryCurrentGrabberColorformat = IAT.Imaging.WDMIATControlColorformats.IATRGB24;
            this.LeftCamera.Name = "LeftCamera";
            this.LeftCamera.OverlayBitmapPosition = IAT.Imaging.PathPositions.Device;
            this.LeftCamera.SinkCompatibilityMode = true;
            this.LeftCamera.Size = new System.Drawing.Size(405, 310);
            this.LeftCamera.TabIndex = 13;
            this.LeftCamera.DeviceLost += new IAT.Imaging.WDMIAT.DeviceLostHandler(this.LeftCamera_DeviceLost);
            // 
            // timerLeft
            // 
            this.timerLeft.Interval = 500;
            this.timerLeft.Tick += new System.EventHandler(this.timerLeft_Tick);
            // 
            // timerRight
            // 
            this.timerRight.Tick += new System.EventHandler(this.timerRight_Tick);
            // 
            // timerAll
            // 
            this.timerAll.Tick += new System.EventHandler(this.timerAll_Tick);
            // 
            // MVDoubleVD
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(405, 334);
            this.Controls.Add(this.RightCamera);
            this.Controls.Add(this.LeftCamera);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "MVDoubleVD";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "��Ƶͼ�񴰿�";
            this.SizeChanged += new System.EventHandler(this.MVDoubleVD_SizeChanged);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MVDoubleVD_FormClosing);
            this.Load += new System.EventHandler(this.MVDoubleVD_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.RightCamera)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LeftCamera)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem deviceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem startToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem stopToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem leftCamToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rightCameraToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem startLeftToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem stopLeftToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem setLetfToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem startRightToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem stopRightToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem setRightToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem propertyLeftToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem propertyRightToolStripMenuItem;
        private IAT.Imaging.WDMIAT RightCamera;
        private System.Windows.Forms.ToolStripMenuItem SaveToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem leftSaveToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem leftSingleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem leftDiskToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem leftMemoryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lDiskStopToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rightSaveToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rightDiskToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem righMemoryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rDiskStopToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem allSaveToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pathTimeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveSingleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem allToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem allToMemmoryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aDiskStopToolStripMenuItem;
        private System.Windows.Forms.Timer timerLeft;
        private System.Windows.Forms.Timer timerRight;
        private System.Windows.Forms.Timer timerAll;
        private IAT.Imaging.WDMIAT LeftCamera;
        private System.Windows.Forms.ToolStripMenuItem fullScreenLeft;
        private System.Windows.Forms.ToolStripMenuItem fullScreenRight;
        private System.Windows.Forms.ToolStripMenuItem recordVideoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem LeftRecordVideo;
        private System.Windows.Forms.ToolStripMenuItem RightRecordVideo;
        private System.Windows.Forms.ToolStripMenuItem rightSingleToolStripMenuItem;
    }
}

