﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace MVDoubleVD
{
    /// <summary>
    /// 该文件来原于 视频 产商，并作简单的修改，详细请查看[驱动光盘\MV-VD VS VE Camera\SDK\SDK开发包\开发说明\WDMIATvb7.chm]
    /// </summary>
    /// 
    public partial class SaveSeries : Form
    {
        public bool m_bTimeMode = false;
        public SaveSeries()
        {
            InitializeComponent();
        }

        private void browserBtn_Click(object sender, EventArgs e)
        {
            try
            {
                if (folderBrowserDialog.ShowDialog() == DialogResult.OK)
                {
                    PathtextBox.Text = folderBrowserDialog.SelectedPath;
                }
            }
            catch { }
        }

        private void radioButton_time_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton_time.Checked)//time mode
            {
                m_bTimeMode = true;
                TimetextBox.Enabled = true;
                textBox_dist.Enabled = false;
            }
        }

        private void radioButton_distance_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton_distance.Checked)//time mode
            {
                m_bTimeMode = false;
                TimetextBox.Enabled = false;
                textBox_dist.Enabled = true;
            }
        }

        private void OK_Click(object sender, EventArgs e)
        {

        }

    
    }
}