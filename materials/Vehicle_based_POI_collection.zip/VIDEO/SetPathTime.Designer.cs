﻿namespace MVDoubleVD
{
    partial class SetPathTime
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.LeftPathtextBox = new System.Windows.Forms.TextBox();
            this.RightPathtextBox = new System.Windows.Forms.TextBox();
            this.DiskTimetextBox = new System.Windows.Forms.TextBox();
            this.MemTimetextBox = new System.Windows.Forms.TextBox();
            this.LeftBrowser = new System.Windows.Forms.Button();
            this.RightBrowser = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.OK = new System.Windows.Forms.Button();
            this.Cancel = new System.Windows.Forms.Button();
            this.folderBrowserDialog = new System.Windows.Forms.FolderBrowserDialog();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "左相机";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 42);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 12);
            this.label2.TabIndex = 1;
            this.label2.Text = "右相机";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 69);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(113, 12);
            this.label3.TabIndex = 2;
            this.label3.Text = "直接采序列间隔时间";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 96);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(113, 12);
            this.label4.TabIndex = 3;
            this.label4.Text = "间接采序列时间长度";
            // 
            // LeftPathtextBox
            // 
            this.LeftPathtextBox.Location = new System.Drawing.Point(59, 12);
            this.LeftPathtextBox.Name = "LeftPathtextBox";
            this.LeftPathtextBox.Size = new System.Drawing.Size(152, 21);
            this.LeftPathtextBox.TabIndex = 4;
            // 
            // RightPathtextBox
            // 
            this.RightPathtextBox.Location = new System.Drawing.Point(59, 39);
            this.RightPathtextBox.Name = "RightPathtextBox";
            this.RightPathtextBox.Size = new System.Drawing.Size(152, 21);
            this.RightPathtextBox.TabIndex = 5;
            // 
            // DiskTimetextBox
            // 
            this.DiskTimetextBox.Location = new System.Drawing.Point(131, 66);
            this.DiskTimetextBox.Name = "DiskTimetextBox";
            this.DiskTimetextBox.Size = new System.Drawing.Size(45, 21);
            this.DiskTimetextBox.TabIndex = 6;
            // 
            // MemTimetextBox
            // 
            this.MemTimetextBox.Location = new System.Drawing.Point(131, 93);
            this.MemTimetextBox.Name = "MemTimetextBox";
            this.MemTimetextBox.Size = new System.Drawing.Size(45, 21);
            this.MemTimetextBox.TabIndex = 7;
            // 
            // LeftBrowser
            // 
            this.LeftBrowser.Location = new System.Drawing.Point(217, 10);
            this.LeftBrowser.Name = "LeftBrowser";
            this.LeftBrowser.Size = new System.Drawing.Size(38, 23);
            this.LeftBrowser.TabIndex = 8;
            this.LeftBrowser.Text = "浏览";
            this.LeftBrowser.UseVisualStyleBackColor = true;
            this.LeftBrowser.Click += new System.EventHandler(this.LeftBrowser_Click);
            // 
            // RightBrowser
            // 
            this.RightBrowser.Location = new System.Drawing.Point(217, 39);
            this.RightBrowser.Name = "RightBrowser";
            this.RightBrowser.Size = new System.Drawing.Size(38, 23);
            this.RightBrowser.TabIndex = 9;
            this.RightBrowser.Text = "浏览";
            this.RightBrowser.UseVisualStyleBackColor = true;
            this.RightBrowser.Click += new System.EventHandler(this.RightBrowser_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(182, 69);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(29, 12);
            this.label5.TabIndex = 10;
            this.label5.Text = "毫秒";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(182, 96);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(17, 12);
            this.label6.TabIndex = 11;
            this.label6.Text = "秒";
            // 
            // OK
            // 
            this.OK.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.OK.Location = new System.Drawing.Point(50, 120);
            this.OK.Name = "OK";
            this.OK.Size = new System.Drawing.Size(75, 23);
            this.OK.TabIndex = 12;
            this.OK.Text = "确定";
            this.OK.UseVisualStyleBackColor = true;
            // 
            // Cancel
            // 
            this.Cancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.Cancel.Location = new System.Drawing.Point(136, 120);
            this.Cancel.Name = "Cancel";
            this.Cancel.Size = new System.Drawing.Size(75, 23);
            this.Cancel.TabIndex = 13;
            this.Cancel.Text = "取消";
            this.Cancel.UseVisualStyleBackColor = true;
            // 
            // SetPathTime
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(267, 151);
            this.Controls.Add(this.Cancel);
            this.Controls.Add(this.OK);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.RightBrowser);
            this.Controls.Add(this.LeftBrowser);
            this.Controls.Add(this.MemTimetextBox);
            this.Controls.Add(this.DiskTimetextBox);
            this.Controls.Add(this.RightPathtextBox);
            this.Controls.Add(this.LeftPathtextBox);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "SetPathTime";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "设置存储路径及时间";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button LeftBrowser;
        private System.Windows.Forms.Button RightBrowser;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button OK;
        private System.Windows.Forms.Button Cancel;
        public System.Windows.Forms.TextBox LeftPathtextBox;
        public System.Windows.Forms.TextBox RightPathtextBox;
        public System.Windows.Forms.TextBox DiskTimetextBox;
        public System.Windows.Forms.TextBox MemTimetextBox;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog;
    }
}