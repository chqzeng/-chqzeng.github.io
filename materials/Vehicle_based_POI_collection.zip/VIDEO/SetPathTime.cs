﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace MVDoubleVD
{
    /// <summary>
    /// 该文件来原于 视频 产商，并作简单的修改，详细请查看[驱动光盘\MV-VD VS VE Camera\SDK\SDK开发包\开发说明\WDMIATvb7.chm]
    /// </summary>
    /// 
    public partial class SetPathTime : Form
    {
        public SetPathTime()
        {
            InitializeComponent();
        }

        private void LeftBrowser_Click(object sender, EventArgs e)
        {
            if (folderBrowserDialog.ShowDialog() == DialogResult.OK)
            {
                LeftPathtextBox.Text = folderBrowserDialog.SelectedPath;
            }
        }

        private void RightBrowser_Click(object sender, EventArgs e)
        {
            if (folderBrowserDialog.ShowDialog() == DialogResult.OK)
            {
                RightPathtextBox.Text = folderBrowserDialog.SelectedPath;
            }
        }
    }
}