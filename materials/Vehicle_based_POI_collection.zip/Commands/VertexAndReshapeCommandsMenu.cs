using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;
using ESRI.ArcGIS.ADF.CATIDs;
using ESRI.ArcGIS.ADF.BaseClasses;

namespace Commands
{
    /// <summary>
    /// Summary description for EditorUtilitiesMenu.
    /// </summary>
    [Guid("efd4ed66-1459-4558-ad93-d377a044fb8e")]
    [ClassInterface(ClassInterfaceType.None)]
    [ProgId("Commands.VertexAndReshapeCommandsMenu")]
    public sealed class VertexAndReshapeCommandsMenu : BaseMenu
    {
        #region COM Registration Function(s)
        [ComRegisterFunction()]
        [ComVisible(false)]
        static void RegisterFunction(Type registerType)
        {
            // Required for ArcGIS Component Category Registrar support
            ArcGISCategoryRegistration(registerType);

            //
            // TODO: Add any COM registration code here
            //
        }

        [ComUnregisterFunction()]
        [ComVisible(false)]
        static void UnregisterFunction(Type registerType)
        {
            // Required for ArcGIS Component Category Registrar support
            ArcGISCategoryUnregistration(registerType);
        }

        #region ArcGIS Component Category Registrar generated code
        /// <summary>
        /// Required method for ArcGIS Component Category registration -
        /// Do not modify the contents of this method with the code editor.
        /// </summary>
        private static void ArcGISCategoryRegistration(Type registerType)
        {
            string regKey = string.Format("HKEY_CLASSES_ROOT\\CLSID\\{{{0}}}", registerType.GUID);
            ControlsMenus.Register(regKey);
        }
        /// <summary>
        /// Required method for ArcGIS Component Category unregistration -
        /// Do not modify the contents of this method with the code editor.
        /// </summary>
        private static void ArcGISCategoryUnregistration(Type registerType)
        {
            string regKey = string.Format("HKEY_CLASSES_ROOT\\CLSID\\{{{0}}}", registerType.GUID);
            ControlsMenus.Unregister(regKey);
        }

        #endregion
        #endregion

        #region class constructor

        public VertexAndReshapeCommandsMenu()
        {

            AddItem("Commands.VertexEditTools", 1);   //Add vertex on boundary
            AddItem("Commands.VertexEditTools", 2);   //Add vertex at clicked point
            AddItem("Commands.VertexEditTools", 3);   //Delete vertex nearest to clicked point
            AddItem("Commands.ReshapePolylineTool");  //Reshape Polyline Tool

        }
        #endregion

        #region overridden methods

        public override string Caption
        {
            get
            {
                return "�ڵ�";
            }
        }
        public override string Name
        {
            get
            {
                return "VertexAndReshapeCommandsMenu";
            }
        }
        #endregion
    }
}