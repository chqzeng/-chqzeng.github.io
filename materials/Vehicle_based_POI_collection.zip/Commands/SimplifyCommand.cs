using System;
using System.Drawing;
using System.Runtime.InteropServices;
using ESRI.ArcGIS.ADF.BaseClasses;
using ESRI.ArcGIS.ADF.CATIDs;
using ESRI.ArcGIS.Controls;

using ESRI.ArcGIS.Geometry;
using ESRI.ArcGIS.Geodatabase;
using ESRI.ArcGIS.Carto;

namespace Commands
{
    /// <summary>
    /// Summary description for SimplifyCommand.
    /// </summary>
    [Guid("cd202751-76c7-4c70-940a-3a026a7ff4d3")]
    [ClassInterface(ClassInterfaceType.None)]
    [ProgId("Commands.SimplifyCommand")]
    public sealed class SimplifyCommand : BaseCommand
    {
        #region COM Registration Function(s)
        [ComRegisterFunction()]
        [ComVisible(false)]
        static void RegisterFunction(Type registerType)
        {
            // Required for ArcGIS Component Category Registrar support
            ArcGISCategoryRegistration(registerType);

            //
            // TODO: Add any COM registration code here
            //
        }

        [ComUnregisterFunction()]
        [ComVisible(false)]
        static void UnregisterFunction(Type registerType)
        {
            // Required for ArcGIS Component Category Registrar support
            ArcGISCategoryUnregistration(registerType);

            //
            // TODO: Add any COM unregistration code here
            //
        }

        #region ArcGIS Component Category Registrar generated code
        /// <summary>
        /// Required method for ArcGIS Component Category registration -
        /// Do not modify the contents of this method with the code editor.
        /// </summary>
        private static void ArcGISCategoryRegistration(Type registerType)
        {
            string regKey = string.Format("HKEY_CLASSES_ROOT\\CLSID\\{{{0}}}", registerType.GUID);
            ControlsCommands.Register(regKey);

        }
        /// <summary>
        /// Required method for ArcGIS Component Category unregistration -
        /// Do not modify the contents of this method with the code editor.
        /// </summary>
        private static void ArcGISCategoryUnregistration(Type registerType)
        {
            string regKey = string.Format("HKEY_CLASSES_ROOT\\CLSID\\{{{0}}}", registerType.GUID);
            ControlsCommands.Unregister(regKey);

        }

        #endregion
        #endregion

        private IHookHelper m_hookHelper;
        private IEngineEditProperties m_engineEditor;

        public SimplifyCommand()
        {
            //
            // TODO: Define values for the public properties
            //
            base.m_category = "Custom vertex & reshape editing commands"; //localizable text
            base.m_caption = "simplify";  //localizable text
            base.m_message = "simplify selected line";  //localizable text 
            base.m_toolTip = "simplify";  //localizable text 
            base.m_name = "Commands_simplify";   //unique id, non-localizable (e.g. "MyCategory_MyCommand")

            try
            {
                //
                // TODO: change bitmap name if necessary
                //
                string bitmapResourceName = GetType().Name + ".bmp";
                base.m_bitmap = new Bitmap(GetType(), bitmapResourceName);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Trace.WriteLine(ex.Message, "Invalid Bitmap");
            }
        }

        #region Overriden Class Methods

        /// <summary>
        /// Occurs when this command is created
        /// </summary>
        /// <param name="hook">Instance of the application</param>
        public override void OnCreate(object hook)
        {
            if (hook == null)
                return;

            if (m_hookHelper == null)
                m_hookHelper = new HookHelperClass();

            m_hookHelper.Hook = hook;
            m_engineEditor = new EngineEditorClass();

            // TODO:  Add other initialization code
        }

        /// <summary>
        /// Occurs when this command is clicked
        /// </summary>
        public override void OnClick()
        {  
            IFeatureLayer featureLayer = m_engineEditor.TargetLayer as IFeatureLayer;
            IDataset dataset = featureLayer.FeatureClass as IDataset;
            IWorkspaceEdit workspaceEdit = dataset.Workspace as IWorkspaceEdit;

            //get selection
            IFeatureSelection featureSelection = featureLayer as IFeatureSelection;
            ISelectionSet2 selectionSet = featureSelection.SelectionSet as ISelectionSet2;
           
            //get an update cursor
            ICursor cursor;
            selectionSet.Update(null, true, out cursor);
            IFeatureCursor featureCursor = cursor as IFeatureCursor;
            
            IFeature feature = featureCursor.NextFeature();
                    
            if (feature != null)
            {
                workspaceEdit.StartEditOperation();
            }

            try 
            {
                while (feature != null)
                {   
                    IPolycurve editShape = feature.Shape as IPolycurve;
                    editShape.Generalize(10);
                    featureCursor.UpdateFeature(feature);

                    feature = featureCursor.NextFeature();       
                }

                workspaceEdit.StopEditOperation();
            }
            catch (Exception ex)
            {
                workspaceEdit.AbortEditOperation();
                System.Diagnostics.Debug.WriteLine(ex.Message);
            }

          


        }


        public override bool Enabled
        {
            get
            {
                //are we editing
                //check whether Editing 
                ILayer layer = m_engineEditor.TargetLayer;

                if (layer == null)
                {
                    return false;
                }

                //check that only one feature is currently selected
                IFeatureSelection featureSelection = layer as IFeatureSelection;
                ISelectionSet selectionSet = featureSelection.SelectionSet;
                if (selectionSet.Count == 0)
                {
                    return false;
                }

                return true;

            }
        }

        #endregion
    }
}
