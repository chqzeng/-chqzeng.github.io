using System;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using System.Resources;
using System.Reflection;

using ESRI.ArcGIS.ADF.BaseClasses;
using ESRI.ArcGIS.ADF.CATIDs;
using ESRI.ArcGIS.Controls;
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.Geometry;
using ESRI.ArcGIS.Geodatabase;
using ESRI.ArcGIS.SystemUI;


namespace Commands
{
    /// <summary>
    /// Summary description for InsertVertex.
    /// </summary>
    [Guid("9B0F3816-AB49-4d5b-BCC1-3ADA19EE1DB2")]
    [ClassInterface(ClassInterfaceType.None)]
    [ProgId("Commands.VertexEditTools")]
    public sealed class VertexEditTools : BaseTool, ICommandSubType
    {
        #region COM Registration Function(s)
        [ComRegisterFunction()]
        [ComVisible(false)]
        static void RegisterFunction(Type registerType)
        {
            // Required for ArcGIS Component Category Registrar support
            ArcGISCategoryRegistration(registerType);
        }

        [ComUnregisterFunction()]
        [ComVisible(false)]
        static void UnregisterFunction(Type registerType)
        {
            // Required for ArcGIS Component Category Registrar support
            ArcGISCategoryUnregistration(registerType);
        }

        #region ArcGIS Component Category Registrar generated code
        /// <summary>
        /// Required method for ArcGIS Component Category registration -
        /// Do not modify the contents of this method with the code editor.
        /// </summary>
        private static void ArcGISCategoryRegistration(Type registerType)
        {
            string regKey = string.Format("HKEY_CLASSES_ROOT\\CLSID\\{{{0}}}", registerType.GUID);
            ControlsCommands.Register(regKey);
        }
        /// <summary>
        /// Required method for ArcGIS Component Category unregistration -
        /// Do not modify the contents of this method with the code editor.
        /// </summary>
        private static void ArcGISCategoryUnregistration(Type registerType)
        {
            string regKey = string.Format("HKEY_CLASSES_ROOT\\CLSID\\{{{0}}}", registerType.GUID);
            ControlsCommands.Unregister(regKey);
        }

        #endregion
        #endregion

        #region Private Members

        private long m_lSubType;
        private IHookHelper m_hookHelper = null;
        private IEngineEditProperties m_engineEditor;
        private System.Windows.Forms.Cursor m_InsertVertexCursor;
        private System.Windows.Forms.Cursor m_AddVertexCursor;
        private System.Windows.Forms.Cursor m_DeleteVertexCursor;

        #endregion

        #region Class constructor
        public VertexEditTools()
        {
            #region load the cursors
         
            try
            {
                m_InsertVertexCursor = new System.Windows.Forms.Cursor(GetType().Assembly.GetManifestResourceStream("Commands.InsertVertexCursor.cur"));
                m_AddVertexCursor = new System.Windows.Forms.Cursor(GetType().Assembly.GetManifestResourceStream("Commands.AddVertexCursor.cur"));
                m_DeleteVertexCursor = new System.Windows.Forms.Cursor(GetType().Assembly.GetManifestResourceStream("Commands.DeleteVertexCursor.cur"));  
            }
            catch (Exception ex)
            {
                System.Diagnostics.Trace.WriteLine(ex.Message, "Invalid Cursor");
            }
            #endregion
        }
        #endregion

        #region Overriden Class Methods

        /// <summary>
        /// Return the cursor to be used by the tool
        /// </summary>
        public override int Cursor
        {
           
            get
            { 
                int iHandle = 0;

                switch (m_lSubType)
                {
                    case 1:
                        iHandle = m_InsertVertexCursor.Handle.ToInt32();
                        break;
                    
                    case 2:
                        iHandle = m_AddVertexCursor.Handle.ToInt32();
                        break;

                    case 3:
                        iHandle = m_DeleteVertexCursor.Handle.ToInt32();
                        break;
                }

                return (iHandle); 
            
            }
        }

        /// <summary>
        /// Occurs when this tool is created
        /// </summary>
        /// <param name="hook">Instance of the application</param>
        public override void OnCreate(object hook)
        {
            try
            {
                m_hookHelper = new HookHelperClass();
                m_hookHelper.Hook = hook;    
                m_engineEditor = new EngineEditorClass(); //this class is a singleton
                
            }
            catch
            {
                m_hookHelper = null;
            }
        }


        /// <summary>
        /// Perform checks so that the tool is enabled appropriately
        /// </summary>
        public override bool Enabled
        {
            get
            {   
                
                //check whether Editing 
                ILayer layer = m_engineEditor.TargetLayer;
                IFeatureLayer featureLayer;

                if (layer == null)
                {
                    return false;
                }
                
                //check only for featurelayers
                if (!(layer is IFeatureLayer))
                {
                    return false;
                }
                else
                {
                    featureLayer = layer as IFeatureLayer;
                    //check for appropriate geometry types
                    IFeatureClass featureClass = featureLayer.FeatureClass;
                    esriGeometryType geomType = featureClass.ShapeType;
                    if ((geomType != esriGeometryType.esriGeometryPolygon) & (geomType != esriGeometryType.esriGeometryPolyline))
                    {
                        return false;
                    }

                    //check that only one feature is currently selected
                    IFeatureSelection featureSelection = featureLayer as IFeatureSelection;
                    ISelectionSet selectionSet = featureSelection.SelectionSet;
                    if (selectionSet.Count != 1) 
                    {
                        return false;
                    }
                }

                //check for appropriate scale threshhold - change this to suit the data being edited
                //if (m_hookHelper.FocusMap.MapScale > 500000)
                //{
                //    return false;
                //}
            
                //conditions have been met so enable the tool
                return true;
            }
        }

        /// <summary>
        /// The mouse up performs the action appropriate for each sub-typed command: 
        /// insert vertex, add vertex or delete vertex
        /// </summary>
        /// <param name="Button"></param>
        /// <param name="Shift"></param>
        /// <param name="X">The X screen coordinate of the clicked location</param>
        /// <param name="Y">The Y screen coordinate of the clicked location</param>
        public override void OnMouseUp(int Button, int Shift, int X, int Y)
        {
            try
            {
                IPoint clickedPt = m_hookHelper.ActiveView.ScreenDisplay.DisplayTransformation.ToMapPoint(X, Y);

                //get layer being edited
                IFeatureLayer featureLayer = m_engineEditor.TargetLayer as IFeatureLayer;

                //get the currently selected feature    
                IFeatureSelection featureSelection = featureLayer as IFeatureSelection;
                ISelectionSet selectionSet = featureSelection.SelectionSet;
                ICursor cursor;
                selectionSet.Search(null, true, out cursor);
                IFeatureCursor featureCursor = cursor as IFeatureCursor;
                //the enabled property has already checked that only 1 feature is selected
                IFeature feature = featureCursor.NextFeature();

                //Take a copy of geometry for the selected feature
                IGeometry editShape = feature.ShapeCopy;

                #region local variables used in the HitTest

                IHitTest hitShape = editShape as IHitTest;
                IPoint hitPoint = new PointClass();
                double hitDistance = 0;
                int hitPartIndex = 0;
                int hitSegmentIndex = 0;
                bool bRightSide = false;
                esriGeometryHitPartType hitPartType = esriGeometryHitPartType.esriGeometryPartNone;
                double searchRadius = 0; //this is the maximum distance away from the shape that will be used for the test

                switch (m_lSubType)
                {
                    case 1:
                        hitPartType = esriGeometryHitPartType.esriGeometryPartBoundary;
                        searchRadius = 10000;
                        break;

                    case 2:

                        hitPartType = esriGeometryHitPartType.esriGeometryPartBoundary;
                        searchRadius = 1000;
                        break;

                    case 3:

                        hitPartType = esriGeometryHitPartType.esriGeometryPartVertex;
                        searchRadius = 100;
                        break;
                }

                #endregion

                //perform the HitTest
                hitShape.HitTest(clickedPt, searchRadius, hitPartType, hitPoint, ref hitDistance, ref hitPartIndex, ref hitSegmentIndex, ref bRightSide);

                //check whether the HitTest was successful (i.e within the search radius)
                if (hitPoint.IsEmpty == false)
                {
                    object missing = Type.Missing;
                    object hitSegmentIndexObject = new object();
                    hitSegmentIndexObject = hitSegmentIndex;

                    //get the point collection for this features geometry
                    IPointCollection pointCollection = editShape as IPointCollection;

                    //modify the geometry appropriately for each sub-typed command
                    switch (m_lSubType)
                    {
                        case 1: //Insert Vertex on shape boundary
                            pointCollection.AddPoint(hitPoint, ref missing, ref hitSegmentIndexObject);
                            break;

                        case 2: //Add Vertex at clicked location
                            pointCollection.AddPoint(clickedPt, ref missing, ref hitSegmentIndexObject);
                            break;

                        case 3: //Delete Vertex closest to clicked location
                            pointCollection.RemovePoints(hitSegmentIndex, 1);
                            break;
                    }

                    #region Perform an edit operation to store the new geometry for selected feature

                    IDataset dataset = featureLayer.FeatureClass as IDataset;
                    IWorkspaceEdit workspaceEdit = dataset.Workspace as IWorkspaceEdit;

                    try
                    {                        
                        workspaceEdit.StartEditOperation();
                        feature.Shape = editShape;
                        feature.Store();
                        workspaceEdit.StopEditOperation();
                    }
                    catch (Exception ex)
                    {
                        workspaceEdit.AbortEditOperation();
                        System.Diagnostics.Trace.WriteLine(ex.Message, "Edit Geometry Failed");
                    }

                    #endregion
                }

                //refresh the display 
                m_hookHelper.ActiveView.PartialRefresh(esriViewDrawPhase.esriViewGeography, (object)featureLayer, m_hookHelper.ActiveView.Extent);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Trace.WriteLine(ex.Message, "Unexpected Error");
            }
        }

        #endregion

        #region ICommandSubType Interface

        /// <summary>
        /// Returns the number of subtyped commands
        /// </summary>
        /// <returns></returns>
        public int GetCount()
        {
            return 3;
        }

        /// <summary>
        /// Sets the sub-type
        /// </summary>
        /// <param name="SubType"></param>
        public void SetSubType(int SubType)
        {
            m_lSubType = SubType;

            //set a common Command category for all subtypes
            base.m_category = "Custom vertex & reshape editing commands";

            ResourceManager rm = new ResourceManager("Commands.Resources", Assembly.GetExecutingAssembly());

            switch (m_lSubType)
            {
                case 1: //Insert Vertex on shape boundary

                    base.m_caption = (string)rm.GetString("InsertVertex_CommandCaption");//
                    base.m_message = (string)rm.GetString("InsertVertex_CommandMessage");
                    base.m_toolTip = (string)rm.GetString("InsertVertex_CommandToolTip");
                    base.m_name = "Commands_InsertVertexOnShape";
                    base.m_cursor = m_InsertVertexCursor;

                    #region bitmap

                    try
                    {
                        base.m_bitmap = (System.Drawing.Bitmap)rm.GetObject("InsertVertex");   
                    }
                    catch (Exception ex)
                    {
                        System.Diagnostics.Trace.WriteLine(ex.Message, "Invalid Bitmap");
                    }

                    #endregion

                    break;

                case 2: //Add vertex at clicked location

                    base.m_caption = (string)rm.GetString("AddVertex_CommandCaption");//
                    base.m_message = (string)rm.GetString("AddVertex_CommandMessage");
                    base.m_toolTip = (string)rm.GetString("AddVertex_CommandToolTip");
                    base.m_name = "Commands_AddVertexAtClickPoint";
                    base.m_cursor = m_AddVertexCursor;

                    #region bitmap

                    try
                    {
                        base.m_bitmap = (System.Drawing.Bitmap)rm.GetObject("AddVertex");
                    }
                    catch (Exception ex)
                    {
                        System.Diagnostics.Trace.WriteLine(ex.Message, "Invalid Bitmap");
                    }

                    #endregion

                    break;

                case 3: //Delete vertex at clicked location

                    base.m_caption = (string)rm.GetString("DeleteVertex_CommandCaption");//
                    base.m_message = (string)rm.GetString("DeleteVertex_CommandMessage");
                    base.m_toolTip = (string)rm.GetString("DeleteVertex_CommandToolTip");
                    base.m_name = "Commands_DeleteVertexAtClickPoint";
                    base.m_cursor = m_DeleteVertexCursor;

                    #region bitmap
                    try
                    {
                        base.m_bitmap = (System.Drawing.Bitmap)rm.GetObject("DeleteVertex");
                    }
                    catch (Exception ex)
                    {
                        System.Diagnostics.Trace.WriteLine(ex.Message, "Invalid Bitmap");
                    }

                    #endregion

                    break;
                    
            }
         
        }

        #endregion
    }
        
}
