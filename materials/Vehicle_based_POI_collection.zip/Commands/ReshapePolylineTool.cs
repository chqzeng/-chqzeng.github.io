using System;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using System.Resources;
using System.Reflection;

using ESRI.ArcGIS.ADF.BaseClasses;
using ESRI.ArcGIS.ADF.CATIDs;
using ESRI.ArcGIS.Controls;
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.Geometry;
using ESRI.ArcGIS.Geodatabase;
using ESRI.ArcGIS.SystemUI;
using ESRI.ArcGIS.Display;


namespace Commands
{
    /// <summary>
    /// Summary description for InsertVertex.
    /// </summary>
    [Guid("C193694B-36BF-4b4c-884E-4DFF430FF036")]
    [ClassInterface(ClassInterfaceType.None)]
    [ProgId("Commands.ReshapePolylineTool")]
    public sealed class ReshapePolylineTool : BaseTool
    {
        #region COM Registration Function(s)
        [ComRegisterFunction()]
        [ComVisible(false)]
        static void RegisterFunction(Type registerType)
        {
            // Required for ArcGIS Component Category Registrar support
            ArcGISCategoryRegistration(registerType);
        }

        [ComUnregisterFunction()]
        [ComVisible(false)]
        static void UnregisterFunction(Type registerType)
        {
            // Required for ArcGIS Component Category Registrar support
            ArcGISCategoryUnregistration(registerType);
        }

        #region ArcGIS Component Category Registrar generated code
        /// <summary>
        /// Required method for ArcGIS Component Category registration -
        /// Do not modify the contents of this method with the code editor.
        /// </summary>
        private static void ArcGISCategoryRegistration(Type registerType)
        {
            string regKey = string.Format("HKEY_CLASSES_ROOT\\CLSID\\{{{0}}}", registerType.GUID);
            ControlsCommands.Register(regKey);
        }
        /// <summary>
        /// Required method for ArcGIS Component Category unregistration -
        /// Do not modify the contents of this method with the code editor.
        /// </summary>
        private static void ArcGISCategoryUnregistration(Type registerType)
        {
            string regKey = string.Format("HKEY_CLASSES_ROOT\\CLSID\\{{{0}}}", registerType.GUID);
            ControlsCommands.Unregister(regKey);
        }

        #endregion
        #endregion

        #region Private Members

        private IHookHelper m_hookHelper = null;
        private IEngineEditProperties m_engineEditor;
      
        #endregion

        #region Class Constructor
        public ReshapePolylineTool()
        {
            #region load the cursor
            
            System.Windows.Forms.Cursor reshapeCursor = null;
         
            try
            {
                reshapeCursor = new System.Windows.Forms.Cursor(GetType().Assembly.GetManifestResourceStream("Commands.ReshapePolylineCursor.cur"));
            }
            catch (Exception ex)
            {
                System.Diagnostics.Trace.WriteLine(ex.Message, "Invalid Cursor");
            }
            #endregion

            #region load the  bitmap

            ResourceManager rm = new ResourceManager("Commands.Resources", Assembly.GetExecutingAssembly());

            try
            {
                base.m_bitmap = (System.Drawing.Bitmap)rm.GetObject("ReshapePolyline");
            }
            catch (Exception ex)
            {
                System.Diagnostics.Trace.WriteLine(ex.Message, "Invalid Bitmap");
            }

            #endregion

            base.m_category = "Custom vertex & reshape editing commands";
            base.m_caption = (string)rm.GetString("Reshape_CommandCaption");//
            base.m_message = (string)rm.GetString("Reshape_CommandMessage");
            base.m_toolTip = (string)rm.GetString("Reshape_CommandToolTip");
            base.m_name = "Commands_ReshapeSelectedShape";
            base.m_cursor = reshapeCursor;
        }
        #endregion

        #region Overriden Class Methods

        /// <summary>
        /// Occurs when this tool is created
        /// </summary>
        /// <param name="hook">Instance of the application</param>
        public override void OnCreate(object hook)
        {
            try
            {
                m_hookHelper = new HookHelperClass();
                m_hookHelper.Hook = hook;
                m_engineEditor = new EngineEditorClass(); //this class is a singleton
               
            }
            catch
            {
                m_hookHelper = null;
            }
        }

        /// <summary>
        /// Perform checks so that the tool is enabled appropriately
        /// </summary>
        public override bool Enabled
        {
            get
            {  
                //check whether Editing 
                ILayer layer = m_engineEditor.TargetLayer;
             
                if (layer == null)
                {
                    return false;
                }
                
                //check only for featurelayers
                IFeatureLayer featureLayer = null;

                if (!(layer is IFeatureLayer))
                {
                    
                    return false;
                }
                else
                {
                    featureLayer = layer as IFeatureLayer;
                    //check for appropriate geometry types
                    IFeatureClass featureClass = featureLayer.FeatureClass;
                    esriGeometryType geomType = featureClass.ShapeType;
                    if (geomType != esriGeometryType.esriGeometryPolyline)
                    {
                        return false;
                    }

                    //check that only one feature is currently selected
                    IFeatureSelection featureSelection = featureLayer as IFeatureSelection;
                    ISelectionSet selectionSet = featureSelection.SelectionSet;
                    if (selectionSet.Count != 1)
                    {
                        return false;
                    }
                }
            
                //conditions have been met so enable the tool
                return true;
            }
        }


        public override void OnMouseDown(int Button, int Shift, int X, int Y)
        {
         
            IScreenDisplay screenDisplay = m_hookHelper.ActiveView.ScreenDisplay;
            
            #region Create a symbol to use for feedback

                ISimpleLineSymbol sym = new SimpleLineSymbolClass();
                
			    IRgbColor color = new RgbColorClass();	 //red
			    color.Red = 255;
			    color.Green  = 0;
			    color.Blue  = 0;

                sym.Color = color;
                sym.Style = esriSimpleLineStyle.esriSLSSolid;
                sym.Width = 2;

            #endregion

            IRubberBand reshapeBand = new RubberLineClass();
            IGeometry reshapeGeom =  reshapeBand.TrackNew(screenDisplay,sym as ISymbol);

            //get layer being edited
            IFeatureLayer featureLayer = m_engineEditor.TargetLayer as IFeatureLayer;
            
            //trace the line drawn by the user onto the screen
            screenDisplay.StartDrawing(screenDisplay.hDC, (short) esriScreenCache.esriNoScreenCache);
            screenDisplay.SetSymbol(sym as ISymbol);
            screenDisplay.DrawPolyline(reshapeGeom);
            screenDisplay.FinishDrawing();

            if (reshapeGeom.IsEmpty == false)
            {    
                //get the currently selected feature    
                IFeatureSelection featureSelection = featureLayer as IFeatureSelection;
                ISelectionSet selectionSet = featureSelection.SelectionSet;
                ICursor cursor;
                selectionSet.Search(null, true, out cursor);
                IFeatureCursor featureCursor = cursor as IFeatureCursor;
                //the enabled property has already checked that only 1 feature is selected
                IFeature feature = featureCursor.NextFeature();

                //Take a copy of geometry for the selected feature
                IGeometry editShape = feature.ShapeCopy;

                //create a path from the rubberband
                IPointCollection reshapePath = new PathClass();
                reshapePath.AddPointCollection(reshapeGeom as IPointCollection);
                
                //reshape the selected feature
                IPolyline polyline = editShape as IPolyline;
                polyline.Reshape(reshapePath as IPath);

                #region Perform an edit operation to store the new geometry for selected feature

                IDataset dataset = featureLayer.FeatureClass as IDataset;
                IWorkspaceEdit workspaceEdit = dataset.Workspace as IWorkspaceEdit;
                workspaceEdit.EnableUndoRedo();

                try
                {
                    workspaceEdit.StartEditOperation();
                    feature.Shape = editShape;
                    feature.Store();
                    workspaceEdit.StopEditOperation();
                }
                catch (Exception ex)
                {
                    workspaceEdit.AbortEditOperation();
                    System.Diagnostics.Trace.WriteLine(ex.Message, "Edit Geometry Failed");
                }

                #endregion
            }

            //refresh the display 
            m_hookHelper.ActiveView.PartialRefresh(esriViewDrawPhase.esriViewGeography, (object)featureLayer, m_hookHelper.ActiveView.Extent);

        }
        
        
        #endregion

       
    }
        
}
