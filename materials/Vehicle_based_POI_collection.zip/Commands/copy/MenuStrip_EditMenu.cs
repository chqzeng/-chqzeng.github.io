using System;
using System.Collections.Generic;
using System.Text;


using ESRI.ArcGIS.ADF.BaseClasses;
using ESRI.ArcGIS.Controls;
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.SystemUI;

namespace Commands
{
    public sealed class MenuStrip_EditMenu : BaseCommand, ICommandSubType
    {
        private IHookHelper m_hookHelper = new HookHelperClass();
        private long m_subType;
        
        bool b_IsEditState = false;

        //private EngineEditor m_EngineEditor = new EngineEditorClass();
        //private IEngineEditEvents_Event m_EngineEditEvents;

        public MenuStrip_EditMenu()
        {
        }

        public override void OnClick()
        {
            ICommand pCommand = null;
            switch (m_subType)
            {
                case 1:
                    pCommand = new ControlsEditingStartCommandClass();
                    pCommand.OnCreate(this.m_hookHelper.Hook);
                    pCommand.OnClick();
                    //b_IsEditState = true;
                    break;
                case 2:
                    pCommand = new ControlsEditingStopCommandClass();
                    pCommand.OnCreate(this.m_hookHelper.Hook);
                    pCommand.OnClick();
                    //b_IsEditState = false;
                    break;
                case 3:
                    pCommand = new ControlsEditingSaveCommandClass();
                    pCommand.OnCreate(this.m_hookHelper.Hook);
                    pCommand.OnClick();
                    break;
            }
        }

        public override void OnCreate(object hook)
        {
            m_hookHelper.Hook = hook;
        }

        public int GetCount()
        {
            return 3;
        }

        public void SetSubType(int SubType)
        {
            m_subType = SubType;
        }

        public override string Caption
        {
            get
            {
                switch (m_subType)
                {
                    case 1:
                        return "��ʼ�༭";  
                    case 2:
                        return "ֹͣ�༭";
                    case 3:
                        return "����༭";
                }
                return "";
            }
        }
        public override bool Enabled
        {
            get
            {
                bool enabled = false;
                IEngineEditor editor = new EngineEditorClass();
                if (editor.EditState == esriEngineEditState.esriEngineStateEditing) b_IsEditState = true;
                else b_IsEditState = false;
                switch (m_subType)
                {
                    case 1:
                        if (b_IsEditState) enabled = false;
                        else enabled = true;
                        //if (((IMapControl2)this.m_hookHelper.Hook).LayerCount <= 0) enabled = false;
                        break;
                    case 2:
                        if (!b_IsEditState) enabled = false;
                        else enabled = true;
                        break;
                    case 3:
                        if (!b_IsEditState) enabled = false;
                        else enabled = true;
                        break;
                }
                return enabled;
            }
        }

        public void ExportYutuVectorData(string strPath, IFeatureLayer lyr)
        {

            string strName = System.IO.Path.GetFileNameWithoutExtension(strPath);
            string strOutPath = strPath;
            bool m_bExists = false;
            //����ļ����ڣ���������ɾ��
            try
            {
                if (System.IO.File.Exists(strPath))
                {
                    //m_bExists = true;
                    //strOutPath = strOutPath + "_ext";
                    System.IO.File.Delete(strPath);
                }

                System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor;

                YuTuSurveyPlatform.Geometry_Attribute attr = new YuTuSurveyPlatform.Geometry_Attribute();

                string strpath = strOutPath;// strPath;
                string TableName = System.IO.Path.GetFileNameWithoutExtension(strpath);//"MytestShp"
                attr.CreateTableInMDB(strpath, TableName, lyr);
                if (!attr.WriteShpaeFile2YutuFile(strpath, TableName, lyr)) return;

                if (m_bExists)
                {
                    System.IO.File.Delete(strPath);
                    //System.IO.File.Replace(strPath, strOutPath,"");
                    System.IO.File.Move(strOutPath, strPath);
                }
                System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default;
            }
            catch (Exception ex) { MessageBox.Show("����YUTU����������ԭ����ִ���\r\n" + ex.Message); return; }
            MessageBox.Show("�ɹ����� YVT ��ʽ ���� ��");
        }
    }
}
