//�ļ�����Ȩ��Ϣ------------------
/*
 * ���ļ������п���ͼ���¿Ƽ����޹�˾����ҵ����ƽ̨����ɲ���
 * δ���������ÿ���������������������ҵ��;
 * ��Ȩ���У��п���ͼ���¿Ƽ����޹�˾(http://www.mapuni.com/) 
 * �������ߣ�������   chqzeng@163.com 
 * ��дʱ�䣺2010-09-01
 */
using System;
using System.Collections.Generic;
using System.Text;
using System.Data.OleDb;
using System.Data;
using System.IO;
using ADOX;
using System.Runtime.InteropServices;

using Geometry_Define;

using ESRI.ArcGIS.Geodatabase;
using ESRI.ArcGIS.esriSystem;
using ESRI.ArcGIS.Carto;
namespace YuTuSurveyPlatform
{
    /// <summary>
    /// ���ڹ�����ǰ��ͼ�����У�����༭�Ĺ���
    /// ������������ɾ���޵ı��� �͵�ǰ��ͼ��Ӧ��ά��
    /// </summary>
    /// 
    public class Survey_RecordMng
    {
        //��ͼ���ݱ��е�ID�ֶ� ���� 
        public string strObjectID = Geometry_IO.Geometry_Attribute.m_strConstOIDName;
        //��ͼ���ݱ��ж�ӦSHAPE��FID�ֶ� ���� 
        public string strFldDirty = Geometry_IO.Geometry_Attribute.m_strConstFieldChange;

        /// <summary>
        /// Gets the field name from SHP.
        /// ��ȡĳ���ֶε�����
        /// </summary>
        /// <param name="indField">The ind field.�ֶε�������</param>
        /// <param name="pLayer">The p layer.����</param>
        /// <returns></returns>
        public string GetFieldNameFromShp(int indField, IFeatureLayer pLayer)
        {
            ITable pTable = pLayer as ITable;
            IField pField = null;
            pField = pTable.Fields.get_Field(indField);
            return pField.Name;

            //if (pField.Type == esriFieldType.esriFieldTypeGeometry)
            //{
            //    strOutFieldName="SHAPE";
            //}
        }
        
        //δʹ�ã�����ɾ�������ӵ����������
        public bool Suvery_Record_Update(OleDbCommand odCommand,string tableName,IFeatureLayer pLayer,int featureOID, IRow differenceRow, ILongArray longArray )
        {
            string strSQL = "update " + tableName + " set ";
            ITable table=pLayer as ITable;
            bool IsShapeUpdated = false;

            //���� UPDATE SQL   ���
            for (int i = 0; i < longArray.Count; i++)
            {
                string curField = GetFieldNameFromShp(longArray.get_Element(i), pLayer);
                if (curField == "SHAPE")
                {
                    IsShapeUpdated = true;
                    continue;
                }
                strSQL=strSQL+curField + " = '";
                strSQL = strSQL + differenceRow.get_Value(longArray.get_Element(i)).ToString()+"', ";
            }

            strSQL = strSQL.Remove(strSQL.Length - 2);
            strSQL = strSQL + " where " + table.OIDFieldName + " = " + featureOID.ToString();

            odCommand.CommandText = strSQL;
            try
            {
                odCommand.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show("����:��" + ex.Message + ",�޷�ִ��:\r\n" + odCommand.CommandText);
                return false;
            }

            if(IsShapeUpdated)  //����ͼ�α�����
            {
                IFeatureLayer ftrLayer = pLayer;
                IQueryFilter queryFilter = new QueryFilterClass();
                queryFilter.SubFields = "SHAPE";
                queryFilter.WhereClause =table.OIDFieldName + " = " + featureOID.ToString();
                IFeatureCursor featureCursor = ftrLayer.FeatureClass.Search(queryFilter, false);
                IFeature Infeature = featureCursor.NextFeature();

                //loop through all of the features and save it 
                string strtTablename, strOIDname;
                strtTablename = tableName;
                strOIDname = table.OIDFieldName;
                Geometry_IO.Geometry_Attribute geometry_att = new Geometry_IO.Geometry_Attribute();
                try
                {
                    if (Infeature != null)
                    {
                        G_Geometry pt = Geometry_IO.Geometry_Conv2Shp.ConvFromSHP2YutuGeometry(Infeature.Shape);
                        geometry_att.SetShapeGeometry(odCommand, strtTablename, strOIDname, Infeature.OID, pt);

                        featureCursor.Flush();
                        //Infeature = featureCursor.NextFeature();
                    }
                }
                catch (Exception ex)
                {
                    System.Windows.Forms.MessageBox.Show("����:��" + ex.Message + ",�޷�ִ��:\r\n");
                    return false;
                }
            }
            return true;
        }

        /// <summary>
        /// Suvery_s the record_ delete.
        /// ɾ����¼
        /// </summary>
        /// <param name="OIDList">The OID list. ��Ҫ������ID�б�</param>
        /// <param name="mdbPath">��ͼ��ʽ���ݵ�·�� </param>
        /// <param name="tableName">Name of the table.��ͼ��ʽ���ݵı���</param>
        /// <param name="pLayer">The p layer.����</param>
        /// <returns>�����Ƿ�ִ�гɹ�</returns>
        public bool Suvery_Record_Delete(List<int> OIDList, string mdbPath, string tableName, IFeatureLayer pLayer)
        {
            //1���������� 
            string strConn = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + mdbPath;
            OleDbConnection odcConnection = new OleDbConnection(strConn);
            odcConnection.Open();
            OleDbCommand odCommand = odcConnection.CreateCommand();

            ITable pTable = pLayer as ITable;
            string strOIDName = pTable.OIDFieldName;
            
            string strOriginal = "delete from " + tableName + " where " + strOIDName + " = ";
            for (int index = 0; index < OIDList.Count; index++)
            {
                odCommand.CommandText = strOriginal + OIDList[index].ToString();
                try
                {
                    odCommand.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    System.Windows.Forms.MessageBox.Show("����:��" + ex.Message + ",�޷�ִ��:\r\n" + odCommand.CommandText);
                    //return false;
                    continue;
                }
            }
            return true;
        }

        /// <summary>
        /// Suvery_s the record_ delete.
        /// ���Ӽ�¼
        /// </summary>
        /// <param name="OIDList">The OID list. ��Ҫ������ID�б�</param>
        /// <param name="mdbPath">��ͼ��ʽ���ݵ�·�� </param>
        /// <param name="tableName">Name of the table.��ͼ��ʽ���ݵı���</param>
        /// <param name="pLayer">The p layer.����</param>
        /// <returns>�����Ƿ�ִ�гɹ�</returns>
        public bool Suvery_Record_Insert(List<int> OIDList, string mdbPath, string tableName, IFeatureLayer pLayer)//int featureOID
        {
            //1���������� 
            string strConn = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + mdbPath;
            OleDbConnection odcConnection = new OleDbConnection(strConn);
            odcConnection.Open();
            OleDbCommand odCommand = odcConnection.CreateCommand();

            ITable pTable = pLayer as ITable;
            IQueryFilter queryFilter = new QueryFilterClass();
            //queryFilter.SubFields = "*";
            string strOIDName = pTable.OIDFieldName;
            string strSQL = "";

            //queryFilter.WhereClause = strOIDName + " = " + Infeature.OID.ToString();

            for (int index = 0; index < OIDList.Count; index++)
                strSQL = strSQL + strOIDName + " =  " + OIDList[index].ToString() + " or ";
            strSQL=strSQL.Remove(strSQL.Length - 3);
            queryFilter.WhereClause = strSQL;

            ICursor pCursor = pTable.Search(queryFilter, false); //OIDList
            IRow pRow = pCursor.NextRow();
            Geometry_IO.Geometry_Attribute geometry_att = new Geometry_IO.Geometry_Attribute();
            string strOriginal = "insert into " + tableName + geometry_att.GetFieldListFromShp(pLayer);

            while (pRow != null)
            {
                odCommand.CommandText =strOriginal;

                string valuestring = "values (";

                for (int i = 0; i < pRow.Fields.FieldCount; i++)
                {
                    //����ֶ�����ΪesriFieldTypeGeometry�������ͼ�����������ֶ�ֵ
                    if (pRow.Fields.get_Field(i).Type == esriFieldType.esriFieldTypeGeometry || pRow.Fields.get_Field(i).Name == strFldDirty)//
                    {
                        continue;
                    }
                    else if (pRow.Fields.get_Field(i).Type == esriFieldType.esriFieldTypeBlob)
                    {
                        valuestring = valuestring + @"'Unsupport Blob Field',";
                    }
                    else
                    {
                        if (pRow.get_Value(i) == null || pRow.get_Value(i).ToString() == "")//Ϊ��ʱ��Ϊ�ռ�����ֶ�
                        {
                            //if (pRow.Fields.get_Field(i).Type == esriFieldType.esriFieldTypeString) valuestring = valuestring + @"'',";
                            if (pRow.Fields.get_Field(i).Type == esriFieldType.esriFieldTypeString) valuestring = valuestring + @"'',";
                            else if (pRow.Fields.get_Field(i).Type == esriFieldType.esriFieldTypeDate)
                            {
                                System.DateTime curT = System.DateTime.Now;
                                string str = string.Format("'{0}-{1}-{2}' ,", curT.Year, curT.Month, curT.Day);
                                valuestring = valuestring + str;
                                //valuestring = valuestring + @"'',";
                            }
                            else valuestring = valuestring + @"'0',";
                        }
                        else
                        {
                            string strTemp = pRow.get_Value(i).ToString();
                            valuestring = valuestring + @"'" + strTemp + @"',";
                        }
                    }
                }
                valuestring = valuestring.Remove(valuestring.Length - 1) + ")";

                odCommand.CommandText = odCommand.CommandText + valuestring;
                try
                {
                    odCommand.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    System.Windows.Forms.MessageBox.Show("����:��" + ex.Message + ",�޷�ִ��:\r\n" + odCommand.CommandText);
                    //return false;
                    continue;
                }
                //new line
                pRow = pCursor.NextRow();
            }

          
            //IQueryFilter queryFilter = new QueryFilterClass();
            //queryFilter.WhereClause = "";
            IFeatureLayer ftrLayer = pLayer as IFeatureLayer;
            IFeatureCursor featureCursor = ftrLayer.FeatureClass.Search(queryFilter, false);
            IFeature Infeature = featureCursor.NextFeature();
            
            //loop through all of the features and save it 
            string strtTablename, strOIDname;
            strtTablename = tableName;
            strOIDname = pTable.OIDFieldName;
            try
            {
                while (Infeature != null)
                {
                    G_Geometry pt = Geometry_IO.Geometry_Conv2Shp.ConvFromSHP2YutuGeometry(Infeature.Shape);
                    geometry_att.SetShapeGeometry(odCommand, strtTablename, strOIDname, Infeature.OID, pt);

                    featureCursor.Flush();
                    Infeature = featureCursor.NextFeature();
                }
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show("����:��" + ex.Message + ",�޷�ִ��:\r\n");
                return false;
            }

            odcConnection.Close();

            return true;
        }

        //δʹ�ã����������ݿ�FEATURELYAER ��Ч
        public void UpdatgeChangesForScope(string mdbPath, string tableName, IFeatureLayer pLayer, esriEditDataChangesType scope)
        {
            IWorkspace workspace = ((IDataset)(pLayer.FeatureClass)) as IWorkspace;
            IWorkspaceEdit2 workspaceEdit = (IWorkspaceEdit2)workspace;
            IDataChangesEx dataChangesEx = workspaceEdit.get_EditDataChanges(scope);

            // Show the changes for each modified class in the workspace. -->update
            IEnumBSTR modifiedClasses = dataChangesEx.ModifiedClasses;
            String modifiedClass = null;
            while ((modifiedClass = modifiedClasses.Next()) != null)
            {
                IDifferenceCursorEx differenceCursorEx = dataChangesEx.ExtractEx
                    (modifiedClass, esriDifferenceType.esriDifferenceTypeUpdateNoChange);

                int featureOID = -1;
                IRow sourceRow = null;
                IRow differenceRow = null;
                ILongArray longArray = null;
                List<int> OIDList = new List<int>();

                // ɾ����¼ Get a FID set for all of the deleted features. -->delete
                IFIDSet2 deletedFIDSet = (IFIDSet2)dataChangesEx.get_ChangedIDs
                    (modifiedClass, esriDifferenceType.esriDifferenceTypeDeleteNoChange);
                IEnumIDs deletedEnumIDs = deletedFIDSet.IDs;
                int nextDeletedID = -1;
                OIDList.Clear();
                while ((nextDeletedID = deletedEnumIDs.Next()) != -1)
                {
                    OIDList.Add(nextDeletedID);
                }
                Suvery_Record_Delete(OIDList, mdbPath, tableName,pLayer);


                // ���Ӽ�¼ Get a FID set for all of the inserted features.  -->add
                IFIDSet2 insertedFIDSet = (IFIDSet2)dataChangesEx.get_ChangedIDs
                    (modifiedClass, esriDifferenceType.esriDifferenceTypeInsert);
                IEnumIDs insertedEnumIDs = insertedFIDSet.IDs;
                int nextInsertedID = -1;
                OIDList.Clear();
                while ((nextInsertedID = insertedEnumIDs.Next()) != -1)
                {
                    OIDList.Add(nextInsertedID);
                }
                Suvery_Record_Insert(OIDList, mdbPath, tableName, pLayer);
                //finish of one class

                //IFIDSet2 updatedFIDSet = (IFIDSet2)dataChangesEx.get_ChangedIDs
                //    (modifiedClass, esriDifferenceType.esriDifferenceTypeUpdateNoChange);
                //IEnumIDs updatedEnumIDs = updatedFIDSet.IDs;
                //int nextUpdatedID = -1;
                //OIDList.Clear();
                //while ((nextUpdatedID = updatedEnumIDs.Next()) != -1)
                //{
                //    OIDList.Add(nextUpdatedID);
                //}
                //Suvery_Record_Update(OIDList, mdbPath, tableName, pLayer);

                //���¼�¼ 
                differenceCursorEx = dataChangesEx.ExtractEx(modifiedClass, esriDifferenceType.esriDifferenceTypeInsert);
                featureOID = -1;
                sourceRow = null;
                differenceRow = null;
                longArray = null;

                string strConn = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + mdbPath;
                OleDbConnection odcConnection = new OleDbConnection(strConn);
                odcConnection.Open();
                OleDbCommand odCommand = odcConnection.CreateCommand();

                // Get the row values and featureOID.
                OIDList.Clear();
                differenceCursorEx.Next(out featureOID, out sourceRow, out differenceRow, out longArray);
                while (featureOID != -1)
                {
                    Suvery_Record_Update(odCommand,tableName,pLayer, featureOID, differenceRow, longArray);
                    differenceCursorEx.Next(out featureOID, out sourceRow, out differenceRow, out longArray);
                }
                odcConnection.Close();
                return;
            }
            //finish all modified layers
        }

        /// <summary>
        /// Updatges the changes for layer.
        /// ͨ����ʶ������ͼ�㣬ʹ�õı�ʶΪ _DIRTY �ֶ�
        /// </summary>
        /// <param name="mdbPath">��ͼ��ʽ���ݵ�·�� </param>
        /// <param name="tableName">Name of the table.��ͼ��ʽ���ݵı���</param>
        /// <param name="pLayer">The p layer.��Ҫά�������µ�ͼ����</param>
        public void UpdatgeChangesForLayer(string mdbPath, string tableName, IFeatureLayer pLayer)
        {
            List<int> OIDListAdd=new List<int>();
            List<int> OIDListDel = new List<int>();

            ITable pTable = pLayer as ITable;
            IQueryFilter queryFilter = new QueryFilterClass();
            queryFilter.SubFields = pTable.OIDFieldName;
            queryFilter.WhereClause = " "+strFldDirty+ " > 2";  //��ѯ���е� DIRTY �ֶ� ���� 0��\

            //��ȡ���еĸı��˼�¼��ID
            IFeatureClass featureClass = pLayer.FeatureClass;
            IFeatureCursor searchCursor = featureClass.Search(queryFilter, true);
            IFeature feature = null;
            //��ѯ��Ҫɾ�������ӵ��ֶ�
            try
            {
                while ((feature = searchCursor.NextFeature()) != null)
                {
                    object obj = feature.get_Value(0);

                    OIDListAdd.Add(Convert.ToInt32(obj));
                }
            }
            catch {}

            //��ѯ��Ҫ���ӵ����ӵ��ֶ�
            queryFilter.SubFields = pTable.OIDFieldName +" , " + strFldDirty;
            queryFilter.WhereClause = " " + strFldDirty + " > 0";  //��ѯ���е� DIRTY �ֶ� ���� 2��\
            searchCursor = featureClass.Update(queryFilter, false);
            feature = null;
            try
            {
                int fieldIndex = featureClass.FindField(strFldDirty);

                while ((feature = searchCursor.NextFeature()) != null)
                {
                    object obj = feature.get_Value(0);
                    OIDListDel.Add(Convert.ToInt32(obj));

                    //���õ�ǰ����޸ı�ǣ� Ϊ�Ѿ�����޸�״̬
                    if (feature.get_Value(fieldIndex) == null) continue;
                    int mark = Convert.ToInt32(feature.get_Value(fieldIndex));//����
                    if (mark == 1) //ɾ����¼
                    {
                        //feature.set_Value(fieldIndex, 0);
                        //searchCursor.UpdateFeature(feature);
                        searchCursor.DeleteFeature();
                    }
                    else
                    {
                        feature.set_Value(fieldIndex, 0);
                        searchCursor.UpdateFeature(feature);
                    }
                }
                searchCursor.Flush();
            }
            catch { }

            Marshal.ReleaseComObject(searchCursor);

            try
            {
                //��ɾ����Щ��¼��Ȼ���ٲ�����Щ��¼
                if (OIDListDel.Count>0) Suvery_Record_Delete(OIDListDel, mdbPath, tableName, pLayer);
                if (OIDListAdd.Count > 0) Suvery_Record_Insert(OIDListAdd, mdbPath, tableName, pLayer);
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show("���ݸ��¹��̳�����\r\n" + ex.Message);
            }
        }
    }
}
