//�ļ�����Ȩ��Ϣ------------------
/*
 * ���ļ������п���ͼ���¿Ƽ����޹�˾����ҵ����ƽ̨����ɲ���
 * δ���������ÿ���������������������ҵ��;
 * ��Ȩ���У��п���ͼ���¿Ƽ����޹�˾(http://www.mapuni.com/) 
 * �������ߣ�������   chqzeng@163.com 
 * ��дʱ�䣺2010-09-01
 */
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.Drawing;

using ESRI.ArcGIS.ADF.BaseClasses;
using ESRI.ArcGIS.Controls;
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.SystemUI;
using ESRI.ArcGIS.Geodatabase;

namespace YuTuSurveyPlatform
{
    public sealed class MenuStrip_EditMenu : BaseCommand, ICommandSubType
    {
        private IHookHelper m_hookHelper = new HookHelperClass();
        private long m_subType;
        
        bool b_IsEditState = false;
        private MainInterface m_parent = null;
        IMapControl3 m_Mapcontrol = null;

        //private EngineEditor m_EngineEditor = new EngineEditorClass();
        //private IEngineEditEvents_Event m_EngineEditEvents;

        public MenuStrip_EditMenu(int subType, MainInterface interf)
        {
            m_subType = subType;
            m_parent = interf;

            switch (m_subType)
            {
                case 1:
                    base.m_caption = "��ʼ�༭";
                    base.m_category = "myCustomCommands(C#)";
                    base.m_message = "��ʼ�༭";
                    base.m_name = "myCustomCommands(C#)_NorthArrow";
                    base.m_toolTip = "��ʼ�༭";
                    try
                    {
                        string bitmapResourceName = "Edit_StartEdit.bmp";
                        base.m_bitmap = new Bitmap(GetType(), bitmapResourceName);
                    }
                    catch (Exception ex)
                    {
                        System.Diagnostics.Trace.WriteLine(ex.Message, "Invalid Bitmap");
                    }
                    break;
                case 2:
                    base.m_caption = "ֹͣ�༭";
                    base.m_category = "myCustomCommands(C#)";
                    base.m_message = "ֹͣ�༭";
                    base.m_name = "myCustomCommands(C#)_NorthArrow";
                    base.m_toolTip = "ֹͣ�༭";
                    try
                    {
                        string bitmapResourceName = "Edit_StopEdit.bmp";
                        base.m_bitmap = new Bitmap(GetType(), bitmapResourceName);
                    }
                    catch (Exception ex)
                    {
                        System.Diagnostics.Trace.WriteLine(ex.Message, "Invalid Bitmap");
                    }
                    break;

                case 3:
                    base.m_caption = "����༭";
                    base.m_category = "myCustomCommands(C#)";
                    base.m_message = "����༭";
                    base.m_name = "myCustomCommands(C#)_NorthArrow";
                    base.m_toolTip = "����༭";
                    try
                    {
                        string bitmapResourceName = "Edit_SaveEdit.bmp";
                        base.m_bitmap = new Bitmap(GetType(), bitmapResourceName);
                    }
                    catch (Exception ex)
                    {
                        System.Diagnostics.Trace.WriteLine(ex.Message, "Invalid Bitmap");
                    }
                    break;
            }
        }

        public override void OnClick()
        {
            ICommand pCommand = null;
            switch (m_subType)
            {
                case 1:
                    pCommand = new ControlsEditingStartCommandClass();
                    pCommand.OnCreate(m_parent.m_mapControl);//this.m_hookHelper.Hook
                    pCommand.OnClick();
                    //b_IsEditState = true;
                    break;
                case 2:

                    pCommand = new ControlsEditingStopCommandClass();
                    pCommand.OnCreate(this.m_hookHelper.Hook);
                    pCommand.OnClick();
                    //b_IsEditState = false;

                    //m_parent.StopEdit();
                    break;
                case 3:
                    pCommand = new ControlsEditingSaveCommandClass();
                    pCommand.OnCreate(this.m_hookHelper.Hook);
                    pCommand.OnClick();

                    //m_parent.SaveEdit();
                    break;
            }
        }

        public override void OnCreate(object hook)
        {
            m_hookHelper.Hook = hook;
            m_Mapcontrol = hook as IMapControl3;
        }

        public int GetCount()
        {
            return 3;
        }

        public void SetSubType(int SubType)
        {
            m_subType = SubType;
        }

        public override string Caption
        {
            get
            {
                switch (m_subType)
                {
                    case 1:
                        return "��ʼ�༭";  
                    case 2:
                        return "ֹͣ�༭";
                    case 3:
                        return "����༭";
                }
                return "";
            }
        }
        public override bool Enabled
        {
            get
            {
                bool enabled = false;
                IEngineEditor editor = new EngineEditorClass();
                if (editor.EditState == esriEngineEditState.esriEngineStateEditing) b_IsEditState = true;
                else b_IsEditState = false;
                switch (m_subType)
                {
                    case 1:
                        if (b_IsEditState) enabled = false;
                        else enabled = true;
                        //if (((IMapControl2)this.m_hookHelper.Hook).LayerCount <= 0) enabled = false;
                        break;
                    case 2:
                        if (!b_IsEditState) enabled = false;
                        else enabled = true;
                        break;
                    case 3:
                        if (!b_IsEditState) enabled = false;
                        else enabled = true;
                        break;
                }
                return enabled;
            }
        }
    
       
    }
}
