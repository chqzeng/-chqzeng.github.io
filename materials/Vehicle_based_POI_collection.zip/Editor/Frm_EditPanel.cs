using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using ESRI.ArcGIS.Controls;
using ESRI.ArcGIS.SystemUI;
using ESRI.ArcGIS.esriSystem;
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.Geodatabase;
using ESRI.ArcGIS.Geometry;

namespace YuTuSurveyPlatform
{
    public partial class Frm_EditPanel : Form
    {
        private MainInterface m_mainForm;
        private IMapControl3 m_mapControl;
        private ICommandPool m_pool;
        private IOperationStack m_operationStack;

        public Frm_EditPanel()
        {
            InitializeComponent();
        }

        private void Frm_EditPanel_Load(object sender, EventArgs e)
        {
            //*********  Important *************
            //Obtain a reference to the MainForm using the EditHelper class
            m_mainForm = EditHelper.TheMainForm;
            m_mapControl = m_mainForm.m_mapControl;

            //buddy the toolbars with the MapControl 
            this.axToolBar_Blank.SetBuddyControl(m_mapControl);
            this.axToolbar_Create.SetBuddyControl(m_mapControl);
            this.axToolbar_Modify.SetBuddyControl(m_mapControl);
            this.axToolbar_Attribute.SetBuddyControl(m_mapControl);
            this.axToolbar_Normal.SetBuddyControl(m_mapControl);

            //Create and share command pool
            m_pool = new CommandPoolClass();
            axToolBar_Blank.CommandPool = m_pool;
            axToolbar_Create.CommandPool = m_pool;
            axToolbar_Modify.CommandPool = m_pool;
            axToolbar_Attribute.CommandPool = m_pool;
            axToolbar_Normal.CommandPool = m_pool;

            //Create and share operation stack
            m_operationStack = new ControlsOperationStackClass();
            axToolbar_Create.OperationStack = m_operationStack;
            axToolbar_Modify.OperationStack = m_operationStack;
            axToolbar_Attribute.OperationStack = m_operationStack;
            axToolbar_Normal.OperationStack = m_operationStack;

            //load items for the axModifyToolbar blank
            axToolBar_Blank.AddItem("esriControls.ControlsEditingEditorMenu", 0, -1, true, 0, esriCommandStyles.esriCommandStyleIconOnly);
            axToolBar_Blank.AddItem("esriControls.ControlsEditingEditTool", 0, -1, false, 0, esriCommandStyles.esriCommandStyleIconOnly);
            axToolBar_Blank.AddItem("esriControls.ControlsEditingSketchTool", 0, -1, false, 0, esriCommandStyles.esriCommandStyleIconOnly);
            axToolBar_Blank.AddItem("VertexCommands_CS.VertexCommandsMenu", 0, -1, false, 0, esriCommandStyles.esriCommandStyleIconAndText);
            axToolBar_Blank.AddItem("esriControls.ControlsEditingSketchPropertiesCommand", 0, -1, false, 0, esriCommandStyles.esriCommandStyleIconOnly);

            axToolbar_Create.AddItem("esriControls.ControlsEditingTargetToolControl", 0, -1, true, 0, esriCommandStyles.esriCommandStyleIconOnly);

            axToolbar_Attribute.AddItem("esriControls.ControlsEditingTaskToolControl", 0, -1, true, 0, esriCommandStyles.esriCommandStyleIconOnly);


            axToolbar_Modify.AddItem("esriControls.ControlsUndoCommand", 0, -1, true, 0, esriCommandStyles.esriCommandStyleIconOnly);
            axToolbar_Modify.AddItem("esriControls.ControlsRedoCommand", 0, -1, false, 0, esriCommandStyles.esriCommandStyleIconOnly);
            
            axToolbar_Modify.AddItem("esriControls.ControlsEditingCutCommand", 0, -1, true, 0, esriCommandStyles.esriCommandStyleIconOnly);
            axToolbar_Modify.AddItem("esriControls.ControlsEditingPasteCommand", 0, -1, false, 0, esriCommandStyles.esriCommandStyleIconOnly);
            axToolbar_Modify.AddItem("esriControls.ControlsEditingCopyCommand", 0, -1, false, 0, esriCommandStyles.esriCommandStyleIconOnly);
            axToolbar_Modify.AddItem("esriControls.ControlsEditingClearCommand", 0, -1, false, 0, esriCommandStyles.esriCommandStyleIconOnly);
            
            axToolbar_Normal.AddItem("esriControls.ControlsEditingAttributeCommand", 0, -1, true, 0, esriCommandStyles.esriCommandStyleIconOnly);
            axToolbar_Normal.AddItem("SnapCommands_CS.SnapSettingsCommand", 0, -1, true, 0, esriCommandStyles.esriCommandStyleIconAndText);               

        }
    }
}