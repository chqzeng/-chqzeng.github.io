﻿namespace YuTuSurveyPlatform
{
    partial class Frm_EditPanel
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Frm_EditPanel));
            this.axToolbar_Create = new ESRI.ArcGIS.Controls.AxToolbarControl();
            this.axToolbar_Normal = new ESRI.ArcGIS.Controls.AxToolbarControl();
            this.axToolBar_Blank = new ESRI.ArcGIS.Controls.AxToolbarControl();
            this.axToolbar_Attribute = new ESRI.ArcGIS.Controls.AxToolbarControl();
            this.axToolbar_Modify = new ESRI.ArcGIS.Controls.AxToolbarControl();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.axToolbar_Create)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axToolbar_Normal)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axToolBar_Blank)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axToolbar_Attribute)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axToolbar_Modify)).BeginInit();
            this.SuspendLayout();
            // 
            // axToolbar_Create
            // 
            this.axToolbar_Create.Location = new System.Drawing.Point(123, 45);
            this.axToolbar_Create.Name = "axToolbar_Create";
            this.axToolbar_Create.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axToolbar_Create.OcxState")));
            this.axToolbar_Create.Size = new System.Drawing.Size(258, 28);
            this.axToolbar_Create.TabIndex = 17;
            // 
            // axToolbar_Normal
            // 
            this.axToolbar_Normal.Location = new System.Drawing.Point(123, 112);
            this.axToolbar_Normal.Name = "axToolbar_Normal";
            this.axToolbar_Normal.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axToolbar_Normal.OcxState")));
            this.axToolbar_Normal.Size = new System.Drawing.Size(258, 28);
            this.axToolbar_Normal.TabIndex = 16;
            // 
            // axToolBar_Blank
            // 
            this.axToolBar_Blank.Location = new System.Drawing.Point(123, 10);
            this.axToolBar_Blank.Name = "axToolBar_Blank";
            this.axToolBar_Blank.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axToolBar_Blank.OcxState")));
            this.axToolBar_Blank.Size = new System.Drawing.Size(258, 28);
            this.axToolBar_Blank.TabIndex = 15;
            // 
            // axToolbar_Attribute
            // 
            this.axToolbar_Attribute.Location = new System.Drawing.Point(122, 146);
            this.axToolbar_Attribute.Name = "axToolbar_Attribute";
            this.axToolbar_Attribute.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axToolbar_Attribute.OcxState")));
            this.axToolbar_Attribute.Size = new System.Drawing.Size(259, 28);
            this.axToolbar_Attribute.TabIndex = 14;
            // 
            // axToolbar_Modify
            // 
            this.axToolbar_Modify.Location = new System.Drawing.Point(123, 78);
            this.axToolbar_Modify.Name = "axToolbar_Modify";
            this.axToolbar_Modify.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axToolbar_Modify.OcxState")));
            this.axToolbar_Modify.Size = new System.Drawing.Size(258, 28);
            this.axToolbar_Modify.TabIndex = 13;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Navy;
            this.label1.Location = new System.Drawing.Point(29, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 18);
            this.label1.TabIndex = 18;
            this.label1.Text = "编辑图层";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Navy;
            this.label2.Location = new System.Drawing.Point(29, 45);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 18);
            this.label2.TabIndex = 19;
            this.label2.Text = "图层选项";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Navy;
            this.label3.Location = new System.Drawing.Point(29, 78);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 18);
            this.label3.TabIndex = 20;
            this.label3.Text = "常用操作";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Navy;
            this.label4.Location = new System.Drawing.Point(29, 146);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(74, 18);
            this.label4.TabIndex = 21;
            this.label4.Text = "属性修改";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Navy;
            this.label5.Location = new System.Drawing.Point(29, 112);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(74, 18);
            this.label5.TabIndex = 22;
            this.label5.Text = "对象操作";
            // 
            // Frm_EditPanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(392, 179);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.axToolbar_Create);
            this.Controls.Add(this.axToolbar_Normal);
            this.Controls.Add(this.axToolBar_Blank);
            this.Controls.Add(this.axToolbar_Attribute);
            this.Controls.Add(this.axToolbar_Modify);
            this.MaximizeBox = false;
            this.Name = "Frm_EditPanel";
            this.Text = "测图编辑窗口";
            this.Load += new System.EventHandler(this.Frm_EditPanel_Load);
            ((System.ComponentModel.ISupportInitialize)(this.axToolbar_Create)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axToolbar_Normal)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axToolBar_Blank)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axToolbar_Attribute)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axToolbar_Modify)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private ESRI.ArcGIS.Controls.AxToolbarControl axToolbar_Create;
        private ESRI.ArcGIS.Controls.AxToolbarControl axToolbar_Normal;
        private ESRI.ArcGIS.Controls.AxToolbarControl axToolBar_Blank;
        private ESRI.ArcGIS.Controls.AxToolbarControl axToolbar_Attribute;
        private ESRI.ArcGIS.Controls.AxToolbarControl axToolbar_Modify;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
    }
}