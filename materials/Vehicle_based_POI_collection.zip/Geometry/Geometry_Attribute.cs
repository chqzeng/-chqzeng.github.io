//�ļ�����Ȩ��Ϣ------------------
/*
 * ���ļ������п���ͼ���¿Ƽ����޹�˾����ҵ����ƽ̨����ɲ���
 * δ���������ÿ���������������������ҵ��;
 * ��Ȩ���У��п���ͼ���¿Ƽ����޹�˾(http://www.mapuni.com/) 
 * �������ߣ�������   chqzeng@163.com 
 * ��дʱ�䣺2010-09-01
 */
using System;
using System.Collections.Generic;
using System.Text;
using System.Data.OleDb;   
using System.Data;
using System.IO;
using ADOX;
using System.Windows.Forms;

using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.InteropServices;

using ESRI.ArcGIS.esriSystem;
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.Geodatabase;
using ESRI.ArcGIS.Geometry;
using ESRI.ArcGIS.DataSourcesGDB;

using Geometry_Define;


namespace Geometry_IO
{
    // user defined table field
    /// <summary>
    /// �����ֶ�����Ҫ����Ϣ
    /// </summary>
    public struct MyTableField
    {
        //�ֶ���
        public string Name;
        //�ֶ�����
        public DataTypeEnum Type;
        //Ĭ�ϴ�С 
        public int DefinedSize;
        //����
        public int Precision;
        //С��λ��
        public byte NumericScale;
    }


    /// <summary>
    /// Geometry_Attribute ��ժҪ˵����
    /// ����Ϊ������Ҫ���࣬������ YVT��ʽ���ݵĹ���
    /// ͨ������ʵ��YVT������SHP�ļ����� ֮�� ���໥ת��
    /// </summary>
    public partial class Geometry_Attribute
    {
        private OleDbConnection Conn;
        private OleDbCommand cmd;

        //Ĭ�ϵ�YVT���� ��ID��
        public const string m_strConstOIDName = "ObjectId"; //ObjectId  FID
        //Ĭ�ϵ�SHAPE�ļ��е�ID ��
        public const string m_strConstShapeID = "FID";
        //Ĭ�ϱ���
        public const string m_strConstTableName = "MyDataTable";
        //Ĭ�ϵļ����ֶ���
        public const string m_strShapeFieldName = "SHAPE";
        //Ĭ�ϵ��޸��ֶ���
        public const string m_strConstFieldChange = "_DIRTY";

        public const int  m_constShapeColumnIdx = 1;  //����˳��: objectid, shape, fid,

   #region class Geometry_Attribute Operations
        //���캯��
        public Geometry_Attribute()
        {
        }
        /// <summary>
        /// Initializes a new instance of the <see cref="Geometry_Attribute"/> class.
        ///���캯���� ͨ��һ��YVT�ļ���·�� �Լ������������ļ�
        /// </summary>
        /// <param name="MDBFileName">Name of the MDB file.</param>
        /// <param name="Password">The password.</param>
         public Geometry_Attribute(String MDBFileName, String Password)
        {
          
            String Str = string.Format("Provider=Microsoft.Jet.OLEDB.4.0;Data Source={0};Jet Oledb:Database Password={1}", MDBFileName, Password);
            Conn = new OleDbConnection(Str);  //�������ݿ�,Password��MDB������
        }

        /// <summary>
        /// DB_s the conn
        /// //������Դ����
        /// </summary>
        /// <returns></returns>
        public OleDbConnection Db_Conn()
        {
            Conn.Open();
            return Conn;
        }

        /// <summary>
        /// DB_s the create reader.
        /// ����DataReader���ݼ��������SQL���Զ�̬����
        /// </summary>
        /// <param name="SQL">The SQL.��ѯ���</param>
        /// <returns></returns>
        public OleDbDataReader Db_CreateReader(string SQL)
        {
            try
            {
                cmd = new OleDbCommand(SQL, Conn);
                OleDbDataReader Rs = cmd.ExecuteReader();

                return Rs;
            }
            catch (Exception ex)
            {
                MessageBox.Show("����:��" + ex.Message + ",�޷�ִ��:" + SQL);
                return null;

            }
        }


        /// <summary>
        /// DB_s the command reader.
        /// //����DataReader���ݼ��������SQL�Ǵ洢����
        /// </summary>
        /// <param name="SQL">The SQL.</param>
        /// <returns></returns>
        public OleDbDataReader Db_CommandReader(string SQL)
        {
            try
            {

                cmd = new OleDbCommand(SQL, Conn);
                cmd.CommandType = CommandType.StoredProcedure;
                OleDbDataReader Rs = cmd.ExecuteReader();
                return Rs;
            }
            catch (Exception ex)
            {
                MessageBox.Show("����:��" + ex.Message + ",�޷�ִ��:" + SQL);
                return null;
            }

        }

        /// <summary>
        /// DB_s the create data set.
        /// //��������DataSet���ݼ�
        /// </summary>
        /// <param name="SQL">The SQL.</param>
        /// <returns></returns>
        public DataSet Db_CreateDataSet(string SQL)
        {
            try
            {
                cmd = new OleDbCommand(SQL, Conn);
                OleDbDataAdapter Adpt = new OleDbDataAdapter(cmd);
                DataSet Ds = new DataSet();
                Adpt.Fill(Ds, "NewTable");
                return Ds;
            }
            catch (Exception ex)
            {
                MessageBox.Show("����:��" + ex.Message + ",�޷�ִ��:" + SQL);
                return null;
            }

        }

        /// <summary>
        /// DB_s the execute nonquery.
        /// //��������DataReader���ݼ�������Ҫ�������ݵ��޸ģ�ɾ������ʹ�ñ�����
        /// </summary>
        /// <param name="SQL">The SQL.</param>
        /// <returns></returns>
        public bool Db_ExecuteNonquery(string SQL)
        {
            try
            {
                Db_Conn();
                cmd = new OleDbCommand(SQL, Conn);
                try
                {
                    cmd.ExecuteNonQuery();

                    return true;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("����:��" + ex.Message + ",�޷�ִ��:" + SQL);
                    return false;
                }
            }
            finally
            {

                this.close();
            }

        }

        /// <summary>
        /// DB_s the execute nonquery.
        /// //��������DataReader���ݼ�������Ҫ�������ݵ��޸ģ�ɾ������ʹ�ñ�����
        /// </summary>
        /// <param name="SQL">The SQL.</param>
        /// <param name="Connect">if set to <c>true</c> [connect].</param>
        /// <returns></returns>
        public bool Db_ExecuteNonquery(string SQL, bool Connect)
        {
            try
            {
                if (Connect)
                    Db_Conn();
                cmd = new OleDbCommand(SQL, Conn);
                try
                {
                    cmd.ExecuteNonQuery();

                    return true;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("����:��" + ex.Message + ",�޷�ִ��:" + SQL);
                    return false;
                }
            }
            finally
            {
                if (Connect)
                    this.close();
            }

        }

        /// <summary>
        /// DB_s the executequery.
        /// //��������DataReader���ݼ�����������
        /// </summary>
        /// <param name="SQL">The SQL.</param>
        /// <returns></returns>
        public String Db_Executequery(string SQL)
        {
            try
            {
                Db_Conn();
                cmd = new OleDbCommand(SQL, Conn);
                try
                {
                    return cmd.ExecuteScalar().ToString();


                }
                catch (Exception ex)
                {
                    MessageBox.Show("����:��" + ex.Message + ",�޷�ִ��:" + SQL);
                    return "";
                }
            }
            finally
            {
                this.close();
            }

        }

        /// <summary>
        /// DB_s the executequery.
        /// //��������DataReader���ݼ�����������
        /// </summary>
        /// <param name="SQL">The SQL. ��ѯ���</param>
        /// <param name="parent">The parent.�����ڵľ��</param>
        /// <param name="connect">if set to <c>true</c> [connect]. �Ƿ��Ѿ����� </param>
        /// <returns></returns>
        public String Db_Executequery(string SQL,String parent, bool connect)
        {
            try
            {
                if (connect)
                    Db_Conn();
                cmd = new OleDbCommand(SQL, Conn);
                try
                {
                    return cmd.ExecuteScalar().ToString();


                }
                catch (Exception ex)
                {
                    MessageBox.Show("parent:" + parent + "����:��" + ex.Message + ",�޷�ִ��:" + SQL);
                    return "";
                }
            }
            finally
            {
                if (connect)
                    this.close();
            }

        }

        /// <summary>
        /// Gets the BLOB.//����blob���� ���ڼ������ݴ洢
        /// </summary>
        /// <param name="SQL">The SQL.</param>
        /// <returns></returns>
        public MemoryStream getBlob(string SQL)
        {
            try
            {
                Db_Conn();
                cmd = new OleDbCommand(SQL, Conn);
                cmd.CommandType = CommandType.Text;//��sql
                OleDbDataReader Rs = cmd.ExecuteReader();
                if (Rs.Read()) //ѭ������һ����¼
                {
                    if (!(Rs.GetValue(0)  is System.DBNull))
                    {
                        byte[] image_bytes = (byte[])Rs.GetValue(0);
                        MemoryStream ms = new MemoryStream(image_bytes);
                        return ms;
                    }
                    else
                        return null;
                }
                else
                    return null;

            }
           
            finally
            {
                this.close();
            }


        }

        /// <summary>
        /// Sets the BLOB.//����blob
        /// �������ü�������
        /// </summary>
        /// <param name="SQL">The SQL.</param>
        /// <param name="Ms">The ms.</param>
        /// <returns></returns>
        public bool SetBlob(string SQL, MemoryStream Ms)
        {
            try
            {
                Db_Conn();
               
                cmd = new OleDbCommand(SQL, Conn);              
                cmd.CommandType = CommandType.Text;//��sql
         
                int n=Convert.ToInt32(Ms.Length.ToString());
                Ms.Position = 0;
                byte[] pReadByte = new Byte[n];
                Ms.Read(pReadByte, 0, n);              

                cmd.Parameters.Add("BLOB", OleDbType.Binary).Value = pReadByte;
                cmd.ExecuteNonQuery();

                return true;

            }
            catch (Exception ex)
            {
                MessageBox.Show("����:��" + ex.Message + ",�޷�ִ��:" + SQL);
                return false;
            }

            finally
            {
                this.close();
            }


        }

        /// <summary>
        /// Closes this instance.
        /// //�ر���������
        /// </summary>
        public void close()
        {
            Conn.Close();
        }
#endregion


        /// <summary>
        /// Gets the field list from SHP. ��ȡ�ֶ��б�
        /// </summary>
        /// <param name="pLayer">The p layer.</param>
        /// <returns></returns>
        public string GetFieldListFromShp(ILayer pLayer)
        {
            ITable pTable = pLayer as ITable;
            IField pField = null;
            string strFieldList=" (";
            int i = 0;
            for (i = 0; i < pTable.Fields.FieldCount; i++) //
            {
                pField = pTable.Fields.get_Field(i);
                if (pField.Name == m_strConstFieldChange || pField.Name == m_strConstOIDName || pField.Type == esriFieldType.esriFieldTypeGeometry)
                {
                    continue;
                }
                strFieldList = strFieldList + pField.Name + ",";
            }
            //strFieldList = strFieldList + pTable.Fields.get_Field(i).Name+")";
            strFieldList = strFieldList.Substring(0, strFieldList.Length-1) + ")";

            return strFieldList;
        }


        /// <summary>
        /// Gets the BLOB data.
        /// TEst functions  ���Ժ���δʹ��
        /// </summary>
        /// <param name="ID">The ID.</param>
         public void GetBlobData(int ID)
        {
            RichTextBox richTextBox = new RichTextBox();
             String sqlStr = "select content from dp where id=" + ID;//contentΪdp�е�BLOB�ֶ�,IDΪ����
             MemoryStream ms = this.getBlob(sqlStr);
                if (ms == null)
                   richTextBox.Clear();
                else
                {
                    if (ms.Length > 0)
                    {
                        ms.Position = 0;
                        try
                        {
                            richTextBox.LoadFile(ms, RichTextBoxStreamType.RichText);
                        }
                        catch
                        {
                            richTextBox.LoadFile(ms, RichTextBoxStreamType.PlainText);
                        }
                    }
                    else
                        richTextBox.Clear();
                }
        }

        /// <summary>
        /// Sets the shape geometry. ���ü��ζ����ֶ�ֵ
        /// </summary>
        /// <param name="odCommand">The od command. command����</param>
        /// <param name="tablename">The tablename.����</param>
        /// <param name="OIDname">The OI dname.ID�ֶ���</param>
        /// <param name="OID">The OID.  ID ֵ </param>
        /// <param name="geoObj">The geo obj. ����ļ��ζ���</param>
        public void SetShapeGeometry(OleDbCommand odCommand, string tablename,string OIDname,int OID,G_Geometry geoObj)
        {
            String sqlStr = "update "+ tablename+" set SHAPE=:BLOB where "+OIDname+"=" + OID;
            MemoryStream ms = new MemoryStream();
            //BinaryWriter writer = new BinaryWriter(ms);

            IFormatter formatter = new BinaryFormatter();
            formatter.Serialize(ms, geoObj);
            odCommand.CommandText = sqlStr;
            if (!this.SetBlob(odCommand, ms))
            {
                MessageBox.Show("����ʧ��");
            }
        }

        /// <summary>
        /// Sets the BLOB.����һ��BLOB
        /// </summary>
        /// <param name="cmd">The CMD.</param>
        /// <param name="Ms">The ms.</param>
        /// <returns></returns>
        public bool SetBlob(OleDbCommand cmd, MemoryStream Ms)
        {
            try
            {
                int n = Convert.ToInt32(Ms.Length.ToString());
                Ms.Position = 0;
                byte[] pReadByte = new Byte[n];
                Ms.Read(pReadByte, 0, n);
                cmd.Parameters.Clear();
                cmd.Parameters.Add("BLOB", OleDbType.Binary).Value = pReadByte;
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show("����:��" + ex.Message + ",�޷�ִ��:" + cmd.CommandText);
                return false;
            }

            return true;

        }

        //δʹ�õĺ���
        public void TestSerialized()
        {
            G_Point pt = new G_Point(100, 24);
            IFormatter formatter = new BinaryFormatter();

            Stream stream =null;//= new FileStream("MyFile.bin", FileMode.Create, FileAccess.Write, FileShare.None);

            formatter.Serialize(stream, pt);

            stream.Close();
        }
        public void TestDeSerialized()
        {
            IFormatter formatter = new BinaryFormatter();

            Stream stream = null; // new FileStream("MyFile.bin", FileMode.Open, FileAccess.Read, FileShare.Read);

            G_Point pt = (G_Point)formatter.Deserialize(stream);

            stream.Close();

            //textBox1.Text = pt.GetX().ToString() + "\r\n" + pt.GetY().ToString();
        }


    }


       

}