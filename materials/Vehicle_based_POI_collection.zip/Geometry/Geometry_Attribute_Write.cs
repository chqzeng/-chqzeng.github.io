//�ļ�����Ȩ��Ϣ------------------
/*
 * ���ļ������п���ͼ���¿Ƽ����޹�˾����ҵ����ƽ̨����ɲ���
 * δ���������ÿ���������������������ҵ��;
 * ��Ȩ���У��п���ͼ���¿Ƽ����޹�˾(http://www.mapuni.com/) 
 * �������ߣ�������   chqzeng@163.com 
 * ��дʱ�䣺2010-09-01
 */
using System;
using System.Collections.Generic;
using System.Text;
using System.Data.OleDb;   
using System.Data;
using System.IO;
using ADOX;
using System.Windows.Forms;

using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.InteropServices;

using ESRI.ArcGIS.esriSystem;
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.Geodatabase;
using ESRI.ArcGIS.Geometry;
using ESRI.ArcGIS.DataSourcesGDB;

using Geometry_Define;

namespace Geometry_IO
{
    /// <summary>
    ///  YVT���ݹ��� �� д���� ����
    /// �������������ڹ���YVT��ʽ���һ����
    /// </summary>
    /// 
    partial class Geometry_Attribute
    {

        #region ���ڴ��ж�SHAPE ��д�뵽YUT �ļ���ȥ Creeat my MDB file and correspoding table

        /// <summary>
        /// Reads all data.// ��ȡ����   ���ú���δʹ��
        /// </summary>
        /// <param name="tableName">Name of the table.</param>
        /// <param name="mdbPath">The MDB path.</param>
        /// <param name="success">if set to <c>true</c> [success].</param>
        /// <returns></returns>
        public DataTable ReadAllData(string tableName, string mdbPath, ref bool success)
        {
            DataTable dt = new DataTable();
            try
            {
                DataRow dr;
                //1���������� C#����Access֮��ȡmdb   
                string strConn = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + mdbPath;// +";Jet OLEDB:Database Password=123";
                //string strConn = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + mdbPath + ";Jet OLEDB:Database  Password=123";

                OleDbConnection odcConnection = new OleDbConnection(strConn);
                //2�������� C#����Access֮��ȡmdb  
                odcConnection.Open();
                //����SQL��ѯ   
                OleDbCommand odCommand = odcConnection.CreateCommand();
                //3�������ѯ��� C#����Access֮��ȡmdb  
                odCommand.CommandText = "select * from " + tableName;
                //������ȡ  
                OleDbDataReader odrReader = odCommand.ExecuteReader();
                //��ѯ����ʾ����   
                int size = odrReader.FieldCount;
                for (int i = 0; i < size; i++)
                {
                    DataColumn dc;
                    dc = new DataColumn(odrReader.GetName(i));
                    dt.Columns.Add(dc);
                }
                while (odrReader.Read())
                {
                    dr = dt.NewRow();
                    for (int i = 0; i < size; i++)
                    {
                        dr[odrReader.GetName(i)] = odrReader[odrReader.GetName(i)].ToString();
                    }
                    dt.Rows.Add(dr);
                }

                //�ر����� C#����Access֮��ȡmdb  
                odrReader.Close();
                odcConnection.Close();
                success = true;
                return dt;
            }
            catch
            {
                success = false;
                return dt;
            }
        }

        /// <summary>
        /// ����MDB�ļ���δʹ�ã���������
        /// </summary>
        /// <param name="filename">�ļ���</param>
        public void CreateAccessFile(string filename)
        {
            if (!Directory.Exists(AppDomain.CurrentDomain.BaseDirectory + "DataBase\\"))
            {
                Directory.CreateDirectory(AppDomain.CurrentDomain.BaseDirectory + "DataBase\\");
            }
            ADOX.CatalogClass cat = new CatalogClass();
            string str = "provider=Microsoft.Jet.OleDb.4.0;Data Source=" + AppDomain.CurrentDomain.BaseDirectory + "DataBase\\" + filename + ".yvt;";
            cat.Create(str);
            cat = null;

        }



        /// <summary>
        /// Creates the table in MDB.
        /// //����һ�� ʹ���ڴ��е�shp ������
        /// </summary>
        /// <param name="MDBFileName">Name of the MDB file. ��Ҫ�����ı�·��</param>
        /// <param name="TableName">Name of the table. ��Ҫ�����ı���</param>
        /// <param name="pLayer">The p layer. ������Ҫ������SHAPE���ݲ�</param>
        public void CreateTableInMDB(string MDBFileName, string TableName, ILayer pLayer)
        {
            CreateTableInMDB(MDBFileName, TableName, pLayer, 10240); //���֧��10M�ĵ�����¼
        }
        /// <summary>
        /// Creates the table in MDB.  �����ļ�
        /// </summary>
        /// <param name="MDBFileName">Name of the MDB file. ��Ҫ�����ı�·��</param>
        /// <param name="TableName">Name of the table.��Ҫ�����ı���</param>
        /// <param name="pLayer">The p layer.������Ҫ������SHAPE���ݲ�</param>
        /// <param name="shapeFilesize">The shape filesize. �����ֶε���󳤶�</param>
        public void CreateTableInMDB(string MDBFileName, string TableName, ILayer pLayer, int shapeFilesize)
        {
            if (System.IO.File.Exists(MDBFileName))
            {
                try { System.IO.File.Delete(MDBFileName); }
                catch{return;}
            }
            //creat table
            ADOX.Catalog catalog = new Catalog();

            String StrConn = string.Format("Provider=Microsoft.Jet.OLEDB.4.0;Data Source={0};Jet OLEDB:Engine Type=5", MDBFileName);
            catalog.Create(StrConn);
            //catalog.Create("Provider=Microsoft.Jet.OLEDB.4.0;Data Source={0};Jet OLEDB:Engine Type=5");// Database Type=5; Password=yutu123

            ADODB.Connection cn = new ADODB.Connection();

            String StrOpen = string.Format("Provider=Microsoft.Jet.OLEDB.4.0;Data Source={0}", MDBFileName);
            cn.Open(StrOpen, null, null, -1);
            //cn.Open("Provider=Microsoft.Jet.OLEDB.4.0;Data Source={0}", null, null, -1);

            catalog.ActiveConnection = cn;

            ADOX.Table table = new ADOX.Table();

            table.Name = TableName;// "FirstTable";

            ////////////////////////�ֶδ��� OID/////////////////////////
            ADOX.Column column = new ADOX.Column();
            column.ParentCatalog = catalog;
            column.Name = m_strConstOIDName;
            column.Type = DataTypeEnum.adInteger;
            column.DefinedSize = 9;
            column.Properties["AutoIncrement"].Value = true;
            table.Columns.Append(column, DataTypeEnum.adInteger, 9);
            table.Keys.Append("FirstTablePrimaryKey", KeyTypeEnum.adKeyPrimary, column, null, null);
            ////////////////////////�ֶδ��� SHAPE/////////////////////////
            table.Columns.Append("SHAPE", DataTypeEnum.adLongVarBinary, shapeFilesize);
            table.Columns["SHAPE"].Attributes = ADOX.ColumnAttributesEnum.adColNullable;

            //table.Columns.Append("test", DataTypeEnum.adVarWChar, 50);
            //table.Columns.Append("Age", DataTypeEnum.adInteger, 9);

            // attributes
            //CreateDataTableByLayer(pLayer, ref table);
            //ȡ��ITable�ӿ�
            try
            {
                ITable pTable = pLayer as ITable;
                IField pField = null;
                for (int i = 0; i < pTable.Fields.FieldCount; i++) //
                {
                    pField = pTable.Fields.get_Field(i);
                    if (pField.Name == m_strConstOIDName || pField.Type == esriFieldType.esriFieldTypeGeometry || pField.Name == m_strConstFieldChange)
                    {
                        //table.Columns.Append("SHAPE", DataTypeEnum.adLongVarBinary, shapeFilesize);
                        //table.Columns["SHAPE"].Attributes = ADOX.ColumnAttributesEnum.adColNullable;
                        continue;
                    }

                    //if(ESRIDataType2CSharp(pField.Type)==DataTypeEnum.adDate)
                    //{
                    //    table.Columns.Append(pField.Name, ESRIDataType2CSharp(pField.Type),20);
                    //}
                    //else 
                    table.Columns.Append(pField.Name, ESRIDataType2CSharp(pField.Type), pField.Length);

                    table.Columns[pField.Name].Attributes = ADOX.ColumnAttributesEnum.adColNullable;
                }
                catalog.Tables.Append(table);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            table = null;
            catalog.ActiveConnection = null;
            catalog = null;
            cn.Close();
        }


        /// <summary>
        /// Writes the shpae file2 yutu file.
        /// // ������� ��SHAPE ��д���� ��YUTU��ʽ
        /// </summary>
        /// <param name="mdbPath">The MDB path.��Ҫ�����ı�·��</param>
        /// <param name="tableName">Name of the table. ��Ҫ�����ı���</param>
        /// <param name="pLayer">The p layer.������Ҫ������SHAPE���ݲ�</param>
        /// <returns>�����Ƿ�ִ�гɹ�</returns>
        public bool WriteShpaeFile2YutuFile(string mdbPath, string tableName, ILayer pLayer)
        {
            //1���������� C#����Access֮��ȡmdb   
            string strConn = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + mdbPath;// +";Jet OLEDB:Database Password=123";
            //string strConn = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + mdbPath + ";Jet OLEDB:Database  Password=123";
            OleDbConnection odcConnection = new OleDbConnection(strConn);
            //2�������� C#����Access֮��ȡmdb  
            odcConnection.Open();
            //����SQL��ѯ   
            OleDbCommand odCommand = odcConnection.CreateCommand();

            ITable pTable = pLayer as ITable;
            ICursor pCursor = pTable.Search(null, false);
            IRow pRow = pCursor.NextRow();

            //3�������ѯ��� C#����Access֮��ȡmdb  

            while (pRow != null)
            {
                odCommand.CommandText = "insert into " + tableName + GetFieldListFromShp(pLayer);

                string valuestring = "values (";

                for (int i = 0; i < pRow.Fields.FieldCount; i++)
                {
                    //����ֶ�����ΪesriFieldTypeGeometry�������ͼ�����������ֶ�ֵ
                    if (pRow.Fields.get_Field(i).Name == m_strConstOIDName || pRow.Fields.get_Field(i).Name == m_strConstFieldChange || pRow.Fields.get_Field(i).Type == esriFieldType.esriFieldTypeGeometry)
                    {
                        continue;
                    }
                    //��ͼ������ΪAnotationʱ��Ҫ�����л���esriFieldTypeBlob���͵����ݣ�
                    //��洢���Ǳ�ע���ݣ��������轫��Ӧ���ֶ�ֵ����ΪElement
                    else if ( pRow.Fields.get_Field(i).Type == esriFieldType.esriFieldTypeBlob)
                    {
                        valuestring = valuestring + @"'Unsupport Blob Field',";
                    }
                    else
                    {
                        if (pRow.get_Value(i) == null || pRow.get_Value(i).ToString() == "")//Ϊ��ʱ��Ϊ�ռ�����ֶ�
                        {
                            if (pRow.Fields.get_Field(i).Type == esriFieldType.esriFieldTypeString ) valuestring = valuestring + @"'',";
                            else if (pRow.Fields.get_Field(i).Type == esriFieldType.esriFieldTypeDate)
                            {
                                System.DateTime curT = System.DateTime.Now;
                                string str=string.Format("'{0}-{1}-{2}' ,",curT.Year,curT.Month,curT.Day);
                                valuestring = valuestring + str;
                                //valuestring = valuestring + @"'',";
                            }
                            else valuestring = valuestring + @"'0',"; //
                        }
                        else
                        {
                            string strTemp = pRow.get_Value(i).ToString();
                            valuestring = valuestring + @"'" + strTemp + @"',";
                        }
                    }
                }
                valuestring = valuestring.Remove(valuestring.Length - 1) + ")";

                odCommand.CommandText = odCommand.CommandText + valuestring;
                try
                {
                    odCommand.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("����:��" + ex.Message + ",�޷�ִ��:\r\n" + odCommand.CommandText);
                    return false;
                }
                //new line
                pRow = pCursor.NextRow();
            }

            //4 //����shape��DataTable
            //odCommand.CommandText = "update " + tableName + "set ";

            IQueryFilter queryFilter = new QueryFilterClass();
            queryFilter.WhereClause = "";
            //preform the search on the supplied feature class; use a cursor to hold the results
            IFeatureLayer ftrLayer = pLayer as IFeatureLayer;
            IFeatureCursor featureCursor = ftrLayer.FeatureClass.Search(queryFilter, false);
            //object featureOID;
            //get the first feature returned
            IFeature Infeature = featureCursor.NextFeature();
            if (Infeature.FeatureType != esriFeatureType.esriFTSimple)
            {
                MessageBox.Show("���Ǽ����ݣ��޷����������͵ļ������ݣ�");
                return false;
            }
            //loop through all of the features and save it 
            string strtTablename, strOIDname;
            strtTablename = tableName;
            strOIDname = pTable.OIDFieldName;
            try
            {
                while (Infeature != null)
                {
                    G_Geometry pt = Geometry_Conv2Shp.ConvFromSHP2YutuGeometry(Infeature.Shape);
                    SetShapeGeometry(odCommand, strtTablename, strOIDname, Infeature.OID, pt);

                    //switch (ftrLayer.FeatureClass.ShapeType)  //Geometry����

                    featureCursor.Flush();
                    Infeature = featureCursor.NextFeature();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("����:��" + ex.Message + ",�޷�ִ��:\r\n");
                return false;
            }

            //this.SetShapeGeometry(odCommand,  tablename, OIDname, OID, geoObj);
            odcConnection.Close();

            return true;
        }

        
        /// <summary>
        /// ESRIs the data type to Csharp.
        /// shape�� yutu֮�� ��������������֮�� ��ת��: yvt --> shape
        /// </summary>
        /// <param name="fieldType">Type of the field. ESRI�ֶε�����</param>
        /// <returns>C#ʶ����ֶ�����</returns>
        public static DataTypeEnum ESRIDataType2CSharp(esriFieldType fieldType)
        {
            switch (fieldType)
            {
                case esriFieldType.esriFieldTypeBlob:
                    return DataTypeEnum.adLongVarBinary;
                case esriFieldType.esriFieldTypeDate:
                    return DataTypeEnum.adDate;
                case esriFieldType.esriFieldTypeDouble:
                    return DataTypeEnum.adDouble;
                case esriFieldType.esriFieldTypeGeometry:
                    return DataTypeEnum.adLongVarBinary;
                case esriFieldType.esriFieldTypeGlobalID:
                    return DataTypeEnum.adGUID;
                case esriFieldType.esriFieldTypeGUID:
                    return DataTypeEnum.adGUID;
                case esriFieldType.esriFieldTypeInteger:
                    return DataTypeEnum.adInteger;
                case esriFieldType.esriFieldTypeOID:
                    return DataTypeEnum.adInteger;
                case esriFieldType.esriFieldTypeRaster:
                    return DataTypeEnum.adLongVarBinary;
                case esriFieldType.esriFieldTypeSingle:
                    return DataTypeEnum.adSingle;
                case esriFieldType.esriFieldTypeSmallInteger:
                    return DataTypeEnum.adSmallInt;
                case esriFieldType.esriFieldTypeString:
                    return DataTypeEnum.adVarWChar;
                default:
                    return DataTypeEnum.adVarWChar;
            }
        }

        /// <summary>
        /// Cs the type of the sharp2 ESRI data.
        ///  shape�� yutu֮�� ��������������֮�� ��ת��: shape --> yvt
        /// </summary>
        /// <param name="fieldType">Type of the field.C#ʶ����ֶ�����</param>
        /// <returns>ESRI�ֶε�����</returns>
        public static esriFieldType CSharp2ESRIDataType(DataTypeEnum fieldType)
        {
            switch (fieldType)
            {
                case DataTypeEnum.adLongVarBinary:
                    return esriFieldType.esriFieldTypeBlob;
                case DataTypeEnum.adDate:
                    return esriFieldType.esriFieldTypeDate;
                case DataTypeEnum.adDouble:
                    return esriFieldType.esriFieldTypeDouble;

                case DataTypeEnum.adGUID:
                    return esriFieldType.esriFieldTypeGUID;
                case DataTypeEnum.adInteger:
                    return esriFieldType.esriFieldTypeInteger;

                case DataTypeEnum.adSingle:
                    return esriFieldType.esriFieldTypeSingle;
                case DataTypeEnum.adSmallInt:
                    return esriFieldType.esriFieldTypeSmallInteger;
                case DataTypeEnum.adVarWChar:
                    return esriFieldType.esriFieldTypeString;
                default:
                    return esriFieldType.esriFieldTypeString;
            }
        }

        #endregion
    }
}