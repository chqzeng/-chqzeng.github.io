//�ļ�����Ȩ��Ϣ------------------
/*
 * ���ļ������п���ͼ���¿Ƽ����޹�˾����ҵ����ƽ̨����ɲ���
 * δ���������ÿ���������������������ҵ��;
 * ��Ȩ���У��п���ͼ���¿Ƽ����޹�˾(http://www.mapuni.com/) 
 * �������ߣ�������   chqzeng@163.com 
 * ��дʱ�䣺2010-09-01
 */
using System;
using System.Collections.Generic;
using System.Text;
using System.Data.OleDb;   
using System.Data;
using System.IO;
using ADOX;
using System.Windows.Forms;

using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.InteropServices;

using ESRI.ArcGIS.esriSystem;
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.Geodatabase;
using ESRI.ArcGIS.Geometry;
using ESRI.ArcGIS.DataSourcesGDB;
using ESRI.ArcGIS.DataSourcesFile;

using Geometry_Define;

namespace Geometry_IO
{
    /// <summary>
    ///  YVT���ݹ��� �� ������ ����
    /// �������������ڹ���YVT��ʽ���һ����
    /// </summary>
    partial class Geometry_Attribute
    {

#region      //��ȡ YUT ���� ������ SHAPE�ڴ��ļ�
        /// <summary>
        /// Opens the MDB table for fieds. �� MDB���ݱ�
        /// </summary>
        /// <param name="MDBFileName">Name of the MDB file.���ݱ�·��</param>
        /// <param name="TableName">Name of the table.���ݱ���</param>
        /// <param name="FieldList">The field list. �ֶ��б�</param>
        /// <returns>���ظñ��е���ļ�������</returns>
        public tagGeoType OpenMDBTableForFieds(string MDBFileName, string TableName, ref List<MyTableField> FieldList)
        {
            Columns m_columns;
            //creat table
            ADOX.Catalog catalog = new Catalog();

            ADODB.Connection cn = new ADODB.Connection();

            String StrOpen = string.Format("Provider=Microsoft.Jet.OLEDB.4.0;Data Source={0}", MDBFileName);
            try
            {
                //ADODB.Recordset rsSchema = cn.OpenSchema(ADODB.SchemaEnum.adSchemaColumns, null, null);
                //rsSchema.Sort="ORDINAL_POSITION";
                //int count = rsSchema.Fields.Count;
                cn.Open(StrOpen, null, null, -1);
                //cn.Open("Provider=Microsoft.Jet.OLEDB.4.0;Data Source={0}", null, null, -1);

                catalog.ActiveConnection = cn;
                ADOX.Table table = catalog.Tables[TableName];
                m_columns = table.Columns;
                
                if (m_columns.Count == 0)
                { MessageBox.Show("error field read!"); return tagGeoType.GT_GeoUnknown; }
            }
            catch { return tagGeoType.GT_GeoUnknown; }

            cn.Close();

            //�������м�¼   
            string strConn = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + MDBFileName;
            OleDbConnection odcConnection = new OleDbConnection(strConn);
            odcConnection.Open();
            OleDbCommand odCommand = odcConnection.CreateCommand();
            odCommand.CommandText = "select * from " + TableName + " where "+m_strConstOIDName+" < 2";
            OleDbDataReader odrReader = odCommand.ExecuteReader();
            int count = odrReader.FieldCount;
            for (int index = 0; index < count; index++)
            {
                MyTableField fld = new MyTableField();
                fld.Name = odrReader.GetName(index);
                if (fld.Name == m_strConstShapeID || fld.Name == m_strConstOIDName) continue;  ////�����OBJECTID ���� FID������Ҫ

                fld.DefinedSize = m_columns[fld.Name].DefinedSize;
                fld.Precision = m_columns[fld.Name].Precision;
                fld.NumericScale = m_columns[fld.Name].NumericScale;
                fld.Type = m_columns[fld.Name].Type;

                FieldList.Add(fld);
            }
            odrReader.Close();

            //Get geoemetry type
            odCommand.CommandText = "select SHAPE from " + TableName + " where " + m_strConstOIDName + "  < 10 ";
            MemoryStream ms = GetBlob(odCommand);
            if (ms == null) 
            {
                if (MDBFileName.ToUpper().Contains("�½���_") || MDBFileName.ToUpper().Contains("GPS��ʶ��")) //ͼ��Ϊ�գ����ص��
                    return tagGeoType.GT_GeoPoint;
                else if (MDBFileName.ToUpper().Contains("GPS·��"))
                return tagGeoType.GT_GeoCurve;
            } 

            IFormatter formatter = new BinaryFormatter();
            G_Geometry geoObj = (G_Geometry)formatter.Deserialize(ms);
            tagGeoType type = geoObj.GetGeoType();
            //OleDbDataReader odrReader = odCommand.ExecuteReader();
            //odrReader.GetValue(0);

            odcConnection.Close();

            return type;// m_columns;
        }

        /// <summary>
        /// Loads all fields from MDB. �ӱ��м������е��ֶ�
        /// </summary>
        /// <param name="pFieldsEdit">The p fields edit.�ֶμ��ص����壬����һ����������</param>
        /// <param name="FieldList">The field list.�ֶ��б�</param>
        /// <param name="m_columns">The m_columns.�м��ϣ�δʹ�øò���</param>
        public void LoadAllFieldsFromMDB(ref IFieldsEdit pFieldsEdit, List<MyTableField> FieldList, Columns m_columns)
        {
            //�����ֶ�
            IField pField = new FieldClass();
            IFieldEdit pFieldEdit = (IFieldEdit)pField;

            int FldCount = FieldList.Count;// m_columns.Count;
            for (int index = 0; index < FldCount; index++)
            {
                //shape �ֶ��Լ�ϵͳ�Դ��ֶ� �����
                //Column clm = m_columns[FieldList[index]];
                MyTableField clm = FieldList[index];
                if ((clm.Name == "SHAPE" && clm.Type == DataTypeEnum.adLongVarBinary) || clm.Name == m_strConstOIDName) continue;  //

                pField = new FieldClass();
                pFieldEdit = (IFieldEdit)pField;
                pFieldEdit.Name_2 = clm.Name;
                esriFieldType m_fldtype = CSharp2ESRIDataType(clm.Type);
                pFieldEdit.Type_2 = m_fldtype; CSharp2ESRIDataType(clm.Type);

                //optional
                if (m_fldtype == esriFieldType.esriFieldTypeString)
                {
                    pFieldEdit.Length_2 = clm.DefinedSize;
                }
                else if (m_fldtype == esriFieldType.esriFieldTypeInteger ||
                    m_fldtype == esriFieldType.esriFieldTypeSmallInteger ||
                    m_fldtype == esriFieldType.esriFieldTypeSingle ||
                    m_fldtype == esriFieldType.esriFieldTypeDouble)
                {
                    pFieldEdit.Precision_2 = clm.Precision;//��ֵ����
                    pFieldEdit.Scale_2 = clm.NumericScale;//С�������λ��
                }

                pFieldsEdit.AddField(pField);
            }

        }

        /// <summary>
        /// Creates the empty layer in memeory. �����յ��ڴ�ͼ��
        /// </summary>
        /// <param name="FieldList">The field list.�ֶ��б�</param>
        /// <param name="slayername">The slayername.��Ҫ�����Ĳ�����</param>
        /// <param name="pspatialreference">The pspatialreference.���βο� ���������null��Ϊ��γ������</param>
        /// <param name="itype">The itype.���󼸺�����</param>
        /// <param name="pWSF">The p WSF.</param>
        /// <param name="strOutDiretory">The STR out diretory.д����·���������������ݸ�ʽת��ʱ</param>
        /// <returns>����һ�����ɺõĹ����ռ�</returns>
        public IFeatureWorkspace CreateEmptyLayerInMemeory(List<MyTableField> FieldList, string slayername, ESRI.ArcGIS.Geometry.ISpatialReference pspatialreference, tagGeoType itype, ref IFeatureWorkspace pWSF, string strOutDiretory) //IFeatureWorkspace pWSF
        {
            //IFeatureWorkspace pWSF = pWSForStroutDirectory as IFeatureWorkspace;
            //string strOutDiretory = pWSForStroutDirectory as string;
            bool m_bReadForMemory = true;
            //const string strShapeFieldName = "SHAPE";
            //�򿪹����ռ�, ���û�����½�һ��
            if (pWSF == null)
            {
                if(strOutDiretory==null)//�ڴ�ͼ��
                {
                    IWorkspaceFactory pMemWSF = new InMemoryWorkspaceFactoryClass();
                    ESRI.ArcGIS.Geodatabase.IWorkspaceName pworkspacename = pMemWSF.Create("", "MyWorkspace", null, 0);
                    ESRI.ArcGIS.esriSystem.IName pname = (IName)pworkspacename;
                    pWSF = (IFeatureWorkspace)(pname.Open()); //�򿪸ս������ڴ�ռ�
                }
                else
                {
                    IWorkspaceFactory pWorkspaceFactory = new ShapefileWorkspaceFactoryClass();
                    pWSF = pWorkspaceFactory.OpenFromFile(strOutDiretory, 0) as IFeatureWorkspace;
                    m_bReadForMemory = false;
                }
            }
            
            IFeatureWorkspace pfeatureworkspace = pWSF;

            try
            {

                //ΪesriFieldTypeGeometry���͵��ֶδ������ζ��壬�������ͺͿռ���� 
                IGeometryDef pGeoDef = new GeometryDefClass();     //The geometry definition for the field if IsGeometry is TRUE.
                IGeometryDefEdit pGeoDefEdit = (IGeometryDefEdit)pGeoDef;
                if (itype == tagGeoType.GT_GeoPoint)  //point
                {
                    pGeoDefEdit.GeometryType_2 = esriGeometryType.esriGeometryPoint;
                }
                else
                {
                    if (itype == tagGeoType.GT_GeoCurve)  //polyline
                    {
                        pGeoDefEdit.GeometryType_2 = esriGeometryType.esriGeometryPolyline;
                    }
                    else if (itype == tagGeoType.GT_GeoPolygon) //polygon :3
                    {
                        pGeoDefEdit.GeometryType_2 = esriGeometryType.esriGeometryPolygon;
                    }
                }
                if (pspatialreference != null)
                {
                    pspatialreference.SetDomain(-180, 180, -90, 90);
                    pGeoDefEdit.SpatialReference_2 = pspatialreference;
                }
                else //Ĭ��ΪWGS-84�µ� ��γ��ͶӰ
                {

                    ISpatialReferenceFactory3 pspatialRefFac = new SpatialReferenceEnvironmentClass();
                    ISpatialReference pspatialRef = pspatialRefFac.CreateGeographicCoordinateSystem((int)esriSRGeoCSType.esriSRGeoCS_WGS1984);//�����ΪWGS84�Ŀռ��������ϵ
                    pspatialRef.SetDomain(-180, 180, -90, 90);//����һ��Ҫ����ֵ�����ã�
                    pGeoDefEdit.SpatialReference_2 = pspatialRef;
                }


                //�����ֶμ�
                IFields pFields = new FieldsClass();
                IFieldsEdit pFieldsEdit = (IFieldsEdit)pFields;
                //�����ֶ�
                IField pField = new FieldClass();
                IFieldEdit pFieldEdit = (IFieldEdit)pField;

                IField oidField = new FieldClass();
                IFieldEdit oidFieldEdit = (IFieldEdit)oidField;
                oidFieldEdit.Name_2 = m_strConstShapeID;//m_strConstOIDName
                oidFieldEdit.Type_2 = esriFieldType.esriFieldTypeOID;
                pFieldsEdit.AddField(oidField);

                //��������Ϊ�������͵��ֶ�0
                pFieldEdit.Name_2 = m_strShapeFieldName;
                pFieldEdit.Type_2 = esriFieldType.esriFieldTypeGeometry;//esriFieldTypeGeometry;
                pFieldEdit.GeometryDef_2 = pGeoDef;
                pFieldsEdit.AddField(pField);

                //���� TABLE �л�õ��ֶ�
                LoadAllFieldsFromMDB(ref pFieldsEdit, FieldList, null);

                if (m_bReadForMemory) //�����Ҫ���뵽�ڴ���
                {
                    IField chgField = new FieldClass();
                    IFieldEdit chgFieldEdit = (IFieldEdit)chgField;
                    chgFieldEdit.Name_2 = m_strConstFieldChange;//��¼�仯���ֶ�
                    chgFieldEdit.Type_2 = esriFieldType.esriFieldTypeSmallInteger;
                    chgFieldEdit.DefaultValue_2 = 0;
                    pFieldsEdit.AddField(chgField);
                }

                //����shapefile
                IFeatureClass pfclass = pfeatureworkspace.CreateFeatureClass(slayername, pFields, null, null, esriFeatureType.esriFTSimple, m_strShapeFieldName, "");//��һ�����ǳ����⣡���Ľ�������ǣ�ԭ��֮ǰ�趨������ϵͳû��������
                IDataset pdataset = (IDataset)pfclass; // ����geodatabase���Ա�
                pdataset.BrowseName = slayername;

            }
            catch //(Exception ex)
            {
                //throw (ex);
                //MessageBox.Show("���ݴ򿪹��̳�����\r\n"+ex.Message);
            }

            return pfeatureworkspace;
        }


        /// <summary>
        /// Gets the BLOB.��ȡ������ֶε�ֵ ����Ӧ���ζ���
        /// </summary>
        /// <param name="cmd">The CMD. ���Ӷ�Ӧ��command</param>
        /// <returns>����һ���ڴ���</returns>
        public MemoryStream GetBlob(OleDbCommand cmd)
        {
            try
            {
                OleDbDataReader Rs = cmd.ExecuteReader();
                if (Rs.Read()) //ѭ������һ����¼
                {
                    if (!(Rs.GetValue(0) is System.DBNull))
                    {
                        byte[] image_bytes = (byte[])Rs.GetValue(0);
                        MemoryStream ms = new MemoryStream(image_bytes);
                        return ms;
                    }
                    else
                        return null;
                }
                else
                    return null;

            }
            catch (Exception ex)
            {
                MessageBox.Show("����:��" + ex.Message + ",�޷�ִ��:" + cmd.CommandText);
                return null;
            }
        }

        /// <summary>
        /// Gets the shape geometry.��ȡ���ζ���
        /// </summary>
        /// <param name="Rs">The rs. OLE��¼�����</param>
        /// <param name="ShpFldIndex">Index of the SHP FLD. SHAPE�ֶζ�Ӧ��������</param>
        /// <returns>����һ�����ζ��� </returns>
        private G_Geometry GetShapeGeometry(OleDbDataReader Rs, int ShpFldIndex)//OleDbCommand odCommand, string tablename, string OIDname, int OID )
        {
            MemoryStream ms = null;
            if (!(Rs.GetValue(ShpFldIndex) is System.DBNull))
            {
                byte[] image_bytes = (byte[])Rs.GetValue(ShpFldIndex);
                ms = new MemoryStream(image_bytes);
            }
            else
                return null;


            G_Geometry geoObj = null;
            //String sqlStr = "select SHAPE from " + tablename + "  where " + OIDname + "=" + OID;
            //odCommand.CommandText=sqlStr;
            //MemoryStream ms = GetBlob(odCommand);

            if (ms == null)
                return null;
            else
            {
                if (ms.Length > 0)
                {
                    ms.Position = 0;
                    try
                    {
                        IFormatter formatter = new BinaryFormatter();
                        geoObj = (G_Geometry)formatter.Deserialize(ms);
                    }
                    catch
                    {
                        MessageBox.Show("��ȡ����ͼ�ι��̳�����");
                    }
                }
                else
                    return null;
            }
            return geoObj;
        }


        /// <summary>
        /// Loads the data from MD b2 SHP.
        /// //�������� ���ڶ�ȡYUTU���ݸ�ʽ
        /// </summary>
        /// <param name="mdbPath">The MDB path. ��Ҫ�򿪵�YVT�ļ�·�� </param>
        /// <param name="TableName">Name of the table. ��Ӧ�ı���</param>
        /// <param name="SHPlayerName">Name of the SH player. �趨�������ݺ�Ĳ���</param>
        /// <param name="pWSF">The p WSF. �����ۿռ�</param>
        /// <param name="strOutDirectory">The STR out directory.д����·���������������ݸ�ʽת��ʱ</param>
        /// <returns>����һ��ʸ����</returns>
        public IFeatureLayer LoadDataFromMDB2SHP(string mdbPath, string TableName, string SHPlayerName,ref IFeatureWorkspace pWSF, string strOutDirectory) //
        {
            List<MyTableField> FieldList = new List<MyTableField>();

            //�򿪱�������¼�������ֶ���Ϣ
            //Columns m_columns = OpenMDBTableForFieds(mdbPath, TableName, ref FieldList);
            tagGeoType CurType = OpenMDBTableForFieds(mdbPath, TableName, ref FieldList);
            if (CurType == tagGeoType.GT_GeoUnknown) return null;

            //if (m_columns == null) return null; 

            //ADODB.Connection conn=OpenMDBTableForFieds( MDBFileName, TableName,ref m_columns);
            //if (conn == null) { return false; }

            //�����յ�SHAPE �ڴ��ļ��������ֶ� ʹ��ǰ���򿪵ı���Ӧ���ֶΡ�
            //IFeatureWorkspace pWSF = pWSForstrOutDirectory as IFeatureWorkspace;
            //string strOutDirectory = pWSForstrOutDirectory as string;
            //if (pWSF != null)
            //{
            IFeatureWorkspace pvehicleworkspace = CreateEmptyLayerInMemeory(FieldList, SHPlayerName, null, CurType, ref pWSF,strOutDirectory);//�����ڴ湤���ռ�
            //}
            //else
            //{
            //    IFeatureWorkspace pvehicleworkspace = CreateEmptyLayerInMemeory(strOutDirectory, FieldList, SHPlayerName, null, CurType);//���������ռ�
            //}

            IFeatureClass pvehicleclass = pvehicleworkspace.OpenFeatureClass(SHPlayerName); //��֮ǰ��CreateEmptyLayerInmemeory�������Ѿ�������һ������Ϊ��vehicle����Ҫ�ؼ�����������
            IFeatureLayer pvehiclelayer = new FeatureLayerClass();
            pvehiclelayer.FeatureClass = pvehicleclass;  //��֮ǰ������shapefile ��pvehicleclass����ֵ���´�����layer��pvehiclelayer
            pvehiclelayer.Name = SHPlayerName;

            IDataset pdataset = (IDataset)pvehiclelayer; //�������Ա�
            IWorkspaceEdit pworkspaceedit = (IWorkspaceEdit)(pdataset.Workspace);
            //��ʼ�༭
            if (!pworkspaceedit.IsBeingEdited())
            {
                pworkspaceedit.StartEditing(true);
            }
            pworkspaceedit.StartEditOperation();

            //�������м�¼   
            string strConn = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + mdbPath;
            OleDbConnection odcConnection = new OleDbConnection(strConn);
            odcConnection.Open();
            OleDbCommand odCommand = odcConnection.CreateCommand();

#region un used code
            //Test code
            for (int j = 2; j < 1; j++)
            {
                G_Point geoObj = null;
                String sqlStr = "select SHAPE , ���� from " + TableName + "  where FID =" + j;
                odCommand.CommandText = sqlStr;
                OleDbDataReader Rs = odCommand.ExecuteReader();

                //MemoryStream ms;
                if (Rs.Read()) //ѭ������һ����¼
                {
                    if (!(Rs.GetValue(0) is System.DBNull))
                    {
                        byte[] image_bytes = (byte[])Rs.GetValue(0);
                        MemoryStream Ms = new MemoryStream(image_bytes);
                        //MemoryStream ms = GetBlob(odCommand);
                        IFormatter formatter = new BinaryFormatter();
                        geoObj = (G_Point)formatter.Deserialize(Ms);
                        Rs.Close();

                        //re write
                        int n = Convert.ToInt32(Ms.Length.ToString());
                        Ms.Position = 0;
                        byte[] pReadByte = new Byte[n];
                        Ms.Read(pReadByte, 0, n);
                        pReadByte[194] = (byte)(j * 7);
                        sqlStr = "update " + TableName + " set SHAPE=:BLOB where FID =" + j;
                        odCommand.CommandText = sqlStr;
                        odCommand.Parameters.Clear();
                        odCommand.Parameters.Add("BLOB", OleDbType.Binary).Value = pReadByte;
                        int linenum = odCommand.ExecuteNonQuery();
                    }

                }

            }
 #endregion
            odCommand.CommandText = "select * from " + TableName + " order by "+m_strConstShapeID+" asc";
            OleDbDataReader odrReader = odCommand.ExecuteReader();
            //��ѯ����ʾ����   
            int size = odrReader.FieldCount;

            // Create a feature buffer.
            IFeatureClass featureClass = pvehiclelayer.FeatureClass;
            IFeatureBuffer featureBuffer = featureClass.CreateFeatureBuffer();
            IFeatureCursor featureCursor = featureClass.Insert(true);

            //IFeatureCursor m_NewFeatureCursor = pvehiclelayer.FeatureClass.Update(null, false);
            //string strOIDName=odrReader.GetName(0);

            try
            {
                //��ͼ����α������
                while (odrReader.Read())
                {
                    //IFeature m_NewFeature = pvehicleclass.CreateFeature();
                    
                    G_Geometry geo = GetShapeGeometry(odrReader, m_constShapeColumnIdx);
                    if (geo == null) continue;// return null;
                    //m_NewFeature.Shape = Geometry_Conv2Shp.ConvFromYutuGeometry2SHP((G_Point)geo); //shape geometry
                    //m_NewFeature.Store();

                    //int index = 1;
                    for (int i = 0; i < size; i++)
                    {

                        if (odrReader.GetName(i) == "SHAPE" || odrReader.GetName(i) == m_strConstShapeID || odrReader.GetName(i) == m_strConstOIDName) continue;  //   //skip shape field

                        int installedByFieldIndex = featureClass.FindField(odrReader.GetName(i));
                        featureBuffer.set_Value(installedByFieldIndex, odrReader.GetValue(i));

                        //m_NewFeature.set_Value(index++, odrReader.GetValue(i));
                    }
                    IGeometry g = Geometry_Conv2Shp.ConvFromYutuGeometry2SHP(geo);
                    if (g == null)
                    {
                        MessageBox.Show("��ȡ�������ݴ��󣬿��������Ͳ�֧�֣�\r\n" + odrReader.GetName(0) + " = " + odrReader.GetValue(0).ToString());
                        continue;
                    }
                    else { featureBuffer.Shape = g; }

                    featureCursor.InsertFeature(featureBuffer);

                    // m_NewFeatureCursor.UpdateFeature(m_NewFeature);
                }
                featureCursor.Flush();

                //�ر����� C#����Access֮��ȡmdb  
                odrReader.Close();
                odcConnection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            //ֹͣ�༭
            pworkspaceedit.StopEditOperation();
            pworkspaceedit.StopEditing(true);

            return pvehiclelayer;
        }
#endregion

        /// <summary>
        /// Tests the increasment.δʹ�ú���
        /// </summary>
        /// <param name="mdbPath">The MDB path. </param>
        /// <param name="TableName">Name of the table.</param>
        public static void TestIncreasment(string mdbPath, string TableName)
        {
            string strConn = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + mdbPath;
            OleDbConnection odcConnection = new OleDbConnection(strConn);
            odcConnection.Open();
            OleDbCommand odCommand = odcConnection.CreateCommand();
            string strSQL = "";
            try
            {
                strSQL = string.Format("select {0} from {1}", m_strConstShapeID, TableName);
                odCommand.CommandText = strSQL;
                //odCommand.CommandText = "SELECT "+m_strConstOIDName+" FROM " + TableName + "where" + m_strConstOIDName + " > ( 1 + " + m_strConstShapeID + ") order by ";//"alter table " + TableName + " DROP COLUMN FID";
                OleDbDataReader odrReader = odCommand.ExecuteReader();
                

                //odCommand.CommandText = "alter table " + TableName + " Add COLUMN FIDS INT NOT NULL AUTO_INCREMENT";
                //odrReader = odCommand.ExecuteReader();
                int tempFID=0;
                int changedFID = -1;
                while (odrReader.Read())
                {
                    int temp = Convert.ToInt32(odrReader.GetValue(0));
                    if ( temp== tempFID++) continue;
                    else
                    {
                        if (temp == 0) changedFID = 0;
                        else changedFID = tempFID - 1;
                        break;
                    }
                }
                if (changedFID >= 0 )  //�в������ļ�¼
                {
                    List<string> strSQLList = new List<string>();

                    int temp = Convert.ToInt32(odrReader.GetValue(0));
                    strSQL = string.Format("update {0} set {1} = {2} where {1} ={3}", TableName, m_strConstShapeID, changedFID++, temp);
                    strSQLList.Add(strSQL);

                    while (odrReader.Read())  //��¼���е���Ҫ�޸���
                    {
                        temp = Convert.ToInt32(odrReader.GetValue(0));
                        strSQL = string.Format("update {0} set {1} = {2} where {1} ={3}", TableName, m_strConstShapeID, changedFID++, temp);
                        strSQLList.Add(strSQL);
                    }
                    odrReader.Close();

                    for (int i = 0; i < strSQLList.Count; i++) //ִ���޸����е�FID��ʹ�䰴˳��
                    {
                       odCommand.CommandText = strSQLList[i];
                       //odCommand.ExecuteReader();
                       odCommand.ExecuteNonQuery();
                    }
                }
                else
                {
                    odrReader.Close();
                }
                

            }
            catch (Exception ex) { }

            //�ر����� C#����Access֮��ȡmdb  
            
            odcConnection.Close();

        }

        /// <summary>
        /// Tests the increasment ex. ���ڶԴ������ʱ��FID����
        /// </summary>
        /// <param name="mdbPath">The MDB path.��Ҫ������ļ�·�� </param>
        /// <param name="TableName">Name of the table. ����</param>
        public static void TestIncreasmentEx(string mdbPath, string TableName)  //���С��¼����65535����¼��
        {
            
            //�������м�¼   
            string strConn = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + mdbPath;
            OleDbConnection odcConnection = new OleDbConnection(strConn);
            odcConnection.Open();
            OleDbCommand odCommand = odcConnection.CreateCommand();
            string strSQL = "";
            string strNewTableName = "newtable";
            //TEST
            try
            {
               // strSQL = string.Format("select count(*) from {0} a inner join {0} b on (a.FID < b.FID)  GROUP BY a.FID order by a.FID desc", TableName);

                //strSQL = string.Format("UPDATE A SET {1}= 0 FROM {0} A LEFT JOIN {0} B ON (A.{1} < B.{1}) ORDER BY 4", TableName, m_strConstShapeID);
                //strSQL = string.Format("UPDATE A SET {1} = 13 FROM {0} A", TableName, m_strConstShapeID);
                //strSQL = string.Format("UPDATE {0} set FID =OBJECTID", TableName);
                //strSQL = "alter table " + TableName + " drop COLUMN OBJECTID "; //add ID int identity(1,1) default count(*)
                //strSQL = string.Format("select count(*) from ({0} a inner join {0} b on (a.FID < b.FID) ) T GROUP BY a.FID order BY a.FID desc WHERE T.FID=10", TableName);
                //strSQL = string.Format("UPDATE {0} SET FID = (select count(*) from (select * from {0} a where a.FID < 10) )", TableName);
                //strSQL = string.Format("create TEMPORARY table myTestTable as  select * from  ", TableName); //
                
                //����������
                //order BY a.{1} ASC
                //strSQL = string.Format("SELECT a.{1}, count(*) as NEWIDX INTO {2} FROM {0} a inner join {0} b on (a.{1}>= b.{1}) GROUP BY a.{1} ", TableName, m_strConstOIDName, strNewTableName);
                //strSQL = "CREATE  TEMPORARY  TABLE TEMPTABLE1 ID int Identity(1,1), OBJECTID int AS (select ObjectId FROM MyDataTable)"; 

                odCommand.CommandText = string.Format("Create Table {0} ( NEWIDX int identity(1,1) primary  key, {1} int) ", strNewTableName, m_strConstOIDName);
                odCommand.ExecuteNonQuery();

                // identity(int,1,1),
                //strSQL = string.Format("SELECT {0}.{1} INTO {2} FROM {0} ", TableName, m_strConstOIDName, strNewTableName);
                //strSQL = string.Format("SELECT  NEWIDX =Identity(int,1,1),{0}.{1} INTO {2} FROM {0} ", TableName, m_strConstOIDName, strNewTableName);
                strSQL = string.Format("Insert into {2}({1}) select {1} from {0} order by {1} asc", TableName, m_strConstOIDName, strNewTableName);
                odCommand.CommandText = strSQL;
                odCommand.ExecuteNonQuery();

                //�������� ���¼�¼
                //UPDATE MyDataTable INNER JOIN newtable ON MyDataTable.ObjectId = newtable.ObjectId  SET MyDataTable.FID = newtable.NEWIDX
                odCommand.CommandText = string.Format("UPDATE {1} INNER JOIN {2} ON {1}.{3} = {2}.{3}  SET {1}.{0} = {2}.NEWIDX ", m_strConstShapeID, TableName, strNewTableName, m_strConstOIDName);
                odCommand.ExecuteNonQuery();
                 }
            catch (Exception ex) { }

            try{

                //ɾ����
                odCommand.CommandText = string.Format("drop table {0}", strNewTableName);
                odCommand.ExecuteNonQuery();
            }
            catch (Exception ex) { }

            odcConnection.Close();
            return;

            #region unused code
            try
            {
                 strSQL = string.Format("select {0} from {1}", m_strConstShapeID, TableName);
                odCommand.CommandText = strSQL;
                OleDbDataReader odrReader = odCommand.ExecuteReader();

                int tempFID = 0;
                int changedFID = 0;
                List<string> strSQLList = new List<string>();
                while (odrReader.Read())
                {
                    int temp = Convert.ToInt32(odrReader.GetValue(0));
                    strSQL = string.Format("update {0} set {1} = {2} where {1} ={3}", TableName, m_strConstShapeID, changedFID++, temp);
                    strSQLList.Add(strSQL);
                }
                odrReader.Close();

                for (int i = 0; i < strSQLList.Count; i++) //ִ���޸����е�FID��ʹ�䰴˳��
                {
                    odCommand.CommandText = strSQLList[i];
                    odCommand.ExecuteNonQuery();
                }
            }
            catch (Exception ex) 
            {
                MessageBox.Show("���±༭���ݵ�ID��˳�������\r\n"+ex.Message);
            }

            //�ر����� C#����Access֮��ȡmdb  

            odcConnection.Close();
            #endregion

        }
    }
}