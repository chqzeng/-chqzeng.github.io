//�ļ�����Ȩ��Ϣ------------------
/*
 * ���ļ������п���ͼ���¿Ƽ����޹�˾����ҵ����ƽ̨����ɲ���
 * δ���������ÿ���������������������ҵ��;
 * ��Ȩ���У��п���ͼ���¿Ƽ����޹�˾(http://www.mapuni.com/) 
 * �������ߣ�������   chqzeng@163.com 
 * ��дʱ�䣺2010-09-01
 */
using System;
using System.Runtime.InteropServices;

using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Windows.Forms;

//arcGIS reference
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.Controls;
//using ESRI.ArcGIS.esriSystem;
using ESRI.ArcGIS.Display;
using ESRI.ArcGIS.Geometry;
using ESRI.ArcGIS.SystemUI;
using ESRI.ArcGIS.Geodatabase;
using ESRI.ArcGIS.Output;
using ESRI.ArcGIS.DataSourcesRaster;

namespace YuTuSurveyPlatform
{
    /// <summary>
    /// ��Ҫ���࣬���ڼ���/�������� ������ʹ����ҵ�����ķ�����
    /// ��������Ҫ�����ڽ������� �����ص���ǰ���̣���ȷ���ܹ����� EncryptDLL.dll
    /// </summary>
    /// 
    public class Geometry_Encrypt
    {
        //�������е�DLL �н�Ҫ�õĺ��� 
        [DllImport(@"EncryptDLL.dll", CharSet=CharSet.Auto)]
        public static extern uint GetNum();
        [DllImport(@"EncryptDLL.dll", CharSet = CharSet.Auto)]
        public static extern bool GetMethods(uint Num, byte[] MethodNames);
        [DllImport(@"EncryptDLL.dll", CharSet = CharSet.Auto)]
        public static extern bool Encrypt(byte[] OpenFile, byte[] SaveFile, byte[] Style);
        [DllImport(@"EncryptDLL.dll", CharSet=CharSet.Auto)]
        public static extern bool HeadDecrypt(byte[] CheckBits);
        [DllImport(@"EncryptDLL.dll", CharSet = CharSet.Auto)]
        public static extern bool Decrypt(byte[] lpData, ulong FileSize, int Index);

        //typedef BOOL(*GETNUM)();
	    //typedef BOOL (*GETMETHODS)(UINT Num,LPSTR MethodNames);
        //typedef BOOL(*ENCRYPT)(LPTSTR OpenFile, LPTSTR SaveFile, LPTSTR Style);
        //typedef BOOL(*DECRYPT)(LPTSTR lpData,DWORD FileSize, int Index);
	    //typedef BOOL(*HEADDECRYPT)(LPTSTR CheckBits);

        //�����ַ�������ܵĹ����й�
        public const int MethodNameLength=8;
        //�ļ���׺����
        public const int ExtentLength = 3;
        //��ͼԪ��
        public IMapControl2 mapControl;
        //��ǰ�ļ���
        public string strTempFilePath;

        /// <summary>
        /// Initializes a new instance of the <see cref="Geometry_Encrypt"/> class.
        /// ���캯��������һ����ͼԪ��
        /// </summary>
        /// <param name="map">The map.</param>
        public Geometry_Encrypt(IMapControl2 map)
        {
            mapControl=map;
            strTempFilePath = "";
        }


        /// <summary>
        /// Opens the feature class_ example. ��ʸ�����ݲ㣬����������  
        /// </summary>
        /// <param name="dataPath">The data path.���ݵ�·��</param>
        /// <param name="nameOfShapefile">The name of shapefile. ��Ҫд���SHAPE�ļ���</param>
        /// <returns>�������ɵ�ʸ����</returns>
        public IFeatureClass OpenFeatureClass_Example(string dataPath, string nameOfShapefile)
        {
            IWorkspaceFactory workspaceFactory = new ESRI.ArcGIS.DataSourcesFile.ShapefileWorkspaceFactoryClass();
            IFeatureWorkspace featureWorkspace = (IFeatureWorkspace)workspaceFactory.OpenFromFile(dataPath, 0);
            IFeatureClass featureClass = featureWorkspace.OpenFeatureClass(nameOfShapefile);
            return featureClass;
            //Console.WriteLine("There are {0} features in the {1} feature class", 
            //    featureClass.FeatureCount(new QueryFilterClass()), featureClass.AliasName); 
        }

        /// <summary>
        /// Opens the rasterfrom file.���ļ��д�դ������
        /// </summary>
        /// <param name="fullPath">The full path.���� ��դ������ ·��</param>
        /// <returns>����һ��RASTER���� </returns>
        public IRaster openRasterfromFile(string fullPath)
        {

            string pathToWorkspace = System.IO.Path.GetDirectoryName(fullPath);
            string rasterfileName = System.IO.Path.GetFileName(fullPath);

            IRasterWorkspace pRWS;
            IWorkspaceFactory pWSF;
            IWorkspace pWS;
            IRasterDataset pRasterDataset;
            IRaster pRaster;
            //IRasterLayer pRasterLayer = new RasterLayerClass();

            pWSF = new RasterWorkspaceFactoryClass();
            pWS = pWSF.OpenFromFile(pathToWorkspace, 0);
            pRWS = pWS as IRasterWorkspace;
            pRasterDataset = pRWS.OpenRasterDataset(rasterfileName);
            pRaster = pRasterDataset.CreateDefaultRaster();

            Marshal.FinalReleaseComObject(pRWS);
            Marshal.FinalReleaseComObject(pWS);
            Marshal.FinalReleaseComObject(pWSF);
            int d = 1;
            do
                d = Marshal.FinalReleaseComObject(pRasterDataset);
            while (d > 0);

            return pRaster as IRaster;

        }

        /// <summary>
        /// Opens the raster back ground. ��դ��ļ��������ļ�
        /// </summary>
        /// <param name="inFilePath">The in file path.�ļ�·���б�</param>
        /// <param name="LayerList">The layer list.��Ҫά���Ĳ��б�����������</param>
        /// <returns>�����Ƿ�ִ�гɹ�</returns>
        public bool OpenRasterBackGround(List<string> inFilePath,ref List<MyLayerInfo> LayerList)
        {
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor;

            List<string> outFilePath = new List<string>();
            LoadBackgroundData(inFilePath, ref outFilePath);
            //outFilePath.Add(@"D:\zeng\TestData\enrypted101.ti");
            int FileNum = outFilePath.Count;
            try
            {
                for (int index = 0; index < FileNum; index++)
                {
                    //string fname = dlg.FileNames[index];
                    
                    IRasterLayer pRasterLayer = new RasterLayerClass(); 
                    IRaster pRaster = openRasterfromFile(outFilePath[index]);
                    pRasterLayer.CreateFromRaster(pRaster);

                    int curIndex = mapControl.LayerCount;
                    for (int i = 0; i < mapControl.LayerCount; i++)
                    {
                        IRasterLayer lyr = mapControl.get_Layer(i) as IRasterLayer;
                        if (lyr != null)
                        { curIndex = i; break; }
                    }
                   
                    mapControl.AddLayer(pRasterLayer as ILayer, curIndex);

                    
                    //store layer info
                    MyLayerInfo lyrInfo=new MyLayerInfo();
                    lyrInfo.FilePath = inFilePath[index];
                    lyrInfo.LayerName = mapControl.get_Layer(curIndex).Name;
                    lyrInfo.m_bVisible = true;
                    lyrInfo.LayerIndex = curIndex;
                    lyrInfo.type = 1; //raster
                    LayerList.Add(lyrInfo);
                }
            }
            catch (Exception err)
            {
                System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default;
                MessageBox.Show("��դ�����ݲ����\r\n" + err.Message);
            }

            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default;
            return true;
        }

        /// <summary>
        /// Opens the shape back ground.��ʸ���ļ��������ļ�
        /// </summary>
        /// <param name="inFilePath">The in file path.�ļ�·���б�</param>
        /// <param name="LayerList">The layer list.��Ҫά���Ĳ��б�����������</param>
        /// <returns>�����Ƿ�ִ�гɹ�</returns>
        public bool OpenShapeBackGround(List<string> inFilePath, ref List<MyLayerInfo> LayerList)
        {
            //de encrypt files
            List<string> outFilePath = new List<string>();
            LoadBackgroundData(inFilePath, ref outFilePath);

            int FileNum = outFilePath.Count;
            for (int index = 0; index < FileNum; index++)
            {
                string fname = outFilePath[index]; //dlg.FileNames[index];
                if (fname != null)
                {
                    string pathToWorkspace = System.IO.Path.GetDirectoryName(fname);
                    string shapefileName = System.IO.Path.GetFileNameWithoutExtension(fname);
                    IDataset pDataset;

                    IFeatureClass pFClass = OpenFeatureClass_Example(pathToWorkspace, shapefileName);

                    IFeatureLayer pLayer = new FeatureLayerClass();

                    pLayer.FeatureClass = pFClass;

                    pDataset = pFClass as IDataset;

                    pLayer.Name = pDataset.Name;

                    int curIndex = 0;
                    switch (pLayer.FeatureClass.ShapeType)
                    {
                        case esriGeometryType.esriGeometryPoint:
                            curIndex = 0;
                            break;
                        case esriGeometryType.esriGeometryPolyline:
                          for (int i = 0; i < mapControl.LayerCount; i++)
                            {
                                IFeatureLayer lyr = mapControl.get_Layer(i) as IFeatureLayer;
                                if (lyr != null && ((int)(lyr.FeatureClass.ShapeType)) > 2)  
                                { curIndex = i; break; }
                            }
                            break;
                        case esriGeometryType.esriGeometryPolygon:
                            for (int i = 0; i < mapControl.LayerCount; i++)
                            {
                                IFeatureLayer lyr = mapControl.get_Layer(i) as IFeatureLayer;
                                if (lyr == null)
                                { curIndex = i; break; }
                                else if (lyr != null &&
                                    (lyr.FeatureClass.ShapeType == esriGeometryType.esriGeometryPolygon)
                                    || (lyr.FeatureClass.ShapeType == esriGeometryType.esriGeometryEnvelope))
                                { curIndex = i; break; }
                            }
                            break;
                        default:
                            curIndex = mapControl.LayerCount;
                            break;
                    }
                    mapControl.AddLayer(pLayer, curIndex);

                    //store layer info
                    MyLayerInfo lyrInfo = new MyLayerInfo();
                    lyrInfo.FilePath = inFilePath[index];
                    lyrInfo.LayerName = mapControl.get_Layer(curIndex).Name;
                    lyrInfo.m_bVisible = true;
                    lyrInfo.LayerIndex = curIndex;
                    lyrInfo.type = 2;  //shape file
                    LayerList.Add(lyrInfo);
                }
            }
            return true;

        }


        /// <summary>
        /// Loads the background data.//�ļ����ܺ��������ڽ������е��ļ�
        /// </summary>
        /// <param name="inFilePath">The in file path.�����ļ�·���б�</param>
        /// <param name="outFilePath">The out file path.�����ļ�·���б����������</param>
        /// <returns>�����Ƿ�ִ�гɹ�</returns>
        public bool LoadBackgroundData(List<string> inFilePath, ref List<string> outFilePath)
        {
            int FileNum = inFilePath.Count;// dlg.FileNames.GetUpperBound(0) + 1;
    
            for (int index = 0; index < FileNum; index++)
            {
                if (strTempFilePath == "")  //������ʱ�ļ���
                {
                    string strFisrtInFile=inFilePath[0];
                    //string strFisrtInFile = @"D:\zeng\TestData\enrypted";
                    string root = "";
                    if (System.IO.Path.IsPathRooted(strFisrtInFile)) root = System.IO.Path.GetPathRoot(strFisrtInFile);//System.IO.Path.GetDirectoryName(strFisrtInFile);
                    else root = "C:\\";

                    //root = root + "\\";

                    string randomFolder = "_temp_r"; //System.IO.Path.GetFileNameWithoutExtension(System.IO.Path.GetRandomFileName());
                    if (System.IO.Directory.Exists(root + randomFolder)) System.IO.Directory.Delete(root + randomFolder,true);
                    System.IO.DirectoryInfo info = System.IO.Directory.CreateDirectory(root +"\\"+ randomFolder);
                    info.Attributes = System.IO.FileAttributes.Hidden;//System.IO.FileAttributes.Encrypted |
                    strTempFilePath = root + randomFolder+"\\";
                }

                string fname = inFilePath[index];// dlg.FileNames[index];
                if (fname != null)
                {
                    string strName=System.IO.Path.GetFileName(fname);
                    string OutPath = strTempFilePath + strName.Remove(strName.Length - 4); //fname.Remove(fname.Length - 3);
                    if (!FileDecrypt(fname,OutPath))
                    {
                        return false;
                    }
                    outFilePath.Add(OutPath);

                    if (fname.ToLower().Contains(".shp.bcg")) //shape �ļ���ͬʱ��ѹ���
                    {
                        string AuxFileName, dbfOut;
                        try
                        {
                            AuxFileName = fname.ToLower().Replace(".shp.bcg", ".dbf.bcg");
                            dbfOut = OutPath.ToLower().Replace(".shp", ".dbf"); //AuxFileName.Remove(AuxFileName.Length - 3);
                            if (!FileDecrypt(AuxFileName, dbfOut)) return false;
                        }
                        catch { }

                        try
                        {
                            AuxFileName = fname.ToLower().Replace(".shp.bcg", ".prj.bcg");
                        //OutPath = AuxFileName.Remove(AuxFileName.Length - 3);
                        //if (!FileDecrypt(AuxFileName, OutPath)) return false;
                            dbfOut = OutPath.ToLower().Replace(".shp", ".prj"); 
                         if (!FileDecrypt(AuxFileName, dbfOut)) return false;
                        }
                        catch { }

                        try
                        {
                            AuxFileName = fname.ToLower().Replace(".shp.bcg", ".sbn.bcg");
                            dbfOut = OutPath.ToLower().Replace(".shp", ".sbn");
                         if (!FileDecrypt(AuxFileName, dbfOut)) return false;
                            }
                        catch { }

                       try
                        {
                            AuxFileName = fname.ToLower().Replace(".shp.bcg", ".sbx.bcg");
                            dbfOut = OutPath.ToLower().Replace(".shp", ".sbx");
                         if (!FileDecrypt(AuxFileName, dbfOut)) return false;
                                    }
                        catch { }

                        try
                        {
                            AuxFileName = fname.ToLower().Replace(".shp.bcg", ".shx.bcg");
                            dbfOut = OutPath.ToLower().Replace(".shp", ".shx");
                        if (!FileDecrypt(AuxFileName, dbfOut)) return false;
                    }
                    catch { }
                        
                    }
                }
            }

            return true;
        }

        /// <summary>
        /// Files the decrypt.�����ļ��Ľ���
        /// </summary>
        /// <param name="OpenFile">The open file.���ļ�</param>
        /// <param name="OutFile">The out file.������ܺ���ļ�·�� </param>
        /// <returns>�����Ƿ�ִ�гɹ�</returns>
        public bool FileDecrypt(string OpenFile, string OutFile)//,string OutFile
        {
            
            FileStream fileStream = new FileStream(OpenFile, FileMode.Open, FileAccess.Read);
            //ulong FileSize = (ulong)(fileStream.Length);
            long FileSize = fileStream.Length;

            byte[] CheckBits = new byte[MethodNameLength];
            int nBytesRead = fileStream.Read(CheckBits, 0, MethodNameLength);
           
                //�����ļ�ͷ���ܺ���
                bool bResult = false;
                if (bResult = HeadDecrypt(CheckBits))
                    FileSize -= MethodNameLength;
                
            byte[] lpData= new byte[FileSize];
             try
            {
                nBytesRead = fileStream.Read(lpData, 0, (int)FileSize);// MethodNameLength
                if (nBytesRead != FileSize) return false;
                //char temp[1];
                //memcy(temp,CheckBits,1);
                Decrypt(lpData, (ulong)FileSize, CheckBits[0]);
            }
            catch (Exception ex)
            {
                MessageBox.Show("�ļ����ܳ�����\r\n" + ex.Message);
            }
            fileStream.Close();

            //�����ļ�
            try
            {
                //OutFile =string.Format("{0}.{1}{2}{3}",OutFile,CheckBits[1],CheckBits[2],CheckBits[3]);
                //string OutFile = OpenFile.Remove(OpenFile.Length-3);
                fileStream = new FileStream(OutFile, FileMode.Create, FileAccess.Write);
                fileStream.Write(lpData, 0, (int)FileSize);
                fileStream.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("�洢��ʱ�ļ�������\r\n"+ex.Message);
            }

            return true;
        }
    }
}
