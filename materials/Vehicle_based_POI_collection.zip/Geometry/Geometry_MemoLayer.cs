//�ļ�����Ȩ��Ϣ------------------
/*
 * ���ļ������п���ͼ���¿Ƽ����޹�˾����ҵ����ƽ̨����ɲ���
 * δ���������ÿ���������������������ҵ��;
 * ��Ȩ���У��п���ͼ���¿Ƽ����޹�˾(http://www.mapuni.com/) 
 * �������ߣ�������   chqzeng@163.com 
 * ��дʱ�䣺2010-09-01
 */

using System;
using System.Drawing;
using System.Runtime.InteropServices;
using ESRI.ArcGIS.ADF.BaseClasses;
using ESRI.ArcGIS.ADF.CATIDs;
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.Geodatabase;
using ESRI.ArcGIS.DataSourcesGDB;
using ESRI.ArcGIS.Geometry;
using ESRI.ArcGIS.Controls;
using ESRI.ArcGIS.esriSystem;
using ESRI.ArcGIS.Display;

using System.Data;

namespace YuTuSurveyPlatform
{
    public class CreateMemoLayer
    {
        //public const int m_MAXROWS=2000;
        
        private IHookHelper m_hookHelper;

        //�Զ������
        private IFeature pthisfeature;
        IFeatureClass pvehicleclass;
        IFeatureLayer pvehiclelayer;
        IActiveView m_activeView;

        /// <summary>
        /// Ĭ�Ϲ��캯��
        /// </summary>
        public CreateMemoLayer(object hook)
        {
            if (hook == null)
                return;

            if (m_hookHelper == null)
                m_hookHelper = new HookHelperClass();

            m_hookHelper.Hook = hook;
            m_activeView = m_hookHelper.ActiveView;
        
        }

        /// <summary>
        /// �����յ��ڴ湤���ռ䣬���ҷ��ع����ռ� -- pfeatureworkspace
        /// </summary>
        /// <param name="slayername">The slayername.����</param>
        /// <param name="pspatialreference">The pspatialreference.�ռ�ο���������</param>
        /// <param name="itype">The itype.���ε�������</param>
        /// <returns></returns>
        private IFeatureWorkspace CreateEmptyLayerInmemeory(string slayername, ESRI.ArcGIS.Geometry.ISpatialReference pspatialreference, int itype)
        {
            //�򿪹����ռ�
            const string strShapeFieldName = "SHAPE";
            IWorkspaceFactory pWSF = new InMemoryWorkspaceFactoryClass();
            ESRI.ArcGIS.Geodatabase.IWorkspaceName pworkspacename = pWSF.Create("", "MyWorkspace", null, 0);
            ESRI.ArcGIS.esriSystem.IName pname = (IName)pworkspacename;
            IFeatureWorkspace pfeatureworkspace = (IFeatureWorkspace)(pname.Open()); //�򿪸ս������ڴ�ռ�

            try
            {

                //ΪesriFieldTypeGeometry���͵��ֶδ������ζ��壬�������ͺͿռ���� 
                IGeometryDef pGeoDef = new GeometryDefClass();     //The geometry definition for the field if IsGeometry is TRUE.
                IGeometryDefEdit pGeoDefEdit = (IGeometryDefEdit)pGeoDef;
                if (itype == 0)  //point
                {
                    pGeoDefEdit.GeometryType_2 = esriGeometryType.esriGeometryPoint;
                }
                else
                {
                    if (itype == 1)  //polyline
                    {
                        pGeoDefEdit.GeometryType_2 = esriGeometryType.esriGeometryPolyline;
                    }
                    else //polygon :3
                    {
                        pGeoDefEdit.GeometryType_2 = esriGeometryType.esriGeometryPolygon;
                    }
                }
                if (pspatialreference != null)
                {
                    pspatialreference.SetDomain(-180, 180, -90, 90);
                    pGeoDefEdit.SpatialReference_2 = pspatialreference;
                }
                else
                {

                    ISpatialReferenceFactory3 pspatialRefFac = new SpatialReferenceEnvironmentClass();
                    ISpatialReference pspatialRef = pspatialRefFac.CreateGeographicCoordinateSystem((int)esriSRGeoCSType.esriSRGeoCS_WGS1984);//�����ΪWGS84�Ŀռ��������ϵ
                    pspatialRef.SetDomain(-180, 180, -90, 90);//����һ��Ҫ����ֵ�����ã�
                    pGeoDefEdit.SpatialReference_2 = pspatialRef;
                }
                //�����ֶμ�
                IFields pFields = new FieldsClass();
                IFieldsEdit pFieldsEdit = (IFieldsEdit)pFields;
                //�����ֶ�
                IField pField = new FieldClass();
                IFieldEdit pFieldEdit = (IFieldEdit)pField;

                //��������Ϊ�������͵��ֶ�0
                pFieldEdit.Name_2 = strShapeFieldName;
                pFieldEdit.Type_2 = esriFieldType.esriFieldTypeGeometry;//esriFieldTypeGeometry;
                pFieldEdit.GeometryDef_2 = pGeoDef;
                pFieldsEdit.AddField(pField);
                //�����������ֶ�1:nodeid,2:x,3:y
                if (itype == 0)
                {
                    pField = new FieldClass();
                    pFieldEdit = (IFieldEdit)pField;
                    pFieldEdit.Name_2 = "ID";
                    pFieldEdit.Type_2 = esriFieldType.esriFieldTypeInteger;
                    pFieldsEdit.AddField(pField);

                    pField = new FieldClass();
                    pFieldEdit = (IFieldEdit)pField;
                    pFieldEdit.Name_2 = "X";
                    pFieldEdit.Type_2 = esriFieldType.esriFieldTypeDouble;
                    pFieldEdit.Precision_2 = 10;//��ֵ����
                    pFieldEdit.Scale_2 = 6;//С�������λ��
                    pFieldsEdit.AddField(pField);

                    pField = new FieldClass();
                    pFieldEdit = (IFieldEdit)pField;
                    pFieldEdit.Name_2 = "Y";
                    pFieldEdit.Type_2 = esriFieldType.esriFieldTypeDouble;
                    pFieldEdit.Precision_2 = 10;//��ֵ����
                    pFieldEdit.Scale_2 = 6;//С�������λ��
                    pFieldsEdit.AddField(pField);

                    pField = new FieldClass();
                    pFieldEdit = (IFieldEdit)pField;
                    pFieldEdit.Name_2 = "NAME";
                    pFieldEdit.Type_2 = esriFieldType.esriFieldTypeString;
                    pFieldEdit.Length_2 = 30;
                    pFieldsEdit.AddField(pField);
                    //���ӱ���ֶΣ�0��ʾ�������Ҳ���յ㣬1��ʾֻ����㣬2��ʾֻ���յ�
                    pField = new FieldClass();
                    pFieldEdit = (IFieldEdit)pField;
                    pFieldEdit.Name_2 = "flag";
                    pFieldEdit.Type_2 = esriFieldType.esriFieldTypeInteger;
                    pFieldsEdit.AddField(pField);
                }
                else
                {
                    pField = new FieldClass();
                    pFieldEdit = (IFieldEdit)pField;
                    pFieldEdit.Name_2 = "ID";
                    pFieldEdit.Type_2 = esriFieldType.esriFieldTypeInteger;
                    pFieldsEdit.AddField(pField);

                    pField = new FieldClass();
                    pFieldEdit = (IFieldEdit)pField;
                    pFieldEdit.Name_2 = "name";
                    pFieldEdit.Length_2 = 50;
                    pFieldEdit.Type_2 = esriFieldType.esriFieldTypeString;
                    pFieldsEdit.AddField(pField);

                    pField = new FieldClass();
                    pFieldEdit = (IFieldEdit)pField;
                    pFieldEdit.Name_2 = "firstnode";
                    pFieldEdit.Type_2 = esriFieldType.esriFieldTypeInteger;
                    pFieldsEdit.AddField(pField);

                    pField = new FieldClass();
                    pFieldEdit = (IFieldEdit)pField;
                    pFieldEdit.Name_2 = "endnode";
                    pFieldEdit.Type_2 = esriFieldType.esriFieldTypeInteger;
                    pFieldsEdit.AddField(pField);

                    pField = new FieldClass();
                    pFieldEdit = (IFieldEdit)pField;
                    pFieldEdit.Name_2 = "shunxu";
                    pFieldEdit.Type_2 = esriFieldType.esriFieldTypeInteger;
                    pFieldsEdit.AddField(pField);
                }
                //����shapefile
                IFeatureClass pfclass = pfeatureworkspace.CreateFeatureClass(slayername, pFields, null, null, esriFeatureType.esriFTSimple, strShapeFieldName, "");//��һ�����ǳ����⣡���Ľ�������ǣ�ԭ��֮ǰ�趨������ϵͳû��������
                IDataset pdataset = (IDataset)pfclass; // ����geodatabase���Ա�
                pdataset.BrowseName = slayername;
            }
            catch (System.Exception ex)
            {
                throw (ex);
            }

            return pfeatureworkspace;
        }



        /// <summary>
        /// ������ϵͳ��Ҫʹ�õ��ڴ�ͼ�㣬�����ԣ�δʹ��
        /// </summary>
        public void CreateSurveyFeature(string layerName)
        {
            IFeatureWorkspace pvehicleworkspace = CreateEmptyLayerInmemeory("Survey", null, 0);//�����ڴ湤���ռ�
            pvehicleclass = pvehicleworkspace.OpenFeatureClass("Survey"); //��֮ǰ��CreateEmptyLayerInmemeory�������Ѿ�������һ������Ϊ��vehicle����Ҫ�ؼ�����������
            pvehiclelayer = new FeatureLayerClass();
            pvehiclelayer.FeatureClass = pvehicleclass;  //��֮ǰ������shapefile ��pvehicleclass����ֵ���´�����layer��pvehiclelayer
            pvehiclelayer.Name = layerName;

            IDataset pdataset = (IDataset)pvehiclelayer; //�������Ա�
            IWorkspaceEdit pworkspaceedit = (IWorkspaceEdit)(pdataset.Workspace);

            pworkspaceedit.StartEditing(true); //allows the application to start and stop edit sessions during which the objects in a geodatabase can be updated. An edit session corresponds to a long transaction.
            pworkspaceedit.StartEditOperation();
            
            pthisfeature = pvehicleclass.CreateFeature(); //����Ҫ�� Create a new feature, with a system assigned object ID and null property values. 
            //The new feature is by default assigned a unique object ID (OID). 
            //All other fields are initialized to null values if they can be made null and to built-in default values appropriate to the type of the field if they cannot be made null. 
            //Use the IFeature::Store method to actually store this new feature in the database.
            IPoint ppoint = new PointClass();
            double x = 113.2;
            double y = 24.0;
            ppoint.PutCoords(x, y); //set the X,Y coordinates for a Point. The coordinates can also be set by updating the X and Y properties for the point. 
            pthisfeature.Shape = (IGeometry)ppoint; //��ֵ���ѵ�ռ�Ҫ�ظ�ֵ��������Ҫ�ؼ�

            pthisfeature.Store();
            pworkspaceedit.StopEditOperation();
            pworkspaceedit.StopEditing(true);

            IFeatureLayer lyr=new FeatureLayerClass();
            lyr.FeatureClass=pvehicleclass;

            Geometry_IO.Geometry_Attribute attr = new Geometry_IO.Geometry_Attribute();
            attr.CreateTableInMDB("MyTestMDB.mdb", "MytestShp", lyr);
            attr.WriteShpaeFile2YutuFile("MyTestMDB.mdb", "MytestShp", lyr);

            //add
            //PointRender(pvehiclelayer);

            m_activeView.FocusMap.AddLayer(pvehiclelayer);
        }
        
        /// <summary>
        /// ͼ����ʾ���ƣ������ԣ�δʹ��
        /// </summary>
        /// <param name="player"></param>
        private void PointRender(IFeatureLayer player)
        {
            IGeoFeatureLayer pgeolayer = (IGeoFeatureLayer)player;
            IFeatureRenderer pfeaturerender = pgeolayer.Renderer;
            IFeatureClass pfeatureclass = player.FeatureClass;
            ISimpleRenderer psimplerender = new SimpleRendererClass();
            psimplerender.Description = "����Ⱦ";
            psimplerender.Label = "ID";

            //pSymbol.ROP2 = esriRasterOpCode.esriROPCopyPen;//esriROPNotXOrPen;
            IPictureMarkerSymbol ppicmarksymbol = new PictureMarkerSymbolClass();
            //string bitmapname = GetType().Name + ".bmp";
            ppicmarksymbol.CreateMarkerSymbolFromFile(esriIPictureType.esriIPictureBitmap, @"c:\tem\ship_016.bmp");//@"c:\tem\ship_016.bmp"
            ppicmarksymbol.Size = 20;
            //0-360�ȣ���ʱ��ת��
            ppicmarksymbol.Angle = 360;

            psimplerender.Symbol = (ISymbol)ppicmarksymbol;
            pgeolayer.Renderer = (IFeatureRenderer)psimplerender;
            //player.Name = "���򴬲�"; //�趨�½����ڴ�ͼ������
            m_activeView.PartialRefresh(esriViewDrawPhase.esriViewGraphics, player, null); //�ֲ�ˢ��
        }


   #region  ���ݱ�����
        private static DataTable CreateDataTableByLayer(ILayer pLayer, string tableName)
        {
            //����һ��DataTable��
            DataTable pDataTable = new DataTable(tableName);
            //ȡ��ITable�ӿ�
            ITable pTable = pLayer as ITable;
            IField pField = null;
            DataColumn pDataColumn;
            //����ÿ���ֶε����Խ���DataColumn����
            for (int i = 0; i < pTable.Fields.FieldCount; i++)
            {
                pField = pTable.Fields.get_Field(i);
                //�½�һ��DataColumn������������
                pDataColumn = new DataColumn(pField.Name);
                if (pField.Name == pTable.OIDFieldName)
                {
                    pDataColumn.Unique = true;//�ֶ�ֵ�Ƿ�Ψһ
                }
                //�ֶ�ֵ�Ƿ�����Ϊ��
                pDataColumn.AllowDBNull = pField.IsNullable;
                //�ֶα���
                pDataColumn.Caption = pField.AliasName;
                //�ֶ���������
                pDataColumn.DataType = System.Type.GetType(ParseFieldType(pField.Type));
                //�ֶ�Ĭ��ֵ
                pDataColumn.DefaultValue = pField.DefaultValue;
                //���ֶ�ΪString�����������ֶγ���
                if (pField.VarType == 8)
                {
                    pDataColumn.MaxLength = pField.Length;
                }
                //�ֶ����ӵ�����
                pDataTable.Columns.Add(pDataColumn);
                pField = null;
                pDataColumn = null;
            }
            return pDataTable;
        }

        /// <summary>
        /// ��GeoDatabase�ֶ�����ת����.Net��Ӧ����������
        /// </summary>
        /// <param name="fieldType">�ֶ�����</param>
        /// <returns></returns>
        public static string ParseFieldType(esriFieldType fieldType)
        {
            switch (fieldType)
            {
                case esriFieldType.esriFieldTypeBlob:
                    return "System.String";
                case esriFieldType.esriFieldTypeDate:
                    return "System.DateTime";
                case esriFieldType.esriFieldTypeDouble:
                    return "System.Double";
                case esriFieldType.esriFieldTypeGeometry:
                    return "System.String";
                case esriFieldType.esriFieldTypeGlobalID:
                    return "System.String";
                case esriFieldType.esriFieldTypeGUID:
                    return "System.String";
                case esriFieldType.esriFieldTypeInteger:
                    return "System.Int32";
                case esriFieldType.esriFieldTypeOID:
                    return "System.String";
                case esriFieldType.esriFieldTypeRaster:
                    return "System.String";
                case esriFieldType.esriFieldTypeSingle:
                    return "System.Single";
                case esriFieldType.esriFieldTypeSmallInteger:
                    return "System.Int32";
                case esriFieldType.esriFieldTypeString:
                    return "System.String";
                default:
                    return "System.String";
            }
        }
        
        /// <summary>
        /// ���DataTable�е�����
        /// </summary>
        /// <param name="pLayer"></param>
        /// <param name="tableName"></param>
        /// <returns></returns>
        public static DataTable CreateDataTable(ILayer pLayer, string tableName)
        {
            //������DataTable
            DataTable pDataTable = CreateDataTableByLayer(pLayer, tableName);
            //ȡ��ͼ������
            string shapeType = getShapeType(pLayer);
            //����DataTable���ж���
            DataRow pDataRow = null;
            //��ILayer��ѯ��ITable
            ITable pTable = pLayer as ITable;
            ICursor pCursor = pTable.Search(null, false);
            //ȡ��ITable�е�����Ϣ
            IRow pRow = pCursor.NextRow();
            long n = 0;
            while (pRow != null)
            {
                //�½�DataTable���ж���
                pDataRow = pDataTable.NewRow();
                for (int i = 0; i < pRow.Fields.FieldCount; i++)
                {
                    //����ֶ�����ΪesriFieldTypeGeometry�������ͼ�����������ֶ�ֵ
                    if (pRow.Fields.get_Field(i).Type == esriFieldType.esriFieldTypeGeometry)
                    {
                        pDataRow[i] = shapeType;
                    }
                    //��ͼ������ΪAnotationʱ��Ҫ�����л���esriFieldTypeBlob���͵����ݣ�
                    //��洢���Ǳ�ע���ݣ��������轫��Ӧ���ֶ�ֵ����ΪElement
                    else if (pRow.Fields.get_Field(i).Type == esriFieldType.esriFieldTypeBlob)
                    {
                        pDataRow[i] = "Element";
                    }
                    else
                    {
                        if (pRow.get_Value(i) == null)//Ϊ��ʱ��Ϊ�ռ�����ֶ�
                        {
                            if (pRow.Fields.get_Field(i).Type == esriFieldType.esriFieldTypeString) pDataRow[i] = "";
                            else pDataRow[i] = 0;
                        }
                        else
                        {
                            pDataRow[i] = pRow.get_Value(i);
                        }
                    }
                }
                //����DataRow��DataTable
                pDataTable.Rows.Add(pDataRow);
                pDataRow = null;
                n++;
                //Ϊ��֤Ч�ʣ�һ��ֻװ���������¼
                //if (n == m_MAXROWS)
                //{
                //    pRow = null;
                //}
                //else
                //{
                    pRow = pCursor.NextRow();
                //}
            }
            return pDataTable;
        }

        /// <summary>
        /// ���ͼ���Shape����
        /// </summary>
        /// <param name="pLayer">ͼ��</param>
        /// <returns></returns>
        public static string getShapeType(ILayer pLayer)
        {
            IFeatureLayer pFeatLyr = (IFeatureLayer)pLayer;
            switch (pFeatLyr.FeatureClass.ShapeType)
            {
                case esriGeometryType.esriGeometryPoint:
                    return "Point";
                case esriGeometryType.esriGeometryPolyline:
                    return "Polyline";
                case esriGeometryType.esriGeometryPolygon:
                    return "Polygon";
                default:
                    return "";
            }
        }
#endregion
    }
}
