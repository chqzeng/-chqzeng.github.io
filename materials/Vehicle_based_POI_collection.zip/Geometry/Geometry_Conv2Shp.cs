//�ļ�����Ȩ��Ϣ------------------
/*
 * ���ļ������п���ͼ���¿Ƽ����޹�˾����ҵ����ƽ̨����ɲ���
 * δ���������ÿ���������������������ҵ��;
 * ��Ȩ���У��п���ͼ���¿Ƽ����޹�˾(http://www.mapuni.com/) 
 * �������ߣ�������   chqzeng@163.com 
 * ��дʱ�䣺2010-09-01
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.Geodatabase;
using ESRI.ArcGIS.Geometry;
using ESRI.ArcGIS.Output;
using ESRI.ArcGIS.SystemUI;
using ESRI.ArcGIS.Display;
using ESRI.ArcGIS.ADF.BaseClasses;
using ESRI.ArcGIS.ADF.CATIDs;
using ESRI.ArcGIS.Controls;
using ESRI.ArcGIS.esriSystem;
using ESRI.ArcGIS.DataSourcesFile;

using Geometry_Define;


namespace Geometry_IO
{
    /// <summary>
    /// ��Ҫ���࣬����shape�ļ��� yvt�������͵�ת��
    /// </summary>
    
    public partial class Geometry_Conv2Shp
    {

        //�ն�����
        public static object _missing = Type.Missing;

        /// <summary>
        /// Convs from SH p2 yutu geometry.
        /// shape�ļ��� yvt�������͵�ת����yvt-->shape
        /// </summary>
        /// <param name="GeoObject">The geo object.</param>
        /// <returns>����YVT��������</returns>
        public static G_Geometry ConvFromSHP2YutuGeometry(IGeometry GeoObject)
        {
            IPoint inPt;
            G_Point pt;
            G_Line outGeoLine;
            switch (GeoObject.GeometryType) //type
            {
                case esriGeometryType.esriGeometryPoint:
                    inPt = GeoObject as IPoint;
                    pt = new G_Point(inPt.X, inPt.Y, inPt.Z);
                    return pt;
                    
                case esriGeometryType.esriGeometryPolyline:
                    //IPolyline polyline = GeoObject as IPolyline;
                    IGeometryCollection polyline = GeoObject as IGeometryCollection;
                    IPointCollection line = polyline.get_Geometry(0) as IPointCollection; //ֻ��ȡ��һ��PATH!!
                    outGeoLine = new G_Line();
                    for (int index = 0; index < line.PointCount; index++)
                    {
                        inPt = line.get_Point(index);
                        pt = new G_Point(inPt.X, inPt.Y, inPt.Z);
                        outGeoLine.AddPoint(pt);
                    }
                    return outGeoLine;
                    
                case esriGeometryType.esriGeometryPolygon:
                    IGeometryCollection GeoColl = GeoObject as IGeometryCollection;
                    G_Polygon outPolygon = new G_Polygon();
                    for(int i=0; i<GeoColl.GeometryCount;i++)  //�������еĻ�
                    {
                        IPointCollection pts = GeoColl.get_Geometry(i) as IPointCollection; //ֻ��ȡ��һ��PATH!!
                        outGeoLine = new G_Line();
                        for (int index = 0; index < pts.PointCount; index++)
                        {
                            inPt = pts.get_Point(index);
                            pt = new G_Point(inPt.X, inPt.Y, inPt.Z);
                            outGeoLine.AddPoint(pt);
                        }
                        //if (!outGeoLine.IsClosed()) outGeoLine.AddPoint(outGeoLine.GetPoint(0)); //�ж��Ƿ���
                        outPolygon.AddRing(outGeoLine);
                    }
                    return outPolygon;
                    
            }
            // coordiates.\
            return null;
            
        }
       
        /// <summary>
        /// Convs from yutu geometry2 SHP.
        /// shape�ļ��� yvt�������͵�ת����shape-->yvt
        /// </summary>
        /// <param name="GeoObj">The geo obj.</param>
        /// <returns>����ESRI �ļ�������</returns>
        public static IGeometry ConvFromYutuGeometry2SHP(G_Geometry GeoObj)//
        {
            IPoint ppoint;
            G_Point inPt;        
            switch (GeoObj.GetGeoType()) //type
            {
                case tagGeoType.GT_GeoPoint:
                    inPt = GeoObj as G_Point;
                    ppoint = new PointClass();
                    ppoint.PutCoords(inPt.GetX(), inPt.GetY());
                    ppoint.Z = inPt.GetZ();
                    return ppoint;

                case tagGeoType.GT_GeoCurve:
                    G_Line line = GeoObj as G_Line;
                    if (line.GetPointCount() == 0) return null;
                    IPointCollection pointCollection = new PathClass();
                    for (int j = 0; j < line.GetPointCount(); j++)
                    {
                        inPt = line.GetPoint(j);
                        ppoint = new PointClass();
                        ppoint.PutCoords(inPt.GetX(), inPt.GetY());
                        ppoint.Z = inPt.GetZ();
                        pointCollection.AddPoint(ppoint, ref _missing, ref _missing);
                    }
                    IGeometryCollection polyline = new PolylineClass();
                    polyline.AddGeometry(pointCollection as IGeometry, ref _missing, ref _missing);
                    return polyline as IGeometry;

                case tagGeoType.GT_GeoPolygon:
                    G_Polygon InPoly = GeoObj as G_Polygon;
                    IGeometryCollection polygon = new PolygonClass();
                    if (InPoly.GetRingCount() == 0) return null;

                    for (int index = 0; index < InPoly.GetRingCount(); index++) //����ÿ����
                    {
                        pointCollection = new RingClass();
                        line = InPoly.GetRing(index);
                        for (int j = 0; j < line.GetPointCount(); j++)
                        {
                            inPt = line.GetPoint(j);
                            ppoint = new PointClass();
                            ppoint.PutCoords(inPt.GetX(), inPt.GetY());
                            ppoint.Z = inPt.GetZ();
                            pointCollection.AddPoint(ppoint, ref _missing, ref _missing);
                        }
                        polygon.AddGeometry(pointCollection as IGeometry, ref _missing, ref _missing);
                    }

                    return polygon as IGeometry;
            }
            return null;
        }

        
    }
}
