// Copyright 2008 ESRI
// 
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
// 
// You may freely redistribute and use this sample code, with or
// without modification, provided you include the original copyright
// notice and use restrictions.
// 
// See use restrictions at <your ArcGIS install location>/developerkit/userestrictions.txt.
// 

using ESRI.ArcGIS.SystemUI;
namespace Core
{
  partial class SnapEditor
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
        this.clearAgents = new System.Windows.Forms.Button();
        this.turnOffAgents = new System.Windows.Forms.Button();
        this.addFeatureSnapAgent = new System.Windows.Forms.Button();
        this.reverseAgentsPriority = new System.Windows.Forms.Button();
        this.snapToleranceLabel = new System.Windows.Forms.Label();
        this.snapTips = new System.Windows.Forms.CheckBox();
        this.snapTolUnits = new System.Windows.Forms.ComboBox();
        this.snapTolerance = new System.Windows.Forms.MaskedTextBox();
        this.snapAgents = new System.Windows.Forms.DataGridView();
        this.snapAgentNameColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
        this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
        this.ftrSnapAgentColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
        this.addSketchSnapAgent = new System.Windows.Forms.Button();
        this.button1 = new System.Windows.Forms.Button();
        ((System.ComponentModel.ISupportInitialize)(this.snapAgents)).BeginInit();
        this.SuspendLayout();
        // 
        // clearAgents
        // 
        this.clearAgents.Location = new System.Drawing.Point(12, 210);
        this.clearAgents.Name = "clearAgents";
        this.clearAgents.Size = new System.Drawing.Size(131, 28);
        this.clearAgents.TabIndex = 0;
        this.clearAgents.Text = "���Agents";
        this.clearAgents.UseVisualStyleBackColor = true;
        this.clearAgents.Click += new System.EventHandler(this.clearAgents_Click);
        // 
        // turnOffAgents
        // 
        this.turnOffAgents.Location = new System.Drawing.Point(149, 210);
        this.turnOffAgents.Name = "turnOffAgents";
        this.turnOffAgents.Size = new System.Drawing.Size(131, 28);
        this.turnOffAgents.TabIndex = 1;
        this.turnOffAgents.Text = "�ر�Agents";
        this.turnOffAgents.UseVisualStyleBackColor = true;
        this.turnOffAgents.Click += new System.EventHandler(this.turnOffAgents_Click);
        // 
        // addFeatureSnapAgent
        // 
        this.addFeatureSnapAgent.Location = new System.Drawing.Point(439, 77);
        this.addFeatureSnapAgent.Name = "addFeatureSnapAgent";
        this.addFeatureSnapAgent.Size = new System.Drawing.Size(127, 33);
        this.addFeatureSnapAgent.TabIndex = 2;
        this.addFeatureSnapAgent.Text = "����������׽Agent";
        this.addFeatureSnapAgent.UseVisualStyleBackColor = true;
        this.addFeatureSnapAgent.Click += new System.EventHandler(this.addFeatureSnapAgent_Click);
        // 
        // reverseAgentsPriority
        // 
        this.reverseAgentsPriority.Location = new System.Drawing.Point(286, 210);
        this.reverseAgentsPriority.Name = "reverseAgentsPriority";
        this.reverseAgentsPriority.Size = new System.Drawing.Size(131, 28);
        this.reverseAgentsPriority.TabIndex = 3;
        this.reverseAgentsPriority.Text = "����Agents���ȼ�";
        this.reverseAgentsPriority.UseVisualStyleBackColor = true;
        this.reverseAgentsPriority.Click += new System.EventHandler(this.reverseAgentsPriority_Click);
        // 
        // snapToleranceLabel
        // 
        this.snapToleranceLabel.AutoSize = true;
        this.snapToleranceLabel.Location = new System.Drawing.Point(147, 19);
        this.snapToleranceLabel.Name = "snapToleranceLabel";
        this.snapToleranceLabel.Size = new System.Drawing.Size(53, 12);
        this.snapToleranceLabel.TabIndex = 7;
        this.snapToleranceLabel.Text = "��׽�ݲ�";
        // 
        // snapTips
        // 
        this.snapTips.AutoSize = true;
        this.snapTips.Location = new System.Drawing.Point(15, 15);
        this.snapTips.Name = "snapTips";
        this.snapTips.Size = new System.Drawing.Size(108, 16);
        this.snapTips.TabIndex = 9;
        this.snapTips.Text = "��׽���(tips)";
        this.snapTips.UseVisualStyleBackColor = true;
        this.snapTips.CheckedChanged += new System.EventHandler(this.snapTips_CheckedChanged);
        // 
        // snapTolUnits
        // 
        this.snapTolUnits.FormattingEnabled = true;
        this.snapTolUnits.Items.AddRange(new object[] {
            "����",
            "��ͼ��λ"});
        this.snapTolUnits.Location = new System.Drawing.Point(294, 16);
        this.snapTolUnits.Name = "snapTolUnits";
        this.snapTolUnits.Size = new System.Drawing.Size(121, 20);
        this.snapTolUnits.TabIndex = 12;
        this.snapTolUnits.SelectedIndexChanged += new System.EventHandler(this.snapTolUnits_SelectedIndexChanged);
        // 
        // snapTolerance
        // 
        this.snapTolerance.AllowPromptAsInput = false;
        this.snapTolerance.AsciiOnly = true;
        this.snapTolerance.Location = new System.Drawing.Point(236, 16);
        this.snapTolerance.Mask = "00000";
        this.snapTolerance.Name = "snapTolerance";
        this.snapTolerance.Size = new System.Drawing.Size(52, 21);
        this.snapTolerance.TabIndex = 14;
        this.snapTolerance.ValidatingType = typeof(int);
        this.snapTolerance.TypeValidationCompleted += new System.Windows.Forms.TypeValidationEventHandler(this.snapTolerance_TypeValidationEventHandler);
        // 
        // snapAgents
        // 
        this.snapAgents.AllowUserToAddRows = false;
        this.snapAgents.AllowUserToDeleteRows = false;
        this.snapAgents.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCellsExceptHeader;
        this.snapAgents.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.snapAgentNameColumn,
            this.Column1,
            this.ftrSnapAgentColumn});
        this.snapAgents.Location = new System.Drawing.Point(17, 43);
        this.snapAgents.MultiSelect = false;
        this.snapAgents.Name = "snapAgents";
        this.snapAgents.ReadOnly = true;
        this.snapAgents.RowTemplate.Height = 23;
        this.snapAgents.Size = new System.Drawing.Size(400, 150);
        this.snapAgents.TabIndex = 15;
        // 
        // snapAgentNameColumn
        // 
        this.snapAgentNameColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
        this.snapAgentNameColumn.HeaderText = "��׽����(Agent)";
        this.snapAgentNameColumn.MinimumWidth = 100;
        this.snapAgentNameColumn.Name = "snapAgentNameColumn";
        this.snapAgentNameColumn.ReadOnly = true;
        this.snapAgentNameColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
        this.snapAgentNameColumn.Width = 101;
        // 
        // Column1
        // 
        this.Column1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCellsExceptHeader;
        this.Column1.HeaderText = "Feature Agent";
        this.Column1.MinimumWidth = 85;
        this.Column1.Name = "Column1";
        this.Column1.ReadOnly = true;
        this.Column1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
        this.Column1.Width = 85;
        // 
        // ftrSnapAgentColumn
        // 
        this.ftrSnapAgentColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCellsExceptHeader;
        this.ftrSnapAgentColumn.HeaderText = "Feature Agent�������";
        this.ftrSnapAgentColumn.MinimumWidth = 145;
        this.ftrSnapAgentColumn.Name = "ftrSnapAgentColumn";
        this.ftrSnapAgentColumn.ReadOnly = true;
        this.ftrSnapAgentColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
        this.ftrSnapAgentColumn.Width = 145;
        // 
        // addSketchSnapAgent
        // 
        this.addSketchSnapAgent.Location = new System.Drawing.Point(440, 128);
        this.addSketchSnapAgent.Name = "addSketchSnapAgent";
        this.addSketchSnapAgent.Size = new System.Drawing.Size(126, 33);
        this.addSketchSnapAgent.TabIndex = 17;
        this.addSketchSnapAgent.Text = "���ӻ�ͼ��׽Agent";
        this.addSketchSnapAgent.UseVisualStyleBackColor = true;
        this.addSketchSnapAgent.Click += new System.EventHandler(this.addSketchSnapAgent_Click);
        // 
        // button1
        // 
        this.button1.Location = new System.Drawing.Point(439, 210);
        this.button1.Name = "button1";
        this.button1.Size = new System.Drawing.Size(126, 27);
        this.button1.TabIndex = 18;
        this.button1.Text = "�˳�";
        this.button1.UseVisualStyleBackColor = true;
        this.button1.Click += new System.EventHandler(this.button1_Click);
        // 
        // SnapEditor
        // 
        this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
        this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
        this.ClientSize = new System.Drawing.Size(578, 248);
        this.Controls.Add(this.button1);
        this.Controls.Add(this.addSketchSnapAgent);
        this.Controls.Add(this.snapAgents);
        this.Controls.Add(this.snapTolerance);
        this.Controls.Add(this.snapTolUnits);
        this.Controls.Add(this.snapTips);
        this.Controls.Add(this.snapToleranceLabel);
        this.Controls.Add(this.reverseAgentsPriority);
        this.Controls.Add(this.addFeatureSnapAgent);
        this.Controls.Add(this.turnOffAgents);
        this.Controls.Add(this.clearAgents);
        this.MaximizeBox = false;
        this.Name = "SnapEditor";
        this.Text = "��׽��������";
        ((System.ComponentModel.ISupportInitialize)(this.snapAgents)).EndInit();
        this.ResumeLayout(false);
        this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.Button clearAgents;
    private System.Windows.Forms.Button turnOffAgents;
    private System.Windows.Forms.Button addFeatureSnapAgent;
    private System.Windows.Forms.Button reverseAgentsPriority;
    private System.Windows.Forms.Label snapToleranceLabel;
    private System.Windows.Forms.CheckBox snapTips;
    private System.Windows.Forms.ComboBox snapTolUnits;
    private System.Windows.Forms.MaskedTextBox snapTolerance;
    private System.Windows.Forms.DataGridView snapAgents;
      private System.Windows.Forms.Button addSketchSnapAgent;
      private System.Windows.Forms.DataGridViewTextBoxColumn snapAgentNameColumn;
      private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
      private System.Windows.Forms.DataGridViewTextBoxColumn ftrSnapAgentColumn;
      private System.Windows.Forms.Button button1;
  }
}