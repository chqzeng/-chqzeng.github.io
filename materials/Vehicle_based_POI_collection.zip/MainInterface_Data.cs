//�ļ�����Ȩ��Ϣ------------------
/*
 * ���ļ������п���ͼ���¿Ƽ����޹�˾����ҵ����ƽ̨����ɲ���
 * δ���������ÿ���������������������ҵ��;
 * ��Ȩ���У��п���ͼ���¿Ƽ����޹�˾(http://www.mapuni.com/) 
 * �������ߣ�������   chqzeng@163.com 
 * ��дʱ�䣺2010-09-01
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using GPSManager;

using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.InteropServices;

using ESRI.ArcGIS.esriSystem;
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.Geodatabase;
using ESRI.ArcGIS.Geometry;
using ESRI.ArcGIS.DataSourcesGDB;
using ESRI.ArcGIS.DataSourcesFile;
using ESRI.ArcGIS.Display;
using ESRI.ArcGIS.Controls;
using ESRI.ArcGIS.Display;
namespace YuTuSurveyPlatform
{
    /// <summary>
    /// ���ļ���Ҫ���������ݵĹ��������� Ӱ��ʸ���������� �ļ��أ��Լ���ͼYVT��ʽ ���� �ĵ��뵼����
    /// ������������غ�����һ����
    /// </summary>
    /// 

    public partial class MainInterface : Form
    {
        /// <summary>
        /// 	<Description>�˵���Ϣ��Ӧ����: ID_MENU_DATAMNG_IMG_Click</Description>
        /// ���ؼ��ܵ�Ӱ������
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void ID_MENU_DATAMNG_IMG_Click(object sender, EventArgs e)
        {

            List<string> inFilePath = OpenFileWithFilter("����TIF�������� (*.tif.bcg)|*.tif.bcg|����IMG�������� (*.img.bcg)|*.img.bcg");

            if (inFilePath == null || inFilePath.Count == 0) return;
            m_GeoEnctry.OpenRasterBackGround(inFilePath, ref  m_CurLayerList);
        }

        /// <summary>
        /// 	<Description>�˵���Ϣ��Ӧ����: ID_MENU_DATAMNG_SHP_Click</Description>
        /// ���ؼ��ܵ�SHPʸ����������
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void ID_MENU_DATAMNG_SHP_Click(object sender, EventArgs e)
        {
            //OpenFileDialog dlg = new OpenFileDialog();
            //dlg.CheckFileExists = true;
            //dlg.Filter = "Background data (*.shp.bcg)|*.shp.bcg";//filter;// "Background data (*.bcg)|*.bcg";
            //dlg.Multiselect = true; //true
            //dlg.Title = "�򿪼��ܵ�ʸ����ͼ��";

            //if (dlg.ShowDialog() != DialogResult.OK) return;

            //int FileNum = dlg.FileNames.GetUpperBound(0) + 1;
            //List<string> inFilePath = new List<string>();
            //for(int index=0;index<FileNum;index++)
            //{
            //    inFilePath.Add(dlg.FileNames[index]);

            //}
            List<string> inFilePath = OpenFileWithFilter("����shape�������� (*.shp.bcg)|*.shp.bcg");
            if (inFilePath == null || inFilePath.Count == 0) return;
            //Geometry_Encrypt cls= new Geometry_Encrypt(this.axMapControl1.Object as IMapControl2);
            m_GeoEnctry.OpenShapeBackGround(inFilePath, ref  m_CurLayerList);
        }

        /// <summary>
        /// 	<Description>�˵���Ϣ��Ӧ����: ID_MENU_DATAMNG_YUT_IN_Click</Description>
        /// ������ͼ�Զ����YVTʸ������
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void ID_MENU_DATAMNG_YUT_IN_Click(object sender, EventArgs e)
        {

            //OpenFileDialog dlg = new OpenFileDialog();
            //dlg.CheckFileExists = true;
            //dlg.Filter = "Yutu vector data (*.yvt)|*.yvt";
            //dlg.Multiselect = true; //true
            //dlg.Title = "����ͼ��ʽʸ������";

            //if (dlg.ShowDialog() != DialogResult.OK) return;


            List<string> inFilePath = OpenFileWithFilter("��ͼʸ�����ݸ�ʽ (*.yvt)|*.yvt");
            if (inFilePath == null || inFilePath.Count == 0) return;
            OpenYVTvectorData(inFilePath, ref m_CurLayerList);


        }

        /// <summary>
        /// 	<Description>�˵���Ϣ��Ӧ����: ID_MENU_DATAMNG_YUT_OUT_Click</Description>
        /// ������ͼ�Զ����YVTʸ�����ݣ�
        /// ע��������ļ���ѡ�������������������һ��ʸ��YVT����
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void ID_MENU_DATAMNG_YUT_OUT_Click(object sender, EventArgs e)
        {
            if (this.axMapControl1.LayerCount == 0) return;

            SaveFileDialog saveFileDialog1 = new SaveFileDialog();
            saveFileDialog1.Filter = @"Yutu files (*.yvt)|*.yvt|All files (*.*)|*.*";
            saveFileDialog1.Title = "������ͼ��ʽʸ������(��ǰѡ�в�)";
            if (saveFileDialog1.ShowDialog() != DialogResult.OK) return;

            string strPath = saveFileDialog1.FileName; //System.IO.Path.GetDirectoryName(saveFileDialog1.FileName);
            if (!strPath.Contains(".yvt")) strPath = strPath + ".yvt";
            IFeatureLayer lyr = this.axMapControl1.ActiveView.FocusMap.get_Layer(0) as IFeatureLayer;
            ExportYutuVectorData(strPath, lyr);

            MessageBox.Show("�ɹ����� YVT ��ʽ ���� ��");

            return;



            /*
            Geometry_Attribute cls = new Geometry_Attribute();
            string mdbPath, TableName;
            mdbPath = "MyTestMDB.yvt";
            TableName = "MytestShp";
            IFeatureLayer lyr = cls.LoadDataFromMDB2SHP(mdbPath, TableName, TableName);

            this.axMapControl1.ActiveView.FocusMap.AddLayer(lyr);
            
            Geometry_Conv2Shp clss = new Geometry_Conv2Shp();
            clss.ExportFeatureLayerAs(lyr);

            //CreateMemoLayer lyr = new CreateMemoLayer(this.axMapControl1.Object);
            //lyr.CreateSurveyFeature("myLayerTest");
             */
        }

        /// <summary>
        /// Exports the yutu vector data.
        /// ���ĺ��������ڵ��� YVT ����
        /// </summary>
        /// <param name="strPath">The STR path. �������� ��·�� </param>
        /// <param name="lyr">The lyr.��Ҫ�����Ĳ�</param>
        public void ExportYutuVectorData(string strPath, IFeatureLayer lyr)
        {

            string strName = System.IO.Path.GetFileNameWithoutExtension(strPath);
            string strOutPath = strPath;
            bool m_bExists = false;
            //����ļ����ڣ���������ɾ��
            try
            {
                if (System.IO.File.Exists(strPath))
                {
                    //m_bExists = true;
                    //strOutPath = strOutPath + "_ext";
                    System.IO.File.Delete(strPath);
                }

                System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor;

                Geometry_IO.Geometry_Attribute attr = new Geometry_IO.Geometry_Attribute();

                string strpath = strOutPath;// strPath;
                string TableName = Geometry_IO.Geometry_Attribute.m_strConstTableName;// System.IO.Path.GetFileNameWithoutExtension(strpath);//"MytestShp"
                attr.CreateTableInMDB(strpath, TableName, lyr);
                if (!attr.WriteShpaeFile2YutuFile(strpath, TableName, lyr)) return;

                if (m_bExists)
                {
                    System.IO.File.Delete(strPath);
                    //System.IO.File.Replace(strPath, strOutPath,"");
                    System.IO.File.Move(strOutPath, strPath);
                }
                System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default;
            }
            catch (Exception ex) { MessageBox.Show("����YUTU����������ԭ����ִ���\r\n" + ex.Message); return; }

        }

        /// <summary>
        /// Adds all data.
        /// ͨ���Ի���������и�ʽ�����ݣ�
        /// ����ѡ���������еĸ�ʽ���ز�ͬ������ 
        /// </summary>
        /// <param name="inFilePath">The in file path.</param>
        /// <param name="FilterIndex">Index of the filter.</param>
        public void AddAllData(List<string> inFilePath, int FilterIndex) //dlg.FilterIndex
        {
            switch (FilterIndex)
            {
                case 4:  //raster
                case 3:
                    m_GeoEnctry.OpenRasterBackGround(inFilePath, ref m_CurLayerList);
                    break;
                case 2:  //shape
                    m_GeoEnctry.OpenShapeBackGround(inFilePath, ref m_CurLayerList);
                    break;
                case 1: //yutu shape
                    OpenYVTvectorData(inFilePath, ref m_CurLayerList);
                    break;
            }
        }

        /// <summary>
        /// Opens the file with filter.
        /// ѡ����Ҫ�򿪵��ļ�
        /// </summary>
        /// <param name="Filter">The filter.������</param>
        /// <returns></returns>
        private List<string> OpenFileWithFilter(string Filter)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.CheckFileExists = true;
            dlg.Filter = Filter;// "Background data (*.tif.bcg)|*.tif.bcg|Background data (*.img.bcg)|*.img.bcg";
            dlg.Multiselect = true; //true
            dlg.Title = "�򿪼��ܵ�դ���ͼ��";
            if (dlg.ShowDialog() != DialogResult.OK) return null;

            int FileNum = dlg.FileNames.GetUpperBound(0) + 1;
            List<string> inFilePath = new List<string>();
            for (int index = 0; index < FileNum; index++)
            {
                inFilePath.Add(dlg.FileNames[index]);
            }
            return inFilePath;
        }

        /// <summary>
        /// Adds the label to layer.
        /// �������ӱ�ע
        /// </summary>
        /// <param name="pLayer">The p layer.��Ҫ�ӱ�ע�Ĳ�</param>
        /// <param name="strField">The STR field. ��ע�ֶΣ���û�У������עID�ֶ�</param>
        /// <param name="textsize">The textsize.�����С</param>
        /// <param name="textcolor">The textcolor.������ɫ</param>
        /// <param name="strFontType">Type of the STR font.����</param>
        public void AddLabelToLayer(IFeatureLayer pLayer, string strField, int textsize, IColor textcolor,string strFontType)
        {
            this.Cursor = Cursors.WaitCursor;

            try
            {
                //Set the TextSymbol
                ITextSymbol m_textSymbol = new TextSymbolClass();// (ITextSymbol)styleGalleryItem.Item;
                m_textSymbol.Color = textcolor;
                m_textSymbol.Size = textsize;

                stdole.IFontDisp stdFontCls = ((stdole.IFontDisp)(new stdole.StdFont()));
                stdFontCls.Bold = true;
                stdFontCls.Name = strFontType;
                stdFontCls.Size = textsize;
                m_textSymbol.Font = stdFontCls;

                ILabelEngineLayerProperties EngProp;
                IAnnotateLayerProperties AnnProp;
                IAnnotateLayerPropertiesCollection AnnPropCollection;
                IGeoFeatureLayer lyr = pLayer as IGeoFeatureLayer;
                AnnPropCollection = lyr.AnnotationProperties;
                IElementCollection element;
                AnnPropCollection.QueryItem(0, out AnnProp, out element, out element);
                EngProp = AnnProp as ILabelEngineLayerProperties;

                EngProp.IsExpressionSimple = true;
                string strLabelFld = "";
                ITable table = pLayer.FeatureClass as ITable;
                int count = table.Fields.FieldCount;
                for (int i = 0; i < count; i++)
                {
                    string fldName = table.Fields.get_Field(i).Name;
                    if (fldName.ToUpper().Contains(strField.ToUpper()))
                    {
                        strLabelFld = fldName;
                        break;
                    }
                }
                if (strLabelFld == "") strLabelFld = table.OIDFieldName;

                EngProp.Expression = "[" + strLabelFld + "]";
                EngProp.Symbol = m_textSymbol;

                lyr.DisplayAnnotation = true;

            }
            catch (Exception ex)
            {
                MessageBox.Show("��ע����\r\n" + ex.Message);
            }
            // Back to normal  
            this.Cursor = Cursors.Default;
        }
        
        /// <summary>
        /// Updates the pre deined layer.
        /// ͨ�������еĹؼ���������ϵͳ��ʶ��Ĳ㣬
        /// ��POI��ӦPOI�㣬ROAD��Ӧ��·�㣬�����ִ�Сд
        /// </summary>
        /// <param name="pLayer">The p layer.��ǰ���صĲ�</param>
        public void UpdatePreDeinedLayer(IFeatureLayer pLayer)
        {
            string strLyrName = pLayer.Name.ToUpper();
            for (int index = 0; index < m_EditLayerNum; index++)
            {
                if (strLyrName.Contains(m_strEditLayerNameList[index]))//&& m_EditLayerList[index] == null
                {
                    m_EditLayerList[index] = pLayer;

                    
                    #region �½�POI
                    if (index == 0) ////�������POI ������ ������Ҫ�½�һ����ʱ���ݲ�
                    {
                        //�ӱ�ע
                        IColor color = new RgbColorClass();
                        //color.B * 65536 + color.G * 256 + color.R;
                        color.RGB = 0;// 5 * 65536 + 5 * 256 + 60 * 255; 
                        AddLabelToLayer(pLayer, "NAME", 8, color,"Arial");
                        break;

                        //�½� POI�� 
                        System.DateTime curT = System.DateTime.Now;
                        string str = string.Format("_{0}_{1}_{2}_{3}_{4}", curT.Year, curT.Month, curT.Day, curT.Hour, curT.Minute);
                        Geometry_IO.Geometry_Attribute attr = new Geometry_IO.Geometry_Attribute();
                        string strpath = System.IO.Path.GetDirectoryName(GetPathByLayerName(pLayer.Name)) + "\\" + m_strEditLayerNameList[1] + str + ".yvt";
                        string TableName = Geometry_IO.Geometry_Attribute.m_strConstTableName;// System.IO.Path.GetFileNameWithoutExtension(strpath);//"MytestShp"

                        attr.CreateTableInMDB(strpath, TableName, pLayer as ILayer);
                        List<string> m_FileList = new List<string>();
                        m_FileList.Add(strpath);
                        OpenYVTvectorData(m_FileList, ref m_CurLayerList);
                    }
                    else if (index == 2)  //path label
                    {
                        IColor color = new RgbColorClass();
                        color.RGB = 10 * 65536 +10*256+100;
                        AddLabelToLayer(pLayer, "NAME", 12, color, "Arial");
                    }
                    else if(index == 3) 
                        SimpleBuildingsRender(m_EditLayerList[index]); //buildings symbol setting

                    #endregion
                    break;
                }
                else if (strLyrName.Contains("GPS·��"))//&& m_GPSPathLayer == null
                {
                    m_GPSPathLayer = pLayer;
                    SimpleGPSPathRender(m_GPSPathLayer);
                }
                else if (strLyrName.Contains("GPS��ʶ��"))//&& m_GPSMarkerLayer == null
                {
                    m_GPSMarkerLayer = pLayer;
                    GPSMarkerPointRender(m_GPSMarkerLayer);
                }
            }
            //    if (strLyrName.Contains(m_strPOIFileName) && (m_POILayer == null || m_POILayer.FeatureClass == null))
            //    { m_POILayer = pLayer; }

            //if (strLyrName.Contains(m_strAdressFileName) && m_AddressLayer == null)
            //{ m_AddressLayer = pLayer; }

            //if (strLyrName.Contains(m_strPathFileName) && m_PathLayer == null)
            //{ m_PathLayer = pLayer; }

        }

        /// <summary>
        /// Opens the YV tvector data.
        /// ����ͼ��ʽ���� �ĺ��ĺ���
        /// </summary>
        /// <param name="m_FileList">The m_ file list.��Ҫ���ص��ļ��б� </param>
        /// <param name="LayerList">The layer list.��Ҫ���µ��ļ���Ϣ�б�</param>
        public void OpenYVTvectorData(List<string> m_FileList, ref List<MyLayerInfo> LayerList)
        {
            int FileNum = m_FileList.Count;//dlg.FileNames.GetUpperBound(0) + 1;
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor;

            for (int index = 0; index < FileNum; index++)
            {
                string fname = m_FileList[index]; //dlg.FileNames[index];
                if (fname != null)
                {
                    Geometry_IO.Geometry_Attribute cls = new Geometry_IO.Geometry_Attribute();
                    string mdbPath, TableName;
                    mdbPath = fname;// "MyTestMDB.yvt";
                    TableName = System.IO.Path.GetFileNameWithoutExtension(fname);
                    //TableName = "MytestShp";
                    //object obj = m_MemWorkspace as object;
                    IFeatureLayer pLayer = cls.LoadDataFromMDB2SHP(mdbPath, Geometry_IO.Geometry_Attribute.m_strConstTableName, TableName + ".yvt", ref m_MemWorkspace, null);
                    //m_MemWorkspace =obj as IFeatureWorkspace;

                    if (pLayer == null) continue;
                    int curIndex = this.axMapControl1.LayerCount;
                    IMapControl2 mapControl = this.axMapControl1.Object as IMapControl2;
                    switch (pLayer.FeatureClass.ShapeType)
                    {
                        case esriGeometryType.esriGeometryPoint:
                            curIndex = 0;
                            break;
                        case esriGeometryType.esriGeometryPolyline:
                            for (int i = 0; i < mapControl.LayerCount; i++)
                            {
                                IFeatureLayer lyr = mapControl.get_Layer(i) as IFeatureLayer;
                                if (lyr == null)
                                { curIndex = i; break; }
                                if (lyr != null && ((int)(lyr.FeatureClass.ShapeType)) > 2)
                                { curIndex = i; break; }
                            }
                            break;
                        case esriGeometryType.esriGeometryPolygon:
                            for (int i = 0; i < mapControl.LayerCount; i++)
                            {
                                IFeatureLayer lyr = mapControl.get_Layer(i) as IFeatureLayer;
                                if (lyr == null)
                                { curIndex = i; break; }
                                else if (lyr != null &&
                                    (lyr.FeatureClass.ShapeType == esriGeometryType.esriGeometryPolygon)
                                    || (lyr.FeatureClass.ShapeType == esriGeometryType.esriGeometryEnvelope))
                                { curIndex = i; break; }
                            }
                            break;
                        default:
                            curIndex = mapControl.LayerCount;
                            break;
                    }
                    mapControl.AddLayer(pLayer, curIndex);

                    //store layer info
                    // if (!pLayer.Name.Contains(m_strEditLayerNameList[1]))  //��� ��ʱ�½��㣬�򲻽��ļ�ϵͳ
                    {
                        MyLayerInfo lyrInfo = new MyLayerInfo();
                        lyrInfo.FilePath = fname;
                        lyrInfo.LayerName = mapControl.get_Layer(curIndex).Name;
                        lyrInfo.m_bVisible = true;
                        lyrInfo.LayerIndex = curIndex;
                        lyrInfo.type = 3;  //yutu file
                        LayerList.Add(lyrInfo);
                    }

                    UpdatePreDeinedLayer(pLayer);
                    //this.axMapControl1.ActiveView.FocusMap.AddLayer(lyr);
                }
            }
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default;
        }


#region ϣ��ʵ�ּ�������ʱ�Ĺ�����,δʵ��
        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
            //WaitCallback waitCallback = new WaitCallback(Progress_OPEN);
            //ThreadPool.QueueUserWorkItem(waitCallback);
            //ShowProgress("");
            //OpenMapCore(m_strProjectFilePath);
            List<string> m_FileList =e.Argument as List<string>;
            Geometry_IO.Geometry_Attribute cls = new Geometry_IO.Geometry_Attribute();
            int FileNum = m_FileList.Count;//dlg.FileNames.GetUpperBound(0) + 1;
            List<IFeatureLayer> LayerList = new List<IFeatureLayer>();

            for (int index = 0; index < FileNum; index++)
            {
                string fname = m_FileList[index]; //dlg.FileNames[index];
                if (fname != null)
                {
                    string mdbPath, TableName;
                    mdbPath = fname;// "MyTestMDB.yvt";
                    TableName = System.IO.Path.GetFileNameWithoutExtension(fname);
                    IFeatureLayer pLayer = cls.LoadDataFromMDB2SHP(mdbPath, Geometry_IO.Geometry_Attribute.m_strConstTableName, TableName + ".yvt", ref m_MemWorkspace, null);
                    LayerList.Add(pLayer);
                }
            }
            e.Result = LayerList;

        }
        private void backgroundWorker1_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            // this.progressBar1.Visible = false;
            // this.pictureBox1.Visible = false;
            List<IFeatureLayer> LayerList = e.Result as List<IFeatureLayer>;
            if (LayerList == null)
            {
                this.pictureBox1.Visible = false;
                return;
            }
            int FileNum = LayerList.Count;
            for (int index = 0; index < FileNum; index++)
            {
                IFeatureLayer pLayer = LayerList[index];

                //ProcessAfterReadData(pLayer);
            }
            this.pictureBox1.Visible = false;
        }
#endregion
        #region unused code
        /*
        public void OpenYVTvectorData(List<string> m_FileList, ref List<MyLayerInfo> LayerList)
        {
           System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor;
            
            try
                    {
                        this.pictureBox1.Image = Image.FromFile(System.Windows.Forms.Application.StartupPath + "\\WaitingAnimate.gif");
                    }
                    catch { }
                    this.pictureBox1.Visible = true;
  
                    this.backgroundWorker1.RunWorkerAsync(m_FileList);
                    //IFeatureLayer pLayer = cls.LoadDataFromMDB2SHP(mdbPath, Geometry_IO.Geometry_Attribute.m_strConstTableName, TableName + ".yvt", ref m_MemWorkspace, null);
                    //ProcessAfterReadData(IFeatureLayer pLayer);


                    //m_MemWorkspace =obj as IFeatureWorkspace;
                    //this.axMapControl1.ActiveView.FocusMap.AddLayer(lyr);
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default;
        }

        public void ProcessAfterReadData(IFeatureLayer pLayer, string fname, ref List<MyLayerInfo> LayerList)
        {
            if (pLayer == null) return;
            int curIndex = this.axMapControl1.LayerCount;
            IMapControl2 mapControl = this.axMapControl1.Object as IMapControl2;
            switch (pLayer.FeatureClass.ShapeType)
            {
                case esriGeometryType.esriGeometryPoint:
                    curIndex = 0;
                    break;
                case esriGeometryType.esriGeometryPolyline:
                    for (int i = 0; i < mapControl.LayerCount; i++)
                    {
                        IFeatureLayer lyr = mapControl.get_Layer(i) as IFeatureLayer;
                        if (lyr == null)
                        { curIndex = i; break; }
                        if (lyr != null && ((int)(lyr.FeatureClass.ShapeType)) > 2)
                        { curIndex = i; break; }
                    }
                    break;
                case esriGeometryType.esriGeometryPolygon:
                    for (int i = 0; i < mapControl.LayerCount; i++)
                    {
                        IFeatureLayer lyr = mapControl.get_Layer(i) as IFeatureLayer;
                        if (lyr == null)
                        { curIndex = i; break; }
                        else if (lyr != null &&
                            (lyr.FeatureClass.ShapeType == esriGeometryType.esriGeometryPolygon)
                            || (lyr.FeatureClass.ShapeType == esriGeometryType.esriGeometryEnvelope))
                        { curIndex = i; break; }
                    }
                    break;
                default:
                    curIndex = mapControl.LayerCount;
                    break;
            }
            mapControl.AddLayer(pLayer, curIndex);

            //store layer info
            // if (!pLayer.Name.Contains(m_strEditLayerNameList[1]))  //��� ��ʱ�½��㣬�򲻽��ļ�ϵͳ
            //{
            //    MyLayerInfo lyrInfo = new MyLayerInfo();
            //    lyrInfo.FilePath = fname;
            //    lyrInfo.LayerName = mapControl.get_Layer(curIndex).Name;
            //    lyrInfo.m_bVisible = true;
            //    lyrInfo.LayerIndex = curIndex;
            //    lyrInfo.type = 3;  //yutu file
            //    LayerList.Add(lyrInfo);
            //}

            UpdatePreDeinedLayer(pLayer);
        }
*/
        //private void Progress_OPEN(object state)
        //{
        //    // this.progressBar1.Visible = true;
        //}
        //delegate void ShowProgressCallback(string text);
        //private void ShowProgress(string message)
        //{
        //    if (this.pictureBox1.InvokeRequired == true)
        //    {
        //        ShowProgressCallback callback = new ShowProgressCallback(ShowProgress);
        //        this.pictureBox1.Invoke(callback, message);
        //    }
        //    else
        //    {
        //        this.pictureBox1.Image = Image.FromFile(@"F:\YuTuSurveyPlatform\YuTuSurveyPlatform\Resources\LoadData.gif");
        //        this.pictureBox1.Visible = true;
        //    }
        //}
        #endregion
    }
}