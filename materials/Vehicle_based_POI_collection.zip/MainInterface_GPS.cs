//�ļ�����Ȩ��Ϣ------------------
/*
 * ���ļ������п���ͼ���¿Ƽ����޹�˾����ҵ����ƽ̨����ɲ���
 * δ���������ÿ���������������������ҵ��;
 * ��Ȩ���У��п���ͼ���¿Ƽ����޹�˾(http://www.mapuni.com/) 
 * �������ߣ�������   chqzeng@163.com 
 * ��дʱ�䣺2010-09-01
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using GPSManager;

using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.InteropServices;

using ESRI.ArcGIS.esriSystem;
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.Geodatabase;
using ESRI.ArcGIS.Geometry;
using ESRI.ArcGIS.DataSourcesGDB;
using ESRI.ArcGIS.DataSourcesFile;
using ESRI.ArcGIS.Display;
using ESRI.ArcGIS.Controls;

namespace YuTuSurveyPlatform
{

    /// <summary>
    /// �ṹ�壬���ڴ洢GPS��Ϣ�� ����ΪGPS�ṹ��Ϣʾ����
    /// //GPS INFO HEAD
    ///Unit ID: The ID of the unit. 
    ///DateTime: YYYYMMDDhhmmss (GMT Date and Time) 
    ///Longitude: WGS-84 Longitude/Latitude coordinate system 
    ///Latitude: WGS-84 Longitude/Latitude coordinate system 
    ///Speed: 0~65535 km/h 
    ///Heading: 0~360 degrees 
    ///Altitude: Always 0 
    ///Satellite: 0~12 
    ///Report ID:xxx (Please refer to appendix for detailed description) 
    /// </summary>
    public struct GPSDataInfo
    {
        public string UnitID ;
        public System.DateTime m_DateTime;
        public double Longitude ;
        public double Latitude ;
        public int Speed;
        public double Heading;
        public double Altitude;
        public int Satellite;
        public int ReportID;
        public int Inputs;
        public int Outputs;
    }

    /// <summary>
    /// ���ļ���Ҫ������GPS��ز������û������Ĺ����������򿪡��رա�����GPS�ļ����Լ����������� GPSʱ��Ȳ�����
    /// ������������غ�����һ����
    /// </summary>
    /// 

    public partial class MainInterface : Form
    {
        /// <summary>
        /// GPS ��صı�������
        /// </summary>
        //GPS���� ��
        GPSManagerCore GPSMng = null;
        //GPS���� �Ի���
        GPS_SettingDlg GPSsetDlg = new GPS_SettingDlg();
        //����ʱ����
        public System.Timers.Timer m_SaveGPSTimer = null;
        //ģ���ź�ʱ��
        public System.Timers.Timer m_SingalSimulateGPSTimer = null;

        //GPS���Ա��ֶγ���
        public const string m_strFeildGPSTime = "GET_TIME";
        public const string m_strFeildGPSIMGname= "IMAGE_NAME";

        //�Ƿ�Ϊ����GPS��ֱ��ģ�����Ϣ
        public bool m_bIsSimulateSingal = false; 
        // true  false �Ƿ�Ϊ��GPS����GPSԭ�ز�����ģ���ź�
        bool bIsSimulation = true; //false 
        // ģ���������
        int increasement = 0;
        //GPS ·�ߴ���500�Ĳ��ʱ��Ͽ�
        private const int DistTolarence = 500; 
        //����İ뾶����
        private const double EARTH_RADIUS = 6378.137;
        //��¼��ǰ�ľ�γ��
        public double curLat=0;
        public double curLong=0;

        /// <summary>
        /// Defs the WND proc. 
        /// ������Ϣ��׽����ʵ��Ϊ�˲���GPS����������Ϣ��
        /// ������ϢĬ�ϴ���
        /// </summary>
        /// <param name="m">The m ��Ϣ�ṹ��.</param>
        protected override void DefWndProc(ref System.Windows.Forms.Message m)
        {
            switch (m.Msg)
            {
                case GPSManagerCore.WM_MsgGPSsignal:
                    try
                    {
                        GPSManager.SENDDATASTRUCT myData = new GPSManager.SENDDATASTRUCT();
                        Type mytype = myData.GetType();
                        myData = (GPSManager.SENDDATASTRUCT)m.GetLParam(mytype);

                        GPSDataInfo info = new GPSDataInfo();
                        if (FetchInfoFromGPS(myData.lpData, ref info))
                        {
                            if (bIsSimulation)
                            {
                                info.Longitude -= 0.0001 * increasement;
                                info.Latitude += 0.0001 * increasement;
                                increasement++;
                            }
                            UpdateMapWithGPS(info);
                        }

                        //if (GPSMng != null && GPSMng.m_SerialPort.IsOpen == false)  //�˿�״̬����
                        //{
                        //}
                    }
                    catch(Exception ex)
                    {
                        MessageBox.Show("GPS���ݴ������ִ���!\r\n" + ex.Message);
                    }
                    //MessageBox.Show(str);
                    break;
                default:
                    base.DefWndProc(ref m);
                    break;

            }
        }

        /// <summary>
        /// Fetches the info from GPS.
        /// �Ӵ��ص�GPS�ź��У����GPS����
        /// </summary>
        /// <param name="myData">My data.�����GPS��Ϣ����</param>
        /// <param name="info">The info.���ص�GPS�ṹ����Ϣ</param>
        /// <returns></returns>
        public  bool FetchInfoFromGPS(string myData,ref GPSDataInfo info)
        {
            if (myData.Length < 50) return false;
            string[] subList = myData.Split(new Char[] { ',', ' '});
            int count=subList.GetUpperBound(0);
            if (count < 10) return false;

            //GPSDataInfo info = new GPSDataInfo();
            List<string> ValueList=new List<string>();
            for(int i=0;i<count;i++)
            {
                if(subList[i]!="")ValueList.Add(subList[i]);
            }

            int index= 0;
            try
            {
                info.UnitID = ValueList[index++].Trim();

                //set time
                //info.m_DateTime = Convert.ToDateTime(ValueList[index++]);
                string strTime = ValueList[index++];
                 info.m_DateTime = new DateTime(Convert.ToInt32(strTime.Substring(0, 4)),
                    Convert.ToInt32(strTime.Substring(4, 2)),
                    Convert.ToInt32(strTime.Substring(6, 2)),
                    Convert.ToInt32(strTime.Substring(8, 2))+8, //������ ����8
                    Convert.ToInt32(strTime.Substring(10, 2)),
                    Convert.ToInt32(strTime.Substring(12, 2)));
                info.Longitude= Convert.ToDouble(ValueList[index++]);
                info.Latitude = Convert.ToDouble(ValueList[index++]);
                info.Speed = Convert.ToInt32(ValueList[index++]);
            }
            catch
            {
                return false;
            }

            return true;
        }

        /// <summary>
        /// Updates the map with GPS.
        /// ʹ��GPS��Ӧ�����������µ�ͼ
        /// </summary>
        /// <param name="info">The info.�����GPS�ṹ����Ϣ</param>
        public void UpdateMapWithGPS(GPSDataInfo info)
        {
            //this.axMapControl1.
            if (m_GPSPathLayer == null) return;
            IPointCollection pointCollection = new PathClass();
            IPoint pt_old = new PointClass();
            pt_old.PutCoords(curLong, curLat);

            //����GPS��
            AddNewGPSpoint(m_GPSPathLayer,ref m_GPSCurOID,info.Longitude,info.Latitude,ref m_bIsNewGpsPath);
            
            //�жϵ�ǰ���Ƿ�����Ļ����
            IPoint pt = new PointClass();
            pt.PutCoords(info.Longitude, info.Latitude);
            
            pointCollection.AddPoint(pt_old, ref _missing, ref _missing);
            pointCollection.AddPoint(pt, ref _missing, ref _missing);


            if (BTN_GPS_NAVG.Checked && this.axMapControl1.SpatialReference.Name == "GCS_WGS_1984" &&
                IsPointOutBox(info.Longitude, info.Latitude, this.axMapControl1.Extent, 0.1)) this.axMapControl1.CenterAt(pt);
            
            
            //refresh
           
            //IGeometryCollection geo = new PolylineClass();
            //geo.AddGeometry(pointCollection as IGeometry, ref _missing, ref _missing);
            this.axMapControl1.ActiveView.PartialRefresh(esriViewDrawPhase.esriViewGeography, m_GPSPathLayer as object, (pointCollection as IGeometry).Envelope);
        }
        
        /// <summary>
        /// ��� ���壬ARCGIS ������
        /// </summary>
        public static object _missing = Type.Missing;

        /// <summary>
        /// Determines whether [is point out box] [the specified x].
        /// �жϵ��Ƿ��ھ�����
        /// </summary>
        /// <param name="x">The x.����</param>
        /// <param name="y">The y.����</param>
        /// <param name="curExt">The cur ext.���η�Χ</param>
        /// <param name="scale">The scale.������С����0.1��ʾ�����ε����ĵ㲻����������0.1</param>
        /// <returns>
        /// 	<c>true</c> if [is point out box] [the specified x]; otherwise, <c>false</c>.
        /// </returns>
        public bool IsPointOutBox(double x,double y,IEnvelope curExt, double scale)
        {
            double W = curExt.Width * scale;
            double H = curExt.Height * scale;
            IPoint pt=new PointClass();
            pt.X = (curExt.XMax + curExt.XMin) / 2;
            pt.Y = (curExt.YMax + curExt.YMin) / 2;
            //curExt.CenterAt(pt);

            if (Math.Abs(x - pt.X) > W || Math.Abs(y - pt.Y) > H) return true;

            return false;
        }

        /// <summary>
        /// Adds the new GPS point.
        /// ����GPS�㵽GPS�켣�У�������Ƿ���Ҫ����
        /// </summary>
        /// <param name="pLayer">The p layer.����Ĳ㣬��GPS���ݲ�</param>
        /// <param name="OIDrecord">The OI drecord.��ӦGPS���еļ�¼ID��</param>
        /// <param name="x">The x. �����X����</param>
        /// <param name="y">The y.�����Y����</param>
        /// <param name="IsNewRcd">if set to <c>true</c> [is new RCD].</param>
        public void AddNewGPSpoint(IFeatureLayer pLayer,ref int OIDrecord, double x, double y, ref bool IsNewRcd)
        {
            IEngineEditor editor = new EngineEditorClass();
            IFeatureLayer pCurEditLayer = null;
            IMap pCurEditMap=null;
            if(editor.EditState==esriEngineEditState.esriEngineStateEditing)
            {
                pCurEditLayer = (editor as IEngineEditLayers).TargetLayer;
                pCurEditMap = editor.Map;
            }   

            IDataset pdataset = (IDataset)pLayer; //�������Ա�
            IWorkspaceEdit pworkspaceedit = (IWorkspaceEdit)(pdataset.Workspace);
            //��ʼ�༭
            //if (!pworkspaceedit.IsBeingEdited())
            //{
            //   pworkspaceedit.StartEditing(true);
            //}
            //pworkspaceedit.StartEditOperation();

            IPoint pt = new PointClass();
            pt.PutCoords(x, y);

            //����µ�GPS��ľ���С��10���ݴ�������Ϊ��Ȼ��������GPS·��
            if (IsNewRcd && GetDistance(curLat, curLong, y, x) < DistTolarence)
            {
                try
                {
                    IQueryFilter queryFilter = new QueryFilterClass();
                    //queryFilter.SubFields = "SHAPE";
                    queryFilter.WhereClause = Geometry_IO.Geometry_Attribute.m_strConstShapeID + "= " + OIDrecord.ToString();
                    IFeatureCursor featureCursor = pLayer.FeatureClass.Update(queryFilter, false);
                    IFeature Infeature = featureCursor.NextFeature();
                    int fieldIndex = pLayer.FeatureClass.FindField(Geometry_IO.Geometry_Attribute.m_strConstFieldChange);
                    Infeature.set_Value(fieldIndex, 3);
                    featureCursor.UpdateFeature(Infeature);

                    IsNewRcd = false;
                }
                catch(Exception ex) { }
            }

            try
            {
                if (IsNewRcd)  //�µ�GPS·��
                {
                    //IFeatureClass featureClass = pLayer.FeatureClass;
                    //IFeature feature = featureClass.CreateFeature();
                    

                    // Create a feature buffer.
                    IFeatureClass featureClass = pLayer.FeatureClass;
                    IFeatureBuffer featureBuffer = featureClass.CreateFeatureBuffer();
                    IFeatureCursor featureCursor = featureClass.Insert(true);

                    IPointCollection pointCollection = new PathClass();
                    pointCollection.AddPoint(pt, ref _missing, ref _missing);
                    pointCollection.AddPoint(pt, ref _missing, ref _missing);
                    IGeometryCollection geo = new PolylineClass();
                    geo.AddGeometry(pointCollection as IGeometry, ref _missing, ref _missing);
                    IGeometry g = geo as IGeometry;
                    
                    featureBuffer.Shape =g;// geo as IGeometry;

                    //����Ϊ ������
                    int fieldIndex = featureClass.FindField(Geometry_IO.Geometry_Attribute.m_strConstFieldChange);
                    featureBuffer.set_Value(fieldIndex, 3); 
                    //��ȡʱ��
                    fieldIndex = featureClass.FindField(m_strFeildGPSTime);
                    System.DateTime curT = System.DateTime.Now;
                    string str=string.Format("'{0}-{1}-{2}' ,",curT.Year,curT.Month,curT.Day);
                    //esriFieldType curTime;
                    featureBuffer.set_Value(fieldIndex, DateTime.Now); 

                    OIDrecord = Convert.ToInt32(featureCursor.InsertFeature(featureBuffer));
                    featureCursor.Flush();


                    //GPS Marker
                    
                    if (dlgVideoL.m_bTimeMode)
                    {
                        curLong = x;
                        curLat = y;
                    }
                    else
                        saveGPSImageByDist(x, y);


                    IsNewRcd = false;
                }
                else  //���� ������GPS·����
                {
                    IQueryFilter queryFilter = new QueryFilterClass();
                    queryFilter.SubFields = "SHAPE";
                    queryFilter.WhereClause = Geometry_IO.Geometry_Attribute.m_strConstShapeID + "= " + OIDrecord.ToString();
                    IFeatureCursor featureCursor = pLayer.FeatureClass.Update(queryFilter, false);
                    IFeature Infeature = featureCursor.NextFeature();
                    if (Infeature != null)
                    {
                        IGeometryCollection polyline = Infeature.Shape as IGeometryCollection;
                        IPointCollection line = polyline.get_Geometry(0) as IPointCollection;
                        line.AddPoint(pt, ref _missing, ref _missing);
                        Infeature.Shape = polyline as IGeometry;
                        featureCursor.UpdateFeature(Infeature);
                    }
                    else 
                        IsNewRcd = true;

                    //move GPS marker
                    //queryFilter.WhereClause = Geometry_IO.Geometry_Attribute.m_strConstShapeID + "= 0" ;
                    //featureCursor = m_GPSMarkerLayer.FeatureClass.Update(queryFilter, false);
                    //Infeature = featureCursor.NextFeature();
                    //if (Infeature != null)
                    //{
                    //    Infeature.Shape = pt as IGeometry;
                    //    featureCursor.UpdateFeature(Infeature);
                    //}

                    //GPS Marker
                    //featureClass = m_GPSMarkerLayer.FeatureClass;
                    //featureBuffer = featureClass.CreateFeatureBuffer();
                    //featureCursor = featureClass.Insert(true);
                    //featureBuffer.Shape = pt;
                    //featureCursor.InsertFeature(featureBuffer);
                    //featureCursor.Flush();
                    if (dlgVideoL.m_bTimeMode)
                    {
                        curLong = x;
                        curLat = y;
                    }
                    else
                        saveGPSImageByDist(x, y);
                }

            }
            catch (Exception ex){ }

            //ֹͣ�༭
            //pworkspaceedit.StopEditOperation();
            //pworkspaceedit.StopEditing(true);
            return;

            if (pCurEditLayer != null)
            {
                (editor as IEngineEditLayers).SetTargetLayer(pLayer, 0);
                (editor as IEngineEditLayers).SetTargetLayer(pCurEditLayer, 0);
            }
            else  //not edit mode
            {
                pworkspaceedit.StartEditOperation();
                pworkspaceedit.StopEditing(true);
                //IWorkspace pWS = (pLayer.FeatureClass as IDataset).Workspace;
                //editor.StartEditing(pWS, pCurEditMap);
                
            }
        }

        /// <summary>
        /// Saves the GPS image by dist.
        /// ͨ���������洢GPS�� ģʽ
        /// </summary>
        /// <param name="newLong">The new long.����</param>
        /// <param name="newLat">The new lat.γ��</param>
        public void saveGPSImageByDist(double newLong, double newLat)
        {
            if (dlgVideoL.m_bTimeMode || !dlgVideoL.m_bIsImageGrabStat)
            {
                curLat = newLat;
                curLong = newLong;
                return;
            }

            try
            {
                double Dist = Convert.ToDouble(dlgVideoL.m_strLDiskDist);
                if (GetDistance(curLat, curLong, newLat, newLong) < Dist) return;

                //save GPS point to layer
                SaveImageFramebyTime(newLong, newLat);
            }
            catch { return; }
            curLat = newLat;
            curLong = newLong;
            
        }

        /// <summary>
        /// Saves the image frameby time.
        /// ͨ��ʱ�����洢GPS�� ģʽ
        /// </summary>
        /// <param name="newLong">The new long.����</param>
        /// <param name="newLat">The new lat.γ��</param>
        public void SaveImageFramebyTime(double newLong, double newLat)
        {
            //save GPS point to layer
            IPoint pt = new PointClass();
            pt.PutCoords(newLong, newLat);
            string ImgName = GetImageNameFromGPSLoc(newLat, newLong);
            IFeatureClass featureClass = m_GPSMarkerLayer.FeatureClass;
            IFeatureBuffer featureBuffer = featureClass.CreateFeatureBuffer();
            IFeatureCursor featureCursor = featureClass.Insert(true);
            featureBuffer.Shape = pt;

            //��Ӧ��ͼƬ�ļ���
            int FldIndex = featureClass.FindField(Geometry_IO.Geometry_Attribute.m_strConstFieldChange);
            featureBuffer.set_Value(FldIndex, 3);
            FldIndex = featureClass.FindField(m_strFeildGPSIMGname);
            featureBuffer.set_Value(FldIndex, ImgName);


            featureCursor.InsertFeature(featureBuffer);
            featureCursor.Flush();

            //save the picture;
            string strDir = dlgVideoL.m_strSavePath;
            if (strDir == "") strDir = "c:\\photo_";
            //if (strDir.LastIndexOf("\\") != strDir.Length - 1) strDir = System.IO.Path.GetDirectoryName(strDir);
            string strImagePath = strDir + "\\" + "L_"+ImgName + ".jpg";
            if (dlgVideoL.IsDeviceValid())
            {
                dlgVideoL.SaveCurrentWindowEx(strImagePath);
                //ConvertFromBMP2JPG(strImagePath, strImagePath.Replace(".bmp",".jpg"));
            }
            strImagePath = strDir + "\\" + "R_"+ImgName + ".jpg";
            if (dlgVideoR.IsDeviceValid())
            {
                dlgVideoR.SaveCurrentWindowEx(strImagePath);
            }
        }


        /// <summary>
        /// Gets the image name from GPS loc.
        /// ͨ��GPS��������Լ�ʱ�� ���ɶ�Ӧ��Ƭ������
        /// </summary>
        /// <param name="newLat">The new lat.����</param>
        /// <param name="newLong">The new long.γ��</param>
        /// <returns>�������ɵ���Ƭ����</returns>
        public static string GetImageNameFromGPSLoc(double newLat, double newLong)
        {
            System.DateTime curT = System.DateTime.Now;
            string str = string.Format("{0}_{1}_{2}_{3}_{4}", curT.Year, curT.Month, curT.Day, curT.Hour, curT.Minute);


            string strOut = str + "_" + newLat.ToString() + "_" + newLong.ToString();
            return strOut.Replace(".", "_");
        }

       
        /// <summary>
        /// Initializes the GPS path layer.
        /// ��ʼ��GPS ·����
        /// ���������û�в��ļ������½��������˿����ӣ�����ʼ��ʱ���Ͷ˿��źš�
        /// </summary>
        public void InitializeGPSPathLayer()
        {
            string strDirectory = "";
            IFeatureLayer pLayer = m_EditLayerList[0];
            IFeatureWorkspace pWs = null;
            if (pLayer != null)
            {
                strDirectory = System.IO.Path.GetDirectoryName(GetPathByLayerName(pLayer.Name));
                pWs = (pLayer.FeatureClass as IDataset).Workspace as IFeatureWorkspace;
            }
            else
            {
                strDirectory = "C:\\temp";
                if (!System.IO.Directory.Exists(strDirectory)) System.IO.Directory.CreateDirectory(strDirectory);
                IWorkspaceFactory pWorkspaceFactory = new ShapefileWorkspaceFactoryClass();
                pWs = pWorkspaceFactory.OpenFromFile(strDirectory, 0) as IFeatureWorkspace;
            }

            try
            {
                //CreateGPSPathLayer(pWs);
                //////////////////////////////////////////����GPS ��������� ��ʶ���////////////////////////////////////////

                //CreateGPSMarkerLayer(pWs);

                if(m_GPSPathLayer==null)CreateGPSPathLayer(strDirectory,pWs, "GPS·��", esriGeometryType.esriGeometryPolyline, m_strFeildGPSTime);
                if (m_GPSMarkerLayer == null) CreateGPSPathLayer(strDirectory, pWs, "GPS��ʶ��", esriGeometryType.esriGeometryPoint, m_strFeildGPSIMGname);
            }
            catch (Exception ex)
            {
                MessageBox.Show("����GPS���ݲ���ִ���\r\n" + ex.Message);
            }
            
        }


        /// <summary>
        /// Creates the GPS path layer.
        /// ����GPS·����
        /// </summary>
        /// <param name="strDirectory">The STR directory.
        /// ����Ŀ¼�����д��ļ�����Ϊ��ǰ�����ļ��У���û����Ĭ�Ϸ���C��\_tempĿ¼��</param>
        /// <param name="pWs">The p ws. �����ռ�</param>
        /// <param name="sLayerName">Name of the s layer.����</param>
        /// <param name="SHPtype">The SHP type.�ļ�����</param>
        /// <param name="strExtraFieldName">Name of the STR extra field. �½������ֶ�</param>
        public void CreateGPSPathLayer(string strDirectory,IFeatureWorkspace pWs, string sLayerName, esriGeometryType SHPtype, string strExtraFieldName) // esriGeometryPolyline,"GPS·��",m_strFeildGPSTime
        {
            //�����ֶμ�
            IFields pFields = new FieldsClass();
            IFieldsEdit pFieldsEdit = (IFieldsEdit)pFields;

            //OID field
            IField oidField = new FieldClass();
            IFieldEdit oidFieldEdit = (IFieldEdit)oidField;
            oidFieldEdit.Name_2 = Geometry_IO.Geometry_Attribute.m_strConstShapeID;//m_strConstOIDName
            oidFieldEdit.Type_2 = esriFieldType.esriFieldTypeOID;
            pFieldsEdit.AddField(oidField);


            IGeometryDef pGeoDef = new GeometryDefClass();     //The geometry definition for the field if IsGeometry is TRUE.
            IGeometryDefEdit pGeoDefEdit = (IGeometryDefEdit)pGeoDef;
            pGeoDefEdit.GeometryType_2 = SHPtype;// esriGeometryType.esriGeometryPolyline;
            ISpatialReferenceFactory3 pspatialRefFac = new SpatialReferenceEnvironmentClass();
            ISpatialReference pspatialRef = pspatialRefFac.CreateGeographicCoordinateSystem((int)esriSRGeoCSType.esriSRGeoCS_WGS1984);//�����ΪWGS84�Ŀռ��������ϵ
            pspatialRef.SetDomain(-180, 180, -90, 90);//����һ��Ҫ����ֵ�����ã�
            pGeoDefEdit.SpatialReference_2 = pspatialRef;

            
            //��������Ϊ�������͵��ֶ�0
            //�����ֶ�SHAPE
            IField pField = new FieldClass();
            IFieldEdit pFieldEdit = (IFieldEdit)pField;
            pFieldEdit.Name_2 = Geometry_IO.Geometry_Attribute.m_strShapeFieldName;
            pFieldEdit.Type_2 = esriFieldType.esriFieldTypeGeometry;//esriFieldTypeGeometry;
            pFieldEdit.GeometryDef_2 = pGeoDef;
            pFieldsEdit.AddField(pField);

            //�����ֶ� GPS time
            IField pDateField = new FieldClass();
            pFieldEdit = (IFieldEdit)pDateField;
            pFieldEdit.Name_2 = strExtraFieldName;
            if (strExtraFieldName == m_strFeildGPSTime)
            {
                pFieldEdit.Type_2 = esriFieldType.esriFieldTypeDate;
            }
            else
                pFieldEdit.Type_2 = esriFieldType.esriFieldTypeString;
            pFieldsEdit.AddField(pFieldEdit);

            //�����ֶδ���ͼ��
            IFeatureClass pfclass = pWs.CreateFeatureClass(sLayerName, pFields, null, null, esriFeatureType.esriFTSimple, Geometry_IO.Geometry_Attribute.m_strShapeFieldName, "");//��һ�����ǳ����⣡���Ľ�������ǣ�ԭ��֮ǰ�趨������ϵͳû��������
            IDataset pdataset = (IDataset)pfclass;
            IFeatureLayer pLayer = null;
            pLayer = new FeatureLayerClass();
            pLayer.FeatureClass = pfclass;

            System.DateTime curT = System.DateTime.Now;
            string str = string.Format("_{0}_{1}_{2}_{3}_{4}", curT.Year, curT.Month, curT.Day, curT.Hour, curT.Minute);


            //��������� �㵽�ļ�
            Geometry_IO.Geometry_Attribute attr = new Geometry_IO.Geometry_Attribute();
            string strpath = strDirectory + "\\" + sLayerName + str + ".yvt";
            string TableName = Geometry_IO.Geometry_Attribute.m_strConstTableName;
            attr.CreateTableInMDB(strpath, TableName, pLayer as ILayer);

            pdataset.Delete();
            //�������ݵ���ǰ��ͼ
            List<string> m_FileList = new List<string>();
            m_FileList.Add(strpath);
            OpenYVTvectorData(m_FileList, ref m_CurLayerList);
        }


        /// <summary>
        /// Simple the GPS path render.
        /// GPS ·����Ⱦ
        /// </summary>
        /// <param name="player">The player.������Ҫ��Ⱦ�Ĳ�</param>
        private void SimpleGPSPathRender(IFeatureLayer player)
        {
            IGeoFeatureLayer pgeolayer = (IGeoFeatureLayer)player;
            IFeatureRenderer pfeaturerender = pgeolayer.Renderer;
            IFeatureClass pfeatureclass = player.FeatureClass;
            ISimpleRenderer psimplerender = new SimpleRendererClass();
            psimplerender.Description = "����Ⱦ";
       
            ILineSymbol sym = psimplerender.Symbol as ILineSymbol;
            if (sym == null) sym = new SimpleLineSymbolClass();
            IColor clr=new RgbColorClass();
            clr.RGB=255;//B * 65536 + G * 256 + R;
            sym.Color = clr;
            sym.Width = 3;

            psimplerender.Symbol = (ISymbol)sym;
            pgeolayer.Renderer = (IFeatureRenderer)psimplerender;
           
        }


        /// <summary>
        /// GPSs the marker point render.
        /// GPS ��ʶ����Ⱦ
        /// </summary>
        /// <param name="player">The player.������Ҫ��Ⱦ�Ĳ�</param>
        private void GPSMarkerPointRender(IFeatureLayer player)//,string strBitmapPath
        {
            IGeoFeatureLayer pgeolayer = (IGeoFeatureLayer)player;
            IFeatureRenderer pfeaturerender = pgeolayer.Renderer;
            IFeatureClass pfeatureclass = player.FeatureClass;
            ISimpleRenderer psimplerender = new SimpleRendererClass();
            psimplerender.Description = "����Ⱦ";

            //IPictureMarkerSymbol ppicmarksymbol = new PictureMarkerSymbolClass();
            //string bitmapname = GetType().Name + ".bmp";
            
            //string path = System.Windows.Forms.Application.StartupPath + @"../../../"; 
            //ppicmarksymbol.CreateMarkerSymbolFromFile(esriIPictureType.esriIPictureBitmap, strBitmapPath);//@"c:\tem\ship_016.bmp"
            ISimpleMarkerSymbol sym = psimplerender.Symbol as ISimpleMarkerSymbol;
            if (sym == null) sym = new SimpleMarkerSymbolClass();
            sym.Size = 5;
            sym.Angle = 45;
            IColor clr = new RgbColorClass();
            clr.RGB = 255* 65536 ;
            sym.Color = clr;

            psimplerender.Symbol = sym as ISymbol;// (ISymbol)psimplerender;
            pgeolayer.Renderer = (IFeatureRenderer)psimplerender;
        }

        /// <summary>
        /// Simples the buildings render.
        /// ���ݲ���Ⱦ
        /// </summary>
        /// <param name="player">The player.������Ҫ��Ⱦ�Ĳ�</param>
        private void SimpleBuildingsRender(IFeatureLayer player)
        {
            IGeoFeatureLayer pgeolayer = (IGeoFeatureLayer)player;
            IFeatureRenderer pfeaturerender = pgeolayer.Renderer;
            IFeatureClass pfeatureclass = player.FeatureClass;
            ISimpleRenderer psimplerender = new SimpleRendererClass();
            psimplerender.Description = "����Ⱦ";

            ISimpleFillSymbol FillSym = new SimpleFillSymbolClass();
            ILineSymbol sym = new SimpleLineSymbolClass();
            IColor clr = new RgbColorClass();
            clr.RGB = 128 * 65536; //B * 65536 + G * 256 + R;
            sym.Color = clr;
            sym.Width = 0.4;
            FillSym.Outline = sym;
            FillSym.Style = esriSimpleFillStyle.esriSFSHollow;

            psimplerender.Symbol = (ISymbol)FillSym;
            pgeolayer.Renderer = (IFeatureRenderer)psimplerender;
        }

        /// <summary>
        /// 	<Description>��δʹ�ã�GPSģ���ź� �˵���Ϣ��Ӧ����: MENU_GPS_SigalSimu_on_Click</Description>
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void MENU_GPS_SigalSimu_on_Click(object sender, EventArgs e)
        {
            m_bIsSimulateSingal = true;
        }

        /// <summary>
        /// 	<Description>��δʹ�ã�GPSģ���ź� �˵���Ϣ��Ӧ����: MENU_GPS_SigalSimu_on_Click</Description>
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void MENU_GPS_SigalSimu_off_Click(object sender, EventArgs e)
        {
            m_bIsSimulateSingal = false;
        }


  #region      //GPS ��صĲ���
        /// <summary>
        /// 	<Description>����GPS �˵���Ϣ��Ӧ����: ID_MENU_GPS_CONNECT_Click</Description>
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void ID_MENU_GPS_CONNECT_Click(object sender, EventArgs e)
        {

            try
            {
                if (GPSMng!=null && GPSMng.m_SerialPort.IsOpen) return;
                //�½�GPS��
                if (m_GPSPathLayer == null || m_GPSMarkerLayer == null)
                {
                    InitializeGPSPathLayer();

                }
               
                //new GPS ��ʶ
                //GPSPointRender(m_GPSMarkerLayer, System.Windows.Forms.Application.StartupPath+"\\GpsMarker.bmp");//@"\Resources\GpsMarker.bmp"

                this.axMapControl1.ActiveView.PartialRefresh(esriViewDrawPhase.esriViewGraphics, m_GPSPathLayer, null); //�ֲ�ˢ��


                //��GPS�豸
                if (m_bIsSimulateSingal)
                {
                    m_SingalSimulateGPSTimer = new System.Timers.Timer(5 * 1000);
                    m_SingalSimulateGPSTimer.Elapsed += new System.Timers.ElapsedEventHandler(Event_FalseSingalSimulate);
                    m_SingalSimulateGPSTimer.Enabled = true;
                }
                else
                {
                    double time = 1000;
                    if (GPSMng != null) time = GPSMng.m_Timer.Interval;         
                    GPSMng = new GPSManager.GPSManagerCore(this.Handle, "COM1", 57600);
                    GPSMng.m_Timer.Interval = time;
         
                    if(GPSMng.OpenPort()==false) return;
                    //GPSMng.m_SerialPort.
                    GPSMng.m_Timer.Enabled = true;
                }

                

                m_SaveGPSTimer = new System.Timers.Timer(5*60 * 1000);
                m_SaveGPSTimer.Elapsed += new System.Timers.ElapsedEventHandler(Event_SaveGPSTimeTick);
                m_SaveGPSTimer.Enabled = true;

                m_bIsNewGpsPath = true;

                BTN_GPS_ON.Checked = true;
                BTN_GPS_OFF.Checked = false;

            }
            catch (Exception ex)
            {
                MessageBox.Show("����GPS�豸���ִ���\r\n" + ex.Message);
            }
        }
        
        /// <summary>
        /// Handles the SaveGPSTimeTick event of the Event control.
        /// ��ʱ����Ϣ�����ڶ�ʱ�䱣�� GPS ·������
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void Event_SaveGPSTimeTick(object sender, EventArgs e)
        {
            //MENU_GPS_SAVE_Click(null,null);
            //BTN_SAVE_YUTU_Click(null, null);
            SaveAllEditLayers();
        }

        /// <summary>
        /// Handles the FalseSingalSimulate event of the Event control.
        /// ģ��ٵ���Ϣ��Ϣ��Ӧ������ʵ��GPS�в���Ҫʹ�ã������ڵ���
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void Event_FalseSingalSimulate(object sender, EventArgs e)
        {
            GPSDataInfo info = new GPSDataInfo();
            string data="1010000001,20100816080025,116.371637,39.993755,0,182,80,8,0,0,0\r\n";
            if (FetchInfoFromGPS(data, ref info))
            {
                //TESt
                info.Longitude -= 0.0001 * increasement;
                info.Latitude += 0.0001 * increasement;
                increasement++;
                UpdateMapWithGPS(info);
            }
        }
        
        /// <summary>
        /// 	<Description>�ر�GPS �˵���Ϣ��Ӧ����: ID_MENU_GPS_STOP_Click</Description>
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void ID_MENU_GPS_STOP_Click(object sender, EventArgs e)
        {
            try
            {
                //MENU_GPS_SAVE_Click(null, null);
                if (m_bIsSimulateSingal && m_SingalSimulateGPSTimer != null)
                {
                    m_SingalSimulateGPSTimer.Enabled = false;
                }
                else
                {
                    if (GPSMng == null) return;  //|| GPSMng.m_SerialPort.IsOpen == false
                    if (!GPSMng.IsPortConnected())
                    {
                        MessageBox.Show("GPSӲ��δ���ӡ�����GPS�����Ƿ�������\r\n��GPS�ӿ����Ӻú�ϵͳ���Զ����Ͽ�ǰ��״̬������\r\n����벻ҪƵ���ص����/�ر�GPS������ܻᵼ�´���");
                        return;
                    }
                    //�ر�GPS�豸
                    GPSMng.Close();
                    GPSMng.m_Timer.Enabled = false;
                    //����GPS·��
                    SaveGPSPath();
                }
                
                ////����GPS·��
                //ExportYutuVectorData(GetPathByLayerName(m_GPSPathLayer.Name), m_GPSPathLayer);

                //���� Ϊ�µ�GPS·��
                m_bIsNewGpsPath = true;

                BTN_GPS_ON.Checked = false;
                BTN_GPS_OFF.Checked = true;

            }
            catch (Exception ex)
            {
                MessageBox.Show("�ر�GPS�豸����\r\n" + ex.Message);
            }
        }


        /// <summary>
        /// Handles the Click event of the BTN_GPS_NAVG control.
        /// �Ƿ񵼺�
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void BTN_GPS_NAVG_Click(object sender, EventArgs e)
        {
            BTN_GPS_NAVG.Checked = !BTN_GPS_NAVG.Checked;
            //    if (BTN_GPS_NAVG.Checked)
            //    {
            ////        m_bIsGPSNavigate = true;
            //        BTN_GPS_NAVG.Checked = false;
            //    }
            //    else
            //    {
            ////        m_bIsGPSNavigate = false;
            //        BTN_GPS_NAVG.Checked = true;
            //    }
        }


        /// <summary>
        /// 	<Description>GPS������ �˵���Ϣ��Ӧ����: MENU_GPS_NAVG_ON_Click</Description>
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void MENU_GPS_NAVG_ON_Click(object sender, EventArgs e)
        {
            BTN_GPS_NAVG.Checked = true;
        }

        /// <summary>
        /// 	<Description>GPS������ �˵���Ϣ��Ӧ����: MENU_GPS_NAVG_OFF_Click</Description>
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void MENU_GPS_NAVG_OFF_Click(object sender, EventArgs e)
        {
            BTN_GPS_NAVG.Checked = false;
        }

        /// <summary>
        /// 	<Description>�˵���Ϣ��Ӧ����: MENU_GPS_SAVE_Click</Description>
        /// ���� GPS���ݲ���
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void MENU_GPS_SAVE_Click(object sender, EventArgs e)
        {
            if (m_GPSPathLayer == null || GPSMng==null) return;

            bool bStat = GPSMng.m_Timer.Enabled;
            //����GPS·��
            if (m_bIsSimulateSingal)
                SaveGPSPath();
            else
            {
                GPSMng.m_Timer.Enabled = false;
                SaveGPSPath();
                GPSMng.m_Timer.Enabled = bStat;
            }
            //���� Ϊ�µ�GPS·��
            m_bIsNewGpsPath = true;
        }


        /// <summary>
        /// Saves the GPS path.�����GPS���ݱ������
        /// </summary>
        public void SaveGPSPath()
        {
            
                //ExportYutuVectorData(GetPathByLayerName(m_GPSPathLayer.Name), m_GPSPathLayer);
                Survey_RecordMng manger = new Survey_RecordMng();
                string strPath = GetPathByLayerName(m_GPSPathLayer.Name);
            try
            {    
                manger.UpdatgeChangesForLayer(strPath, Geometry_IO.Geometry_Attribute.m_strConstTableName, m_GPSPathLayer);
            }
            catch (Exception ex)
            {
                MessageBox.Show("����GPS·��������\r\n" + ex.Message);
            }
                //GPS ��־��
            try
            {
                strPath = GetPathByLayerName(m_GPSMarkerLayer.Name);
                manger.UpdatgeChangesForLayer(strPath, Geometry_IO.Geometry_Attribute.m_strConstTableName, m_GPSMarkerLayer);
           }
            catch (Exception ex)
            {
                MessageBox.Show("����GPS��־�������\r\n" + ex.Message);
            }

        }

        /// <summary>
        /// RADs the specified d.
        /// ���������Ӻ��������㻡��
        /// </summary>
        /// <param name="d">The d.</param>
        /// <returns></returns>
        private static double rad(double d)
        {
           return d * Math.PI / 180.0;
        }

        /// <summary>
        /// Gets the distance.
        /// �������ĺ���������������γ�ȵ㣬�����������
        /// </summary>
        /// <param name="lat1">The lat1.</param>
        /// <param name="lng1">The LNG1.</param>
        /// <param name="lat2">The lat2.</param>
        /// <param name="lng2">The LNG2.</param>
        /// <returns>���ؾ��� ����λΪ��</returns>
        public static double GetDistance(double lat1, double lng1, double lat2, double lng2)
        {
           double radLat1 = rad(lat1);
           double radLat2 = rad(lat2);
           double a = radLat1 - radLat2;
           double b = rad(lng1) - rad(lng2);
           double s = 2 * Math.Asin(Math.Sqrt(Math.Pow(Math.Sin(a/2),2) + 
            Math.Cos(radLat1)*Math.Cos(radLat2)*Math.Pow(Math.Sin(b/2),2)));
           s = s * EARTH_RADIUS;
           //s = Math.Round(s * 10000) ;// 10000;
           return s * 1000;
        }



        /// <summary>
        /// 	<Description>�˵���Ϣ��Ӧ����: MENU_GPS_SETTING_Click</Description>
        /// GPSʱ�� ��ز��������ã������öԻ��򣬲���Ӧ�޸�
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void MENU_GPS_SETTING_Click(object sender, EventArgs e)
        {
            try
            {
                GPS_SettingDlg dlg = new GPS_SettingDlg(); //GPSsetDlg;
                dlg.m_BitRate = GPSMng.m_SerialPort.BaudRate;
                dlg.m_strComPortName = GPSMng.m_SerialPort.PortName;
                dlg.m_TimeSpanSample = GPSMng.m_Timer.Interval / 1000;
                dlg.m_TimeSpanSave = m_SaveGPSTimer.Interval /(60 * 1000);  //minutes
                dlg.m_bIsNavgate= BTN_GPS_NAVG.Checked ;
                dlg.SetParams();
                if (dlg.ShowDialog() == DialogResult.OK)
                {
                    if (dlg.m_strComPortName != "COM1" || dlg.m_BitRate != 57600) //new port
                    {
                        if (GPSMng.IsOpen) GPSMng.Close();
                        //��GPS�豸
                        GPSMng = new GPSManager.GPSManagerCore(this.Handle, dlg.m_strComPortName, dlg.m_BitRate);
                        GPSMng.OpenPort();
                        GPSMng.m_Timer.Enabled = true;
                        m_bIsNewGpsPath = true;
                    }
                    GPSMng.m_Timer.Interval = dlg.m_TimeSpanSample * 1000;
                    m_SaveGPSTimer.Interval = dlg.m_TimeSpanSave * 60 * 1000;  //minutes
                    BTN_GPS_NAVG.Checked = dlg.m_bIsNavgate;
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show("����GPS����������\r\n"+ex.Message);
             }
          }
#endregion

    }
}