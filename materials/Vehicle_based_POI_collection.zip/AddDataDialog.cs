//�ļ�����Ȩ��Ϣ------------------
/*
 * ���ļ������п���ͼ���¿Ƽ����޹�˾����ҵ����ƽ̨����ɲ���
 * δ���������ÿ���������������������ҵ��;
 * ��Ȩ���У��п���ͼ���¿Ƽ����޹�˾(http://www.mapuni.com/) 
 * �������ߣ�������   chqzeng@163.com 
 * ��дʱ�䣺2010-09-01
 */
using System;
using System.Drawing;
using System.Runtime.InteropServices;
using ESRI.ArcGIS.ADF.BaseClasses;
using ESRI.ArcGIS.ADF.CATIDs;
using ESRI.ArcGIS.Controls;
using System.Windows.Forms;
using System.Collections.Generic;

namespace YuTuSurveyPlatform
{
    /// <summary>
    /// Summary description for AddDataDialog.
    /// �Զ����ͼ���ߣ� �������� 
    /// </summary>
    [Guid("b48f5d7a-68e6-42da-9cf3-f80dc19ca056")]
    [ClassInterface(ClassInterfaceType.None)]
    [ProgId("YuTuSurveyPlatform.AddDataDialog")]
    public sealed class AddDataDialog : BaseCommand
    {
        #region COM Registration Function(s)
        [ComRegisterFunction()]
        [ComVisible(false)]
        static void RegisterFunction(Type registerType)
        {
            // Required for ArcGIS Component Category Registrar support
            ArcGISCategoryRegistration(registerType);

            //
            // TODO: Add any COM registration code here
            //
        }

        [ComUnregisterFunction()]
        [ComVisible(false)]
        static void UnregisterFunction(Type registerType)
        {
            // Required for ArcGIS Component Category Registrar support
            ArcGISCategoryUnregistration(registerType);

            //
            // TODO: Add any COM unregistration code here
            //
        }

        #region ArcGIS Component Category Registrar generated code
        /// <summary>
        /// Required method for ArcGIS Component Category registration -
        /// Do not modify the contents of this method with the code editor.
        /// </summary>
        private static void ArcGISCategoryRegistration(Type registerType)
        {
            string regKey = string.Format("HKEY_CLASSES_ROOT\\CLSID\\{{{0}}}", registerType.GUID);
            ControlsCommands.Register(regKey);

        }
        /// <summary>
        /// Required method for ArcGIS Component Category unregistration -
        /// Do not modify the contents of this method with the code editor.
        /// </summary>
        private static void ArcGISCategoryUnregistration(Type registerType)
        {
            string regKey = string.Format("HKEY_CLASSES_ROOT\\CLSID\\{{{0}}}", registerType.GUID);
            ControlsCommands.Unregister(regKey);

        }

        #endregion
        #endregion

        private IHookHelper m_hookHelper;
        private MainInterface parent;
        public AddDataDialog(MainInterface p)
        {
            //
            // TODO: Define values for the public properties
            //
            base.m_category = "Generic"; //localizable text
            base.m_caption = "AddData";  //localizable text
            base.m_message = "";  //localizable text 
            base.m_toolTip = "AddData";  //localizable text 
            base.m_name = "Generic_AddData";   //unique id, non-localizable (e.g. "MyCategory_MyCommand")
            parent = p;
            try
            {
                //
                // TODO: change bitmap name if necessary
                //
                string bitmapResourceName = GetType().Name + ".bmp";
                base.m_bitmap = new Bitmap(GetType(), bitmapResourceName);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Trace.WriteLine(ex.Message, "Invalid Bitmap");
            }
        }

        #region Overriden Class Methods

        /// <summary>
        /// Occurs when this command is created
        /// </summary>
        /// <param name="hook">Instance of the application</param>
        public override void OnCreate(object hook)
        {
            if (hook == null)
                return;

            if (m_hookHelper == null)
                m_hookHelper = new HookHelperClass();

            m_hookHelper.Hook = hook;

            // TODO:  Add other initialization code
        }

        /// <summary>
        /// Occurs when this command is clicked
        /// </summary>
        public override void OnClick()
        {
            // TODO: Add AddDataDialog.OnClick implementation
            string Filter = "��ͼʸ�����ݸ�ʽ(*.yvt)|*.yvt|��������SHAPE���� (*.shp.bcg)|*.shp.bcg|��������TIFF����  (*.tif.bcg)|*.tif.bcg|��������IMG����  (*.img.bcg)|*.img.bcg";
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.CheckFileExists = true;
            dlg.Filter = Filter;// "Background data (*.tif.bcg)|*.tif.bcg|Background data (*.img.bcg)|*.img.bcg";
            dlg.Multiselect = true; //true
            dlg.Title = "��������";
            if (dlg.ShowDialog() != DialogResult.OK) return ;

            int FileNum = dlg.FileNames.GetUpperBound(0) + 1;
            List<string> inFilePath = new List<string>();
            for (int index = 0; index < FileNum; index++)
            {
                inFilePath.Add(dlg.FileNames[index]);
            }
            if (inFilePath == null || inFilePath.Count == 0) return;

            //������������ 
            parent.AddAllData(inFilePath,dlg.FilterIndex);
            
        }

        #endregion
    }
}
