// Copyright 2008 ESRI
// 
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
// 
// You may freely redistribute and use this sample code, with or
// without modification, provided you include the original copyright
// notice and use restrictions.
// 
// See use restrictions at <your ArcGIS install location>/developerkit/userestrictions.txt.
// 

//���ĵ� ΪESRI ���Դ��ļ���û�����Ӷ���˵������鿴ESRI �İ����ĵ� 

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using ESRI.ArcGIS.Geodatabase;
using ESRI.ArcGIS.DataSourcesGDB;
using ESRI.ArcGIS.Carto;

namespace DemoITableBinding
{
  /// <summary>
  /// This class demonstrates how to bind an ITable to Windows Forms controls.
  /// </summary>
  /// <remarks>
  /// The form this class defines contains a DataGridView, a TextBox and a 
  /// BindingNavigator. The class will load the test data and bind it to both
  /// the TextBox and the DataGridView by using a BindingSource. The use of a
  /// BindingSource allows us to bind the test data to a single object that will
  /// act as a datasource for the grid, the text box and the navigation control.
  /// This allows changes made in one control to be reflected in the other controls
  /// with minimal coding effort. This is most clearly demonstrated by using the
  /// navigation control to step backwards and forwards through the grid rows
  /// while also showing the value of a single field in the current row in the
  /// text box.
  /// </remarks>
  public partial class MainWnd : Form
  {
    #region Private Memebers
    /// <summary>
    /// This is used to bind our ITable to the binding source. We need to keep
    /// a reference to it as we will need to re-attach it to the binding source
    /// to force a refresh whenever we change from displaying coded value domain
    /// values to displaying their text equivalents and vice versa.
    /// </summary>
    private ArcDataBinding.TableWrapper tableWrapper;
    
    /// <summary>
    /// This binding object sets the data member within the data source for the 
    /// text box. We need to keep a reference to this as it needs to be reset
    /// whenever viewing of coded value domains is changed.
    /// </summary>
    private Binding txtBoxBinding;
    #endregion Private Memebers

    public IFeatureLayer m_FeatureLyr;
      public string strPath;

    #region Construction/Destruction
    public MainWnd()
    {
      InitializeComponent();
      m_FeatureLyr = null;
      strPath = "";
    }
      public MainWnd(string Path, IFeatureLayer ftr)
      {
          InitializeComponent();
          m_FeatureLyr = ftr;
          strPath = Path;
      }

    #endregion Construction/Destruction

    #region Private Event Handlers
    private void MainWnd_Load(object sender, EventArgs e)
    {
      // Get workspace and open mdb file

        //IWorkspaceFactory2 wkspcFactory = (IWorkspaceFactory2)new ESRI.ArcGIS.DataSourcesFile.ShapefileWorkspaceFactory();
        //IFeatureWorkspace wkspc = wkspcFactory.OpenFromFile(@"D:\temp",Handle.ToInt32()) as IFeatureWorkspace;
        //ITable foundITable = wkspc.OpenFeatureClass("3��׼3��.shp") as ITable;

        //open the Geodatabase table
        ITable foundITable = m_FeatureLyr.FeatureClass as ITable;
        

      if (null != foundITable)
      {
        // Bind dataset to the binding source
        tableWrapper = new ArcDataBinding.TableWrapper(foundITable);
        bindingSource1.DataSource = tableWrapper;

        // Bind binding source to grid. Alternatively it is possible to bind TableWrapper
        // directly to the grid to this offers less flexibility
        dataGridView1.DataSource = bindingSource1;

        // Bind binding source to text box, we are binding the FULL_NAME
        // field.
        string strName = tableWrapper.wrappedTable.Fields.get_Field(0).Name;

        txtBoxBinding = new Binding("Text", bindingSource1, strName);
        textBox1.DataBindings.Add(txtBoxBinding);
      }

    }
/*
    private void chkUseCVD_CheckedChanged(object sender, EventArgs e)
    {
      // Set useage of CV domain on or off
      tableWrapper.UseCVDomains = chkUseCVD.Checked;

      // Refresh the binding source by setting it to null and then rebinding
      // to the data. This will refresh all the field types and ensures that all
      // the fields are using the correct type converters (we will need different
      // type converters depending on whether we are showing cv domain values or
      // their text equivalents). Note that as we will be setting the binding source
      // to null, the text box binding will fail as the "FULL_NAME" field will no
      // longer be present. To prevent any problems here, we need to remove and
      // reset the text box's binding.
      textBox1.DataBindings.Clear();
      bindingSource1.DataSource = null;
      bindingSource1.DataSource = tableWrapper;
      textBox1.DataBindings.Add(txtBoxBinding);
      dataGridView1.Refresh();
    } 
 * */
    #endregion Private Event Handlers

    /// <summary>
    /// Handles the CellClick event of the dataGridView1 control.
    /// ��ĳ����Ԫ��ѡ��ʱ
    /// </summary>
    /// <param name="sender">The source of the event.</param>
    /// <param name="e">The <see cref="System.Windows.Forms.DataGridViewCellEventArgs"/> instance containing the event data.</param>
      private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
      {
          if (e.ColumnIndex == -1) return;
          string strName = tableWrapper.wrappedTable.Fields.get_Field(e.ColumnIndex).Name;
          textBox1.DataBindings.Clear();
          txtBoxBinding = new Binding("Text", bindingSource1, strName);
          textBox1.DataBindings.Add(txtBoxBinding);
      }

      /// <summary>
      /// Handles the Click event of the button_save control.
      /// δʹ��
      /// </summary>
      /// <param name="sender">The source of the event.</param>
      /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
      private void button_save_Click(object sender, EventArgs e)
      {
          dataGridView1.Refresh();
          ExportYutuVectorData(strPath,m_FeatureLyr);

          textBox1.DataBindings.Clear();
          bindingSource1.DataSource = null;
          bindingSource1.DataSource = tableWrapper;
          textBox1.DataBindings.Add(txtBoxBinding);
          dataGridView1.Refresh();
      }
      //δʹ��
      public void ExportYutuVectorData(string strPath, IFeatureLayer lyr)
      {

          string strName = System.IO.Path.GetFileNameWithoutExtension(strPath);
          string strOutPath = strPath;
          bool m_bExists = false;
          //����ļ����ڣ���������ɾ��
          try
          {
              if (System.IO.File.Exists(strPath))
              {
                  //m_bExists = true;
                  //strOutPath = strOutPath + "_ext";
                  System.IO.File.Delete(strPath);
              }

              System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor;

              Geometry_IO.Geometry_Attribute attr = new Geometry_IO.Geometry_Attribute();

              string strpath = strOutPath;// strPath;
              string TableName = Geometry_IO.Geometry_Attribute.m_strConstTableName;   // System.IO.Path.GetFileNameWithoutExtension(strpath);//"MytestShp"
              attr.CreateTableInMDB(strpath, TableName, lyr);
              if (!attr.WriteShpaeFile2YutuFile(strpath, TableName, lyr)) return;

              if (m_bExists)
              {
                  System.IO.File.Delete(strPath);
                  //System.IO.File.Replace(strPath, strOutPath,"");
                  System.IO.File.Move(strOutPath, strPath);
              }
              System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default;
          }
          catch (Exception ex) { MessageBox.Show("����YUTU����������ԭ����ִ���\r\n" + ex.Message); return; }

      }


      /// <summary>
      /// Handles the Click event of the button_exit control.
      /// �˳� ����
      /// </summary>
      /// <param name="sender">The source of the event.</param>
      /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
      private void button_exit_Click(object sender, EventArgs e)
      {
          this.Dispose();
      }


  }
}