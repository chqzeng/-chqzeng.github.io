//�ļ�����Ȩ��Ϣ------------------
/*
 * ���ļ������п���ͼ���¿Ƽ����޹�˾����ҵ����ƽ̨����ɲ���
 * δ���������ÿ���������������������ҵ��;
 * ��Ȩ���У��п���ͼ���¿Ƽ����޹�˾(http://www.mapuni.com/) 
 * �������ߣ�������   chqzeng@163.com 
 * ��дʱ�䣺2010-09-01
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;

using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.Controls;
using ESRI.ArcGIS.esriSystem;
using ESRI.ArcGIS.SystemUI;
using ESRI.ArcGIS.Geometry;
using ESRI.ArcGIS.Geodatabase;

namespace YuTuSurveyPlatform
{
    /// <summary>
    /// �����ڹ������������޸ĶԻ���
    /// �öԻ���ÿ���û��༭�����½� ����ʱ���� 
    /// </summary>
    public partial class Survey_InputAttrDlg : Form
    {
        //��ǰ�༭��
        public IFeatureLayer m_layer;
        //���� ��
        public DataTable attributeTable;
      
        //��ǰ��¼��ID ��ID ����
        public string m_strOIDName;
        public long m_strOIDValue;

        //�Ƿ�Ϊ�½���¼ģʽ 
        public bool m_bIsAddRecord = false;


        /// <summary>
        /// Initializes a new instance of the <see cref="Survey_InputAttrDlg"/> class.
        /// ���캯�������ڳ�ʼ��
        /// </summary>
        public Survey_InputAttrDlg()
        {
            InitializeComponent();

            m_layer = null;
            attributeTable = null;
            m_strOIDName = "";
            m_strOIDValue = -1;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Survey_InputAttrDlg"/> class.
        /// ���캯�������ڳ�ʼ��
        /// </summary>
        /// <param name="layer">The layer.��ǰ�༭��</param>
        /// <param name="strOIDName">Name of the STR OID. ID����</param>
        /// <param name="strOIDValue">The STR OID value. ��ӦID</param>
        public Survey_InputAttrDlg(IFeatureLayer layer,string strOIDName,long strOIDValue)
        {
            InitializeComponent();

            m_layer = layer;
            attributeTable = null;
            m_strOIDName = strOIDName;
            m_strOIDValue = strOIDValue;
        }

        /// <summary>
        /// Sets the params.
        /// ��������
        /// </summary>
        /// <param name="layer">The layer.��ǰ�༭��</param>
        /// <param name="strOIDName">Name of the STR OID. ��ӦID����</param>
        /// <param name="strOIDValue">The STR OID value.��ӦID</param>
        public void SetParams(IFeatureLayer layer,string strOIDName,long strOIDValue)
        {
            m_layer = layer;
            m_strOIDName = strOIDName;
            m_strOIDValue = strOIDValue;

            string tableName = getValidFeatureClassName(m_layer.Name);
            string strSQL = " " + m_strOIDName + " = " + m_strOIDValue.ToString();
            attributeTable = LoadData(m_layer, strSQL, tableName);
            this.dataGridView1.DataSource = attributeTable;
        }


        /// <summary>
        /// Handles the Click event of the button1 control.
        /// ȷ�� ��Ϣ��Ӧ����
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void button1_Click(object sender, EventArgs e)
        {
            
            IEngineEditor editor = new EngineEditorClass();
            IMap map = editor.Map;
            IEngineEditLayers Elyr = editor as IEngineEditLayers;
            IFeatureLayer pLayer = Elyr.TargetLayer;
            IDataset m_Dataset = (IDataset)pLayer.FeatureClass;

            //�ر�EDIT
            if (editor.EditState != esriEngineEditState.esriEngineStateNotEditing)
                editor.StopEditing(true);
            try
            {
                string strSQL = " " + m_strOIDName + " = " + m_strOIDValue.ToString();
                SaveInputAttr(m_layer, strSQL);
            }
            catch (Exception ex)
            {
                MessageBox.Show("���ݱ�������г��ִ���!\r\n" + ex.Message);
                editor.StartEditing(m_Dataset.Workspace, map);
                this.DialogResult = DialogResult.None;
                return;
            }

            //����EDIT
            editor.StartEditing(m_Dataset.Workspace, map);
            IEngineEditTask editTask = editor.GetTaskByUniqueName("ControlToolsEditing_CreateNewFeatureTask");
            editor.CurrentTask = editTask;

            this.DialogResult = DialogResult.OK;

            this.Hide();
        }

        /// <summary>
        /// Handles the Click event of the button2 control.
        /// �˳� ��Ϣ��Ӧ����
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void button2_Click(object sender, EventArgs e)
        {
            IEngineEditor editor = new EngineEditorClass();
            IMap map = editor.Map;
            IEngineEditLayers Elyr = editor as IEngineEditLayers;
            IFeatureLayer pLayer = Elyr.TargetLayer;
            IDataset m_Dataset = (IDataset)pLayer.FeatureClass;

            //�ر�EDIT
            //if (editor.EditState != esriEngineEditState.esriEngineStateNotEditing)
            //    editor.StopEditing(false);
            ////����EDIT
            //editor.StartEditing(m_Dataset.Workspace, map);


            //�ر�EDIT
            if (editor.EditState != esriEngineEditState.esriEngineStateNotEditing)
                editor.StopEditing(true);
            try
            {
                string strSQL = " " + m_strOIDName + " = " + m_strOIDValue.ToString();
                if (m_bIsAddRecord) DeleteRecord(m_layer, strSQL);
            }
            catch (Exception ex)
            {
                MessageBox.Show("���ݱ�������г��ִ���!\r\n" + ex.Message);
                editor.StartEditing(m_Dataset.Workspace, map);
                this.DialogResult = DialogResult.None;
                return;
            }

            //����EDIT
            editor.StartEditing(m_Dataset.Workspace, map);
            IEngineEditTask editTask = editor.GetTaskByUniqueName("ControlToolsEditing_CreateNewFeatureTask");
            editor.CurrentTask = editTask;
            this.DialogResult = DialogResult.Cancel;

            this.Hide();
        }

        /// <summary>
        /// Handles the Load event of the Survey_InputAttrDlg control.
        /// ���غ���
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void Survey_InputAttrDlg_Load(object sender, EventArgs e)
        {
           // CreateAttributeTable(m_layer);

            //string tableName = getValidFeatureClassName(m_layer.Name);
            //string strSQL=" "+m_strOIDName+" = "+ m_strOIDValue.ToString();
            //attributeTable = LoadData(m_layer, strSQL, tableName);
            //this.dataGridView1.DataSource = attributeTable;
        }


        /// <summary>
        /// Loads the data.
        /// ͨ�����е����� ������ ������
        /// </summary>
        /// <param name="pLayer">The p layer.</param>
        /// <param name="strSQL">The STR SQL.</param>
        /// <param name="tableName">Name of the table.</param>
        /// <returns>����һ��������</returns>
        private DataTable LoadData(ILayer pLayer, string strSQL, string tableName)
        {
            //����һ��DataTable��
            DataTable pDataTable = new DataTable(tableName);
            DataColumn pDataColumn;

            //�ֶ� ��
            pDataColumn = new DataColumn("�ֶ�");
            pDataColumn.ReadOnly = true;
            pDataColumn.DataType = System.Type.GetType("System.String");
            pDataTable.Columns.Add(pDataColumn);

            pDataColumn = new DataColumn("ֵ");
            pDataColumn.DataType = System.Type.GetType("System.String");
            pDataTable.Columns.Add(pDataColumn);

            //��ȡ���� 

            IQueryFilter queryFilter = new QueryFilterClass();
            queryFilter.WhereClause = strSQL;
            //��ILayer��ѯ��ITable
            ITable pTable = pLayer as ITable;
            ICursor pCursor = pTable.Search(queryFilter, false);
            //ȡ��ITable�е�����Ϣ
            IRow pRow = pCursor.NextRow();
            if (pRow == null) return pDataTable;

            DataRow pDataRow = null;
            for (int i = 0; i < pRow.Fields.FieldCount; i++)
            {
                pDataRow = pDataTable.NewRow();
                pDataRow[0] = pRow.Fields.get_Field(i).Name;

                //����ֶ�����ΪesriFieldTypeGeometry�������ͼ�����������ֶ�ֵ
                if (pRow.Fields.get_Field(i).Type == esriFieldType.esriFieldTypeGeometry)
                {
                    pDataRow[1] = "�����ֶ�";
                }
                //else if (pRow.Fields.get_Field(i).Name == Geometry_IO.Geometry_Attribute.m_strConstFieldChange)
                //{
                //    continue;
                //}
                //��ͼ������ΪAnotationʱ��Ҫ�����л���esriFieldTypeBlob���͵����ݣ�
                //��洢���Ǳ�ע���ݣ��������轫��Ӧ���ֶ�ֵ����ΪElement
                else if (pRow.Fields.get_Field(i).Type == esriFieldType.esriFieldTypeBlob)
                {
                    pDataRow[1] = "δ֪Ԫ��";
                }
                else
                {
                    if (pRow.get_Value(i) == null)//Ϊ��ʱ��Ϊ�ռ�����ֶ�
                    {
                        if (pRow.Fields.get_Field(i).Type == esriFieldType.esriFieldTypeString) pDataRow[1] = "";
                        else pDataRow[1] = 0;
                    }
                    else
                    {
                        pDataRow[1] = pRow.get_Value(i);
                    }
                }
                pDataTable.Rows.Add(pDataRow);
            }

            return pDataTable;
        }

        /// <summary>
        /// Saves the input attr.
        /// ���û��������� ����Ҫ�������浽��ǰ���ڴ��ļ���
        /// ��������û�д��뵽�ļ��У���Ҫ �� ��������桱���߻���ϵͳ��ʱ������д�뵽�ļ�
        /// </summary>
        /// <param name="pLayer">The p layer.</param>
        /// <param name="strSQL">The STR SQL.</param>
        private void SaveInputAttr(ILayer pLayer, string strSQL)
        {
            IQueryFilter queryFilter = new QueryFilterClass();
            queryFilter.WhereClause = strSQL;
            // Create insert feature cursor using buffering.
            IFeatureClass featureClass = ((IFeatureLayer)pLayer).FeatureClass ;
            IFeatureCursor featureCursor = featureClass.Update(queryFilter, false);

            IFields fields = featureCursor.Fields; 
            IFeature feature = featureCursor.NextFeature();

            for (int index = 0; index < attributeTable.Rows.Count; index++)
            {
                
                DataRow pRow=attributeTable.Rows[index];
                
                string FldName = pRow[0].ToString();//pRow.get_Value(0).ToString();
                if (FldName == "SHAPE" || FldName == m_strOIDName) continue;
                int fieldIndex = fields.FindField(FldName);

                if (FldName == Geometry_IO.Geometry_Attribute.m_strConstFieldChange)  //���������ֶεĴ���  1:ɾ��; 2.���� 3.����
                {
                    int dirtIdx = -1;
                    if (pRow[1].GetType().Name != "DBNull") dirtIdx = Convert.ToInt32(pRow[1]);
                    if (dirtIdx > 0) //�Ѿ����û���ֵ
                    {
                        feature.set_Value(fieldIndex, pRow[1]);
                    }
                    else
                        feature.set_Value(fieldIndex, 3);  //Ĭ��Ϊ���Ӽ�¼
                    continue;
                }

                feature.set_Value(fieldIndex, pRow[1]);
            }
            //����Ϊ�޸ĵı��
            //int fldIndex = fields.FindField(Geometry_IO.Geometry_Attribute.m_strConstFieldChange);
            //feature.set_Value(fldIndex, 3);

            featureCursor.UpdateFeature(feature);
            Marshal.ReleaseComObject(featureCursor);
        }

        /// <summary>
        /// Deletes the record.
        /// ɾ����¼��
        /// ���½�����ģʽ�����û�ȡ��ʱ��Ϊ�˱��� GPS���ݲ����ƻ���
        /// ��Ҫ�����еı༭�ȱ��棬Ȼ��ɾ����ǰ���ӵĶ���
        /// </summary>
        /// <param name="pLayer">The p layer.</param>
        /// <param name="strSQL">The STR SQL.</param>
        private void DeleteRecord(ILayer pLayer, string strSQL)
        {
            IQueryFilter queryFilter = new QueryFilterClass();
            queryFilter.WhereClause = strSQL;
            // Create insert feature cursor using buffering.
            IFeatureClass featureClass = ((IFeatureLayer)pLayer).FeatureClass;
            IFeatureCursor featureCursor = featureClass.Update(queryFilter, false);

            IFields fields = featureCursor.Fields;
            IFeature feature = featureCursor.NextFeature();
            if (feature != null) feature.Delete();

            //featureCursor.UpdateFeature(feature);
            Marshal.ReleaseComObject(featureCursor);
        }

        /// <summary>
        /// Handles the KeyDown event of the Survey_InputAttrDlg control.
        /// ��ݼ�����
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.Windows.Forms.KeyEventArgs"/> instance containing the event data.</param>
        private void Survey_InputAttrDlg_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode==Keys.Enter&& e.Control)   //Ctrl + Enter 
            {
                button1_Click(null, null);
            }
            else if (e.Control && e.KeyCode == Keys.Back)  //Ctrl + escape --> cancel
            {
                button2_Click(null, null);
            }
        }

        /// <summary>
        /// Handles the FormClosing event of the Survey_InputAttrDlg control.
        /// �رմ�����Ϣ��Ӧ����
        /// Ϊ�˲��ô��ڹرվ�ֱ��ע��������Ҫ�Զ���رչ���
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.Windows.Forms.FormClosingEventArgs"/> instance containing the event data.</param>
        private void Survey_InputAttrDlg_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (this.DialogResult != DialogResult.OK)
            {
                button2_Click(null, null);  //equal to cancel
            }
        }
        /// <summary>
        /// ������������ʹ�õ���Դ��
        /// </summary>
        /// <param name="disposing">���Ӧ�ͷ��й���Դ��Ϊ true������Ϊ false��</param>
        protected override void Dispose(bool disposing)
        {
            return;
        }

        /// <summary>
        /// Exits the window.
        /// �˳����ڣ��������ͷ��й���Դ���̣���PARENT���ڹ��� 
        /// </summary>
        /// <param name="disposing">if set to <c>true</c> [disposing].</param>
        public void ExitWindow(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        //private void Survey_InputAttrDlg_FormClosed(object sender, FormClosedEventArgs e)
        //{
        //    return;
        //}

    }
}