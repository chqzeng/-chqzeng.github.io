//�ļ�����Ȩ��Ϣ------------------
/*
 * ���ļ������п���ͼ���¿Ƽ����޹�˾����ҵ����ƽ̨����ɲ���
 * δ���������ÿ���������������������ҵ��;
 * ��Ȩ���У��п���ͼ���¿Ƽ����޹�˾(http://www.mapuni.com/) 
 * �������ߣ�������   chqzeng@163.com 
 * ��дʱ�䣺2010-09-01
 */
using System;
using System.Drawing;
using System.Runtime.InteropServices;
using ESRI.ArcGIS.ADF.BaseClasses;
using ESRI.ArcGIS.ADF.CATIDs;
using ESRI.ArcGIS.Controls;
using ESRI.ArcGIS.Carto;

using ESRI.ArcGIS.Geodatabase;
using ESRI.ArcGIS.DataSourcesFile;
using ESRI.ArcGIS.Geometry;

using System.Windows.Forms;

namespace YuTuSurveyPlatform
{
    /// <summary>
    /// Summary description for RMenu_ExportDataAs.
    /// �Ҽ��˵� ����������
    /// </summary>
    [Guid("a6497b17-f2a8-4e22-877d-e39aa01ad6fa")]
    [ClassInterface(ClassInterfaceType.None)]
    [ProgId("YuTuSurveyPlatform.RMenu_ExportDataAs")]
    public sealed class RMenu_ExportDataAs : BaseCommand
    {
        #region COM Registration Function(s)
        [ComRegisterFunction()]
        [ComVisible(false)]
        static void RegisterFunction(Type registerType)
        {
            // Required for ArcGIS Component Category Registrar support
            ArcGISCategoryRegistration(registerType);

            //
            // TODO: Add any COM registration code here
            //
        }

        [ComUnregisterFunction()]
        [ComVisible(false)]
        static void UnregisterFunction(Type registerType)
        {
            // Required for ArcGIS Component Category Registrar support
            ArcGISCategoryUnregistration(registerType);

            //
            // TODO: Add any COM unregistration code here
            //
        }

        #region ArcGIS Component Category Registrar generated code
        /// <summary>
        /// Required method for ArcGIS Component Category registration -
        /// Do not modify the contents of this method with the code editor.
        /// </summary>
        private static void ArcGISCategoryRegistration(Type registerType)
        {
            string regKey = string.Format("HKEY_CLASSES_ROOT\\CLSID\\{{{0}}}", registerType.GUID);
            ControlsCommands.Register(regKey);

        }
        /// <summary>
        /// Required method for ArcGIS Component Category unregistration -
        /// Do not modify the contents of this method with the code editor.
        /// </summary>
        private static void ArcGISCategoryUnregistration(Type registerType)
        {
            string regKey = string.Format("HKEY_CLASSES_ROOT\\CLSID\\{{{0}}}", registerType.GUID);
            ControlsCommands.Unregister(regKey);

        }

        #endregion
        #endregion

        private IHookHelper m_hookHelper;
        private IMapControl3 m_mapControl;

        public RMenu_ExportDataAs()
        {
            //
            // TODO: Define values for the public properties
            //
            base.m_category = ""; //localizable text
            base.m_caption = "��������";  //localizable text
            base.m_message = "��������";  //localizable text 
            base.m_toolTip = "��������";  //localizable text 
            base.m_name = "ExportData";   //unique id, non-localizable (e.g. "MyCategory_MyCommand")
        }

        #region Overriden Class Methods

        /// <summary>
        /// Occurs when this command is created
        /// </summary>
        /// <param name="hook">Instance of the application</param>
        public override void OnCreate(object hook)
        {
            if (hook == null)
                return;

            if (m_hookHelper == null)
                m_hookHelper = new HookHelperClass();

            m_hookHelper.Hook = hook;

            m_mapControl = (IMapControl3)hook;
            // TODO:  Add other initialization code
        }

        public override bool Enabled
        {
            get
            {
                bool enabled = false;
                try
                {
                    IFeatureLayer layer = m_mapControl.CustomProperty as IFeatureLayer;
                    if (layer != null) enabled = true;
                }
                catch { }

                return enabled;
            }
        }


        /// <summary>
        /// Occurs when this command is clicked
        /// </summary>
        public override void OnClick()
        {
            // TODO: Add RMenu_ExportDataAs.OnClick implementation
            ILayer layer = null;
            try
            {
                layer = (ILayer)m_mapControl.CustomProperty;
                if (layer == null) return;  //����դ�����Ч
            }
            catch { return; }
            IRasterLayer rstlayer = layer as IRasterLayer;
            IFeatureLayer ftrlayer=layer as IFeatureLayer;

            //m_mapControl.MousePointer = esriControlsMousePointer.esriPointerHourglass;
            //System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor;
            if (rstlayer!=null) ExportRasterLayerAs(rstlayer);
            else if (ftrlayer != null)  ExportFeatureLayerAs(ftrlayer);
            else 
            {
                MessageBox.Show("�޷�����ò㣡");
                return;
            }
            //System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default;
            //m_mapControl.MousePointer = esriControlsMousePointer.esriPointerDefault;
            //MessageBox.Show("����ò���ɣ�");
        }
        private void ExportFeatureLayerAs(IFeatureLayer ftrLayer)
        {
            
            SaveFileDialog saveFileDialog1=new SaveFileDialog();
            saveFileDialog1.Filter = @"Yutu files (*.yvt)|*.yvt";
            if(saveFileDialog1.ShowDialog()!= DialogResult.OK) return;

            IFeatureLayer lyr = ftrLayer; 
            string strPath = saveFileDialog1.FileName;
            if (!strPath.Contains(".yvt")) strPath = strPath + ".yvt";
            ExportYutuVectorData(strPath,lyr);
            //string strPath =System.IO.Path.GetDirectoryName(saveFileDialog1.FileName);
            //string strName =System.IO.Path.GetFileNameWithoutExtension(saveFileDialog1.FileName);
            

            //System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor;
            //System.Threading.Thread.Sleep(100);

            ////���SHAPE�ļ�
            ////SaveShapeFile( strPath,  strName, ftrLayer);

            ////��� YUTU��ʽ �ļ�
            //Geometry_Attribute attr = new Geometry_Attribute();
            //string TableName = System.IO.Path.GetFileNameWithoutExtension(strPath);
            //attr.CreateTableInMDB(strPath, TableName, lyr);
            //if (!attr.WriteShpaeFile2YutuFile(strPath, TableName, lyr)) return;

            //System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default;
            
        }
        public void ExportYutuVectorData(string strPath, IFeatureLayer lyr)
        {

            string strName = System.IO.Path.GetFileNameWithoutExtension(strPath);
            string strOutPath = strPath;
            bool m_bExists = false;
            //����ļ����ڣ���������ɾ��
            try
            {
                if (System.IO.File.Exists(strPath))
                {
                    //m_bExists = true;
                    //strOutPath = strOutPath + "_ext";
                    System.IO.File.Delete(strPath);
                }

                System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor;

                Geometry_IO.Geometry_Attribute attr = new Geometry_IO.Geometry_Attribute();

                string strpath = strOutPath;// strPath;
                string TableName = Geometry_IO.Geometry_Attribute.m_strConstTableName; //System.IO.Path.GetFileNameWithoutExtension(strpath);//"MytestShp"
                attr.CreateTableInMDB(strpath, TableName, lyr);
                if (!attr.WriteShpaeFile2YutuFile(strpath, TableName, lyr)) return;

                if (m_bExists)
                {
                    System.IO.File.Delete(strPath);
                    //System.IO.File.Replace(strPath, strOutPath,"");
                    System.IO.File.Move(strOutPath, strPath);
                }
                System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default;
            }
            catch (Exception ex) { MessageBox.Show("����YUTU����������ԭ����ִ���\r\n" + ex.Message); return; }
            MessageBox.Show("�ɹ����� YVT ��ʽ ���� ��");
        }
        public void SaveShapeFile(string strPath, string strName, IFeatureLayer ftrLayer)
        {
            IWorkspaceFactory pWorkspaceFactory = new ShapefileWorkspaceFactoryClass();
            IFeatureWorkspace pFWS = pWorkspaceFactory.OpenFromFile(strPath, 0) as IFeatureWorkspace;
            try
            {
                IFeatureClass pFeatClass = pFWS.CreateFeatureClass(strName, ftrLayer.FeatureClass.Fields, null, null, ftrLayer.FeatureClass.FeatureType, ftrLayer.FeatureClass.ShapeFieldName, "");

                //cast the spatial filter to the IQueryFilter interface
                IQueryFilter queryFilter = new QueryFilterClass();
                queryFilter.WhereClause = "";

                //preform the search on the supplied feature class; use a cursor to hold the results
                IFeatureCursor featureCursor = ftrLayer.FeatureClass.Search(queryFilter, false);


                //Insert each record
                IFeatureClass__Insert(featureCursor, pFeatClass);


            }
            catch
            {
                System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default;
                MessageBox.Show("�ļ�������̳�����");
            }
        }
        public void IFeatureClass__Insert(IFeatureCursor InFeatureCursor, IFeatureClass featureClass)
        {
            
            //get the "Area" field
            //IFields fields = featureCursor.Fields;

            //get the Workspace from the IDataset interface on the feature class
            IDataset dataset = (IDataset)featureClass;
            IWorkspace workspace = dataset.Workspace;

            //Cast for an IWorkspaceEdit
            IWorkspaceEdit workspaceEdit = (IWorkspaceEdit)workspace;

            //Start an edit session and operation
            workspaceEdit.StartEditing(true);
            workspaceEdit.StartEditOperation();

            //Create the Feature Buffer
            IFeatureBuffer featureBuffer = featureClass.CreateFeatureBuffer();
            //Create insert Feature Cursor using buffering = true.
            IFeatureCursor featureCursor = featureClass.Insert(true);

            object featureOID;
            //get the first feature returned
            IFeature Infeature = InFeatureCursor.NextFeature();
            //loop through all of the features and save it 
            while (Infeature != null)
            {
                featureBuffer = Infeature as IFeatureBuffer;
                Infeature = InFeatureCursor.NextFeature();

                featureOID = featureCursor.InsertFeature(featureBuffer);
            }

            //Calling flush allows you to handle any errors at a known time rather then on the cursor destruction.
            featureCursor.Flush();

            //Stop editing
            workspaceEdit.StopEditOperation();
            workspaceEdit.StopEditing(true);

            //Release the Cursor
            System.Runtime.InteropServices.Marshal.ReleaseComObject(featureCursor);
        }

        private void CreatShapeFile(IFeatureLayer pFeatureLayer)     //�½��ļ�������ѡ��Ҫ��
        {
            SaveFileDialog dlg = new SaveFileDialog();
            dlg.Filter = "Shapefiles�ļ�(*.shp)|*.shp";
            dlg.DefaultExt = "*.shp";
            dlg.Title = "' " + pFeatureLayer.Name + " '" + "ͼ��Ҫ�ص���";
            dlg.RestoreDirectory = true;

            string FilePath;

            if (dlg.ShowDialog() == DialogResult.OK)
            {
                FilePath = dlg.FileName;
                if (FilePath.Length > 0)
                {
                    string WorkSpacePath = System.IO.Path.GetDirectoryName(FilePath);//�����ռ�·��
                    string FileName = System.IO.Path.GetFileName(FilePath);//shapefile�ļ���
                    FileName = FileName.Substring(0, FileName.Length - 4);
                    dlg.CheckFileExists = true;

                    //������·���򿪹����ռ�
                    IWorkspaceFactory m_WorkspaceFactory = new ShapefileWorkspaceFactoryClass();
                    IWorkspace m_Workspace = m_WorkspaceFactory.OpenFromFile(WorkSpacePath, 0);
                    IFeatureWorkspace m_FeatureWorkspace = m_Workspace as IFeatureWorkspace;

                    IFields m_Fields = new FieldsClass();
                    IFieldsEdit m_FieldsEdit = (IFieldsEdit)m_Fields;

                    //����shape�ֶΣ�����Geometry����Ϳռ�ο�ϵ
                    IField m_Field = new FieldClass();
                    IFieldEdit m_FieldEdit = (IFieldEdit)m_Field;
                    m_FieldEdit.Name_2 = "Shape";
                    m_FieldEdit.Type_2 = ESRI.ArcGIS.Geodatabase.esriFieldType.esriFieldTypeGeometry;

                    IGeometryDef m_GeomDef = new GeometryDefClass();
                    IGeometryDefEdit m_GeomDefEdit = (IGeometryDefEdit)m_GeomDef;

                    switch (pFeatureLayer.FeatureClass.ShapeType)  //Geometry����
                    {
                        case esriGeometryType.esriGeometryPoint:
                            m_GeomDefEdit.GeometryType_2 = esriGeometryType.esriGeometryPoint;
                            break;
                        case esriGeometryType.esriGeometryPolyline:
                            m_GeomDefEdit.GeometryType_2 = esriGeometryType.esriGeometryPolyline;
                            break;
                        case esriGeometryType.esriGeometryPolygon:
                            m_GeomDefEdit.GeometryType_2 = esriGeometryType.esriGeometryPolygon;
                            break;
                    }
                    m_GeomDefEdit.SpatialReference_2 = pFeatureLayer.FeatureClass.Fields.get_Field(pFeatureLayer.FeatureClass.Fields.FindField(pFeatureLayer.FeatureClass.ShapeFieldName)).GeometryDef.SpatialReference;//�ռ�ο�ϵ

                    m_FieldEdit.GeometryDef_2 = m_GeomDef;
                    m_FieldsEdit.AddField(m_Field);

                    //�����ֶ�����
                    for (int FieldIndex = 2; FieldIndex <= pFeatureLayer.FeatureClass.Fields.FieldCount - 1; FieldIndex++)
                    {
                        m_Field = new FieldClass();
                        m_FieldEdit = (IFieldEdit)m_Field;
                        m_FieldEdit.Type_2 = pFeatureLayer.FeatureClass.Fields.get_Field(FieldIndex).Type;
                        m_FieldEdit.Name_2 = pFeatureLayer.FeatureClass.Fields.get_Field(FieldIndex).Name;
                        m_FieldEdit.Length_2 = pFeatureLayer.FeatureClass.Fields.get_Field(FieldIndex).Length;
                        m_FieldEdit.Scale_2 = pFeatureLayer.FeatureClass.Fields.get_Field(FieldIndex).Scale;
                        m_FieldEdit.Precision_2 = pFeatureLayer.FeatureClass.Fields.get_Field(FieldIndex).Precision;
                        m_FieldsEdit.AddField(m_Field);
                    }

                    //����Ҫ����
                    IFeatureClass m_NewFeatureClass;
                    m_NewFeatureClass = m_FeatureWorkspace.CreateFeatureClass(FileName, m_Fields, null, null,
                             ESRI.ArcGIS.Geodatabase.esriFeatureType.esriFTSimple, "Shape", "");

                    //��ѡ��Ҫ�ظ��Ƶ���shapefile�ļ���
                    IFeatureSelection m_FeatureSelection = (IFeatureSelection)pFeatureLayer;
                    ISelectionSet m_SelectionSet = m_FeatureSelection.SelectionSet;

                    ICursor m_Cursor;
                    m_SelectionSet.Search(null, false, out m_Cursor);
                    IFeatureCursor m_FeatureCursor;
                    m_FeatureCursor = (IFeatureCursor)m_Cursor;

                    IFeature m_Feature;
                    m_Feature = m_FeatureCursor.NextFeature();

                    //��ʼ�༭
                    IDataset m_Dataset = (IDataset)pFeatureLayer.FeatureClass;
                    IWorkspaceEdit m_WorkspaceEdit = (IWorkspaceEdit)m_Dataset.Workspace;
                    IFeature m_NewFeature;
                    if (!m_WorkspaceEdit.IsBeingEdited())
                    {
                        m_WorkspaceEdit.StartEditing(true);
                    }
                    //��ͼ����α������
                    IFeatureCursor m_NewFeatureCursor;
                    m_NewFeatureCursor = m_NewFeatureClass.Update(null, false);

                    while (m_Feature != null)
                    {
                        //����ͼ��
                        m_NewFeature = m_NewFeatureClass.CreateFeature();
                        m_NewFeature.Shape = m_Feature.Shape;
                        m_NewFeature.Store();

                        //�������Ա�
                        for (int Index = 2; Index <= m_Feature.Fields.FieldCount - 1; Index++)
                            m_NewFeature.set_Value(Index, m_Feature.get_Value(Index));

                        m_NewFeatureCursor.UpdateFeature(m_NewFeature);

                        m_Feature = m_FeatureCursor.NextFeature();
                    }
                    //ֹͣ�༭
                    m_WorkspaceEdit.StopEditOperation();
                    m_WorkspaceEdit.StopEditing(true);
                }
            }
        }

        public void IFeatureBuffer_Example(IFeatureClass featureClass)    
        {        
            //Function is designed to work with polyline data        
            if (featureClass.ShapeType != ESRI.ArcGIS.Geometry.esriGeometryType.esriGeometryPolyline) 
            { return; }

        //get the Workspace from the IDataset interface on the feature class        
            IDataset dataset = (IDataset)featureClass;        
            IWorkspace workspace = dataset.Workspace;        
            //Cast for an IWorkspaceEdit        
            IWorkspaceEdit workspaceEdit = (IWorkspaceEdit)workspace;
        //Start an edit session and operation        
            workspaceEdit.StartEditing(true);        
            workspaceEdit.StartEditOperation();
        //Create the Feature Buffer        
            IFeatureBuffer featureBuffer = featureClass.CreateFeatureBuffer();        
            //Create insert Feature Cursor using buffering = true.        
            IFeatureCursor featureCursor = featureClass.Insert(true);
        object featureOID;
        //With a feature buffer you have the ability to set the attribute for a specific field to be        
            //the same for all features added to the buffer.        
            featureBuffer.set_Value(featureBuffer.Fields.FindField("InstalledBy"), "K Johnston");
        //Here you can set the featurebuffers's shape by setting the featureBuffer.Shape         
            //to a geomerty that matched the featureclasses.        
            //Create 100 features using FeatureBuffer and insert into a feature cursor        
            ESRI.ArcGIS.Geometry.IPolyline polyline = new ESRI.ArcGIS.Geometry.PolylineClass();        
            ESRI.ArcGIS.Geometry.IPoint point = new ESRI.ArcGIS.Geometry.PointClass();        
            for (int i = 0; i < 100; i++)        
            {            
                //Create the polyline geometry to assign to the new feature            
                point.X = 498490 + i * 10;           
                point.Y = 675380 + i * 10;           
                polyline.FromPoint = point;            
                point = new ESRI.ArcGIS.Geometry.PointClass();            
                point.X = 498480 + i * 10;            
                point.Y = 675390 + i * 10;            
                polyline.ToPoint = point;            
                featureBuffer.Shape = polyline;
            //Insert the feature into the feature cursor            
                featureOID = featureCursor.InsertFeature(featureBuffer);
            }        
            //Flush the feature cursor to the database        
            //Calling flush allows you to handle any errors at a known time rather then on the cursor destruction.        
            featureCursor.Flush();

        //Stop editing        
            workspaceEdit.StopEditOperation();        
            workspaceEdit.StopEditing(true);
        //Release the Cursor        
            System.Runtime.InteropServices.Marshal.ReleaseComObject(featureCursor);   
        }


        //IFeatureDataConverter ConvertFeatureClass Example
    //e.g., nameOfSourceFeatureClass = "ctgFeatureshp.shp"    
        //      nameOfTargetFeatureClass = "ctgFeature"    
        public void ConvertFeatureClass(IWorkspace sourceWorkspace, IWorkspace targetWorkspace, string nameOfSourceFeatureClass, string nameOfTargetFeatureClass)    
        {        
            //create source workspace name        
            IDataset sourceWorkspaceDataset = (IDataset)sourceWorkspace;        
            IWorkspaceName sourceWorkspaceName = (IWorkspaceName)sourceWorkspaceDataset.FullName;
          //create source dataset name        
            IFeatureClassName sourceFeatureClassName = new FeatureClassNameClass();
            IDatasetName sourceDatasetName = (IDatasetName)sourceFeatureClassName;
            sourceDatasetName.WorkspaceName = sourceWorkspaceName;
            sourceDatasetName.Name = nameOfSourceFeatureClass;

        //create target workspace name        
            IDataset targetWorkspaceDataset = (IDataset)targetWorkspace; 
            IWorkspaceName targetWorkspaceName = (IWorkspaceName)targetWorkspaceDataset.FullName;

        //create target dataset name        
            IFeatureClassName targetFeatureClassName = new FeatureClassNameClass();
            IDatasetName targetDatasetName = (IDatasetName)targetFeatureClassName;
            targetDatasetName.WorkspaceName = targetWorkspaceName;
            targetDatasetName.Name = nameOfTargetFeatureClass;

        //Open input Featureclass to get field definitions.  
            ESRI.ArcGIS.esriSystem.IName sourceName = (ESRI.ArcGIS.esriSystem.IName)sourceFeatureClassName; 
            IFeatureClass sourceFeatureClass = (IFeatureClass)sourceName.Open();
        //Validate the field names because you are converting between different workspace types.        
            IFieldChecker fieldChecker = new FieldCheckerClass();
            IFields targetFeatureClassFields;
            IFields sourceFeatureClassFields = sourceFeatureClass.Fields;
            IEnumFieldError enumFieldError;
        // Most importantly set the input and validate workspaces!        
            fieldChecker.InputWorkspace = sourceWorkspace;        
            fieldChecker.ValidateWorkspace = targetWorkspace;        
            fieldChecker.Validate(sourceFeatureClassFields, out enumFieldError, out targetFeatureClassFields);
        // Loop through the output fields to find the geomerty field        
            IField geometryField;        
            for (int i = 0; i < targetFeatureClassFields.FieldCount; i++)        
            {            
                if (targetFeatureClassFields.get_Field(i).Type == esriFieldType.esriFieldTypeGeometry)
                {                
                    geometryField = targetFeatureClassFields.get_Field(i);
                    // Get the geometry field's geometry defenition                
                    IGeometryDef geometryDef = geometryField.GeometryDef;
                //Give the geometry definition a spatial index grid count and grid size                
                    IGeometryDefEdit targetFCGeoDefEdit = (IGeometryDefEdit)geometryDef;

                targetFCGeoDefEdit.GridCount_2 = 1;
                    targetFCGeoDefEdit.set_GridSize(0, 0);
                    //Allow ArcGIS to determine a valid grid size for the data loaded                
                    targetFCGeoDefEdit.SpatialReference_2 = geometryField.GeometryDef.SpatialReference;

                // we want to convert all of the features                
                    IQueryFilter queryFilter = new QueryFilterClass();                
                    queryFilter.WhereClause = "";

                // Load the feature class                
                    IFeatureDataConverter fctofc = new FeatureDataConverterClass();                
                    IEnumInvalidObject enumErrors = fctofc.ConvertFeatureClass(sourceFeatureClassName, queryFilter, null, targetFeatureClassName, geometryDef, targetFeatureClassFields, "", 1000, 0);
                    break;
                }        
            }    
        }
        private void ExportRasterLayerAs(IRasterLayer rstlayer)
        {
            //��صĲ㵼������
            //ESRI GRID, ERDAS IMAGINE, or TIFF formats are supported
            SaveFileDialog saveFileDialog1=new SaveFileDialog();
            saveFileDialog1.Filter = @"TIFF files (*.tif)|*.tif|IMAGE files (*.img)|*.img|ESRI GRID files (*.*)|*.*";
            string []strFilter = {"TIFF","IMAGINE Image","GRID"};
            if(saveFileDialog1.ShowDialog()!= DialogResult.OK) return;

            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor;
            System.Threading.Thread.Sleep(100);

            //save raster file
            ISaveAs saveAs = rstlayer.Raster as ISaveAs;
            if(saveAs==null)return;
            if (saveAs.CanSaveAs(strFilter[saveFileDialog1.FilterIndex-1]) && !System.IO.File.Exists(saveFileDialog1.FileName) )//
            {
                try
                {
                    saveAs.SaveAs(saveFileDialog1.FileName, null,strFilter[saveFileDialog1.FilterIndex-1]);
                }
                catch
                {
                    System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default;
                    MessageBox.Show("�ļ�������̳�����");
                }
            }
            else
            {
                System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default;
                 MessageBox.Show("�����ļ�·���Ѿ����ڻ��߸�ʽ������������ȷ�����ļ�", "������ʾ",
                     MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }

            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default;
        }
        #endregion
    }
}
