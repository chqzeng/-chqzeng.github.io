//�ļ�����Ȩ��Ϣ------------------
/*
 * ���ļ������п���ͼ���¿Ƽ����޹�˾����ҵ����ƽ̨����ɲ���
 * δ���������ÿ���������������������ҵ��;
 * ��Ȩ���У��п���ͼ���¿Ƽ����޹�˾(http://www.mapuni.com/) 
 * �������ߣ�������   chqzeng@163.com 
 * ��дʱ�䣺2010-09-01
 */
using System;
using System.Drawing;
using System.Runtime.InteropServices;
using ESRI.ArcGIS.ADF.BaseClasses;
using ESRI.ArcGIS.ADF.CATIDs;
using ESRI.ArcGIS.Controls;

using ESRI.ArcGIS.Carto;
namespace YuTuSurveyPlatform
{
    /// <summary>
    /// Summary description for RMenu_RemoveLabel.
    /// �Ҽ��˵� ��ɾ����ע
    /// </summary>
    [Guid("1471124b-e61f-48d7-956e-a175c28e5ebf")]
    [ClassInterface(ClassInterfaceType.None)]
    [ProgId("YuTuSurveyPlatform.RMenu_RemoveLabel")]
    public sealed class RMenu_RemoveLabel : BaseCommand
    {
        #region COM Registration Function(s)
        [ComRegisterFunction()]
        [ComVisible(false)]
        static void RegisterFunction(Type registerType)
        {
            // Required for ArcGIS Component Category Registrar support
            ArcGISCategoryRegistration(registerType);

            //
            // TODO: Add any COM registration code here
            //
        }

        [ComUnregisterFunction()]
        [ComVisible(false)]
        static void UnregisterFunction(Type registerType)
        {
            // Required for ArcGIS Component Category Registrar support
            ArcGISCategoryUnregistration(registerType);

            //
            // TODO: Add any COM unregistration code here
            //
        }

        #region ArcGIS Component Category Registrar generated code
        /// <summary>
        /// Required method for ArcGIS Component Category registration -
        /// Do not modify the contents of this method with the code editor.
        /// </summary>
        private static void ArcGISCategoryRegistration(Type registerType)
        {
            string regKey = string.Format("HKEY_CLASSES_ROOT\\CLSID\\{{{0}}}", registerType.GUID);
            ControlsCommands.Register(regKey);

        }
        /// <summary>
        /// Required method for ArcGIS Component Category unregistration -
        /// Do not modify the contents of this method with the code editor.
        /// </summary>
        private static void ArcGISCategoryUnregistration(Type registerType)
        {
            string regKey = string.Format("HKEY_CLASSES_ROOT\\CLSID\\{{{0}}}", registerType.GUID);
            ControlsCommands.Unregister(regKey);

        }

        #endregion
        #endregion

        private IHookHelper m_hookHelper;

        private IMapControl3 m_mapControl;
        public RMenu_RemoveLabel()
        {
            //
            // TODO: Define values for the public properties
            //
            base.m_category = ""; //localizable text
            base.m_caption = "���ע��";  //localizable text
            base.m_message = "���ע��";  //localizable text 
            base.m_toolTip = "���ע��";  //localizable text 
            base.m_name = "RemoveLabel";   //unique id, non-localizable (e.g. "MyCategory_MyCommand")

           
        }

        #region Overriden Class Methods

        /// <summary>
        /// Occurs when this command is created
        /// </summary>
        /// <param name="hook">Instance of the application</param>
        public override void OnCreate(object hook)
        {
            if (hook == null)
                return;

            if (m_hookHelper == null)
                m_hookHelper = new HookHelperClass();

            m_hookHelper.Hook = hook;

            m_mapControl = (IMapControl3)hook;
            // TODO:  Add other initialization code
        }

        public override bool Enabled
        {
            get
            {
                bool enabled = false;
                try
                {
                    IFeatureLayer layer = (IFeatureLayer)m_mapControl.CustomProperty;
                    if (layer != null) enabled = true;
                }
                catch { }

                return enabled;
            }
        }
        /// <summary>
        /// Occurs when this command is clicked
        /// </summary>
        public override void OnClick()
        {
            // TODO: Add RMenu_AddLabel.OnClick implementation
            //ILayer layer = (ILayer)m_mapControl.CustomProperty;
            IFeatureLayer layer = null;
            try
            {
                layer = (IFeatureLayer)m_mapControl.CustomProperty;
                if (layer == null) return;  //����ʸ������Ч
            }
            catch { return; }

            IGeoFeatureLayer lyr = layer as IGeoFeatureLayer;

            m_mapControl.MousePointer = esriControlsMousePointer.esriPointerHourglass;

            //IAnnotateLayerPropertiesCollection AnnPropCollection;
            //AnnPropCollection = lyr.AnnotationProperties;
            //AnnPropCollection.Clear();

            lyr.DisplayAnnotation = false;
            //Refresh the display 
            m_mapControl.ActiveView.Refresh();//PartialRefresh(esriViewDrawPhase.esriViewGraphics, layer, null);

            m_mapControl.MousePointer = esriControlsMousePointer.esriPointerDefault;
        }

        #endregion
    }
}
