//�ļ�����Ȩ��Ϣ------------------
/*
 * ���ļ������п���ͼ���¿Ƽ����޹�˾����ҵ����ƽ̨����ɲ���
 * δ���������ÿ���������������������ҵ��;
 * ��Ȩ���У��п���ͼ���¿Ƽ����޹�˾(http://www.mapuni.com/) 
 * �������ߣ�������   chqzeng@163.com 
 * ��дʱ�䣺2010-09-01
 */
using System;
using System.Collections.Generic;
using System.Text;

using ESRI.ArcGIS.ADF.BaseClasses;
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.Controls;
using ESRI.ArcGIS.Geodatabase;
using ESRI.ArcGIS.DataSourcesRaster;

using System.Runtime.InteropServices;
namespace YuTuSurveyPlatform
{
    
    /// <summary>
    /// Summary description for RMenu_RemoveLabel.
    /// �Ҽ��˵� ��ɾ��ͼ�㣬��ά��ͼ���б� 
    /// </summary>
    public sealed class RMenu_RemoveLayer : BaseCommand
    {
        private IMapControl3 m_mapControl;

        List<MyLayerInfo> m_LayerList;

        public RMenu_RemoveLayer(ref List<MyLayerInfo> LayerList)
        {
            base.m_caption = "�Ƴ�ͼ��";
            m_LayerList = LayerList;
        }
     /*   public void UpdateMapUnits(IMapControl3 axMapControl1)
        {
            esriUnits mapUnits = axMapControl1.ActiveView.FocusMap.MapUnits;
            switch (mapUnits)
            {
                case esriUnits.esriCentimeters:
                    sMapUnits = "����";
                    break;
                case esriUnits.esriDecimalDegrees:
                    sMapUnits = "ʮ���ƶ���";
                    break;
                case esriUnits.esriDecimeters:
                    sMapUnits = "����";
                    break;
                case esriUnits.esriFeet:
                    sMapUnits = "Ӣ��";
                    break;
                case esriUnits.esriInches:
                    sMapUnits = "Ӣ��";
                    break;
                case esriUnits.esriKilometers:
                    sMapUnits = "����";
                    break;
                case esriUnits.esriMeters:
                    sMapUnits = "��";
                    break;
                case esriUnits.esriMiles:
                    sMapUnits = "Ӣ��";
                    break;
                case esriUnits.esriMillimeters:
                    sMapUnits = "ǧ��";
                    break;
                case esriUnits.esriNauticalMiles:
                    sMapUnits = "����";
                    break;
                case esriUnits.esriPoints:
                    sMapUnits = "��";
                    break;
                case esriUnits.esriUnknownUnits:
                    sMapUnits = "δ֪";
                    break;
                case esriUnits.esriYards:
                    sMapUnits = "��";
                    break;
            }
        }
    */    
        
        public override void OnClick()
        {
            ILayer layer = (ILayer)m_mapControl.CustomProperty;

            for (int index = 0; index < m_LayerList.Count; index++)
            {
                if (layer.Name == m_LayerList[index].LayerName)
                { 
                    m_LayerList.RemoveAt(index); 
                    break; 
                }
            }
            IFeatureLayer ftLyr = layer as IFeatureLayer;
            IRasterLayer  rstLyr= layer as IRasterLayer;
            IWorkspace pWs=null;
            if (rstLyr != null) pWs = (rstLyr as IDataset).Workspace;

            m_mapControl.Map.DeleteLayer(layer);

            if (ftLyr != null && ftLyr.Name.Contains(".yvt"))  //yutu ��ʽ���� �����
            {
                //if(ftLyr.Name.ToUpper().Contains("POI")) 

                IDataset curDS = ftLyr.FeatureClass as IDataset;
                if (curDS != null)
                {
                    curDS.Delete();
                }
                
            }
            else if (rstLyr != null)
            {
                IRasterWorkspace pRWS = pWs as  IRasterWorkspace;
                IRasterDataset pRasterDataset = pRWS.OpenRasterDataset(rstLyr.Name);
                    IDataset pDataset = pRasterDataset as IDataset;
                    if (pDataset.CanDelete())
                    {
                        pDataset.Delete();
                    }
            }


            Marshal.FinalReleaseComObject(layer);

            //UpdateMapUnits(m_mapControl);
        }
        public override void OnCreate(object hook)
        {
          m_mapControl = (IMapControl3)hook;
        }
    }

}
