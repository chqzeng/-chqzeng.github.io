﻿//文件及版权信息------------------
/*
 * 本文件属于中科宇图天下科技有限公司的外业测量平台的组成部分
 * 未经允许不得拷贝、传播，不得用于商业用途
 * 版权所有：中科宇图天下科技有限公司(http://www.mapuni.com/) 
 * 软件作者：曾垂卿   chqzeng@163.com 
 * 编写时间：2010-09-01
 */
using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Runtime.InteropServices;

namespace YuTuSurveyPlatform
{

    /// <summary> 
    /// 读写ini文件
    /// </summary> 
    /// 
    public  class IniFileRW
    {
        //文件INI名称 
        private string Path;

        ////声明读写INI文件的API函数 
        [DllImport("kernel32")]
        private static extern long WritePrivateProfileString(string section, string key, string val, string filePath);


        [DllImport("kernel32")]
        private static extern int GetPrivateProfileString(string section, string key, string def, StringBuilder retVal, int size, string filePath);
        

        //类的构造函数，传递INI文件名 
        public IniFileRW(string inipath)
        {

            Path = inipath;

        }
        

        //写INI文件 
        public void IniWriteValue(string Section, string Key, string Value)
        {
            WritePrivateProfileString(Section, Key, Value, this.Path);
        }


        //读取INI文件指定 
        public string IniReadValue(string Section, string Key)
        {
            StringBuilder temp = new StringBuilder(255);

            int i = GetPrivateProfileString(Section, Key, "", temp, 255, this.Path);

            return temp.ToString();

        }
    }
    /// <summary>
    /// 工程文件的管理 
    /// 包括存储当前工程的层、视口范围大小
    /// </summary>
    public class ProjectInfoMng
    {
        /// <summary>
        /// Reads the project file info.
        /// 读工程文件
        /// </summary>
        /// <param name="sPath">The s path. 工程文件路径</param>
        /// <param name="RSTFileList">The RST file list. 将读出来的加密栅格数据文件名列表</param>
        /// <param name="SHPFileList">The SHP file list.将读出来的加密矢量数据文件名列表</param>
        /// <param name="YVTFileList">The YVT file list.将读出来的宇图(YVT)数据文件名列表</param>
        /// <param name="MinX">The min X. 视口外框范围MINX</param>
        /// <param name="MinY">The min Y. 视口外框范围MINy</param>
        /// <param name="MaxX">The max X. 视口外框范围MAXX</param>
        /// <param name="MaxY">The max Y. 视口外框范围MAXY</param>
        /// <returns>是否执行成功</returns>
        public static bool ReadProjectFileInfo(string sPath, out List<string> RSTFileList, out List<string> SHPFileList, out List<string> YVTFileList, out double MinX, out double MinY, out double MaxX, out double MaxY)
        {
            RSTFileList= new List<string>();
            SHPFileList = new List<string>();
            YVTFileList = new List<string>();

            IniFileRW ini = new IniFileRW(sPath);

            string strTempRead = ini.IniReadValue("RSTFileListInfo", "RSTFileNum");
            int RSTFileNum = Convert.ToInt32(strTempRead);
            for (int index = 0; index < RSTFileNum; index++)
            {
                RSTFileList.Add(ini.IniReadValue("RSTFileListInfo", "RSTFileName" + index.ToString()));
            }

            strTempRead = ini.IniReadValue("SHPFileListInfo", "SHPFileNum");
            int SHPFileNum = Convert.ToInt32(strTempRead);
            for (int index = 0; index < SHPFileNum; index++)
            {
                SHPFileList.Add(ini.IniReadValue("SHPFileListInfo", "SHPFileName" + index.ToString()));
            }

            strTempRead = ini.IniReadValue("YVTFileListInfo", "YVTFileNum");
            int YVTFileNum = Convert.ToInt32(strTempRead);
            for (int index = 0; index < YVTFileNum; index++)
            {
                YVTFileList.Add(ini.IniReadValue("YVTFileListInfo", "YVTFileName" + index.ToString()));
            }

            MinX=Convert.ToDouble( ini.IniReadValue("ExtentInfo", "MinX"));
            MinY = Convert.ToDouble(ini.IniReadValue("ExtentInfo", "MinY"));
            MaxX = Convert.ToDouble(ini.IniReadValue("ExtentInfo", "MaxX"));
            MaxY = Convert.ToDouble(ini.IniReadValue("ExtentInfo", "MaxY"));

            return true;
        }

        /// <summary>
        /// Reads the project file info.
        /// 写工程文件
        /// </summary>
        /// <param name="sPath">The s path. 工程文件路径</param>
        /// <param name="RSTFileList">The RST file list. 将写入的加密栅格数据文件名列表</param>
        /// <param name="SHPFileList">The SHP file list.将写入的加密矢量数据文件名列表</param>
        /// <param name="YVTFileList">The YVT file list.将写入的宇图(YVT)数据文件名列表</param>
        /// <param name="MinX">The min X. 视口外框范围MINX</param>
        /// <param name="MinY">The min Y. 视口外框范围MINy</param>
        /// <param name="MaxX">The max X. 视口外框范围MAXX</param>
        /// <param name="MaxY">The max Y. 视口外框范围MAXY</param>
        /// <returns>是否执行成功</returns>
        public static void WriteProjectFileInfo(string sPath, List<string> RSTFileList, List<string> SHPFileList, List<string> YVTFileList, double MinX, double MinY, double MaxX, double MaxY)
        {
            IniFileRW ini = new IniFileRW(sPath);

            //write file lis info
            int RSTFileNum = RSTFileList.Count;
            ini.IniWriteValue("RSTFileListInfo", "RSTFileNum", RSTFileNum.ToString());
            for (int index = 0; index < RSTFileNum; index++)
            {
                ini.IniWriteValue("RSTFileListInfo", "RSTFileName" + index.ToString(), RSTFileList[index]);
            }

            int SHPFileNum = SHPFileList.Count;
            ini.IniWriteValue("SHPFileListInfo", "SHPFileNum", SHPFileNum.ToString());
            for (int index = 0; index < SHPFileNum; index++)
            {
                ini.IniWriteValue("SHPFileListInfo", "SHPFileName" + index.ToString(), SHPFileList[index]);
            }

            int YVTFileNum = YVTFileList.Count;
            ini.IniWriteValue("YVTFileListInfo", "YVTFileNum", YVTFileNum.ToString());
            for (int index = 0; index < YVTFileNum; index++)
            {
                ini.IniWriteValue("YVTFileListInfo", "YVTFileName" + index.ToString(), YVTFileList[index]);
            }


            //write extent lis info
            ini.IniWriteValue("ExtentInfo", "MinX", MinX.ToString());
            ini.IniWriteValue("ExtentInfo", "MinY", MinY.ToString());
            ini.IniWriteValue("ExtentInfo", "MaxX", MaxX.ToString());
            ini.IniWriteValue("ExtentInfo", "MaxY", MaxY.ToString());
        }
    }

}
