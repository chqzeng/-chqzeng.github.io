//�ļ�����Ȩ��Ϣ------------------
/*
 * ���ļ������п���ͼ���¿Ƽ����޹�˾����ҵ����ƽ̨����ɲ���
 * δ���������ÿ���������������������ҵ��;
 * ��Ȩ���У��п���ͼ���¿Ƽ����޹�˾(http://www.mapuni.com/) 
 * �������ߣ�������   chqzeng@163.com 
 * ��дʱ�䣺2010-09-01
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using GPSManager;

using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.InteropServices;

//arcGIS reference
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.Controls;
using ESRI.ArcGIS.esriSystem;
using ESRI.ArcGIS.Display;
using ESRI.ArcGIS.Geometry;
using ESRI.ArcGIS.SystemUI;
using ESRI.ArcGIS.Geodatabase;
using ESRI.ArcGIS.Output;
using ESRI.ArcGIS.DataSourcesRaster;

using ESRI.ArcGIS.DataSourcesFile;
using ESRI.ArcGIS.DataSourcesGDB;

namespace YuTuSurveyPlatform
{
    /// <summary>
    /// ���ļ���Ҫ�����ڵ�ͼ��صĲ�����
    /// ������������غ�����һ����
    /// </summary>
    /// 

    public partial class MainInterface : Form
    {

        /// <summary>
        /// Axes the TOC control1_ on mouse down.
        /// ���TOC����Ϣ
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The e.</param>
        private void axTOCControl1_OnMouseDown(object sender, ITOCControlEvents_OnMouseDownEvent e)
        {
            //��������Ҽ�����ֱ�ӷ���
            if (e.button != 2) return;

            esriTOCControlItem item = esriTOCControlItem.esriTOCControlItemNone;
            IBasicMap map = null;
            ILayer layer = null;
            object other = null;
            object index = null;
            //�ж���ѡ�˵�������
            m_tocControl.HitTest(e.x, e.y, ref item, ref map, ref layer, ref other, ref index);

            //ȷ��ѡ���Ĳ˵����ͣ�Map����ͼ��˵�
            if (item == esriTOCControlItem.esriTOCControlItemMap)
                m_tocControl.SelectItem(map, null);
            else
                m_tocControl.SelectItem(layer, null);
            //����CustomPropertyΪlayer (�����Զ����Layer����)
            m_mapControl.CustomProperty = layer;
            //�����Ҽ��˵�
            if (item == esriTOCControlItem.esriTOCControlItemMap)
                m_menuMap.PopupMenu(e.x, e.y, m_tocControl.hWnd);

            if (item == esriTOCControlItem.esriTOCControlItemLayer)
            {
                //��̬����OpenAttributeTable�˵���
                m_menuLayer.AddItem(new OpenAttributeTable(layer, GetPathByLayerName(layer.Name)), -1, 1, true, esriCommandStyles.esriCommandStyleTextOnly);
                m_menuLayer.PopupMenu(e.x, e.y, m_tocControl.hWnd);
                //�Ƴ�OpenAttributeTable�˵���Է�ֹ�ظ�����
                m_menuLayer.Remove(1);
            }
        }

        /// <summary>
        /// Axes the TOC control1_ on double click.
        /// ˫��TOC����Ϣ
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The e.</param>
        private void axTOCControl1_OnDoubleClick(object sender, ITOCControlEvents_OnDoubleClickEvent e)
        {
            esriTOCControlItem itemType = esriTOCControlItem.esriTOCControlItemNone;
            IBasicMap basicMap = null;
            ILayer layer = null;
            object unk = null;
            object data = null;
            axTOCControl1.HitTest(e.x, e.y, ref itemType, ref basicMap, ref layer, ref unk, ref data);
            if (e.button == 1)
            {
                if (itemType == esriTOCControlItem.esriTOCControlItemLegendClass)
                {
                    //ȡ��ͼ��
                    ILegendClass pLegendClass = ((ILegendGroup)unk).get_Class((int)data);
                    //��������ѡ����SymbolSelectorʵ��
                    SymbolSelectorFrm SymbolSelectorFrm = new SymbolSelectorFrm(pLegendClass.Symbol, ((IFeatureLayer)layer).FeatureClass.ShapeType);
                    if (SymbolSelectorFrm.ShowDialog() == DialogResult.OK)
                    {
                        //�ֲ�������Map�ؼ�
                        this.axMapControl1.ActiveView.PartialRefresh(esriViewDrawPhase.esriViewGeography, null, null);
                        //�����µķ���
                        pLegendClass.Symbol = SymbolSelectorFrm.pSymbol;
                        //������Map�ؼ���ͼ��ؼ�
                        this.axMapControl1.ActiveView.Refresh();
                        this.axTOCControl1.Refresh();
                    }
                }

            }
        }

        /// <summary>
        /// Axes the map control1_ on mouse down.
        /// �����ͼ������ ��Ϣ
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The e.</param>
        private void axMapControl1_OnMouseDown(object sender, IMapControlEvents2_OnMouseDownEvent e)
        {
            if (e.button == 2)
            {
                //�����Ҽ��˵�
                if (b_IsEditMode) //�༭ģʽ
                {
                    m_EdittoolbarMenu.PopupMenu(e.x, e.y, m_mapControl.hWnd);
                }
                else
                {
                    m_menuMap.PopupMenu(e.x, e.y, m_mapControl.hWnd);
                }
            }
            else if (false) //m_bCurEditToolEdit = 
            {
                SelectLayerByPT(this.axMapControl1 as IMapControl2, e.x, e.y, 20);
            }
            
        }

        /// <summary>
        /// Axes the map control1_ on mouse move.
        ///  ����� ��ͼ������ ��Ϣ
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The e.</param>
        private void axMapControl1_OnMouseMove(object sender, IMapControlEvents2_OnMouseMoveEvent e)
        {
            if (this.axMapControl1.LayerCount <= 0) return;
            // ��ʾ��ǰ������
            ScaleLabel.Text = " ������ 1:" + ((long)this.axMapControl1.MapScale).ToString();

            // ��ʾ��ǰ����
            CoordinatesLabel.Text = "   ��ǰ���� X = " + e.mapX.ToString() + " Y = " + e.mapY.ToString() + " " + sMapUnits; //this.axMapControl1.MapUnits;

            IEngineEditor editor = new EngineEditorClass();//m_bCurEditToolEdit =
            if ( false && editor.EditState == esriEngineEditState.esriEngineStateEditing)// && editor.CurrentTask.UniqueName == "ControlToolsEditing_ModifyFeatureTask")
            {
                IFeatureLayer lyr = (editor as IEngineEditLayers).TargetLayer;
                TrackMapSnapSelection(lyr,e.x,e.y);
            }
        }

        /// <summary>
        /// Updates the map units.
        /// ���µ�ͼ״̬���е���ʾ��Ϣ
        /// </summary>
        /// <param name="m_view">The m_view.</param>
        public void UpdateMapUnits(IActiveView m_view)//AxMapControl axMapControl1
        {
            // ��ʾ��ǰ������
            //((long)this.axMapControl1.MapScale).ToString();

            string str = (m_view.FocusMap.MapScale).ToString();
            string strOut = str;
            int pos = str.IndexOf(".");
            if (pos < 0) pos = str.Length;
            for (int index = pos - 3; index > 0; index = index - 3)
            {
                strOut = strOut.Insert(index, ",");
            }
            pos = strOut.IndexOf(".");
            if (pos < 0) pos = strOut.Length;
            strOut = strOut.Substring(0, pos);
            comboBox_scalebox.Text = "1:" + strOut;

            esriUnits mapUnits = m_view.FocusMap.MapUnits;
            switch (mapUnits)
            {
                case esriUnits.esriCentimeters:
                    sMapUnits = "����";
                    break;
                case esriUnits.esriDecimalDegrees:
                    sMapUnits = "ʮ���ƶ���";
                    break;
                case esriUnits.esriDecimeters:
                    sMapUnits = "����";
                    break;
                case esriUnits.esriFeet:
                    sMapUnits = "Ӣ��";
                    break;
                case esriUnits.esriInches:
                    sMapUnits = "Ӣ��";
                    break;
                case esriUnits.esriKilometers:
                    sMapUnits = "����";
                    break;
                case esriUnits.esriMeters:
                    sMapUnits = "��";
                    break;
                case esriUnits.esriMiles:
                    sMapUnits = "Ӣ��";
                    break;
                case esriUnits.esriMillimeters:
                    sMapUnits = "ǧ��";
                    break;
                case esriUnits.esriNauticalMiles:
                    sMapUnits = "����";
                    break;
                case esriUnits.esriPoints:
                    sMapUnits = "��";
                    break;
                case esriUnits.esriUnknownUnits:
                    sMapUnits = "δ֪";
                    break;
                case esriUnits.esriYards:
                    sMapUnits = "��";
                    break;
            }
        }


        /// <summary>
        /// Axes the map control1_ on map replaced.
        /// ����ͼ�е�ͼ�����ݷ����仯 ʱ����Ӧ���º���
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The e.</param>
        private void axMapControl1_OnMapReplaced(object sender, IMapControlEvents2_OnMapReplacedEvent e)
        {
            UpdateMapUnits(this.axMapControl1.ActiveView);
        }

        /// <summary>
        /// Axes the map control1_ on after draw.
        /// �����Ժ���Ӧ���º���
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The e.</param>
        private void axMapControl1_OnAfterDraw(object sender, IMapControlEvents2_OnAfterDrawEvent e)
        {
            if (this.axMapControl1.LayerCount <= 0) return;

            UpdateMapUnits(this.axMapControl1.ActiveView);
        }


#region MENU MESSAGE �˵���Ϣ��Ӧ

        /// <summary>
        /// 	<Description>�� ȫͼ�� ��Ϣ��Ӧ����: MENU_VIEW_GLOBAL_Click</Description>
        /// </summary>
        /// <param name="sender">��Ϣ��Դ������</param>
        /// <param name="e">���͵���Ϣ����</param>
        private void MENU_VIEW_GLOBAL_Click(object sender, EventArgs e)
        {
            try
            {
                this.axMapControl1.Extent = this.axMapControl1.FullExtent;
            }
            catch{}
           
        }

        /// <summary>
        /// 	<Description>���Ŵ� �� ��Ϣ��Ӧ����: MENU_VIEW_ZOOMIN_Click</Description>
        /// </summary>
        /// <param name="sender">��Ϣ��Դ������</param>
        /// <param name="e">���͵���Ϣ����</param>
        private void MENU_VIEW_ZOOMIN_Click(object sender, EventArgs e)
        {
            try
            {
                ICommand pCommand;
                pCommand = new ControlsMapZoomInTool();

                pCommand.OnCreate(axMapControl1.Object);

                axMapControl1.CurrentTool = pCommand as ITool;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
        }

        /// <summary>
        /// 	<Description>����С �� ��Ϣ��Ӧ����: MENU_VIEW_ZOOMOUT_Click</Description>
        /// </summary>
        /// <param name="sender">��Ϣ��Դ������</param>
        /// <param name="e">���͵���Ϣ����</param>
        private void MENU_VIEW_ZOOMOUT_Click(object sender, EventArgs e)
        {
            try
            {
                ICommand pCommand;
                pCommand = new ControlsMapZoomOutTool();

                pCommand.OnCreate(axMapControl1.Object);

                axMapControl1.CurrentTool = pCommand as ITool;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
        }

        /// <summary>
        /// 	<Description>�� ���Ρ� ��Ϣ��Ӧ����: MENU_VIEW_PAN_Click</Description>
        /// </summary>
        /// <param name="sender">��Ϣ��Դ������</param>
        /// <param name="e">���͵���Ϣ����</param>
        private void MENU_VIEW_PAN_Click(object sender, EventArgs e)
        {
            try
            {
                ICommand pCommand;
                pCommand = new ControlsMapPanTool();

                pCommand.OnCreate(axMapControl1.Object);

                axMapControl1.CurrentTool = pCommand as ITool;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
        }
#endregion
    }
}