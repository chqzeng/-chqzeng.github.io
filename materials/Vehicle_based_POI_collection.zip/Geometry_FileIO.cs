using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace readWriteBinaryFile
{
    public partial class Form1 : Form
    {
        private const string FILE_NAME = "Test.dx";   //�����ļ���
        private string filepath;

        //�������ݽṹ
        public struct ADdata
        {
            public Int32 ch;
            public Double piyiliang;
            public Double xiuzhengxs;
            public Int32 gongchengl;
            public Double shangxianz;
            public Double xiaxianz;
            public Double liangcheng;
        };
        public Form1()
        {
            InitializeComponent();
            filepath = System.Windows.Forms.Application.StartupPath +"\\" + FILE_NAME;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //д����

             // ����Ƿ��ļ��Ѿ�����
            if (!(File.Exists(FILE_NAME)))
            {
                MessageBox.Show("�ļ�Test.dx�����ڣ������½�Test.dx�ļ�","��ʾ",MessageBoxButtons.OK,MessageBoxIcon.Information);
                FileStream fs = new FileStream(FILE_NAME, FileMode.CreateNew);//�����ļ�
                fs.Close();//�ر��ļ�                
            }
           
            //׼������
            ADdata [] ax = new ADdata[16];
            for (int i = 0; i < 16; i++)
            {
                ax[i].ch = i;
                ax[i].piyiliang = 0;
                ax[i].xiuzhengxs = 0;
                ax[i].gongchengl = 0;
                ax[i].shangxianz = 5;
                ax[i].xiaxianz = 0;
                ax[i].liangcheng = 5;
            }


            FileStream fss = new FileStream(filepath, FileMode.Append);
            // ����д��
            BinaryWriter w = new BinaryWriter(fss);
            for (int j = 0; j < 16; j++)
            {
                w.Write(ax[j].ch);
                w.Write(ax[j].piyiliang);
                w.Write(ax[j].xiuzhengxs);
                w.Write(ax[j].gongchengl);
                w.Write(ax[j].shangxianz);
                w.Write(ax[j].xiaxianz);
                w.Write(ax[j].liangcheng);
            }
            w.Close();
            fss.Close();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //������ȡ��.
            FileStream fs = new FileStream(FILE_NAME, FileMode.Open, FileAccess.Read);
            BinaryReader r = new BinaryReader(fs);
            textBox1.Text = "";
            int t = r.ReadInt32();
            textBox1.Text = t.ToString();
            double x = r.ReadDouble();
            textBox1.Text =textBox1.Text + "\r\n" + x.ToString();
            x = r.ReadDouble();
            textBox1.Text = textBox1.Text + "\r\n" + x.ToString();
            t = r.ReadInt32();
            textBox1.Text = textBox1.Text + "\r\n" + t.ToString();
            x = r.ReadDouble();
            textBox1.Text = textBox1.Text + "\r\n" + x.ToString();
            x = r.ReadDouble();
            textBox1.Text = textBox1.Text + "\r\n" + x.ToString();
            x = r.ReadDouble();
            textBox1.Text = textBox1.Text + "\r\n" + x.ToString();            
            r.Close();
            fs.Close();

        }
    }
}

class Program
{
static void Main(string[]args)
{
   Console.WriteLine("�������ļ�����");
   string filename = Console.ReadLine(); //��ȡ�����ļ���
   FileStream fs; //����FileStream����
   try
   {
    fs = new FileStream(filename, FileMode.Create); //��ʼ��FileStream����
    BinaryWriter bw = new BinaryWriter(fs); //����BinaryWriter����
    //д���ļ�
    bw.Write('a');
    bw.Write(123);
    bw.Write(456.789);
    bw.Write("Hello World!");
    Console.WriteLine("�ɹ�д��");
    bw.Close(); //�ر�BinaryWriter����
    fs.Close(); //�ر��ļ���
   }
   catch (IOException ex)
   {
    Console.WriteLine(ex.Message);
   }
}
}

class MyStream 
{
    private const string FILE_NAME = "Test.data";   //�����ļ���
    public static void Main(String[] args) 
    {
        // ����Ƿ��ļ��Ѿ�����
        if (File.Exists(FILE_NAME)) 
        {
            Console.WriteLine("{0} already exists!", FILE_NAME);
            return;
        }
        FileStream fs = new FileStream(FILE_NAME, FileMode.CreateNew);
        // ������д��
        BinaryWriter w = new BinaryWriter(fs);
        // д���������
        for (int i = 0; i < 11; i++) 
        {
            w.Write( (int) i);
        }
        w.Close();
        fs.Close();
        //������ȡ��.
        fs = new FileStream(FILE_NAME, FileMode.Open, FileAccess.Read);
        BinaryReader r = new BinaryReader(fs);


        // ��ȡ��������

        for (int i = 0; i < 11; i++) 
        {
            Console.WriteLine(r.ReadInt32());
        }
        r.Close();
        fs.Close();
    }
}

