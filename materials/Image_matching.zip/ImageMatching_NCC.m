%% Setup
clc
clear all

%% Read files from directory

NIR_Dir='D:\Aditya\Data\IcelandDB\PatternMatch\Code\clipMatch\Input\Warp\NIR';
VIS_Dir='D:\Aditya\Data\IcelandDB\PatternMatch\Code\clipMatch\Input\Warp\VIS';
OUT_Dir='D:\Aditya\Data\IcelandDB\PatternMatch\Code\clipMatch\Input\Warp\OUT';

NIR_d=dir(fullfile([NIR_Dir,'\*.jpg']));
NIR_n={NIR_d.name};

for ni=1:length(NIR_n)
    NIRfn=NIR_n{ni};
    NIRsp=regexp(NIRfn,'_','split');
    OUTbn=[NIRsp{1},'_',NIRsp{2}];
    VISfn=dir(fullfile([VIS_Dir,'\',OUTbn,'*.jpg']));
    VISfn=VISfn.name;
    display({NIRfn,VISfn})
    
    display(['Processing ',VISfn])
    
    baseImg=imread([VIS_Dir,'\',VISfn]);
    shftImg=imread([NIR_Dir,'\',NIRfn]);
    [r,c,b]=size(baseImg);

    % the same region in NIR
    xOff=200;               % Side margin to ignore
    yOff=100;               % Top margin to ignore
    % Keep this always even, or a clean multiple of the denominator of cSz.
    tSz=500;                % Half the size of tile to be panned, template is this*2+1 big
    cSz=50;      % Size of template to be matched as a fraction of tile size
    xtVec=(xOff:floor((cSz*2+1)*2.0):(c-(tSz*2+1)-xOff));
    ytVec=(yOff:floor((cSz*2+1)*2.0):(r-(tSz*2+1)-yOff));

    zbaseImg=zscore(double(baseImg));
    zshftImg=zscore(double(shftImg));
    
    imgQual=1;
    ccLim=0.75;
    fltDm=10;
    outVec=zeros(length(xtVec)*length(ytVec),4);
    doAgain=1;
    while doAgain==1
        ctr=0;
        ccCnt=0;
        for i=1:length(xtVec)
            for j=1:length(ytVec)
                ctr=ctr+1;
                xTop=xtVec(i);
                yTop=ytVec(j);
                vRect=[xTop,yTop,tSz*2,tSz*2];
                vCrop=imcrop(zbaseImg,vRect);
                H=fspecial('average',fltDm);
                vCrop=imfilter(vCrop,H);
                vTx=xTop+tSz-cSz;
                vTy=yTop+tSz-cSz;
                vTemp=[vTx,vTy,cSz*2,cSz*2];
                nCrop=imcrop(zshftImg,vTemp);
                nCrop=imfilter(nCrop,H);
                cc=normxcorr2(nCrop(:,:,3),vCrop(:,:,2));
                [max_cc,imax]=max(abs(cc(:)));
                if max_cc>ccLim
                    ccCnt=ccCnt+1;
                    display('Good')
                    [yPeak,xPeak]=ind2sub(size(cc),imax(1));
                    display(max_cc)
                    xPlot=xPeak-size(nCrop,1)+xTop;
                    yPlot=yPeak-size(nCrop,2)+yTop;
                    intVec=[vTx,vTy,xPlot,yPlot];
                    if ccCnt==1
                        outVec=intVec;
                    else
                        outVec=[outVec;intVec];
                    end
                end
                display([num2str((length(xtVec)*length(ytVec))-ctr),' remaining, points coll. ',num2str(ccCnt)])
            end
        end
        % If number of matched templates < 20, reduce cc limit and do again
        if ccCnt<15
            doAgain=1;
            ccLim=ccLim-0.05;
            imgQual=imgQual+1;
        else
            doAgain=0;
            break
        end
    end
    % Clean input points
    [bX,~,residsX] = regress(outVec(:,1),[ones(size(outVec,1),1) outVec(:,3) outVec(:,4) outVec(:,3).^2 outVec(:,4).^2 outVec(:,3).*outVec(:,4)]);
    [bY,~,residsY] = regress(outVec(:,2),[ones(size(outVec,1),1) outVec(:,3) outVec(:,4) outVec(:,3).^2 outVec(:,4).^2 outVec(:,3).*outVec(:,4)]);
    fullResids=max(abs([zscore(residsX) zscore(residsY)]'))';
    outVec=outVec(fullResids<1,:);
    % Warp NIR image to VIS image
    base_pts=outVec(:,1:2);
    inpt_pts=outVec(:,3:4);
    cpt_tform =cp2tform(inpt_pts,base_pts,'affine');
%     [trn_Img] =imtransform(shftImg,cpt_tform,'bicubic','FillValues',0,'XData',[1 size(baseImg,2)],'YData',[1 size(baseImg,1)]);
    [trn_Img] =imtransform(shftImg,cpt_tform,'bicubic','FillValues',0);

    figure(1)
    imshow(baseImg)
    hold on
    h=imshow(trn_Img,gray(256));
    set(h,'AlphaData',0.7)
    hold off
    
    crpRect=[850,450,2000,1600];
    bCrop=imcrop(baseImg,crpRect);
    oCrop=imcrop(trn_Img,crpRect);
    
    oImg=zeros(size(baseImg));
    oImg(:,:,1)=trn_Img(:,:,1);
    oImg(:,:,2)=baseImg(:,:,1);
    oImg(:,:,3)=baseImg(:,:,2);
    cImg=imcrop(oImg,crpRect);

    v_OUTfn=[OUTbn,'_VIS_MATCHWARP_',num2str(imgQual),'.jpg'];
    v_outFile=[OUT_Dir,'/',v_OUTfn];
    n_OUTfn=[OUTbn,'_NIR_MATCHWARP_',num2str(imgQual),'.jpg'];
    n_outFile=[OUT_Dir,'/',n_OUTfn];
    m_OUTfn=[OUTbn,'_CMB_MATCHWARP_',num2str(imgQual),'.jpg'];
    m_outFile=[OUT_Dir,'/',m_OUTfn];
    
%     imwrite(uint8(baseImg),v_outFile,'jpg')
%     imwrite(uint8(trn_Img),n_outFile,'jpg')
    imwrite(uint8(bCrop),v_outFile,'jpg')
    imwrite(uint8(oCrop),n_outFile,'jpg')
    imwrite(uint8(cImg),m_outFile,'jpg')
end
