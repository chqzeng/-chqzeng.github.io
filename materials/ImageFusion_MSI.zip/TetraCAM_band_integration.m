function Tetracam_band_ref = TetraCAM_band_integration(STS_spectra_Data, Filter, spec_mean,ground_dark_offset,...
                                STS_spectra_sun,sun_constant,dark_mean)
% This function is to further process a given array of spectra, by convert
% measured DN/intensity to convoluted TEtracam 10nm wide bands.
%
%  Params:
%   STS_spectra_Data: the array needed to be processed 
%   Filter: table with three columns: Wavelength_nm_, Tx____,STS_idx
%
%   spec_mean: the mean/average of the white reference spectra (before subtract dark offset)
%   ground_dark_offset: the dark offest of the ground pointing STS.
%
%   STS_spectra_sun:  the array of concurrent sun spectra measurement aligned with "STS_spectra_Data"
%   dark_mean: the mean of dark_offset for the sun STS measurment; if not provided, then no adjustment over illumination
%   sun_constant: the intensitey measured at the downwelling STS (point up), while measuring the white reference 
%
%   Tetracam_band_ref: the wider 10nm bands, according to the defintion of Input "Filter" 

% 
    unit_min2datenum=1/1440;
    unit_second2datenum=1/86400;  %convert from minutes to decimal of a day
    %convert meausred intensity into reflectance by : reflectance = (sample- offset) ./ (reference -offset) 
    STS_spectra_Data_R= spectra_remove_nullcell( STS_spectra_Data );
    num_list=length(STS_spectra_Data_R(:,1));
    Tetracam_band_ref=zeros(num_list,1);  %the output list of reflectance
    for idx=num_list:-1:1
            temp_spectra=STS_spectra_Data_R{idx,2};
            %calculate the convoluted reflectance
            spectra_adj=(temp_spectra(:,2)-ground_dark_offset);
            whiteref_adj=(spec_mean-ground_dark_offset);
            
            %calcuate the convoluted relfectance using the filter: sum(R_t.*F_t)/sum(I_t.*F_t)
            R_t=spectra_adj(Filter.STS_idx);
            I_t=whiteref_adj(Filter.STS_idx);
            F_t=Filter.Tx____;
            Tetracam_band_ref(idx)=sum(R_t.*F_t)/sum(I_t.*F_t);
            
            %adjust the reflectance by considering sun illumination change
            if ~isempty(dark_mean) && ~isempty(sun_constant) && ~isempty(STS_spectra_sun)
                time_tag=STS_spectra_Data_R{idx,1}; %acquisition time of the sample
                %time_tag =start_time + time_tag/60000 * unit_min2datenum;
                [val_sec,ind]=min(abs(cell2mat(STS_spectra_sun(:,1))-time_tag)/unit_second2datenum);  %find the closet sun observation spectra
                if isempty(ind) || ind <1 || val_sec>5  %invalid sun observation at this sample, or the time difference greater than 5seconds
                    adjust_coef=1; %ones(size(temp_spectra(:,2))); %equal to 1, not changed
                else  %need to change the first "offset" to the offset of the other STS-VIS.
                   % adjust_coef=sum(STS_spectra_sun{ind,2}(:,2)-dark_mean)./sum(sun_constant-dark_mean);
                    adjust_coef=(STS_spectra_sun{ind,2}(:,2)-dark_mean)./(sun_constant-dark_mean);
                    adjust_coef=median(adjust_coef(140:980)); %for the average of 400--800range
                end
                Tetracam_band_ref(idx)=Tetracam_band_ref(idx)./(adjust_coef);
            end
    end

    
end

