%load the HS and MS data after alignment
load('Jul21_MosaicFarm_UAV_flight3_step3_regression.mat');

%run different imputation approaches
Imputation_script_PCA
X_imputed_PCA=X_imputed;

Imputation_script_Bayesion
X_imputed_BAY=Ximpute;

Imputation_script_Spline
X_imputed_Spline=X_imputed;

%an exmaple to view all the curves on a given sample
idx=21; idy =4;  %the fourth missing sample, which is the 21th sample in all of the 128 samples.
figure; hold on;
plot(wavelength(f400_800nm),Jul21_MosaicFarm_flight2_Img_cnt_imputation(idx,7:end),'k','Linewidth',1);
plot(wavelength(f400_800nm),X_imputed_PCA(idx,7:end),'b--','Linewidth',1);
plot(wavelength(f400_800nm),X_imputed_BAY(idx,7:end),'m-.','Linewidth',1);
plot(wavelength(f400_800nm),X_imputed_Spline(idx,7:end),'g:','Linewidth',1.5);
plot([490 550 680 720 800],tetracam_bands_avg_2_ref(4,1:5),'rs','MarkerSize' ,8);
grid on, box on; hold off; 
ylim([-0.05 0.45]); xlabel('Wavelength(nm)');ylabel('Resdiual of reflectance');
legend('Observed','PCA','Bayesian','Spline','MS-band');
