%load the HS and MS data after alignment
%load('Jul21_MosaicFarm_UAV_flight3_step3_regression.mat');

%imputation of the data using the given Tetracam and STS-VIS data
wavelength=Spectra_veg_R{1,2}(:,1);

filter=[2873:3100]-2838; %remove some pics in the shade
TetraCAM_photo_centre_adj=TetraCAM_photo_centre(filter,:);

%build the training sample matrix using the matched TEtracam and STS-VIS data at the 5 bands
f400_800nm=140:980;
dt=-1.2; dx=-20 ; dy = 85;  % --> Rsquare(37,16,45,:) for the peak
new_dx=floor((id_dx+100)/5)+1;%range=100; interval=5;
new_dy=floor((id_dy+100)/5)+1;
Tetracam_6bands_avg=squeeze(TetraCAM_photo_centre_mat(filter,new_dx, new_dy,:)); %obtain the optimzed multispectral band values
%[IDX]=knnsearch(STS_spectra_centre.STS_tick-def_Tetracam_STS_offset,(TetraCAM_photo_centre_adj.TetraCAM_tick+dt),'K',1 );
[IDX]=knnsearch(STS_spectra_centre.STS_tick-def_Tetracam_STS_offset,(TetraCAM_photo_centre.new_tick(filter)+dt),'K',1 );
STS_spectra_matched_Tetracam = cell2mat((Spectra_veg_R(IDX,2))');  %obtain the 2nd column (spectra), at matched spectr points
STS_spectra_matched_Tetracam=STS_spectra_matched_Tetracam(f400_800nm,2:2:end); %only keep the spectra value at 400-800nm
XFullTrain=[Tetracam_6bands_avg, STS_spectra_matched_Tetracam'];

%randomly remove some spectra,
XmissTrain=XFullTrain;
rng(1); miss_data=randn(length(filter),1);  %generate some random data to control the traing/test sample index.
XmissTrain(miss_data<-1,7:end)=NaN;


%run different imputation approaches
Imputation_script_PCA
X_imputed_PCA=X_imputed;

Imputation_script_Bayesion
X_imputed_BAY=Ximpute;

Imputation_script_Spline
X_imputed_Spline=X_imputed;

%an exmaple to view all the curves on a given sample
idx=21; idy =4;  %the fourth missing sample, which is the 21th sample in all of the 128 samples.
figure; hold on;
plot(wavelength(f400_800nm),XFullTrain(idx,7:end),'k','Linewidth',1);
plot(wavelength(f400_800nm),X_imputed_PCA(idx,7:end),'b--','Linewidth',1);
plot(wavelength(f400_800nm),X_imputed_BAY(idx,7:end),'m-.','Linewidth',1);
plot(wavelength(f400_800nm),X_imputed_Spline(idx,7:end),'g:','Linewidth',1.5);
plot([490 550 680 720 800],tetracam_bands_avg_2_ref(4,1:5),'rs','MarkerSize' ,8);
grid on, box on; hold off; 
ylim([-0.05 0.45]); xlabel('Wavelength(nm)');ylabel('Resdiual of reflectance');
legend('Observed','PCA','Bayesian','Spline','MS-band');
