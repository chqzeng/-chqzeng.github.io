%clear; clc;
%the path of the log file

Sec_of_day=24*3600;
%str_UAV_log_flight4='..\TetraCAM\July20_GolfCourse\Extracted_2016-7-20 12.44 gslog.dat.log';
str_UAV_log_flight1='..\UAV_flight_logs\Aug26_GolfCourse\F1_2016-8-26 12.10 gslog.dat.log';
str_UAV_log_flight2='..\UAV_flight_logs\Aug26_GolfCourse\2016-8-26 13.36 gslog.dat.log';
str_UAV_log_flight3='..\UAV_flight_logs\Aug26_GolfCourse\2016-8-26 13.36 gslog.dat.log';

%load the entire log file
str_flight_log_name=str_UAV_log_flight1;
UAV_log=fopen(str_flight_log_name);
log_file_data=textscan(UAV_log,'%s','Delimiter', '\n', 'CollectOutput', true);
log_file_data=log_file_data{1};

%search the string in each line
Len_logfile=length(log_file_data);
Log_file_info_array=zeros(Len_logfile,11); %there are 11 params for each record
idy=1;
for idx=1:Len_logfile
    
    if isempty(log_file_data{idx}) %the input row is empty
        continue;
    end
    
    %read the line based on the given format
    temp=textscan(log_file_data{idx},'%f: position: lat=%.14f;	lon=%.14f;	att=%f;	dir=[%f,%f,%f];	v=[%f,%f,%f];	wp=%f');
    if ~isempty(temp{11}) %if the record is wrong
        Log_file_info_array(idy,:)=cell2mat(temp);
        idy=idy+1;
    end
end
fclose(UAV_log);
Log_file_info_array(idy:end,:)=[];%remove the result empty lines
Log_file_info_array=array2table(Log_file_info_array, ...
'VariableNames',{'Time_tick','Lat','Long','Alt','Dir1','Dir2','Dir3','Speed1','Speed2','Speed3','Waypoint'});

%plot the elevation change for this flight
plot(Log_file_info_array.Time_tick,Log_file_info_array.Alt);
title('Elevation profile for the flight');
xlabel('UAV internal time tick (s)'); ylabel('Elevation(m) above ground')
if false %plot the distance , rather than elevation
    home_pt=[mean(Log_file_info_array.Lat(1:100)), mean(Log_file_info_array.Long(1:100)), mean(Log_file_info_array.Alt(1:100))];
    [d1km d2km]=distance([Log_file_info_array.Lat Log_file_info_array.Long],home_pt(1:2)) ;
    dist_horizon=d1km*1e3; %disance in horizontal (m)
    dist_3D=sqrt(dist_horizon.^2+ (Log_file_info_array.Alt - home_pt(3)).^2);
    plot(Log_file_info_array.Time_tick,dist_3D)
end

%---- manaully preapre the Tetracam_image_id_list
Tetracam_img_info=table(0,0,0,'VariableNames',{'Image_ID' 'TetraCAM_tick' 'TetraCAM_time'});
%--------- add data to the Tetracam_img_info table first --------
disp('Add the Tetracam data to the [Tetracam_img_info] table, and then continue ...'); 
disp('The Image_ID (as numbers), and TetraCAM_tick (as 10ms units) are required, while TetraCAM_time is optional'); 
%return;

%---------end of the block ---------
tick_2_time_ratio=0.9334  * 100;  %the 100 is to convert from 10ms to seconds
Tetracam_img_info.TetraCAM_tick=Tetracam_img_info.TetraCAM_tick./tick_2_time_ratio;

%--- the structure of the Tetracam image file name table array
% --- filename modified_time   time_uav_tick
UAV_takeoff_tick=236.9;
UAV_landing_tick= 814.5;
Tetracam_takeoff_tick=531.2272435; %take off between image
Tetracam_landing_tick=1108.984793; %landed between image 
time_tick_match=[mean([UAV_takeoff_tick UAV_landing_tick]) mean([Tetracam_takeoff_tick Tetracam_landing_tick])];%time_tick to match two timeline
%time_tick_match=[UAV_takeoff_tick Tetracam_takeoff_tick];
Tetracam_img_info.UAV_tick=(Tetracam_img_info.TetraCAM_tick-time_tick_match(2))+time_tick_match(1); %convert Tetracam tick to UAV tick

[idx,~]=knnsearch(Log_file_info_array{:,1},Tetracam_img_info{:,4},'K',1);
TetraCAM_photo_centre=Log_file_info_array(idx,2:4);  %collect the lat, Long, and alt
TetraCAM_photo_centre.ImageName = strcat('TTC', num2str(Tetracam_img_info.Image_ID),'_16.TIF'); %add the file name :"TTC####_16.TIF"
TetraCAM_photo_centre=[TetraCAM_photo_centre(:,4) TetraCAM_photo_centre(:,1:3)]; %adjust the order of columns
writetable(TetraCAM_photo_centre,strrep(str_flight_log_name,'gslog.dat.log','img_pos_ctr.txt'),'delimiter','\t');

if true
    plot3(TetraCAM_photo_centre.Lat,TetraCAM_photo_centre.Long,TetraCAM_photo_centre.Alt,'bs-.','MarkerFaceColor','m');
    axis ij; %reverse the y directoin to show North upper side
    grid on; 
    %img_names=Tetracam_img_info.FileName;
    img_names=strrep(Tetracam_img_info.Image_ID,'TTC0',' ');
    img_names=strrep(img_names,'.RAW','');
    text(TetraCAM_photo_centre.Lat,TetraCAM_photo_centre.Long,TetraCAM_photo_centre.Alt,num2str(Tetracam_img_info.Image_ID));
end
% figsave('Aug26_GolfCourse_image_pos_flight1')
% figsave('Aug26_GolfCourse_image_pos_flight1')
