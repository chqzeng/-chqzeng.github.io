   %this script is used for interpolation of spectra point locations
   
    %dist_ratio=@(t,t1,t2)( abs(t-t1)./abs(t2-t1));
    dist_interp=@(t,t1,t2,x1,x2)((t-t1)./(t2-t1).*(x2-x1)+x1);
    %dist_interp=@(r,x1,x2)(r.* abs(x1-x2)+x1); %x1<x2, in UTM coordiate ideally
    
    %[IDX,~]=knnsearch(Log_file_info_array{:,1},Spectra_flight1(:,5),'K',1);
%   [IDX,~]=knnsearch(Log_file_info_array{:,1},cell2mat(Spectra_flight1(:,5)),'K',1);
%   STS_spectra_centre=Log_file_info_array(IDX,1:10);  %oging to improve it using the two functions.
    node1=0;node2=0;
    len=length(STS_spectra_centre{:,1});
    for idy=1:len %using linear interpolation to find the optimal location of the spectra
        t=Spectra_flight1{idy,6} ;% the actual time tick
        t0=Log_file_info_array{IDX(idy),1}; %the time of the node
        if  t == t0  %exactly over the node
            continue; %no change needed;
        elseif t > t0 %the actual time over the matched node
            node1=IDX(idy); %the first node is the matched node
            node2=node1+1; %and its next node
            if node2 > height(Log_file_info_array); continue; end;
              
        else %the actual time less than that of the matched node
            node1=IDX(idy)-1; %the first node is the matched node
            node2=node1+1; %and its next node
            if node1 <=0; continue; end;
        end
        temp_x=dist_interp(t,Log_file_info_array{node1,1},Log_file_info_array{node2,1},Log_file_info_array{node1,2},Log_file_info_array{node2,2});
        temp_y=dist_interp(t,Log_file_info_array{node1,1},Log_file_info_array{node2,1},Log_file_info_array{node1,3},Log_file_info_array{node2,3});
        temp_z=dist_interp(t,Log_file_info_array{node1,1},Log_file_info_array{node2,1},Log_file_info_array{node1,4},Log_file_info_array{node2,4});
        STS_spectra_centre{idy,2:4}=[temp_x temp_y temp_z];
    end
    Spectra_flight1(:,7:9)=table2cell(STS_spectra_centre(:,2:4));
    
    %Spectra_flight1_struct = cell2table(Spectra_flight1, 'VariableNames', {'timeID','spectra','filePath','STS_tick','Time_tag','UAV_tick','Lat','Long','Alt'});
    Spectra_flight1_struct = cell2table(Spectra_flight1(:,3:end), 'VariableNames', {'filePath','STS_tick','Time_tag','UAV_tick','Lat','Long','Alt'});
    writetable(Spectra_flight1_struct,'flight1_test.txt','delimiter','\t'); %save the STS-VIS positions
    