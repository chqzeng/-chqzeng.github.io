% missing data imputation using the Guassian model

Ximpute=zeros(size(XmissTrain));
tStart = tic;  %record the processing time: start
interval=20;

model_name='Gibbs'; %'Em', 'ICM' , 'Gibbs'  %choose one of the three models
for idx=1:interval
 %because the "gaussMissingFitGibbs" report error to process the entire matrix, thus process blocks by blocks   
 %range=[1:6 (interval*idx+7):(min([interval*(idx+1)+6 size(XmissTrain,2)]))];
 range=[1:6 (6+idx):interval:size(XmissTrain,2)];
 
 switch model_name
     case 'Gibbs'
         [model, dataSamples, LLtrace] = gaussMissingFitGibbs(XmissTrain(:,range), 'verbose', false);
         %set up the mu and Sigma
         muSamples = model.mu; SigmaSamples = model.Sigma;
         muHat = mean(muSamples);
         SigmaHat = mean(SigmaSamples,3);
         model = struct('mu', muHat, 'Sigma', SigmaHat);    
     case 'Em'
         [model, LLtrace] = gaussMissingFitEm(XmissTrain(:,range), 'verbose', false, 'maxIter', 500);
     case 'ICM'
         [model, LLtrace] = gaussMissingFitICM(XmissTrain(:,range), 'verbose', false);
 end
  
 %process the imputation and save result
 [Ximpute(:,range), V] = gaussImpute(model, XmissTrain(:,range));
 
end

tElapsed = toc(tStart);  %record the processing time: end
disp(num2str(tElapsed)) %show the time

%calcuate the differnce between imputation and observation
diff_BYS=Ximpute(miss_data<-1,7:end)-XFullTrain(miss_data<-1,7:end);
plot(wavelength(f400_800nm),diff_BYS); 
ylim([-0.1 0.1]);grid on, box on; xlabel('Wavelength(nm)');ylabel('Resdiual of reflectance')
figsave(strcat('Bayesian_Imputation_with_sampling_approach_',model_name));

%calculate the metrics
X=XFullTrain(miss_data<-1,7:end);
Y=Ximpute(miss_data<-1,7:end);
[ME,MAE,STD_AE,SNR,mean_Q,SAM,RMSE,ERGAS,D_dist] = HS_evaluation_metrics(X,Y);
[ME,MAE,STD_AE,SNR,mean_Q,SAM,RMSE,ERGAS,D_dist];
