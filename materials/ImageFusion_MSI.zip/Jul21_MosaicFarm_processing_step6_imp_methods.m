%%X_imputed=MDItoolbox_results.X_imputed;
% [X_imputed,~,~,~,~] = pcambtsr(Jul21_MosaicFarm_flight2_Img_cnt_imputation_missed, 3, 10, 10e-5);
% [X_imputed,~,~,~,~] = pcambkdr(Jul21_MosaicFarm_flight2_Img_cnt_imputation_missed, 3, 10, 10e-5);
% [X_imputed,~,~,~,~] = pcambpcr(Jul21_MosaicFarm_flight2_Img_cnt_imputation_missed, 3, 10, 10e-5);
% [X_imputed,~,~,~,~] = pcambpls(Jul21_MosaicFarm_flight2_Img_cnt_imputation_missed, 3, 10, 10e-5);
% [X_imputed,~,~,~,~] = pcambpmp(Jul21_MosaicFarm_flight2_Img_cnt_imputation_missed, 3, 10, 10e-5);
% [X_imputed,~,~,~,~] = pcambia(Jul21_MosaicFarm_flight2_Img_cnt_imputation_missed, 3, 10, 10e-5);
% [X_imputed,~,~,~,~] = pcambnipals(Jul21_MosaicFarm_flight2_Img_cnt_imputation_missed, 3, 10, 10e-5);
% [X_imputed,~,~] = pcambda(Jul21_MosaicFarm_flight2_Img_cnt_imputation_missed, 10,100,3);

% %caluate the RMSE/RMSD of the curves
% tetracam_bands_avg_2_ref_all=zeros(length(test_idx),length(f400_800nm));
% for plot_idx=1:length(test_idx)
%     tetracam_bands_avg_2_ref_all(plot_idx,:)=interp1([490 550 680 720 800],tetracam_bands_avg_2_ref(plot_idx,1:5),wavelength(f400_800nm));
%     %plot(wavelength(f400_800nm),tetracam_bands_avg_2_ref_all(plot_idx,:));
%     %plot([490 550 680 720 800],tetracam_bands_avg_2_ref(plot_idx,1:5),'s','MarkerSize' ,8)
% end

v_rmse_pre=0;
v_rmse_reg=0;
v_rmsd=0;
for plot_idx=1:length(test_idx)
    v_mse=immse(X_imputed(test_idx(plot_idx),201:end), Jul21_MosaicFarm_flight2_Img_cnt_imputation(test_idx(plot_idx),201:end));
    v_rmse_pre=v_rmse_pre+sqrt(v_mse);
    v_mse=immse(tetracam_bands_avg_2_ref_all(plot_idx,195:end), Jul21_MosaicFarm_flight2_Img_cnt_imputation(test_idx(plot_idx),201:end));
    v_rmse_reg=v_rmse_reg+sqrt(v_mse);
    v_mse=immse(tetracam_bands_avg_2_ref_all(plot_idx,195:end), X_imputed(test_idx(plot_idx),201:end));
    v_rmsd=v_rmsd+sqrt(v_mse);
end
[v_rmse_pre v_rmse_reg  v_rmsd]'./(length(test_idx))


figure;grid on, box on; 
title('the predicted spectra'); xlabel('wavelength(nm)');ylabel('reflectance')
hold on;%only test three samples
plot_idx=1;
    plot(wavelength(f400_800nm),Jul21_MosaicFarm_flight2_Img_cnt_imputation(test_idx(plot_idx),7:end),'r');
    plot(wavelength(f400_800nm),X_imputed(test_idx(plot_idx),7:end),'r-.');
    plot([490 550 680 720 800],tetracam_bands_avg_2_ref(plot_idx,1:5),'rs-','MarkerSize' ,8,'MarkerFaceColor','k')
plot_idx=6;
	plot(wavelength(f400_800nm),Jul21_MosaicFarm_flight2_Img_cnt_imputation(test_idx(plot_idx),7:end),'b');
    plot(wavelength(f400_800nm),X_imputed(test_idx(plot_idx),7:end),'b-.');
    plot([490 550 680 720 800],tetracam_bands_avg_2_ref(plot_idx,1:5),'bs-','MarkerSize' ,8,'MarkerFaceColor','k')
plot_idx=11;	
	plot(wavelength(f400_800nm),Jul21_MosaicFarm_flight2_Img_cnt_imputation(test_idx(plot_idx),7:end),'c');
    plot(wavelength(f400_800nm),X_imputed(test_idx(plot_idx),7:end),'c-.');
    plot([490 550 680 720 800],tetracam_bands_avg_2_ref(plot_idx,1:5),'cs-','MarkerSize' ,8,'MarkerFaceColor','k')
	
hold off;