%clear;close all; clc;
%load('Data_imputation_Jul21_MosaicFarm_UAV_flight2','Jul21_MosaicFarm_flight2_Img_cnt_imputation');
%test_imputation=Jul21_MosaicFarm_flight2_Img_cnt_imputation;

%InputImage=imread('D:\2017_Ag_fusion_paper\Figures\MosaicFarm_stitch_testarea_UTM25.tif');
InputImage=imread('D:\2017_Ag_fusion_paper\Figures\MosaicFarm_stitch_testarea.tif');
InputImage=InputImage(:,:,1:6); %remvoe the last empty band
InputImage=imresize(InputImage,0.5);
[sizex, sizey]=size(InputImage(:,:,1));
simultated_hyper=zeros(sizex, sizey,841,'uint16'); %there are 841 bands from 400-800nm


t_hper=tic;
for idx=1:sizey %iterately process each column of the image
    test_input_tetracam=reshape(squeeze(InputImage(:,idx,:)),[],6);
    test_imputation(129:end,:)=[];
    len=length(test_input_tetracam(:,1));
    test_imputation(129:(129+len-1),1:6)=test_input_tetracam;
    test_imputation(129:end,7:end)=NaN;
    test_X_imputed = pcambtsr(test_imputation, 3, 30, 10e-5); %data imputatoin
    
    %save the result
    test_X_imputed=test_X_imputed(129:end,7:end);
    mask=squeeze(InputImage(:,idx,1))==0; 
    test_X_imputed(mask,:)=0;
    test_X_imputed=uint16(test_X_imputed*10000);
    simultated_hyper(:,idx,:)=test_X_imputed;
end
time_used=toc(t_hper);
disp(['time used in hyper image generation:' , num2str(time_used), 'seconds']);
