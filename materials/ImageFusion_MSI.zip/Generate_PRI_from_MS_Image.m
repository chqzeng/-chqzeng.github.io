%Generate_PRI_from_MS_Image

%clear;close all; clc;

%load('Data_imputation_Jul21_MosaicFarm_UAV_flight2','Jul21_MosaicFarm_flight2_Img_cnt_imputation');
%test_imputation=Jul21_MosaicFarm_flight2_Img_cnt_imputation;


%generate HS image \
if true
    str_HS_PRI_path='D:\2017_Ag_fusion_paper\Figures\PRI_HS_small.dat';
    PRI_2band_idx=knnsearch(wavelength(f400_800nm),[531 570]', 'K',1);%find the band index near 531nm and 570nm
    kernel=3; clear PRI_bands;
    PRI_bands(1,:,:)=mean(simultated_hyper(:,:,PRI_2band_idx(1)+[-1 1].*kernel),3); %band 531nm from simulated HS image, as an average of its neighours (kenrnel=1)
    PRI_bands(2,:,:)=mean(simultated_hyper(:,:,PRI_2band_idx(2)+[-1 1].*kernel),3); %band 570nm
    PRI_hyper=(PRI_bands(2,:,:)-PRI_bands(1,:,:))./(PRI_bands(2,:,:)+PRI_bands(1,:,:));
    PRI_hyper=squeeze(PRI_hyper);
    %PRI_hyper_small=imresize(PRI_hyper,[115 105]);  %resize as a small imagery
    %PRI_hyper_small(isnan(PRI_hyper_small))=-1;   %replace the NaN as -1
    
    PRI_hyper_small=PRI_hyper; %Image_Pyrimad(PRI_hyper,19); %convert from [2226 2024]--> about [115 105]
    enviwrite(PRI_hyper_small,enviinfo(PRI_hyper_small),str_HS_PRI_path); %save the result
end


%str_input_ms_image='D:\2017_Ag_fusion_paper\Figures\MosaicFarm_stitch_testarea_UTM25.tif';
str_input_ms_image='D:\2017_Ag_fusion_paper\Figures\MosaicFarm_stitch_testarea.tif';
InputImage=imread(str_input_ms_image);
InputImage=InputImage(:,:,1:6); %remvoe the last empty band
[sizex, sizey]=size(InputImage(:,:,1));

simultated_PRI=zeros(size(InputImage(:,:,1))); %there are 

%generate PRI image by linear interpolation:
%  490 ---- b1(531) ----550 -----b2(570) ---- 680nm
% input bands  at [490,550,680] nm,then  linear interpolate values at [531 570]
band_list=[490 550 680 720 800 900];
MS_bands=reshape(InputImage(:,:,1:3),sizex*sizey,3); %get MS bands values at [490,550,680]
PRI_bands=interp1(band_list(1:3),double(MS_bands'),[531 570]); %interpolation
%%PRI is calcuated as : PRI =(R531-R570)./(R531+R570)
PRI=(PRI_bands(1,:)-PRI_bands(2,:))./(PRI_bands(1,:)+PRI_bands(2,:));
PRI=reshape(PRI,sizex, sizey); %reshape into the size of inputimage
%imshow(PRI, [min(PRI(:)) max(PRI(:))],'Colormap',copper)

%write the PRI result into a tif file
% temp=simultated_hyper(:,:,364)./simultated_hyper(:,:,282); generate from
% hyperspectral image
info=imfinfo(str_input_ms_image);	info=info(1);
str_out_tiff_path='D:\2017_Ag_fusion_paper\Figures\MS_PRI.tif';
% temp=PRI; temp(isnan(temp))=-1;temp=int16(temp*1e5);
% WriteTIFF(temp, str_out_tiff_path);

temp=PRI;temp(isnan(temp))=-1; temp=uint16((temp+1)*10000);
imwrite(temp,str_out_tiff_path)