%%%---------------------------script to find the optimal time offset  ------------------
if false
    
    %load('Aug26_GolfCourse_UAV_spectra_flight1_per_image_regression.mat')
    wavelength=Spectra_veg{1,2}(:,1);
    
    % ----------------------code used to load the filter of the TEtracam lens ------------------------------ 
    str_filter_path='..\DataProcessing\BandPass_filter_profile\';
    Flt_list=struct;
    band_list=[490  550 680 720  800  900 ];
    Flt_list.Flt_490=readtable([ str_filter_path, '490FS10.csv'],'Format','%f%f','HeaderLines',8,'Delimiter',',');
    Flt_list.Flt_550=readtable([ str_filter_path, '550FS10.csv'],'Format','%f%f','HeaderLines',8,'Delimiter',',');
    Flt_list.Flt_680=readtable([ str_filter_path, '680FS10.csv'],'Format','%f%f','HeaderLines',8,'Delimiter',',');
    Flt_list.Flt_720=readtable([ str_filter_path, '720FS10.csv'],'Format','%f%f','HeaderLines',8,'Delimiter',',');
    Flt_list.Flt_800=readtable([ str_filter_path, '800FS10.csv'],'Format','%f%f','HeaderLines',8,'Delimiter',',');
    Flt_list.Flt_900=readtable([ str_filter_path, '900FS10.csv'],'Format','%f%f','HeaderLines',8,'Delimiter',',');
    
    Flt_list_fields=fieldnames(Flt_list);
    column_idx=11;
    STS_spectra_centre{:,(column_idx+1):(column_idx+5)}=0;
    % ------------for each of the loaded TEtracam band, need to calculate the convoluted bands from narrow bands to 10nm bands------------- 
    for idx=1:5
        band=band_list(idx); flt=getfield(Flt_list, Flt_list_fields{idx});  %take the 680nm band as an example.
        [STS_idx]=knnsearch(wavelength,[band-10,band+10]','K',1); %find the closet bands with that +/-10nm range, get rid of the rest in the filter
        flt_idx=knnsearch(flt{:,1}, wavelength((STS_idx(1):STS_idx(2))'),'K',1);
        flt_usd=flt(flt_idx,:);flt_usd(:,3)=num2cell((STS_idx(1):STS_idx(2))');
        flt_usd.Properties.VariableNames{3} = 'STS_idx';
        %the integration function, requires the detailed dark current, sun condition for the convolution. 
        Tetracam_band_ref = TetraCAM_band_integration(Spectra_veg,flt_usd,White_ref_ground_PI,Dark_offset_ground_PI,Spectra_sun,Spectra_sun_WhiteRef, Dark_offset_sun_OceanView);
        column_idx=column_idx+1; STS_spectra_centre(:,column_idx)=num2cell(Tetracam_band_ref);
        STS_spectra_centre.Properties.VariableNames{column_idx} = Flt_list_fields{idx};
    end
end

if false
    t_preprocess=tic;
    %-------------for the Tetracam image side, find the average from multipage tiff images -----------------------------------
   radius=24; img_mask=make_cricle_mask (radius); %creat a mask with radius of 24pixels.
    Tetracam_photo_center_rows=7; %current exsiting number of rows of Tetracam_photo_center
    Tetracam_mean_bnds=(Tetracam_photo_center_rows+1):(Tetracam_photo_center_rows+6);
    bFieldname=true;
    %TetraCAM_photo_centre.Properties.VariableNames{Tetracam_mean_bnds} = cellstr(strcat('nm',num2str(band_list')));%add the label
    imageNum=324;
    range=100; interval=5;
    %range=20; %the search range in pixels to tolerant possible tilt angle
    
    % --- the structure of  "TetraCAM_photo_centre_mat":  [sampleID, shift_dx, shift_dy, band_No.]
    TetraCAM_photo_centre_mat=zeros(imageNum,2*floor(range/interval)+1,2*floor(range/interval)+1,6); %the matrix of numuber of samples, with shift dx, dy, and in each of the 6 bands
    for idx=1:imageNum %iterate each image
        filepath=['..\TetraCAM\July21_Mosiac_farm2\singlepage_tiff\',TetraCAM_photo_centre{idx,1}];
        if  ~ exist(filepath,'file'); continue; end
        InputImage=imread(filepath); %read the file
        for id_dx=(-1*range):interval:range
            for id_dy=(-1*range):interval:range
                center=size(InputImage(:,:,1))./2+[id_dx id_dy];
                for idy=1:6  %iterate each band
                    template=InputImage((center(1)-radius):(center(1)+radius-1),(center(2)-radius):(center(2)+radius-1),idy);
                    new_dx=floor((id_dx+range)/interval)+1;
                    new_dy=floor((id_dy+range)/interval)+1;
                    TetraCAM_photo_centre_mat(idx, new_dx, new_dy,idy)=mean(template(img_mask));
                    %TetraCAM_photo_centre{idx,idy+6}=mean(template(img_mask));
                    %if(bFieldname) TetraCAM_photo_centre.Properties.VariableNames{idy+6} = Flt_list_fields{idy};end
                end
            end
        end
        bFieldname=false;
    end
    time_used=toc(t_preprocess);
    TetraCAM_photo_centre.new_tick=TetraCAM_photo_centre.TetraCAM_tick; %this line to keep consistent with old version.
    %TetraCAM_photo_centre.new_tick=(TetraCAM_photo_centre.TetraCAM_tick-537.03664)*(1-1.2/521.2)+537.03664; %time=gain*org+offset
    
    disp(['time used in preprocessing:' , num2str(time_used), 'seconds']);
end

%def_Tetracam_STS_offset=(1582.8-532.6);
def_Tetracam_STS_offset=(70074.747-1575.63)-47; 
filter=[2873:3100]-2838; %2855:3117,convert from image id to the index of records in "TetraCAM_photo_centre"
TetraCAM_photo_centre_mat_adj=squeeze(TetraCAM_photo_centre_mat(filter,:,:,:));  %only process a small proportion of samples
searchrange=(-10:0.2:10);
%the structure of Rsquare is : [dx, dy, dt, 5-bands]
Rsquare=zeros(2*floor(range/interval)+1,2*floor(range/interval)+1,length(searchrange),5);  %for the 3-d search range, and 5 bands (900nm not avaliable)
r_idx=1;

if  false  %if 2-step optimizatoin
    Rsquare=zeros(length(searchrange),5);  %for the search range, and 5 bands (900nm not avaliable)
    TetraCAM_photo_centre_adj=squeeze(TetraCAM_photo_centre_mat(filter, 21, 21,:));  %TetraCAM_photo_centre(filter,:)
    r_idx=1;
    searchrange=-10:0.2:10;
    t_time_Opt= tic;
    for dt=searchrange %the time offset from -10s to 10s, with 0.2s interval
        try
            %caculate the best match of list
            [IDX]=knnsearch(STS_spectra_centre.STS_tick-def_Tetracam_STS_offset,(TetraCAM_photo_centre.new_tick(filter)+dt),'K',1 ); %orginal
            %[IDX]=knnsearch(STS_spectra_centre.STS_tick-def_Tetracam_STS_offset,(TetraCAM_photo_centre.new_tick(filter)+dt),'K',1 );
            %[IDX]=knnsearch(STS_spectra_centre.STS_tick-def_Tetracam_STS_offset,(TetraCAM_photo_centre_adj.new_tick+dt),'K',1 );

            b_idx=0;
            b_idx=b_idx+1; band_X=TetraCAM_photo_centre_adj(:,b_idx); band_Y=STS_spectra_centre{IDX,11+b_idx}; Rsquare(r_idx,1)=Calculate_Rsquare( band_X,band_Y);
            b_idx=b_idx+1; band_X=TetraCAM_photo_centre_adj(:,b_idx); band_Y=STS_spectra_centre{IDX,11+b_idx}; Rsquare(r_idx,2)=Calculate_Rsquare( band_X,band_Y);
            b_idx=b_idx+1; band_X=TetraCAM_photo_centre_adj(:,b_idx); band_Y=STS_spectra_centre{IDX,11+b_idx}; Rsquare(r_idx,3)=Calculate_Rsquare( band_X,band_Y);
            b_idx=b_idx+1; band_X=TetraCAM_photo_centre_adj(:,b_idx); band_Y=STS_spectra_centre{IDX,11+b_idx}; Rsquare(r_idx,4)=Calculate_Rsquare( band_X,band_Y);
            b_idx=b_idx+1; band_X=TetraCAM_photo_centre_adj(:,b_idx); band_Y=STS_spectra_centre{IDX,11+b_idx}; Rsquare(r_idx,5)=Calculate_Rsquare( band_X,band_Y);
            r_idx=r_idx+1;
        catch
            continue;
        end
    end
    time_used=toc(t_time_Opt);
    disp(['time space optimization: ', num2str(time_used), 'seconds']);
    %draw the r-square distribution
    figure;plot(searchrange,Rsquare,'.-')
    legend('490nm','550nm','680nm','720nm','800nm')
    xlabel('Shift from intial matched timeline');ylabel('R-sqaure');
    grid on; box on;
end

tGlobalOpt=tic;
%calculate the rsqaure for a three-variable function --> f(dt, dx,dy)
for dt=searchrange %the time offset from -10s to 10s, with 0.2s interval
%dt=-1.2;
        %caculate the best match of list
        %[IDX]=knnsearch(STS_spectra_centre.STS_tick-def_Tetracam_STS_offset,(TetraCAM_photo_centre_adj.TetraCAM_tick+dt),'K',1 ); %orginal
        [IDX]=knnsearch(STS_spectra_centre.STS_tick-def_Tetracam_STS_offset,(TetraCAM_photo_centre.new_tick(filter)+dt),'K',1 );
        %[IDX]=knnsearch(STS_spectra_centre.STS_tick-def_Tetracam_STS_offset,(TetraCAM_photo_centre_adj.new_tick+dt),'K',1 );
        for id_dx=(-1*range):interval:range  %calculate the rsqaure for a three-variable function --> f(dt, dx,dy)
            for id_dy=(-1*range):interval:range   
           %id_dx=-20;id_dy=85;
            try
                b_idx=0;  %band index
                b_idx=b_idx+1; 
                new_dx=floor((id_dx+range)/interval)+1;
                new_dy=floor((id_dy+range)/interval)+1;
                band_X=squeeze(TetraCAM_photo_centre_mat_adj(:,new_dx, new_dy,b_idx)); 
                band_Y=getfield(STS_spectra_centre(IDX,:), Flt_list_fields{b_idx}); 
                Rsquare(new_dx, new_dy,r_idx,1)=Calculate_Rsquare( band_X,band_Y);
                
                b_idx=b_idx+1; band_X=squeeze(TetraCAM_photo_centre_mat_adj(:,new_dx, new_dy,b_idx)); band_Y=getfield(STS_spectra_centre(IDX,:), Flt_list_fields{b_idx}); Rsquare(new_dx, new_dy,r_idx,2)=Calculate_Rsquare( band_X,band_Y);
                b_idx=b_idx+1; band_X=squeeze(TetraCAM_photo_centre_mat_adj(:,new_dx, new_dy,b_idx)); band_Y=getfield(STS_spectra_centre(IDX,:), Flt_list_fields{b_idx}); Rsquare(new_dx, new_dy,r_idx,3)=Calculate_Rsquare( band_X,band_Y);
                b_idx=b_idx+1; band_X=squeeze(TetraCAM_photo_centre_mat_adj(:,new_dx, new_dy,b_idx)); band_Y=getfield(STS_spectra_centre(IDX,:), Flt_list_fields{b_idx}); Rsquare(new_dx, new_dy,r_idx,4)=Calculate_Rsquare( band_X,band_Y);
                b_idx=b_idx+1; band_X=squeeze(TetraCAM_photo_centre_mat_adj(:,new_dx, new_dy,b_idx)); band_Y=getfield(STS_spectra_centre(IDX,:), Flt_list_fields{b_idx}); Rsquare(new_dx, new_dy,r_idx,5)=Calculate_Rsquare( band_X,band_Y);
         
            catch
                continue;
            end
        end
      end
      r_idx=r_idx+1;
      if(mod(dt,1)==0)disp(num2str(dt));end
 end
time_used2=toc(tGlobalOpt);
disp(['time used in optimization:' , num2str(time_used2), 'seconds']);

t_Opt=-1.2; % dx=85 ; dy = -20;  --> Rsquare(37,16,45,:) for the peak
[~,t_Opt_idx]=min(abs(searchrange-t_Opt));
[gridx,gridy]=meshgrid((-1*range):interval:range,(-1*range):interval:range);
temp=sum(squeeze(Rsquare(:,:,t_Opt_idx,:)),3)./5; %average the 5 bands
figure;surface(gridx,gridy,temp)
xlabel('X offset (in pixels)');ylabel('Y offset (in pixels)');zlabel('Average R^2');
grid on; box on;
view([160 30]);
set(get(gca,'YLabel'),'Rotation',-50)
set(get(gca,'XLabel'),'Rotation',8)

% dt=-1.2; dx=85 ; dy = -20;  --> Rsquare(37,16,45,:) for the peak
%val=squeeze(Rsquare(37,16,45,:));
break;
%[val, idx]=max(squeeze(sum(squeeze(Rsquare(:,:,45,:)))),2);  %find the offset with highest r-square
disp(['R square' , num2str(val/5)])
disp(['Time offset: ',num2str(searchrange(idx))])


%draw the r-square distribution
figure;plot(searchrange,Rsquare,'.-')
legend('490nm','550nm','680nm','720nm','800nm')
xlabel('Shift from intial matched timeline');ylabel('R^2');
grid on; box on;
text(searchrange(1)+0.2,(val/5),[{['Avg R^2: ', num2str(val/5)]}, {['Time offset: ',num2str(searchrange(idx))]}])
%title('Image used: All');
str_title=['Image used: ID ',TetraCAM_photo_centre{filter(1),1},'---',TetraCAM_photo_centre{filter(end),1}];
str_title=strrep(str_title,'_16.TIF','');str_title=strrep(str_title,'TTC','');
title(str_title)

%draw the scatterplot of regression for each band at the optimal offset
if true
    dt=searchrange(idx); %find the optimal time offset
    [IDX]=knnsearch(STS_spectra_centre.STS_tick-def_Tetracam_STS_offset,(TetraCAM_photo_centre_adj.TetraCAM_tick+dt),'K',1 );
    %[IDX]=knnsearch(STS_spectra_centre.STS_tick-def_Tetracam_STS_offset,(TetraCAM_photo_centre_adj.new_tick+dt),'K',1 );
    Calculate_Rsquare( getfield(TetraCAM_photo_centre_adj, Flt_list_fields{1}), getfield(STS_spectra_centre(IDX,:), Flt_list_fields{1}), true);%calcuate r square and plot
    Calculate_Rsquare( getfield(TetraCAM_photo_centre_adj, Flt_list_fields{2}), getfield(STS_spectra_centre(IDX,:), Flt_list_fields{2}), true);
    Calculate_Rsquare( getfield(TetraCAM_photo_centre_adj, Flt_list_fields{3}), getfield(STS_spectra_centre(IDX,:), Flt_list_fields{3}), true);
    Calculate_Rsquare( getfield(TetraCAM_photo_centre_adj, Flt_list_fields{4}), getfield(STS_spectra_centre(IDX,:), Flt_list_fields{4}), true);
    Calculate_Rsquare( getfield(TetraCAM_photo_centre_adj, Flt_list_fields{5}), getfield(STS_spectra_centre(IDX,:), Flt_list_fields{5}), true);
end


