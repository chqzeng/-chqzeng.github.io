% missing data imputation using the Guassian model
X_imputed=XmissTrain;
model_name='spline'; %'pcambkdr', etc

%add the regression based reflectance 6-points to the curve as well
p=[1.32453457281875e-05	0.0207876645136882
9.67783680583884e-06	-0.00756167199483431
8.15927286625553e-06	0.00556123750379710
1.17407284773385e-05	0.0283083651505677
1.38648742999604e-05	0.0511408718037953];  %each band is Ref=p(0)*DN_Tetra + p(1)

p=[1.143597E-05	0.024242553
6.847122E-06	0.021197909
6.704033E-06	0.021167632
1.006340E-05	0.0503726
9.961114E-06	0.131700133]; 

tetracam_bands_avg=XmissTrain(miss_data<-1,1:6);
tetracam_bands_avg_2_ref=zeros(size(tetracam_bands_avg));
for idx=1:5
    tetracam_bands_avg_2_ref(:,idx)=polyval(p(idx,:),tetracam_bands_avg(:,idx));
end

tStart=tic;
test_idx=find(miss_data<-1);
for plot_idx=1:length(test_idx) %spline interploation for each sample
    X_imputed(test_idx(plot_idx),7:end)=interp1([490 550 680 720 800],tetracam_bands_avg_2_ref(plot_idx,1:5),wavelength(f400_800nm),'spline');
    %plot(wavelength(f400_800nm),X_imputed(test_idx(plot_idx),7:end));
    %plot([490 550 680 720 800],tetracam_bands_avg_2_ref(plot_idx,1:5),'s','MarkerSize' ,8)
end

tElapsed = toc(tStart);  %record the processing time: end
disp(num2str(tElapsed)) %show the time

%calcuate the differnce between imputation and observation
diff_BYS=X_imputed(miss_data<-1,7:end)-XFullTrain(miss_data<-1,7:end);
plot(wavelength(f400_800nm),diff_BYS); 
ylim([-0.15 0.1]);
grid on, box on; xlabel('Wavelength(nm)');ylabel('Resdiual of reflectance')
figsave(strcat('site2_spline_Imputation_with_sampling_approach_',model_name));

%calculate the metrics
f490_800nm=find(wavelength(f400_800nm)>=490 & wavelength(f400_800nm)<=800);
X=XFullTrain(miss_data<-1,6+f490_800nm); %the first 6 bands are multispetral bands, need to shift
Y=X_imputed(miss_data<-1,6+f490_800nm);
[ME,MAE,STD_AE,SNR,mean_Q,SAM,RMSE,ERGAS,D_dist] = HS_evaluation_metrics(X,Y);
[ME,MAE,STD_AE,SNR,mean_Q,SAM,RMSE,ERGAS,D_dist];
