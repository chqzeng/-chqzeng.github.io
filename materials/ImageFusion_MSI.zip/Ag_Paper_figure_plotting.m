% Plot the figures in the paper and save their result for further
% repeating.

%load the data and result from previous mat file
load('Jul21_MosaicFarm_UAV_Spectra_veg_R_step3_regression.mat');

%------------Figure 5 : the R square of timeline shift -------------
% ---- run this block of code three times for the three set of filter :
% beginning, end, and entire set. ---------------------
%%
filter=[2573:2700]-2570;  %[2573:2582]-2570;   %[2690:2700]-2570;
TetraCAM_photo_centre_adj=TetraCAM_photo_centre(filter,:);
searchrange=(-10:0.2:10);
Rsquare=zeros(length(searchrange),5);  %for the search range, and 5 bands (900nm not avaliable)
r_idx=1;
for dt=searchrange %the time offset from -10s to 10s, with 0.2s interval
    try
        %caculate the best match of list
        [IDX]=knnsearch(STS_spectra_centre.STS_tick-def_Tetracam_STS_offset,(TetraCAM_photo_centre_adj.TetraCAM_tick+dt),'K',1 ); %orginal
        %[IDX]=knnsearch(STS_spectra_centre.STS_tick-def_Tetracam_STS_offset,(TetraCAM_photo_centre_adj.new_tick+dt),'K',1 );
        b_idx=0;
        b_idx=b_idx+1; band_X=getfield(TetraCAM_photo_centre_adj, Flt_list_fields{b_idx}); band_Y=getfield(STS_spectra_centre(IDX,:), Flt_list_fields{b_idx}); Rsquare(r_idx,1)=Calculate_Rsquare( band_X,band_Y);
        b_idx=b_idx+1; band_X=getfield(TetraCAM_photo_centre_adj, Flt_list_fields{b_idx}); band_Y=getfield(STS_spectra_centre(IDX,:), Flt_list_fields{b_idx}); Rsquare(r_idx,2)=Calculate_Rsquare( band_X,band_Y);
        b_idx=b_idx+1; band_X=getfield(TetraCAM_photo_centre_adj, Flt_list_fields{b_idx}); band_Y=getfield(STS_spectra_centre(IDX,:), Flt_list_fields{b_idx}); Rsquare(r_idx,3)=Calculate_Rsquare( band_X,band_Y);
        b_idx=b_idx+1; band_X=getfield(TetraCAM_photo_centre_adj, Flt_list_fields{b_idx}); band_Y=getfield(STS_spectra_centre(IDX,:), Flt_list_fields{b_idx}); Rsquare(r_idx,4)=Calculate_Rsquare( band_X,band_Y);
        b_idx=b_idx+1; band_X=getfield(TetraCAM_photo_centre_adj, Flt_list_fields{b_idx}); band_Y=getfield(STS_spectra_centre(IDX,:), Flt_list_fields{b_idx}); Rsquare(r_idx,5)=Calculate_Rsquare( band_X,band_Y);
        r_idx=r_idx+1;
    catch
        continue;
    end
end
[val, idx]=max(sum(Rsquare,2));  %find the offset with highest r-square
disp(['R^2' , num2str(val/5)])
disp(['Time offset: ',num2str(searchrange(idx))])
%draw the r-square distribution
figure;plot(searchrange,Rsquare,'.-')
legend('490nm','550nm','680nm','720nm','800nm')
xlabel('Spectrometer time offset from nominal real world time (sec)','FontWeight', 'bold');ylabel('R^2','FontWeight', 'bold');
grid on; box on;
text(searchrange(1)+0.2,(val/5),[{['Avg R^2: ', num2str(val/5)]}, {['Time offset: ',num2str(searchrange(idx))]}],'FontWeight', 'bold');
%title('Image used: All');
str_title=['Images used: ID ',TetraCAM_photo_centre{filter(1),1},'---',TetraCAM_photo_centre{filter(end),1}];
str_title=strrep(str_title,'_16.TIF','');str_title=strrep(str_title,'TTC','');
title(str_title)
%%


%%
%------------Figure 6 : Per band regression between the multispectral camera image brightness -------------
%draw the scatterplot of regression for each band at the optimal offset
if true
    dt=searchrange(idx); %find the optimal time offset
    [IDX]=knnsearch(STS_spectra_centre.STS_tick-def_Tetracam_STS_offset,(TetraCAM_photo_centre_adj.TetraCAM_tick+dt),'K',1 );
    %[IDX]=knnsearch(STS_spectra_centre.STS_tick-def_Tetracam_STS_offset,(TetraCAM_photo_centre_adj.new_tick+dt),'K',1 );
    Calculate_Rsquare( getfield(TetraCAM_photo_centre_adj, Flt_list_fields{1}), getfield(STS_spectra_centre(IDX,:), Flt_list_fields{1}), true);%calcuate r square and plot
    Calculate_Rsquare( getfield(TetraCAM_photo_centre_adj, Flt_list_fields{2}), getfield(STS_spectra_centre(IDX,:), Flt_list_fields{2}), true);
    Calculate_Rsquare( getfield(TetraCAM_photo_centre_adj, Flt_list_fields{3}), getfield(STS_spectra_centre(IDX,:), Flt_list_fields{3}), true);
    Calculate_Rsquare( getfield(TetraCAM_photo_centre_adj, Flt_list_fields{4}), getfield(STS_spectra_centre(IDX,:), Flt_list_fields{4}), true);
    Calculate_Rsquare( getfield(TetraCAM_photo_centre_adj, Flt_list_fields{5}), getfield(STS_spectra_centre(IDX,:), Flt_list_fields{5}), true);
end

figsave('Jul21_MosaicFarm_Flight2_optimzed_regression_b490')
figsave('Jul21_MosaicFarm_Flight2_optimzed_regression_b550')
figsave('Jul21_MosaicFarm_Flight2_optimzed_regression_b680')
figsave('Jul21_MosaicFarm_Flight2_optimzed_regression_b720')
figsave('Jul21_MosaicFarm_Flight2_optimzed_regression_b800')


%% ------------- plot 2D-R square distribution------------------------
clear; load('Jul21_MosaicFarm_UAV_Spectra_veg_R_step3_regression_2D_ext.mat');
[gridx,gridy]=meshgrid((-1*range):interval:range,(-1*range):interval:range);
temp=sum(squeeze(Rsquare(:,:,1,:)),3)./5; %average the 5 bands
figure('position',[500 500 580 480]);
surface(gridx,gridy,temp)
xlabel('X offset (in pixels)','FontWeight', 'bold'); %'Rotation',-50
ylabel('Y offset (in pixels)','FontWeight', 'bold');
zlabel('Average R^2','FontWeight', 'bold');
grid on; box on;
grid on; box on;
view([160 30]);
set(get(gca,'YLabel'),'Rotation',-50)
set(get(gca,'XLabel'),'Rotation',8)

% ---- add a datatip at : [45 5 0.946] -----------
figsave('Jul21_MosaicFarm_Flight2_optimzed_spatial_2D')

[val, idx]=max(sum(squeeze(Rsquare(:,:,1,:))),2);  %find the offset with highest r-square
disp(['R square' , num2str(val/5)])
disp(['Time offset: ',num2str(searchrange(idx))])

%% ------------- plot 2D-R square distribution profile------------------------
%conitnue from the previous figure
temp=sum(squeeze(Rsquare(:,:,1,:)),3)./5;  %get the average over 5 bands
figure('position',[500 500 450 330])
plot(-100:5:100,temp((5+100)/5+1,:),'b')
grid on; box on;
xlabel('X offset (in pixels) when y offset = 5','FontWeight', 'bold');
ylabel('Average R^2','FontWeight', 'bold');
%text(45, 0.946,['\leftarrow X:45', 'R^2: 0.946'],'FontWeight', 'bold')
figsave('Jul21_MosaicFarm_Flight2_optimzed_spatial_2D_profileX')

figure('position',[500 500 450 330])
plot(-100:5:100,temp(:,(45+100)/5+1),'r')
grid on; box on;
xlabel('Y offset (in pixels) when x offset = 45','FontWeight', 'bold');
ylabel('Average R^2','FontWeight', 'bold');
%figsave('Jul21_MosaicFarm_Flight2_optimzed_spatial_2D_profileX')

%% ----- the imputatoin result of the 21 smaples ------------------
clear; clc; load('Jul21_MosaicFarm_UAV_flight2_final_all.mat');
figure('position',[500 500 700 500]); 
axes('ColorOrder',jet(sum(miss_data<-1)),'NextPlot','replacechildren')
plot(wavelength(f400_800nm),Jul21_MosaicFarm_flight2_Img_cnt_imputation(miss_data<-1,7:end));
grid on, box on; 
xlabel('Wavelength(nm)','FontWeight', 'bold');
ylabel('Observed Reflectance','FontWeight', 'bold');
legend(num2str((1:(sum(miss_data<-1)))'));


figure('position',[500 500 700 500]); 
axes('ColorOrder',jet(sum(miss_data<-1)),'NextPlot','replacechildren')
plot(wavelength(f400_800nm),X_imputed(miss_data<-1,7:end));
grid on, box on; 
xlabel('Wavelength(nm)','FontWeight', 'bold');
ylabel('Predicted reflectance','FontWeight', 'bold');
legend(num2str((1:(sum(miss_data<-1)))'));


figure('position',[500 500 700 500]); 
axes('ColorOrder',jet(sum(miss_data<-1)),'NextPlot','replacechildren')
plot(wavelength(f400_800nm),diff);
grid on, box on; 
xlabel('Wavelength(nm)','FontWeight', 'bold');
ylabel('Residual of reflectance','FontWeight', 'bold');
legend(num2str((1:(sum(miss_data<-1)))'));

figsave('Jul21_MosaicFarm_Flight2_imputation_validation_observ')
figsave('Jul21_MosaicFarm_Flight2_imputation_validation_residual')
figsave('Jul21_MosaicFarm_Flight2_imputation_validation_Predict')
figsave('Jul21_MosaicFarm_Flight2_imputation_validation_H_observ')
figsave('Jul21_MosaicFarm_Flight2_imputation_validation_H_Predict')
figsave('Jul21_MosaicFarm_Flight2_imputation_validation_H_residual')

%% an extra small figure to show the residual as perctange
figure('position',[500 500 700 500]); 
axes('ColorOrder',jet(sum(miss_data<-1)),'NextPlot','replacechildren')
obs=Jul21_MosaicFarm_flight2_Img_cnt_imputation(miss_data<-1,7:end);
plot(wavelength(f400_800nm),diff./obs*100);
grid on, box on; 
xlabel('Wavelength(nm)','FontWeight', 'bold');
ylabel('Residual of reflectance','FontWeight', 'bold');
legend(num2str((1:(sum(miss_data<-1)))'));


%% last plot of three-group comaprison
test_idx=find(miss_data<-1);
figure('position',[500 500 700 500]); 
grid on, box on; xlabel('Wavelength (nm)','FontWeight', 'bold');
ylabel('Reflectance','FontWeight', 'bold')
hold on;
plot_idx=1;
plot(wavelength(f400_800nm),Jul21_MosaicFarm_flight2_Img_cnt_imputation(test_idx(plot_idx),7:end),'r-');
plot(wavelength(f400_800nm),X_imputed(test_idx(plot_idx),7:end),'r--');
plot([490 550 680 720 800],tetracam_bands_avg_2_ref(plot_idx,1:5),'rs-','MarkerSize' ,8, 'MarkerFaceColor','k')
plot_idx=6;
plot(wavelength(f400_800nm),Jul21_MosaicFarm_flight2_Img_cnt_imputation(test_idx(plot_idx),7:end),'b-');
plot(wavelength(f400_800nm),X_imputed(test_idx(plot_idx),7:end),'b--');
plot([490 550 680 720 800],tetracam_bands_avg_2_ref(plot_idx,1:5),'bs-','MarkerSize' ,8, 'MarkerFaceColor','k')
plot_idx=11;
plot(wavelength(f400_800nm),Jul21_MosaicFarm_flight2_Img_cnt_imputation(test_idx(plot_idx),7:end),'c-');
plot(wavelength(f400_800nm),X_imputed(test_idx(plot_idx),7:end),'c--');
plot([490 550 680 720 800],tetracam_bands_avg_2_ref(plot_idx,1:5),'cs-','MarkerSize' ,8, 'MarkerFaceColor','k')
hold off;
legend('Obs1', 'Pre1','Reg1','Obs2', 'Pre2','Reg2','Obs3', 'Pre3','Reg3');

%only test three samples
for plot_idx=1:5:15
    plot(wavelength(f400_800nm),Jul21_MosaicFarm_flight2_Img_cnt_imputation(test_idx(plot_idx),7:end));
    plot(wavelength(f400_800nm),X_imputed(test_idx(plot_idx),7:end));
    plot([490 550 680 720 800],tetracam_bands_avg_2_ref(plot_idx,1:5),'s-','MarkerSize' ,8)
end
hold off;

