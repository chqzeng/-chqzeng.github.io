%imputation of the data using the given Tetracam and STS-VIS data
wavelength=Spectra_veg_R{1,2}(:,1);

filter=[2573:2700]-2570; %remove some pics in the shade
%TetraCAM_photo_centre.new_tick=(TetraCAM_photo_centre.TetraCAM_tick-537.03664)*(1-1.2/521.2)+537.03664;
TetraCAM_photo_centre_adj=TetraCAM_photo_centre(filter,:);

%build the training sample matrix using the matched TEtracam and STS-VIS data at the 5 bands
%[IDX]=knnsearch(STS_spectra_centre.STS_tick-def_Tetracam_STS_offset,(TetraCAM_photo_centre_adj.new_tick+dt),'K',1 );
[IDX]=knnsearch(STS_spectra_centre.STS_tick-def_Tetracam_STS_offset,(TetraCAM_photo_centre_adj.TetraCAM_tick+dt),'K',1 );
f400_800nm=140:980;
Tetracam_6bands_avg=TetraCAM_photo_centre{filter,8:13};
STS_spectra_matched_Tetracam = cell2mat((Spectra_veg_R(IDX,2))');  %obtain the 2nd column (spectra), at matched spectr points
STS_spectra_matched_Tetracam=STS_spectra_matched_Tetracam(f400_800nm,2:2:end); %only keep the spectra value at 400-800nm
Jul21_MosaicFarm_flight2_Img_cnt_imputation=[Tetracam_6bands_avg, STS_spectra_matched_Tetracam'];

%randomly remove some spectra,
miss_data=randn(128,1); %hist(miss_data)
Jul21_MosaicFarm_flight2_Img_cnt_imputation_missed=Jul21_MosaicFarm_flight2_Img_cnt_imputation;
Jul21_MosaicFarm_flight2_Img_cnt_imputation_missed(miss_data<-1,7:end)=NaN;

%do the imputation
[X_imputed, m, S, It, diff, Xrec] = pcambtsr(Jul21_MosaicFarm_flight2_Img_cnt_imputation_missed, 3, 10, 10e-5); %use the first 3PCA, iterate maximum 10times,

%view the result
diff=X_imputed(miss_data<-1,7:end)-Jul21_MosaicFarm_flight2_Img_cnt_imputation(miss_data<-1,7:end);
figure; plot(wavelength(f400_800nm),Jul21_MosaicFarm_flight2_Img_cnt_imputation(miss_data<-1,7:end));grid on, box on; title('the observed spectra'); xlabel('wavelength(nm)');ylabel('reflectance')
figure; plot(wavelength(f400_800nm),X_imputed(miss_data<-1,7:end));grid on, box on; title('the predicted spectra'); xlabel('wavelength(nm)');ylabel('reflectance')
figure; plot(wavelength(f400_800nm),diff); grid on, box on; title('difference of the predicted spectra'); xlabel('wavelength(nm)');ylabel('reflectance')

clear  m S It diff Xrec;

%add the regression based reflectance 6-points to the curve as well
p=[1.32453457281875e-05	0.0207876645136882
9.67783680583884e-06	-0.00756167199483431
8.15927286625553e-06	0.00556123750379710
1.17407284773385e-05	0.0283083651505677
1.38648742999604e-05	0.0511408718037953];
tetracam_bands_avg=Jul21_MosaicFarm_flight2_Img_cnt_imputation(miss_data<-1,1:6);

tetracam_bands_avg_2_ref=zeros(size(tetracam_bands_avg));
for idx=1:5
    tetracam_bands_avg_2_ref(:,idx)=polyval(p(idx,:),tetracam_bands_avg(:,idx));
end

test_idx=find(miss_data<-1);
figure; 
grid on, box on; title('the predicted spectra'); xlabel('wavelength(nm)');ylabel('reflectance')
hold on;
%only test three samples
for plot_idx=1:5:15
    plot(wavelength(f400_800nm),Jul21_MosaicFarm_flight2_Img_cnt_imputation(test_idx(plot_idx),7:end));
    plot(wavelength(f400_800nm),X_imputed(test_idx(plot_idx),7:end));
    plot([490 550 680 720 800],tetracam_bands_avg_2_ref(plot_idx,1:5),'s','MarkerSize' ,8)
end
hold off;

%caluate the RMSE/RMSD of the curves
tetracam_bands_avg_2_ref_all=zeros(length(test_idx),length(f400_800nm));
for plot_idx=1:length(test_idx)
    tetracam_bands_avg_2_ref_all(plot_idx,:)=interp1([490 550 680 720 800],tetracam_bands_avg_2_ref(plot_idx,1:5),wavelength(f400_800nm));
    %plot(wavelength(f400_800nm),tetracam_bands_avg_2_ref_all(plot_idx,:));
    %plot([490 550 680 720 800],tetracam_bands_avg_2_ref(plot_idx,1:5),'s','MarkerSize' ,8)
end

v_rmse_pre=0;
v_rmse_reg=0;
v_rmsd=0;
for plot_idx=1:length(test_idx)
    v_mse=immse(X_imputed(test_idx(plot_idx),201:end), Jul21_MosaicFarm_flight2_Img_cnt_imputation(test_idx(plot_idx),201:end));
    v_rmse_pre=v_rmse_pre+sqrt(v_mse);
    v_mse=immse(tetracam_bands_avg_2_ref_all(plot_idx,195:end), Jul21_MosaicFarm_flight2_Img_cnt_imputation(test_idx(plot_idx),201:end));
    v_rmse_reg=v_rmse_reg+sqrt(v_mse);
    v_mse=immse(tetracam_bands_avg_2_ref_all(plot_idx,195:end), X_imputed(test_idx(plot_idx),201:end));
    v_rmsd=v_rmse_reg+sqrt(v_mse);
end

v_mse=immse(X_imputed(miss_data<-1,201:end), Jul21_MosaicFarm_flight2_Img_cnt_imputation(miss_data<-1,201:end));
sqrt(v_mse)
v_mse=immse(tetracam_bands_avg_2_ref_all(:,195:end), Jul21_MosaicFarm_flight2_Img_cnt_imputation(miss_data<-1,201:end));
sqrt(v_mse)

