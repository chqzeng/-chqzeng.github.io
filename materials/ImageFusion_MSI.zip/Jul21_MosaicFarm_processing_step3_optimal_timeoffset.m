%%%---------------------------script to find the optimal time offset  ------------------
if false
    
    %load('Aug26_GolfCourse_UAV_spectra_flight1_per_image_regression.mat')
    wavelength=Spectra_veg{1,2}(:,1);
    
    % ----------------------code used to load the filter of the TEtracam lens ------------------------------ 
    str_filter_path='.\BandPass_filter_profile\';
    Flt_list=struct;
    band_list=[490  550 680 720  800  900 ];
    Flt_list.Flt_490=readtable([ str_filter_path, '490FS10.csv'],'Format','%f%f','HeaderLines',8,'Delimiter',',');
    Flt_list.Flt_550=readtable([ str_filter_path, '550FS10.csv'],'Format','%f%f','HeaderLines',8,'Delimiter',',');
    Flt_list.Flt_680=readtable([ str_filter_path, '680FS10.csv'],'Format','%f%f','HeaderLines',8,'Delimiter',',');
    Flt_list.Flt_720=readtable([ str_filter_path, '720FS10.csv'],'Format','%f%f','HeaderLines',8,'Delimiter',',');
    Flt_list.Flt_800=readtable([ str_filter_path, '800FS10.csv'],'Format','%f%f','HeaderLines',8,'Delimiter',',');
    Flt_list.Flt_900=readtable([ str_filter_path, '900FS10.csv'],'Format','%f%f','HeaderLines',8,'Delimiter',',');
    
    Flt_list_fields=fieldnames(Flt_list);
    column_idx=11;
    STS_spectra_centre{:,(column_idx+1):(column_idx+5)}=0;
    % ------------for each of the loaded TEtracam band, need to calculate the convoluted bands from narrow bands to 10nm bands------------- 
    for idx=1:5
        band=band_list(idx); flt=getfield(Flt_list, Flt_list_fields{idx});  %take the 680nm band as an example.
        [STS_idx]=knnsearch(wavelength,[band-10,band+10]','K',1); %find the closet bands with that +/-10nm range, get rid of the rest in the filter
        flt_idx=knnsearch(flt{:,1}, wavelength((STS_idx(1):STS_idx(2))'),'K',1);
        flt_usd=flt(flt_idx,:);flt_usd(:,3)=num2cell((STS_idx(1):STS_idx(2))');
        flt_usd.Properties.VariableNames{3} = 'STS_idx';
        %the integration function, requires the detailed dark current, sun condition for the convolution. 
        %Tetracam_band_ref = TetraCAM_band_integration(Spectra_veg,flt_usd,White_ref_ground_PI,Dark_offset_ground_PI,Spectra_sun,Spectra_sun_WhiteRef, Dark_offset_sun_OceanView);
        Tetracam_band_ref = TetraCAM_band_integration(Spectra_veg,flt_usd,White_ref_ground_PI,Dark_offset_ground_PI,[],[], []);
        column_idx=column_idx+1; STS_spectra_centre(:,column_idx)=num2cell(Tetracam_band_ref);
        STS_spectra_centre.Properties.VariableNames{column_idx} = Flt_list_fields{idx};
    end
end

if false
    %-------------for the Tetracam image side, find the average from multipage tiff images -----------------------------------
    radius=24; img_mask=make_cricle_mask (radius); %creat a mask with radius of 24pixels.
    Tetracam_photo_center_rows=7; %current exsiting number of rows of Tetracam_photo_center
    Tetracam_mean_bnds=(Tetracam_photo_center_rows+1):(Tetracam_photo_center_rows+6);
    bFieldname=true;
    TetraCAM_photo_centre{:,Tetracam_mean_bnds}=0;
    %TetraCAM_photo_centre.Properties.VariableNames{Tetracam_mean_bnds} = cellstr(strcat('nm',num2str(band_list')));%add the label
    for idx=1:264 %iterate each image
        filepath=['L:\_London_fieldwork_July\TetraCAM\July21_Mosiac_farm\SinglePage_tiff\',TetraCAM_photo_centre{idx,1}];
        %filepath = strrep(filepath, 'TTC', 'TTC00');
        %filepath=['L:\_London_fieldwork_July\TetraCAM\July21_Mosiac_farm\SinglePage_tiff\TTC',TetraCAM_photo_centre{idx,1},'_16.TIF'];
        
        if  ~ exist(filepath,'file'); continue; end
        InputImage=imread(filepath); %read the file
        center=size(InputImage(:,:,1))./2;
        for idy=1:6  %iterate each band
            template=InputImage((center(1)-radius):(center(1)+radius-1),(center(2)-radius):(center(2)+radius-1),idy);
            TetraCAM_photo_centre{idx,idy+Tetracam_photo_center_rows}=mean(template(img_mask));
            if(bFieldname) TetraCAM_photo_centre.Properties.VariableNames{idy+Tetracam_photo_center_rows} = Flt_list_fields{idy};end
        end
        bFieldname=false;
    end
end


%def_Tetracam_STS_offset=(1582.8-532.6);
def_Tetracam_STS_offset=(64942.326-1539.459);  %the initial time offset based manual inspection of the spectra over the sand bunker 
%filter=[116:192, 203:240, 249:263, 306:370]-85;%29:287, removed the very cloudy image samples;
%filter=[123:170, 185:191, 221:231, 252:263, 337:358]-85;%only select the brightest images
%filter=[116:126] -85;   %start: sand bunker
%filter=[154:174] -85;   %end: sand bunker
filter=[2573:2700]-2570;  %[2571:2834]-2570;   %250:264;
TetraCAM_photo_centre_adj=TetraCAM_photo_centre(filter,:);
searchrange=(-10:0.2:10);
Rsquare=zeros(length(searchrange),5);  %for the search range, and 5 bands (900nm not avaliable)
r_idx=1;

t_time_Opt=tic;
for dt=searchrange %the time offset from -10s to 10s, with 0.2s interval
    try
        %caculate the best match of list
        [IDX]=knnsearch(STS_spectra_centre.STS_tick-def_Tetracam_STS_offset,(TetraCAM_photo_centre_adj.TetraCAM_tick+dt),'K',1 ); %orginal
        %[IDX]=knnsearch(STS_spectra_centre.STS_tick-def_Tetracam_STS_offset,(TetraCAM_photo_centre_adj.new_tick+dt),'K',1 );
        b_idx=0;
        b_idx=b_idx+1; band_X=getfield(TetraCAM_photo_centre_adj, Flt_list_fields{b_idx}); band_Y=getfield(STS_spectra_centre(IDX,:), Flt_list_fields{b_idx}); Rsquare(r_idx,1)=Calculate_Rsquare( band_X,band_Y);
        b_idx=b_idx+1; band_X=getfield(TetraCAM_photo_centre_adj, Flt_list_fields{b_idx}); band_Y=getfield(STS_spectra_centre(IDX,:), Flt_list_fields{b_idx}); Rsquare(r_idx,2)=Calculate_Rsquare( band_X,band_Y);
        b_idx=b_idx+1; band_X=getfield(TetraCAM_photo_centre_adj, Flt_list_fields{b_idx}); band_Y=getfield(STS_spectra_centre(IDX,:), Flt_list_fields{b_idx}); Rsquare(r_idx,3)=Calculate_Rsquare( band_X,band_Y);
        b_idx=b_idx+1; band_X=getfield(TetraCAM_photo_centre_adj, Flt_list_fields{b_idx}); band_Y=getfield(STS_spectra_centre(IDX,:), Flt_list_fields{b_idx}); Rsquare(r_idx,4)=Calculate_Rsquare( band_X,band_Y);
        b_idx=b_idx+1; band_X=getfield(TetraCAM_photo_centre_adj, Flt_list_fields{b_idx}); band_Y=getfield(STS_spectra_centre(IDX,:), Flt_list_fields{b_idx}); Rsquare(r_idx,5)=Calculate_Rsquare( band_X,band_Y);
        r_idx=r_idx+1;
    catch
        continue;
    end
end
time_used=toc(t_time_Opt);
disp(['time space optimization: ', num2str(time_used), 'seconds']);

[val, idx]=max(sum(Rsquare,2));  %find the offset with highest r-square
disp(['R square' , num2str(val/5)])
disp(['Time offset: ',num2str(searchrange(idx))])

%draw the r-square distribution
figure;plot(searchrange,Rsquare,'.-')
legend('490nm','550nm','680nm','720nm','800nm')
xlabel('Shift from intial matched timeline');ylabel('R-sqaure');
grid on; box on;
text(searchrange(1)+0.2,(val/5),[{['Avg R-square: ', num2str(val/5)]}, {['Time offset: ',num2str(searchrange(idx))]}])
%title('Image used: All');
str_title=['Image used: ID ',TetraCAM_photo_centre{filter(1),1},'---',TetraCAM_photo_centre{filter(end),1}];
str_title=strrep(str_title,'_16.TIF','');str_title=strrep(str_title,'TTC','');
title(str_title)

%draw the scatterplot of regression for each band at the optimal offset
if true
    dt=searchrange(idx); %find the optimal time offset
    [IDX]=knnsearch(STS_spectra_centre.STS_tick-def_Tetracam_STS_offset,(TetraCAM_photo_centre_adj.TetraCAM_tick+dt),'K',1 );
    %[IDX]=knnsearch(STS_spectra_centre.STS_tick-def_Tetracam_STS_offset,(TetraCAM_photo_centre_adj.new_tick+dt),'K',1 );
    Calculate_Rsquare( getfield(TetraCAM_photo_centre_adj, Flt_list_fields{1}), getfield(STS_spectra_centre(IDX,:), Flt_list_fields{1}), true);%calcuate r square and plot
    Calculate_Rsquare( getfield(TetraCAM_photo_centre_adj, Flt_list_fields{2}), getfield(STS_spectra_centre(IDX,:), Flt_list_fields{2}), true);
    Calculate_Rsquare( getfield(TetraCAM_photo_centre_adj, Flt_list_fields{3}), getfield(STS_spectra_centre(IDX,:), Flt_list_fields{3}), true);
    Calculate_Rsquare( getfield(TetraCAM_photo_centre_adj, Flt_list_fields{4}), getfield(STS_spectra_centre(IDX,:), Flt_list_fields{4}), true);
    Calculate_Rsquare( getfield(TetraCAM_photo_centre_adj, Flt_list_fields{5}), getfield(STS_spectra_centre(IDX,:), Flt_list_fields{5}), true);
end


