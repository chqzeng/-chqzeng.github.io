%load the dark offset for the STS-Raspberry Pi
if true  %load the dark object for both STS when connecting to the Raspberry PI
    % clear;clc;  
    unit_min2datenum=1/1440;
    load('STS_Calibration_Dark.mat');  %STS_S07364_dark_PI_mean STS_S07352_dark_OV_mean  str_integration_list
   
    integ_time_PI=200; %integration time of the PI spectrometer in milliseconds
    integ_time_OV=200; %integration time of the OceanView spectrometer in milliseconds
    
    temp_idx=strfind(str_integration_list(1,:),num2str(integ_time_PI));
    temp_idx = find(not(cellfun('isempty', temp_idx )));
    if isempty(temp_idx)
        disp('no stored dark offset for the given PI integration time for the ground')
        return;
    end
    dark_idx_PI=temp_idx(1);  %only use the first match
    Dark_offset_ground_PI=STS_S07364_dark_PI_mean{dark_idx_PI,2}; %PI sensor: S07364;
    
    temp_idx=strfind(str_integration_list(1,:),num2str(integ_time_OV));
    temp_idx = find(not(cellfun('isempty', temp_idx )));
    if isempty(temp_idx)
        disp('no stored dark offset for the given OceanView integration time for the sun')
        return;
    end
    dark_idx_OV=temp_idx(1);  %only use the first match
    Dark_offset_sun_OceanView=STS_S07352_dark_OV_mean{dark_idx_OV,2}; %OV sensor: 07352;
end

if (1) %Load the site specific data
    %--- If ground sun illumination: load the sun illumination STS with oceanview software ----
    Spectra_sun=[];
    Spectra_sun_WhiteRef=[];
 
    %load the PI mesaured spectormetr from sky
    str_Directory='..\Spectrometer\July21_MoasicFarm\';
    Spectra_veg=Read_STS_file_group(str_Directory,'flight3*_.txt_');  %only one sample per 10 samples
    Spectra_ref_all=Read_STS_file_group(str_Directory,'white-ref*_.txt_');  
    Spectra_ref=Spectra_ref_all(1:20,:);
   
    start_time=Estimate_PI_start_time([69356264 2016 07 21 12 33 06],[70284948 2016 07 21 12 48 34 ]);
    
    %update the time in down-looking STS using Raspberry PI, to keep consistent with normal time
    %convert from milliseconds to minutes,by dividing 60000;; then add the start time in datenum format
    Spectra_veg(:,4)=Spectra_veg(:,1);
    Spectra_ref(:,4)=Spectra_ref(:,1);
    Spectra_veg(:,1)=num2cell(cell2mat(Spectra_veg(:,1))/60000* unit_min2datenum+start_time);
    Spectra_ref(:,1)=num2cell(cell2mat(Spectra_ref(:,1))/60000* unit_min2datenum+start_time);
    Spectra_veg(:,5)=cellstr(datestr(cell2mat(Spectra_veg(:,1))));
    Spectra_ref(:,5)=cellstr(datestr(cell2mat(Spectra_ref(:,1))));
    
%     valid_veg_id_list=1720:2980;
%     valid_ref_id_list=20:50;
    [White_ref_ground_PI,~,~,~] = stats_spectra(Spectra_ref);  
end    
    %call the core function to process the water samples.
    Spectra_veg_R = Spectral_processing(Spectra_veg,White_ref_ground_PI,Dark_offset_ground_PI,[],[],[],false);    
 