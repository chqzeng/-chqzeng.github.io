function [C] = make_cricle_mask (radius)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
%Circle with radius centered at 40,40 in an 80x80image
%   return a logical mask of circle shape

[rr cc] = meshgrid(1:(radius*2));
C = sqrt((rr-radius).^2+(cc-radius).^2)<=radius;
return

end

