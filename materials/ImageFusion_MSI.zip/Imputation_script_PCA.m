% missing data imputation using the Guassian model

X_imputed=zeros(size(XmissTrain));

model_name='pcambtsr'; %'pcambkdr', etc
tStart=tic;
switch model_name
    case 'pcambtsr'
        [X_imputed, m, S, It, diff, Xrec] = pcambtsr(XmissTrain, 3, 10, 10e-5); %use the first 3PCA, iterate maximum 10times,
    case 'pcambkdr'
        [X_imputed,~,~,~,~] = pcambkdr(XmissTrain, 3, 10, 10e-5);
    case 'pcambpcr'
        [X_imputed,~,~,~,~] = pcambpcr(XmissTrain, 3, 10, 10e-5);
    case 'pcambpls'
        [X_imputed,~,~,~,~] = pcambpls(XmissTrain, 3, 10, 10e-5);
    case 'pcambpmp'
        [X_imputed,~,~,~,~] = pcambpmp(XmissTrain, 3, 10, 10e-5);
    case 'pcambia'
        [X_imputed,~,~,~,~] = pcambia(XmissTrain, 3, 10, 10e-5);
    case 'pcambnipals'
        [X_imputed,~,~,~,~] = pcambnipals(XmissTrain, 3, 10, 10e-5);
    case 'pcambda'  %it will report "positive definite" error if run the entire dataset, thus seperate into 20 subsets
        interval=20;
        for idx=1:interval
            range=[1:6 (6+idx):interval:size(XmissTrain,2)];
            [X_imputed(:,range),~,~] = pcambda(XmissTrain(:,range), 10,100,3);
        end
end
tElapsed = toc(tStart);  %record the processing time: end
disp(num2str(tElapsed)) %show the time

%calcuate the differnce between imputation and observation
diff_BYS=X_imputed(miss_data<-1,7:end)-XFullTrain(miss_data<-1,7:end);
plot(wavelength(f400_800nm),diff_BYS); 
ylim([-0.1 0.1]);grid on, box on; xlabel('Wavelength(nm)');ylabel('Resdiual of reflectance')
figsave(strcat('Bayesian_Imputation_with_sampling_approach_',model_name));

%calculate the metrics
X=XFullTrain(miss_data<-1,7:end);
Y=X_imputed(miss_data<-1,7:end);
[ME,MAE,STD_AE,SNR,mean_Q,SAM,RMSE,ERGAS,D_dist] = HS_evaluation_metrics(X,Y);
[ME,MAE,STD_AE,SNR,mean_Q,SAM,RMSE,ERGAS,D_dist];
