%load('Generate_Hyperspectral_Image_cube.mat');

mask=simultated_hyper(:,:,1)>0;
%I=decorrstretch(simultated_hyper,'tol',0.1);
figure; hold on;
for idx=1:10: size(I,3)
imagesc(idx*-0.1, idx*-0.1,simultated_hyper(:,:,idx),'AlphaData',mask);
end; hold off;xlabel('X');ylabel('Y');
set (gca, 'YDir','reverse'); colormap(jet)
%grid on;
break;

%draw the true 3D but result problematic, gave up
for k=1:10:size(I,3)
    s=surface('XData',X-0.5,'YData',Y-0.5,'ZData',Z.*k,'CData',I(:,:,k),'CDataMapping','scale',...
     'FaceColor','texturemap','Edgecolor','none');
    s.FaceAlpha='texturemap';
    s.AlphaData=0; %mask; %max(I(:,:,k),[]);
end
myclr=jet;
myclr(1,:)=[1 1 1]; %set the background as white
colormap(myclr);
xlabel('X');ylabel('Y');zlabel('bands');
grid on;view([-25,70])
%view(3), box on; axis tight square;
%set (gca, 'YDir','reverse','ZLim',[1 size(I,3)+1])