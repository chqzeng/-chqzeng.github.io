    %clean the workspace
 %   clear;clc
    
    %----------------------step1: load spectra----------------------
    if false
        load_sts_spectra_batch_July21_mosaicFarm_flight3;
%         clearvars -except Spectra_veg_R Spectra_veg  White_ref_ground_PI Dark_offset_ground_PI  ...
%                           Spectra_sun Spectra_sun_WhiteRef  Dark_offset_sun_OceanView;  %only keep the useful variable
        %refine the spectra, by smoothing
        Spectra_veg_R = spectra_filter_single(Spectra_veg_R,7);%smooth the curve with a window size 7
        save('Jul21_Flight3_MosaicFarm_UAV_Spectra_veg_R.mat');
%    else
        load('Jul21_Flight3_MosaicFarm_UAV_Spectra_veg_R.mat');
    end
    
    %----------------------step 2: determine the location of Tetracam image positions----------------------
    if false 
        %--------------need manual input in this step ------------------
        Load_UAV_log_file_July21_MoasicFarm_flight3;
        save('UAV_log_info_July21_MosiacFarm_flight3.mat');
 %   else %or load the existing data
        %fetch the X,Y, Z coords for each measurement
        load('UAV_log_info_July21_MosiacFarm_flight3.mat');
    end

    % ----------------------STEP 3: adjust the timeline by finding the optimal offest that gives the 
    %           highest R-square between Tetracam bands and STS-VIS convolutedbands----------------------
    if true
        Spectra_veg_R(:,6)=num2cell(cell2mat(Spectra_veg_R(:,4))/1000 -70074.747+983.11); %Image3130 matches with STS id: flight3_3069.txt
        [IDX,~]=knnsearch(Log_file_info_array{:,1},cell2mat(Spectra_veg_R(:,6)),'K',1);
        STS_spectra_centre=Log_file_info_array(IDX,1:10);  %oging to improve it using the two functions.
        STS_spectra_centre.STS_tick=cell2mat(Spectra_veg_R(:,4))./1000;  %convert usecond to second

        TetraCAM_photo_centre(:,5:7)=Tetracam_img_info(:,2:4); %merge the two tables 
        %TetraCAM_photo_centre.new_tick=(TetraCAM_photo_centre.TetraCAM_tick-537.03664)*(1-1.2/521.2)+537.03664; %time=gain*org+offset
        
        %Jul21_MosaicFarm_processing_step3_optimal_timeoffset
        %Jul21_MosaicFarm_processing_step3_optimal_timeoffset_ex
        Jul21_MosaicFarm_processing_step3_optimal_global
        
        clearvars -except Spectra_veg_R Spectra_veg  White_ref_ground_PI Dark_offset_ground_PI  ...
                          Spectra_sun Spectra_sun_WhiteRef  Dark_offset_sun_OceanView ...
                          TetraCAM_photo_centre Log_file_info_array Tetracam_img_info ...
                          wavelength STS_spectra_centre  TetraCAM_photo_centre_adj Rsquare def_Tetracam_STS_offset dt;
        save('Jul21_MosaicFarm_UAV_flight3_step3_regression.mat');
    else
        load('Jul21_MosaicFarm_UAV_flight3_step3_regression.mat');
    end
    
    % -----------STEP 4: skipped determine the initial location of STS-vis Spectra positions by interpolation--------------
    if false
        Jul21_MosaicFarm_processing_step4_STSVIS_interpolation
        clearvars -except Spectra_veg_R Spectra_veg  White_ref_ground_PI Dark_offset_ground_PI  ...
                          Spectra_sun Spectra_sun_WhiteRef  Dark_offset_sun_OceanView ...
                          TetraCAM_photo_centre Log_file_info_array Tetracam_img_info ...
                          STS_spectra_centre  TetraCAM_photo_centre_adj Rsquare def_Tetracam_STS_offset dt...
                          Spectra_veg_R_struct ;
        save('Jul21_MosaicFarm_UAV_Spectra_veg_R_step4_cnt_pos.mat');
    else
        load('Jul21_MosaicFarm_UAV_Spectra_veg_R_step4_cnt_pos.mat');
    end
    
    % ----------STEP 5:  build the sample to predict new values----------
    %Jul21_MosaicFarm_processing_step5_imputation;
    Jul21_MosaicFarm_processing_flight3_step5_imputation
    save('Jul21_MosaicFarm_processing_flight3_step5_imputation.mat');
    
return;  

    