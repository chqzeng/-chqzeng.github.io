% Imputation_script_PCA_performance
% this scripts used to test the change of PCA imputation parameters and their impact on imputation result

% load('Data_imputation_Jul21_MosaicFarm_UAV_flight2.mat');

XFullTrain=Jul21_MosaicFarm_flight2_Img_cnt_imputation; %the incoming dataset for test
sampleNum=128; %overall sample number
rng default %returns the same value as at startup
[~, miss_data]=sort(randn(sampleNum,1)); %only intrested in the index of the random sample, now the first "missNum" of smaller samples will be treated as "missing"

%run the PCA based imputation with different parameters
tol=10e-5; %tolerance f
Max_iter=10; %maximum of M iterations
Num_PC=3; % A components is used.
missNum=25; % the number of samples used for training, while the rest(sampleNum - missNum) used as test sample
%List_Performance = table(0,0,0,0,0,array(5),'VariableNames',{'SmpNum' 'TrainNum' 'tol' 'max_iter' 'num_Pc' 'Err'})
clear List_Performance;
List_Performance(1) = struct('SmpNum', sampleNum, 'TrainNum',missNum, 'tol',tol, 'max_iter',Max_iter, 'num_Pc',Num_PC, 'Err',zeros(9,1));

if true  %test the number of training samples
    interval=3;
    for missNum=5:interval:120 %run with different training/test smaples ratio
        XmissTrain=XFullTrain;  %the traning matrix, with some NaN values
        XmissTrain(miss_data(1:missNum),7:end)=NaN;
        [X_imputed, m, S, It, diff, Xrec] = pcambtsr(XmissTrain, Num_PC, Max_iter, tol); %use the first 3PCA, iterate maximum 10times,
        %calcuate the accuracy matrix
        X=XFullTrain(miss_data(1:missNum),7:end);
        Y=X_imputed(miss_data(1:missNum),7:end);
        [ME,MAE,STD_AE,SNR,mean_Q,SAM,RMSE,ERGAS,D_dist]= HS_evaluation_metrics(X,Y);
        List_Performance(floor(missNum/interval))=List_Performance(1);
        List_Performance(floor(missNum/interval)).TrainNum=missNum;  %update the training number 
        List_Performance(floor(missNum/interval)).Err = [ME,MAE,STD_AE,SNR,mean_Q,SAM,RMSE,ERGAS,D_dist];
    end
    List_Performance_TrainNum=List_Performance;
    %view how the error changes
    List_Err=cell2mat({List_Performance.Err}');
    %the 7th column is the RMSE
    
    %figure; 
    plot(sampleNum-cell2mat({List_Performance.TrainNum}), List_Err(:,7),'-bs',...
        'LineWidth',1,'MarkerSize',5,'MarkerEdgeColor','r','MarkerFaceColor','r'); 
    grid on; box on; xlim(minmax(cell2mat({List_Performance.TrainNum})));
    xlabel('Number of Training samples (in 128)','FontWeight' ,'bold'); ylabel('RMSE','FontWeight' ,'bold'); grid on; box on;
end

if false  %test tolerance
    List_Performance(2:end)=[]; %only keep the first error list in the struct array
    XmissTrain=XFullTrain;  %the traning matrix, with some NaN values
    XmissTrain(miss_data(1:missNum),7:end)=NaN;
   X=XFullTrain(miss_data(1:missNum),7:end);
   
    interval=0.5*10e-5;
    for idx=1:20 %run with different training/test smaples ratio
        tol=10e-6+idx*interval;
        [X_imputed, m, S, It, diff, Xrec] = pcambtsr(XmissTrain, Num_PC, Max_iter, tol); %use the first 3PCA, iterate maximum 10times,
        %calcuate the accuracy matrix
        Y=X_imputed(miss_data(1:missNum),7:end);
        [ME,MAE,STD_AE,SNR,mean_Q,SAM,RMSE,ERGAS,D_dist]= HS_evaluation_metrics(X,Y);
        List_Performance(idx)=List_Performance(1);
        List_Performance(idx).tol=tol;  %update the training number 
        List_Performance(idx).Err = [ME,MAE,STD_AE,SNR,mean_Q,SAM,RMSE,ERGAS,D_dist];
    end
    List_Performance_tol=List_Performance;
    List_Err=cell2mat({List_Performance.Err}');
    %figure;
    plot(cell2mat({List_Performance.tol}), List_Err(:,7),'-bs',...
    'LineWidth',1,'MarkerSize',5,'MarkerEdgeColor','r','MarkerFaceColor','r');
    grid on; box on; xlim(minmax(cell2mat({List_Performance.tol})));
    xlabel('Tolerance','FontWeight' ,'bold'); ylabel('RMSE','FontWeight' ,'bold'); grid on; box on;
end

if false  %test iteration times
    List_Performance(2:end)=[]; %only keep the first error list in the struct array
    XmissTrain=XFullTrain;  %the traning matrix, with some NaN values
    XmissTrain(miss_data(1:missNum),7:end)=NaN;
    X=XFullTrain(miss_data(1:missNum),7:end);
   
    interval=1;
    for idx=1:20 %run with different training/test smaples ratio
        Max_iter=interval*idx;
        [X_imputed, m, S, It, diff, Xrec] = pcambtsr(XmissTrain, Num_PC, Max_iter, tol); %use the first 3PCA, iterate maximum 10times,
        %calcuate the accuracy matrix
        Y=X_imputed(miss_data(1:missNum),7:end);
        [ME,MAE,STD_AE,SNR,mean_Q,SAM,RMSE,ERGAS,D_dist]= HS_evaluation_metrics(X,Y);
        List_Performance(idx)=List_Performance(1);
        List_Performance(idx).max_iter=Max_iter;  %update the training number 
        List_Performance(idx).Err = [ME,MAE,STD_AE,SNR,mean_Q,SAM,RMSE,ERGAS,D_dist];
    end
    List_Performance_iter=List_Performance;
    List_Err=cell2mat({List_Performance.Err}');
    %figure; 
    plot(cell2mat({List_Performance.Max_iter}), List_Err(:,7),'-bs',...
    'LineWidth',1,'MarkerSize',5,'MarkerEdgeColor','r','MarkerFaceColor','r');
    grid on; box on; xlim(minmax(cell2mat({List_Performance.Max_iter})));
    xlabel('Iteration times','FontWeight' ,'bold'); ylabel('RMSE','FontWeight' ,'bold'); grid on; box on;
end

Imputation_script_PCA_performance_plot;
