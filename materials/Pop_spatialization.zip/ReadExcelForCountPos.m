function MeanValue=ReadExcelForCountPos(filename,InDataSheet)
%open excel  file and then read the data to calculate MEAN of each column
%
%param 1: input excel file 
%       with at least TWO sheets, one for indata, one for outdat
%
%param 2: indata with columns to calculate MEAN
% treat the first coloumn as IDtown
% treat the second/3rd  coloumn as residual of current pop model
% treat the 4/5th  coloumn as residual of Yang pop model
% treat the 6/7th  coloumn as residual of (nitght+land) pop model
%
%PARAM 3: for output sheet name
%
%output: the matrix of MEAN, 
%
%usage example:  MeanValue=ReadExcelForMean('E:\2010��1�¹���\�ƹ����ؽ�Ϸ�����ʡ��֤����\SumTableForMATLAB.xls','Sheet1','Sheet2')

    %clear all;
    %cd 'E:\2010��1�¹���\�ƹ����ؽ�Ϸ�����ʡ��֤����\'
    xlsdata = xlsread(filename,InDataSheet);

    proCol=fix(xlsdata(:,1)/1e4);
    proIdx=unique(proCol);
    MeanValue=zeros(length(proIdx),2);
    
    for i=1:length(proIdx)
        SelectedCol=find(proCol==proIdx(i));
        SelectValue=xlsdata(SelectedCol,[4,5]);
        MeanValue(i,:)=[length(find(SelectValue(:,1)>0)),length(find(SelectValue(:,2)>0))];
    end
    
    %xlswrite(filename, MeanValue, OutDataSheet);
end