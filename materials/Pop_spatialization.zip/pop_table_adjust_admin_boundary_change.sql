
--// ���ٱ������ӵĽ��
select AD2004, NAME2004,ProvCode, ProvName, Pop2008,test from  CountyBoundary where AD2004>310000  --Pop2008 is null 
update CountyBoundary set Pop2008=test where Pop2008 is null

--   ����3�������Щ��Ͻ�����˿�

--  ����Ȧ
declare @m_popsum numeric(10)
DECLARE m_cursor CURSOR
   FOR SELECT PopCity FROM Pop_CityTable_2008 where LEFT(rtrim(ltrim(CityName)),2) ='Ӫ��'

OPEN m_cursor
FETCH NEXT FROM m_cursor INTO @m_popsum 

update CountyBoundary set Pop2008=@m_popsum* 0.32967033 
where LEFT(rtrim(ltrim(NAME2004)),3) ='����Ȧ'

update CountyBoundary set Pop2008=@m_popsum* (1 - 0.32967033)
where LEFT(rtrim(ltrim(NAME2004)),3) ='Ӫ����'

CLOSE m_cursor
DEALLOCATE m_cursor



--  �ֿ���, ������
  declare @m_popsum numeric(10)
  DECLARE m_cursor CURSOR
   FOR SELECT PopCity FROM Pop_CityTable_2008 where LEFT(rtrim(ltrim(CityName)),2) ='�Ͼ�'
OPEN m_cursor
FETCH NEXT FROM m_cursor INTO @m_popsum 
CLOSE m_cursor
DEALLOCATE m_cursor

declare @m_pop1 numeric(10)
  DECLARE m_cursor CURSOR
   FOR SELECT Pop2008 FROM CountyBoundary where LEFT(rtrim(ltrim(NAME2004)),3) ='������'
OPEN m_cursor
FETCH NEXT FROM m_cursor INTO @m_pop1 


update CountyBoundary set Pop2008=@m_popsum* 0.095
where LEFT(rtrim(ltrim(NAME2004)),3) ='�ֿ���'

update CountyBoundary set Pop2008=@m_popsum* (1 - 0.095)-@m_pop1  
where LEFT(rtrim(ltrim(NAME2004)),3) ='�Ͼ���'

CLOSE m_cursor
DEALLOCATE m_cursor

--  �³���
declare @m_popsum numeric(10)
DECLARE m_cursor CURSOR
   FOR SELECT PopCity FROM Pop_CityTable_2008 where LEFT(rtrim(ltrim(CityName)),2) ='����'

OPEN m_cursor
FETCH NEXT FROM m_cursor INTO @m_popsum 


update CountyBoundary set Pop2008=@m_popsum* 0.50617284
where LEFT(rtrim(ltrim(NAME2004)),3) ='�³���'

update CountyBoundary set Pop2008=@m_popsum* (1- 0.50617284 )
where LEFT(rtrim(ltrim(NAME2004)),3) ='�齭��'

CLOSE m_cursor
DEALLOCATE m_cursor

--  ������
declare @m_popsum numeric(10)
DECLARE m_cursor CURSOR
   FOR SELECT PopCity FROM Pop_CityTable_2008 where LEFT(rtrim(ltrim(CityName)),2) ='����'

OPEN m_cursor
FETCH NEXT FROM m_cursor INTO @m_popsum 


update CountyBoundary set Pop2008=@m_popsum* 0.053763441
where LEFT(rtrim(ltrim(NAME2004)),3) ='������'

update CountyBoundary set Pop2008=@m_popsum* (1- 0.053763441 )
where LEFT(rtrim(ltrim(NAME2004)),3) ='������'

CLOSE m_cursor
DEALLOCATE m_cursor


--  ï����
declare @m_popsum numeric(10)
DECLARE m_cursor CURSOR
   FOR SELECT PopCity FROM Pop_CityTable_2008 where LEFT(rtrim(ltrim(CityName)),2) ='ï��'

OPEN m_cursor
FETCH NEXT FROM m_cursor INTO @m_popsum 


update CountyBoundary set Pop2008=@m_popsum* 0.611570248
where LEFT(rtrim(ltrim(NAME2004)),3) ='ï����'

update CountyBoundary set Pop2008=@m_popsum* 0.388429752
where LEFT(rtrim(ltrim(NAME2004)),3) ='ï����'

CLOSE m_cursor
DEALLOCATE m_cursor

--  ������
declare @m_popsum numeric(10)
DECLARE m_cursor CURSOR
   FOR SELECT PopCity FROM Pop_CityTable_2008 where LEFT(rtrim(ltrim(CityName)),2) ='����'

OPEN m_cursor
FETCH NEXT FROM m_cursor INTO @m_popsum 


update CountyBoundary set Pop2008=@m_popsum* 0.548672566
where LEFT(rtrim(ltrim(NAME2004)),3) ='������'

update CountyBoundary set Pop2008=@m_popsum* 0.451327434
where LEFT(rtrim(ltrim(NAME2004)),3) ='������'

CLOSE m_cursor
DEALLOCATE m_cursor



--  ��Ԫ��
declare @m_popsum numeric(10)
DECLARE m_cursor CURSOR
   FOR SELECT PopCity FROM Pop_CityTable_2008 where LEFT(rtrim(ltrim(CityName)),2) ='��Ԫ'

OPEN m_cursor
FETCH NEXT FROM m_cursor INTO @m_popsum 


update CountyBoundary set Pop2008=@m_popsum* 0.505494505
where LEFT(rtrim(ltrim(NAME2004)),3) ='������'

update CountyBoundary set Pop2008=@m_popsum* 0.263736264
where LEFT(rtrim(ltrim(NAME2004)),3) ='Ԫ����'

update CountyBoundary set Pop2008=@m_popsum* 0.230769231
where LEFT(rtrim(ltrim(NAME2004)),3) ='������'

CLOSE m_cursor
DEALLOCATE m_cursor


--  ʯ��ɽ��
declare @m_popsum numeric(10)
DECLARE m_cursor CURSOR
   FOR SELECT PopCity FROM Pop_CityTable_2008 where LEFT(rtrim(ltrim(CityName)),2) ='ʯ��'

OPEN m_cursor
FETCH NEXT FROM m_cursor INTO @m_popsum 


update CountyBoundary set Pop2008=@m_popsum* 0.534883721
where LEFT(rtrim(ltrim(NAME2004)),3) ='�����'

update CountyBoundary set Pop2008=@m_popsum* 0.465116279
where LEFT(rtrim(ltrim(NAME2004)),3) ='��ũ��'

CLOSE m_cursor
DEALLOCATE m_cursor


--  ��³ľ����  --��Ȫ��
declare @m_popsum numeric(10)
DECLARE m_cursor CURSOR
   FOR SELECT PopCity FROM Pop_CityTable_2008 where LEFT(rtrim(ltrim(CityName)),3) ='��³ľ'

OPEN m_cursor
FETCH NEXT FROM m_cursor INTO @m_popsum 


update CountyBoundary set Pop2008=@m_popsum* 0.098273244
where LEFT(rtrim(ltrim(NAME2004)),3) ='��Ȫ��'

update CountyBoundary set Pop2008=@m_popsum* (1- 0.098273244 )
where LEFT(rtrim(ltrim(NAME2004)),5) ='��³ľ����'

CLOSE m_cursor
DEALLOCATE m_cursor

--select * from CountyBoundary where Pop2008 is null
--SELECT PopCity FROM Pop_CityTable_2008 where LEFT(rtrim(ltrim(CityName)),2) ='����'
--update  CountyBoundary set Pop2008 =102.83 where LEFT(rtrim(ltrim(NAME2004)),3) = '������'


---�������� ��Щ �� ���� ����Ͻ���� �ְ��� �������� ��

--  �����
declare @m_popsum numeric(10)
  DECLARE m_cursor CURSOR
   FOR SELECT PopCity FROM Pop_CityTable_2008 where LEFT(rtrim(ltrim(CityName)),2) ='���'
OPEN m_cursor
FETCH NEXT FROM m_cursor INTO @m_popsum 
CLOSE m_cursor
DEALLOCATE m_cursor

  DECLARE m_cursor CURSOR
   FOR SELECT Pop2008 FROM CountyBoundary where LEFT(rtrim(ltrim(NAME2004)),3) ='������' or LEFT(rtrim(ltrim(NAME2004)),3) ='������'or LEFT(rtrim(ltrim(NAME2004)),3) ='�����'  
or LEFT(rtrim(ltrim(NAME2004)),3) ='������'  or LEFT(rtrim(ltrim(NAME2004)),3) ='������' or LEFT(rtrim(ltrim(NAME2004)),3) ='������' 
or LEFT(rtrim(ltrim(NAME2004)),3) ='������'or LEFT(rtrim(ltrim(NAME2004)),3) ='������' or LEFT(rtrim(ltrim(NAME2004)),3) ='������' 
OPEN m_cursor
declare @m_pop1 numeric(10)
declare @m_pop_more numeric(10)
set @m_pop_more=0

FETCH NEXT FROM m_cursor INTO @m_pop1 
WHILE (@@FETCH_STATUS = 0) 
begin
set @m_pop_more=@m_pop_more+@m_pop1
FETCH NEXT FROM m_cursor INTO @m_pop1 
end
CLOSE m_cursor
DEALLOCATE m_cursor

update CountyBoundary set Pop2008=@m_popsum-@m_pop_more  
where LEFT(rtrim(ltrim(NAME2004)),3) ='�����'


--  �Ϻ���
declare @m_popsum numeric(10)
  DECLARE m_cursor CURSOR
   FOR SELECT PopCity FROM Pop_CityTable_2008 where LEFT(rtrim(ltrim(CityName)),2) ='�Ϻ�'
OPEN m_cursor
FETCH NEXT FROM m_cursor INTO @m_popsum 
CLOSE m_cursor
DEALLOCATE m_cursor

  DECLARE m_cursor CURSOR
   FOR SELECT Pop2008 FROM CountyBoundary where LEFT(rtrim(ltrim(NAME2004)),3) ='������' or LEFT(rtrim(ltrim(NAME2004)),3) ='�ζ���' 
or LEFT(rtrim(ltrim(NAME2004)),3) ='�ֶ���'  or LEFT(rtrim(ltrim(NAME2004)),3) ='��ɽ��' or LEFT(rtrim(ltrim(NAME2004)),3) ='�ɽ���' 
or LEFT(rtrim(ltrim(NAME2004)),3) ='������'or LEFT(rtrim(ltrim(NAME2004)),3) ='�ϻ���' or LEFT(rtrim(ltrim(NAME2004)),3) ='������' 
OPEN m_cursor
declare @m_pop1 numeric(10)
declare @m_pop_more numeric(10)
set @m_pop_more=0

FETCH NEXT FROM m_cursor INTO @m_pop1 
WHILE (@@FETCH_STATUS = 0) 
begin
set @m_pop_more=@m_pop_more+@m_pop1
FETCH NEXT FROM m_cursor INTO @m_pop1 
end
CLOSE m_cursor
DEALLOCATE m_cursor

update CountyBoundary set Pop2008=@m_popsum -@m_pop_more    --
where LEFT(rtrim(ltrim(NAME2004)),3) ='�Ϻ���'


--select AD2004, NAME2004,ProvCode, ProvName, Pop2008,test from  CountyBoundary where AD2004>410900

---select * from   CountyBoundary where AD2004>410900

--  ��ɽ����Ͻ��

declare @m_popsum numeric(10)
  DECLARE m_cursor CURSOR
   FOR SELECT PopCity FROM Pop_CityTable_2008 where LEFT(rtrim(ltrim(CityName)),2) ='��ɽ'
OPEN m_cursor
FETCH NEXT FROM m_cursor INTO @m_popsum 
CLOSE m_cursor
DEALLOCATE m_cursor

  DECLARE m_cursor CURSOR
   FOR SELECT Pop2008 FROM CountyBoundary where LEFT(rtrim(ltrim(NAME2004)),3) ='������' or LEFT(rtrim(ltrim(NAME2004)),3) ='������' 
OPEN m_cursor
declare @m_pop1 numeric(10)
declare @m_pop_more numeric(10)
set @m_pop_more=0

FETCH NEXT FROM m_cursor INTO @m_pop1 
WHILE (@@FETCH_STATUS = 0) 
begin
set @m_pop_more=@m_pop_more+@m_pop1
FETCH NEXT FROM m_cursor INTO @m_pop1 
end
CLOSE m_cursor
DEALLOCATE m_cursor

update CountyBoundary set Pop2008=@m_popsum-@m_pop_more  
where LEFT(rtrim(ltrim(NAME2004)),3) ='��ɽ��'



-- ����������Ͻ��  ������
declare @m_popsum numeric(10)
  DECLARE m_cursor CURSOR
   FOR SELECT PopCity FROM Pop_CityTable_2008 where LEFT(rtrim(ltrim(CityName)),3) ='������'
OPEN m_cursor
FETCH NEXT FROM m_cursor INTO @m_popsum 
CLOSE m_cursor
DEALLOCATE m_cursor

  DECLARE m_cursor CURSOR
   FOR SELECT Pop2008 FROM CountyBoundary where LEFT(rtrim(ltrim(NAME2004)),3) ='������' 
OPEN m_cursor
declare @m_pop numeric(10)

FETCH NEXT FROM m_cursor INTO @m_pop
CLOSE m_cursor
DEALLOCATE m_cursor
update CountyBoundary set Pop2008=@m_popsum-@m_pop
where LEFT(rtrim(ltrim(NAME2004)),3) ='������'



-- ��������Ͻ��  ۴����
declare @m_popsum numeric(10)
  DECLARE m_cursor CURSOR
   FOR SELECT PopCity FROM Pop_CityTable_2008 where LEFT(rtrim(ltrim(CityName)),3) ='����'
OPEN m_cursor
FETCH NEXT FROM m_cursor INTO @m_popsum 
CLOSE m_cursor
DEALLOCATE m_cursor

  DECLARE m_cursor CURSOR
   FOR SELECT Pop2008 FROM CountyBoundary where LEFT(rtrim(ltrim(NAME2004)),3) ='۴����' 
OPEN m_cursor
declare @m_pop numeric(10)

FETCH NEXT FROM m_cursor INTO @m_pop
CLOSE m_cursor
DEALLOCATE m_cursor
update CountyBoundary set Pop2008=@m_popsum-@m_pop
where LEFT(rtrim(ltrim(NAME2004)),3) ='������'




-- ��������Ͻ�� �����
declare @m_popsum numeric(10)
  DECLARE m_cursor CURSOR
   FOR SELECT PopCity FROM Pop_CityTable_2008 where LEFT(rtrim(ltrim(CityName)),2) ='����'
OPEN m_cursor
FETCH NEXT FROM m_cursor INTO @m_popsum 
CLOSE m_cursor
DEALLOCATE m_cursor

  DECLARE m_cursor CURSOR
   FOR SELECT Pop2008 FROM CountyBoundary where LEFT(rtrim(ltrim(NAME2004)),3) ='�����' 
OPEN m_cursor
declare @m_pop numeric(10)

FETCH NEXT FROM m_cursor INTO @m_pop
CLOSE m_cursor
DEALLOCATE m_cursor
update CountyBoundary set Pop2008=@m_popsum-@m_pop
where LEFT(rtrim(ltrim(NAME2004)),3) ='������'



--�γ�����Ͻ�� �ζ���
declare @m_popsum numeric(10)
  DECLARE m_cursor CURSOR
   FOR SELECT PopCity FROM Pop_CityTable_2008 where LEFT(rtrim(ltrim(CityName)),2) ='�γ�'
OPEN m_cursor
FETCH NEXT FROM m_cursor INTO @m_popsum 
CLOSE m_cursor
DEALLOCATE m_cursor

  DECLARE m_cursor CURSOR
   FOR SELECT Pop2008 FROM CountyBoundary where LEFT(rtrim(ltrim(NAME2004)),3) ='�ζ���' 
OPEN m_cursor
declare @m_pop numeric(10)

FETCH NEXT FROM m_cursor INTO @m_pop
CLOSE m_cursor
DEALLOCATE m_cursor
update CountyBoundary set Pop2008=@m_popsum-@m_pop
where LEFT(rtrim(ltrim(NAME2004)),3) ='�γ���'



--������Ͻ�� ��ͽ��
declare @m_popsum numeric(10)
  DECLARE m_cursor CURSOR
   FOR SELECT PopCity FROM Pop_CityTable_2008 where LEFT(rtrim(ltrim(CityName)),2) ='��'
OPEN m_cursor
FETCH NEXT FROM m_cursor INTO @m_popsum 
CLOSE m_cursor
DEALLOCATE m_cursor

  DECLARE m_cursor CURSOR
   FOR SELECT Pop2008 FROM CountyBoundary where LEFT(rtrim(ltrim(NAME2004)),3) ='��ͽ��' 
OPEN m_cursor
declare @m_pop numeric(10)

FETCH NEXT FROM m_cursor INTO @m_pop
CLOSE m_cursor
DEALLOCATE m_cursor
update CountyBoundary set Pop2008=@m_popsum-@m_pop
where LEFT(rtrim(ltrim(NAME2004)),3) ='����'



--��������Ͻ�� ��ɽ��
declare @m_popsum numeric(10)
  DECLARE m_cursor CURSOR
   FOR SELECT PopCity FROM Pop_CityTable_2008 where LEFT(rtrim(ltrim(CityName)),2) ='����'
OPEN m_cursor
FETCH NEXT FROM m_cursor INTO @m_popsum 
CLOSE m_cursor
DEALLOCATE m_cursor

  DECLARE m_cursor CURSOR
   FOR SELECT Pop2008 FROM CountyBoundary where LEFT(rtrim(ltrim(NAME2004)),3) ='��ɽ��' 
OPEN m_cursor
declare @m_pop numeric(10)

FETCH NEXT FROM m_cursor INTO @m_pop
CLOSE m_cursor
DEALLOCATE m_cursor
update CountyBoundary set Pop2008=@m_popsum-@m_pop
where LEFT(rtrim(ltrim(NAME2004)),3) ='������'


--��������Ͻ�� ������

declare @m_popsum numeric(10)
  DECLARE m_cursor CURSOR
   FOR SELECT PopCity FROM Pop_CityTable_2008 where LEFT(rtrim(ltrim(CityName)),2) ='����'
OPEN m_cursor
FETCH NEXT FROM m_cursor INTO @m_popsum 
CLOSE m_cursor
DEALLOCATE m_cursor

  DECLARE m_cursor CURSOR
   FOR SELECT Pop2008 FROM CountyBoundary where LEFT(rtrim(ltrim(NAME2004)),3) ='������' 
OPEN m_cursor
declare @m_pop numeric(10)

FETCH NEXT FROM m_cursor INTO @m_pop
CLOSE m_cursor
DEALLOCATE m_cursor
update CountyBoundary set Pop2008=@m_popsum-@m_pop
where LEFT(rtrim(ltrim(NAME2004)),3) ='������'



--�差����Ͻ�� ������

declare @m_popsum numeric(10)
  DECLARE m_cursor CURSOR
   FOR SELECT PopCity FROM Pop_CityTable_2008 where LEFT(rtrim(ltrim(CityName)),2) ='�差'
OPEN m_cursor
FETCH NEXT FROM m_cursor INTO @m_popsum 
CLOSE m_cursor
DEALLOCATE m_cursor

  DECLARE m_cursor CURSOR
   FOR SELECT Pop2008 FROM CountyBoundary where LEFT(rtrim(ltrim(NAME2004)),3) ='������' 
OPEN m_cursor
declare @m_pop numeric(10)

FETCH NEXT FROM m_cursor INTO @m_pop
CLOSE m_cursor
DEALLOCATE m_cursor
update CountyBoundary set Pop2008=@m_popsum-@m_pop
where LEFT(rtrim(ltrim(NAME2004)),3) ='�差��'



--��ͷ����Ͻ�� �κ���

declare @m_popsum numeric(10)
  DECLARE m_cursor CURSOR
   FOR SELECT PopCity FROM Pop_CityTable_2008 where LEFT(rtrim(ltrim(CityName)),2) ='��ͷ'
OPEN m_cursor
FETCH NEXT FROM m_cursor INTO @m_popsum 
CLOSE m_cursor
DEALLOCATE m_cursor

  DECLARE m_cursor CURSOR
   FOR SELECT Pop2008 FROM CountyBoundary where LEFT(rtrim(ltrim(NAME2004)),3) ='�κ���' 
OPEN m_cursor
declare @m_pop numeric(10)

FETCH NEXT FROM m_cursor INTO @m_pop
CLOSE m_cursor
DEALLOCATE m_cursor
update CountyBoundary set Pop2008=@m_popsum-@m_pop
where LEFT(rtrim(ltrim(NAME2004)),3) ='��ͷ��'



--��������Ͻ�� �»���

declare @m_popsum numeric(10)
  DECLARE m_cursor CURSOR
   FOR SELECT PopCity FROM Pop_CityTable_2008 where LEFT(rtrim(ltrim(CityName)),2) ='����'
OPEN m_cursor
FETCH NEXT FROM m_cursor INTO @m_popsum 
CLOSE m_cursor
DEALLOCATE m_cursor

  DECLARE m_cursor CURSOR
   FOR SELECT Pop2008 FROM CountyBoundary where LEFT(rtrim(ltrim(NAME2004)),3) ='�»���' 
OPEN m_cursor
declare @m_pop numeric(10)

FETCH NEXT FROM m_cursor INTO @m_pop
CLOSE m_cursor
DEALLOCATE m_cursor
update CountyBoundary set Pop2008=@m_popsum-@m_pop
where LEFT(rtrim(ltrim(NAME2004)),3) ='������'
--DEALLOCATE @m_pop
--DEALLOCATE @m_popsum


--�ɶ�����Ͻ�� �¶���

declare @m_popsum numeric(10)
  DECLARE m_cursor CURSOR
   FOR SELECT PopCity FROM Pop_CityTable_2008 where LEFT(rtrim(ltrim(CityName)),2) ='�ɶ�'
OPEN m_cursor
FETCH NEXT FROM m_cursor INTO @m_popsum 
CLOSE m_cursor
DEALLOCATE m_cursor

  DECLARE m_cursor CURSOR
   FOR SELECT Pop2008 FROM CountyBoundary where LEFT(rtrim(ltrim(NAME2004)),3) ='�¶���' or LEFT(rtrim(ltrim(NAME2004)),3) ='�½���' 

OPEN m_cursor
declare @m_pop numeric(10)

FETCH NEXT FROM m_cursor INTO @m_pop
CLOSE m_cursor
DEALLOCATE m_cursor
update CountyBoundary set Pop2008=@m_popsum-@m_pop
where LEFT(rtrim(ltrim(NAME2004)),3) ='�ɶ���'


--��������Ͻ�� ������

declare @m_popsum numeric(10)
  DECLARE m_cursor CURSOR
   FOR SELECT PopCity FROM Pop_CityTable_2008 where LEFT(rtrim(ltrim(CityName)),2) ='����'
OPEN m_cursor
FETCH NEXT FROM m_cursor INTO @m_popsum 
CLOSE m_cursor
DEALLOCATE m_cursor

  DECLARE m_cursor CURSOR
   FOR SELECT Pop2008 FROM CountyBoundary where LEFT(rtrim(ltrim(NAME2004)),3) ='������' 
OPEN m_cursor
declare @m_pop numeric(10)

FETCH NEXT FROM m_cursor INTO @m_pop
CLOSE m_cursor
DEALLOCATE m_cursor
update CountyBoundary set Pop2008=@m_popsum-@m_pop
where LEFT(rtrim(ltrim(NAME2004)),3) ='������'

--ͭ������Ͻ��  ҫ����

declare @m_popsum numeric(10)
  DECLARE m_cursor CURSOR
   FOR SELECT PopCity FROM Pop_CityTable_2008 where LEFT(rtrim(ltrim(CityName)),2) ='ͭ��'
OPEN m_cursor
FETCH NEXT FROM m_cursor INTO @m_popsum 
CLOSE m_cursor
DEALLOCATE m_cursor

  DECLARE m_cursor CURSOR
   FOR SELECT Pop2008 FROM CountyBoundary where LEFT(rtrim(ltrim(NAME2004)),3) ='ҫ����' 
OPEN m_cursor
declare @m_pop numeric(10)

FETCH NEXT FROM m_cursor INTO @m_pop
CLOSE m_cursor
DEALLOCATE m_cursor
update CountyBoundary set Pop2008=@m_popsum-@m_pop
where LEFT(rtrim(ltrim(NAME2004)),3) ='ͭ����'