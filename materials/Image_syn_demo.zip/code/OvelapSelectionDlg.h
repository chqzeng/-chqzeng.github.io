#if !defined(AFX_OVELAPSELECTIONDLG_H__A2A1DF1B_4885_4B06_A06B_BCED553A59FD__INCLUDED_)
#define AFX_OVELAPSELECTIONDLG_H__A2A1DF1B_4885_4B06_A06B_BCED553A59FD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// OvelapSelectionDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// COvelapSelectionDlg dialog
#include "resource.h"
#include "dibapi.h"

#define GAP_COMPONENT 10
class COvelapSelectionDlg : public CDialog
{
// Construction
public:
	COvelapSelectionDlg(CWnd* pParent = NULL);   // standard constructor

public:
	CSize ImgL,ImgR;
	HDIB  m_hDIBL,m_hDIBR;
	CRect rcButton,rcOK;
	CRect InRect,OutRect,OverRect;
	CRect TrueInRect,TrueOutRect,TrueOverRect;
	bool  bIn,bOut,bOver;
	CRect rectDesL,rectDesR;
	int nFlag;		//operation flag
public:
	bool IsRectValid(CRect& rectDes, CRect rectBox);
	CRect RectTolerance(CRect pDes,CRect pMatch);
// Dialog Data
	//{{AFX_DATA(COvelapSelectionDlg)
	enum { IDD = IDD_DIALOG_OVERLAP };
	CButton	m_ok;
	CButton	m_OverlapSel;
	CButton	m_OutSel;
	CButton	m_InSel;
	CButton	m_OutputBox;
	CButton	m_InputBox;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(COvelapSelectionDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(COvelapSelectionDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnButtonSelin();
	afx_msg void OnButtonSelout();
	afx_msg void OnButtonSelover();
	virtual void OnOK();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnPaint();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OVELAPSELECTIONDLG_H__A2A1DF1B_4885_4B06_A06B_BCED553A59FD__INCLUDED_)
