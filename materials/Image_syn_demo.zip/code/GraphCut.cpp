#include "stdafx.h"
#include "TextureSynthesisDlg.h"

#include "graph.h"

//extern inline BOOL OffsetFetch( color3D  ** pSrc, color3D  **pDes, long nWidth,long nHeight, long offsetx,long offsety);
//extern inline BOOL PatchMatchProcess( color3D  ** pData,  color3D  ** pMatchPatch, CArray<OffsetPair,OffsetPair>& OffsetArray,long lWidth,long lHeight);

//////////////////////////////////////////////////////////////////////////
//	s(x, y) = s(x, y-1) + i(x,y)
//	ii(x, y) = ii(x-1, y) + s(x,y)
//	s(x, y) = s(x, y-1) + i(x,y)
//	ii(x, y) = ii(x-1, y) + s(x,y)
BOOL CTextureSynthesisDlg::GenerateSummedTable(int lWidth,int lHeight, color3D  ** pData,colorEx3D **SummedTable,long **SummedTableEx)
{

	long sum=0;
	colorEx3D sumEx,zero(0,0,0);
	
	
	//first row
	for (int j=0;j<lWidth;j++)
	{
		sum+=pData[0][j]*pData[0][j];
		sumEx=sumEx+pData[0][j];
		SummedTable[0][j]=sumEx;
		SummedTableEx[0][j]=sum;
	}
	//later rows
	for (int i=1;i<lHeight;i++)
	{
		sum=0;sumEx=zero;
		for (int j=0;j<lWidth;j++)
		{
			sum+=pData[i][j]*pData[i][j];
			sumEx=sumEx+pData[i][j];
			SummedTableEx[i][j]=sum+SummedTableEx[i-1][j];
			SummedTable[i][j]=sumEx+SummedTable[i-1][j];
		}
	}
/*
	long ** SummedTable,SummedTableEx;
	SummedTable =new long *[lHeight];
	for (i=0;i<lHeight;i++)
	{
		SummedTable[i]=new long[lWidth];
	}
	SummedTableEx =new long *[lHeight];
	for (i=0;i<lHeight;i++)
	{
		SummedTableEx[i]=new long[lWidth];
	}

  
	int offsetY,offsetX;
	for (i=0;i<lHeight; i++)
	{
		for (int j=0;j<lWidth;;j++)
		{
			double Sum;//,SumII,SumI,tp;
			double A,B,C,D;
			offsetX=j-1;
			offsetY=i-1;
			A=offsetY>=0&&offsetX>=0 ? TempSummedTable[offsetY][offsetX] : 0;
			B=offsetY>=0 ?TempSummedTable[offsetY][offsetX+nWidth] :0;
			C=offsetX>=0? TempSummedTable[offsetY+nHeight][offsetX]:0;
			D=TempSummedTable[offsetY+nHeight][offsetX+nWidth];
			Sum=A+D-B-C;
			
			A=offsetY>=0&&offsetX>=0 ? TempSummedTableEx[offsetY][offsetX] : 0;
			B=offsetY>=0 ?TempSummedTableEx[offsetY][offsetX+nWidth] :0;
			C=offsetX>=0? TempSummedTableEx[offsetY+nHeight][offsetX]:0;
			D=TempSummedTableEx[offsetY+nHeight][offsetX+nWidth];
			SummedTable[i][j]=A+D-B-C;

			SummedTableEx[i][j]=Sum
		}
	}
*/
	return TRUE;
}
///////////////////////////////////////////////////////////////////////////
// TextureSynthesisDlg Functions
// Function name:		TextureSynthesisDlg::TextureSynthesis()
// Function Description:the whole process of TextureSynthesis
// Return Value:		HDIB 
// Rt Val Description:	image handle of output image
// Parameters:			HDIB m_hDIB
// Param Desription:	image handle of input image
// Notes:				The outline function to call other functions in order to implement Texture Synthesis 
///////////////////////////////////////////////////////////////////////////
HDIB CTextureSynthesisDlg::TextureSynthesis(HDIB m_hDIB)
{
	//output
	HDIB m_hOutDIB;

	//data point for convenient operation
	LPSTR lpDIB;
	LPSTR lpDIBBits;
	
	long lWidth;                    //width and height of the image
	long lHeight;
	
	//lock DIB
	lpDIB = (LPSTR)::GlobalLock((HGLOBAL)m_hDIB);
	
	//Find beginning data position of the DIB
	lpDIBBits = ::FindDIBBits(lpDIB);
	
	lWidth = ::DIBWidth(lpDIB);   //DIB width
	lHeight = ::DIBHeight(lpDIB); //DIB Height
    
	//Now only support >=256 color bitmap, the other formats will be ignored..
	if (::DIBNumColors(lpDIB) < 256&&::DIBNumColors(lpDIB) >0 )
	{
		//report message
		MessageBox("only support bmp more than 256 colors!", "System Message" , MB_ICONINFORMATION | MB_OK);
		//unlock
		::GlobalUnlock((HGLOBAL)m_hDIB);
		return NULL;	
	}
	
	color3D  **pData=0;
	long lWidthOut,lHeightOut ;                    //width and height of the output image
	//	yiterator=(lHeightOut-MIN_PATCH_SIZE)%(MIN_PATCH_SIZE-OVERLAP_WIDTH)+1;
	
	lWidthOut=lWidth*IMAGE_EXTSCALE_W;
	lHeightOut=lHeight*IMAGE_EXTSCALE_H;
	
	//modify the size of the IMAGE
	int xiterator,yiterator;
	xiterator=(lWidthOut-MIN_PATCH_SIZE)/(MIN_PATCH_SIZE-OVERLAP_WIDTH);
	lWidthOut=xiterator*(MIN_PATCH_SIZE-OVERLAP_WIDTH)+MIN_PATCH_SIZE;
	yiterator=(lHeightOut-MIN_PATCH_SIZE)/(MIN_PATCH_SIZE-OVERLAP_WIDTH);
	lHeightOut=yiterator*(MIN_PATCH_SIZE-OVERLAP_WIDTH)+MIN_PATCH_SIZE;
	
	//memory allocate for output matrix
	color3D  **pOutput;
	pOutput =new  color3D  *[lHeightOut];
	for (int i=0;i<lHeightOut;i++)
	{
		pOutput[i]=new  color3D [lWidthOut];
	}

	//memory allocate for output matrix
/*	 color3D  **pDataOut;
	pDataOut =new  color3D  *[MIN_PATCH_SIZE];
	for (i=0;i<MIN_PATCH_SIZE;i++)
	{
		pDataOut[i]=new  color3D [lWidthOut];
	}
*/
	//memory allocate for Seams matrix
	Seam **pSeams;
	pSeams =new Seam *[lHeightOut];
	for (i=0;i<lHeightOut;i++)
	{
		pSeams[i]=new Seam[lWidthOut];
	}
	
	//memory allocate for record offset matrix
	OffsetPair **pIndexOutput;
	pIndexOutput =new OffsetPair *[lHeightOut];
	for (i=0;i<lHeightOut;i++)
	{
		pIndexOutput[i]=new OffsetPair[lWidthOut];
	}

	//process of Texture Synthesis

		//get data matrix of the input image
	pData=RetrieveDataMatrix(m_hDIB);		
		
	//memory allocate for record offset matrix
	SummedTable =new colorEx3D *[lHeight];
	for (i=0;i<lHeight;i++)
	{
		SummedTable[i]=new colorEx3D[lWidth];
	}
	SummedTableEx =new long *[lHeight];
	for (i=0;i<lHeight;i++)
	{
		SummedTableEx[i]=new long[lWidth];
	}

	DWORD BeginTime,EndTime;
	BeginTime=GetTickCount();
//	if (lWidth*lHeight>1024*1024)
// 	{
		GenerateSummedTable(lWidth,lHeight,pData,SummedTable,SummedTableEx);
// 	}
		//create the first strip
//		StripCreation(pData,pOutput,lWidth,lHeight,xiterator);
		FirstStripCreation(pData,pOutput,lWidth,lHeight,xiterator,pSeams,pIndexOutput);
		
		//process of whole image generate
//		int j=0;
		for (int j=0;j<yiterator;j++)//
		{
			//create a stripe of output image
			LaterStripCreation(pData,pOutput,lWidth,lHeight,xiterator,(j+1)*(MIN_PATCH_SIZE-OVERLAP_WIDTH),pSeams,pIndexOutput);
			
			//Union the current stripe into the output data with min-cut
	//		StripUnion(pOutput,pDataOut,(j+1)*(MIN_PATCH_SIZE-OVERLAP_WIDTH),lWidthOut);
		}
		
		//construct the m_hOutDIB
/*		m_hOutDIB=OutPutProcess(m_hDIB,pOutput,lWidthOut,lHeightOut);
		SaveOutputFile("D:\\zeng\\result_1.bmp",m_hOutDIB);
		::GlobalFree((HGLOBAL)m_hOutDIB);


		CString str,strOutput;
		for (i=0;i<=128;i++)
		{
			for (int j=0;j<=128;j++)
			{
		//		int index=i*(xiterator+1)+j;
				str.Format("%d\t",(int)pOutput[i][j]);
				strOutput+=str;
			}
			strOutput+="\n";					
		}

		CStdioFile pStream;
			CString pFileName="D:\\zeng\\test.txt";
			pStream.Open( pFileName, CFile::modeCreate | CFile::modeWrite );
			pStream.WriteHuge(strOutput.GetBuffer(0),strOutput.GetLength());
			pStream.Close();
*/
		//pro process
		if(m_bPorprocess.GetCheck())
			ProProcess(pSeams,pIndexOutput,pData,lWidth,lHeight,pOutput,lWidthOut,lHeightOut);
		
		//surround patching modify
/*		int Siterator=xiterator*yiterator*2;
		for (i=0;i<Siterator;i++)
		{
			SurroundPatch( pData,lWidth,lHeight, pOutput, lWidthOut, lHeightOut,pSeams, pIndexOutput,OffsetArray);
		}
*/
//		DetectOutput(pSeams,lWidthOut,lHeightOut);

//	AfxMessageBox(strTime);	

		EndTime=GetTickCount();
		strTime.Format("Time Cost: %f seconds\n",(EndTime-BeginTime)/1000.0);

		try{}
	//error toleration

	catch (...)
	{
		//unlock data
		::GlobalUnlock((HGLOBAL)m_hDIB);
//		::GlobalUnlock((HGLOBAL)m_hOutDIB);
		
		//clear data
		clear2DArray(lHeight,pData);
//		clear2DArray(MIN_PATCH_SIZE,pDataOut);
//		clear2DArray(lHeightOut-1,pSeams);

		clear2DArray(lHeightOut,pOutput);
		
		//clear seams
		for (int i=0;i<lHeightOut;i++)
		{
			delete [] 	pSeams[i];
		}
		delete   []   pSeams;
		
		//clear pIndexOutput
		for (i=0;i<lHeightOut;i++)
		{
			delete [] 	pIndexOutput[i];
		}
		delete   []   pIndexOutput;
		
			for (i=0;i<lHeight;i++)
	{
		delete SummedTable[i];
		delete SummedTableEx[i];
	}
	delete   []   SummedTable;
	delete   []   SummedTableEx;


//		return TRUE;

		//error report
//		AfxMessageBox("Operation error!");
		
		return NULL;
	}
	
	//////////////////////////////////////////////////////////////////////////
	//out put image
/*	CString strOutput,str;
	strOutput.Format("offsetArray size:%d\n",OffsetArray.GetSize());
	for (i=0;i<OffsetArray.GetSize();i++)
	{
		str.Format("%d,%d\n",OffsetArray.GetAt(i).x,OffsetArray.GetAt(i).y);
		strOutput+=str;
	}
	AfxMessageBox(strOutput);
	
	
	for (i=0;i<lHeightOut;i++)
	{
		for (int j=0;j<lWidthOut;j++)
		{
			pOutput[i][j]=pData[i][j];
		}
	}
*/	//construct the m_hOutDIB
	m_hOutDIB=OutPutProcess(m_hDIB,pOutput,lWidthOut,lHeightOut);
	
	//unlock data
	::GlobalUnlock((HGLOBAL)m_hDIB);
	::GlobalUnlock((HGLOBAL)m_hOutDIB);
	
	//clear data
	clear2DArray(lHeight,pData);
//	clear2DArray(MIN_PATCH_SIZE,pDataOut);
//	clear2DArray(lHeightOut-1,pSeams);
	clear2DArray(lHeightOut,pOutput);

	for (i=0;i<lHeight;i++)
	{
		delete SummedTable[i];
		delete SummedTableEx[i];
	}
	delete   []   SummedTable;
	delete   []   SummedTableEx;

	for (i=0;i<lHeightOut-1;i++)
	{
		delete [] 	pSeams[i];
	}
	delete   []   pSeams;
	
	//clear pIndexOutput
	for (i=0;i<lHeightOut;i++)
	{
		delete [] 	pIndexOutput[i];
	}
	delete   []   pIndexOutput;
	
	EndWaitCursor();
	
	return m_hOutDIB;
		
		
}

///////////////////////////////////////////////////////////////////////////
// TextureSynthesisDlg Functions
// Function name:		TextureSynthesisDlg::StripCreation()
// Function Description:Using the input image to generate a strip of output with size: MIN_PATCH_SIZE*lWidthOut
// Return Value:		BOOL
// Rt Val Description:	whether the function has been successful execute
// Parameters:			 color3D  **pData
// Param Desription:	point to the first byte of input data matrix
// Parameters:			 color3D  **pData
// Param Desription:	point to the first byte of output data matrix
// Parameters:			long lWidth,long lHeight
// Param Desription:	size of the input data relate to the pData 
// Parameters:			int xiterator
// Param Desription:	the times of iteration to generate the strip which is determined by the output width
// Notes:				Using the input image to generate a strip of output with size: MIN_PATCH_SIZE*lWidthOut
//						------------------------------------
//						|		|O	|		|	|		|
//						|		|V	|		|	|		|
//						|PatchA	|E	|PatchB	|..	|	..	|..
//						|		|R	|		|	|		|
//						|		|LAP|		|	|		|	
//						------------------------------------
///////////////////////////////////////////////////////////////////////////
BOOL CTextureSynthesisDlg::StripCreation( color3D  **pData, color3D  **pDataOut,
										 long lWidth,long lHeight,int xiterator)
										 //,Seam **pSeams, unsigned int **pIndexOutput, int OutoffsetY)
{
	//determine whether is the first time of strip creation
	BOOL bFirst=FALSE;
//	if (OutoffsetY==MIN_PATCH_SIZE-OVERLAP_WIDTH)bFirst=TRUE;

	//memory allocate for match patch matrix
	 color3D  **pMatchPatch;
	pMatchPatch =new  color3D  *[MIN_PATCH_SIZE];
	for (int i=0;i<MIN_PATCH_SIZE;i++)
	{
		pMatchPatch[i]=new  color3D [OVERLAP_WIDTH];
	}
	
	//insert the first patch
	FirstPatchInsert(pData,pDataOut,lWidth,lHeight);
	
	//circulation for generating a lot of Patches
	for (i=0;i<xiterator;i++)
	{
		int InOffsetX;
		InOffsetX=(MIN_PATCH_SIZE-OVERLAP_WIDTH)*(i+1);
		//the first time to fetch data from output image as Match Patch
		OffsetFetch(pDataOut,pMatchPatch,OVERLAP_WIDTH,MIN_PATCH_SIZE,InOffsetX,0);
		//	OffsetArray.GetAt(0).x+MIN_PATCH_SIZE-OVERLAP_WIDTH,OffsetArray.GetAt(0).y);
		
		//Patches Match Methods Select:
		//match the patch and find the right candidate patch from input image
		if(m_style.GetCurSel()==0) 
			PatchMatchProcess(OffsetArray,lWidth,lHeight);
		else
			if(!PatchMatchProcess(pData, pMatchPatch, OffsetArray,lWidth,lHeight))throw ;
		
		//construct the output offset which is at the left-up coner of region 
		//in Output data matrix which already has data coverage.
		OffsetPair OutOffset;
		OutOffset.y=0;
		OutOffset.x=InOffsetX+OVERLAP_WIDTH;

		//Using the max flow process to cut the image.
		MinCutProcess(pData,OffsetArray.GetAt(OffsetArray.GetSize()-1),pDataOut,pMatchPatch,OutOffset);					
	}

	//clear data
	clear2DArray(MIN_PATCH_SIZE,pMatchPatch);
	
	return TRUE;
}

///////////////////////////////////////////////////////////////////////////
// TextureSynthesisDlg Functions
// Function name:		TextureSynthesisDlg::StripUnion()
// Function Description:Union the current stripe into the output data with min-cut
// Return Value:		BOOL
// Rt Val Description:	whether the function has been successful execute
// Parameters:			 color3D  **pDataOut
// Param Desription:	point to the first byte of input data matrix
// Parameters:			 color3D  **pOutput
// Param Desription:	point to the first byte of output data matrix
// Parameters:			int OffsetY,long lWidthOut
// Param Desription:	offset pair which determine the offset of the input data(pDataOut) into Out put(pOutput)
// Notes:				union the new generated strip into the already exist output data
//						------------------------------------
//						|		|	|		|	|		|
//						|	S	|T	|	R	|I	|	P	|1	..
//						|		|	|		|	|		|
//						------------------------------------
//						|			OVERLAP AREA		|	...
//						------------------------------------
//						|		|	|		|	|		|
//						|	S	|T	|	R	|I	|	P	|2	..
//						|		|	|		|	|		|
//						------------------------------------
///////////////////////////////////////////////////////////////////////////
BOOL CTextureSynthesisDlg::StripUnion( color3D  **pOutput, color3D  **pDataOut,int OffsetY,long lWidthOut)
{
	
	 color3D  ** pDes;

	//memory allocate for candidate patch matrix
	pDes =new  color3D  *[lWidthOut];
	for (int i=0;i<lWidthOut;i++)
	{
		pDes[i]=new  color3D [OVERLAP_WIDTH];
	}

	//memory allocate for MatchPatch patch matrix
	 color3D  ** pMatchPatch;
	pMatchPatch =new  color3D  *[lWidthOut];
	for (i=0;i<lWidthOut;i++)
	{
		pMatchPatch[i]=new  color3D [OVERLAP_WIDTH];
	}
	
	//fetch data from the input matrix
	//	OffsetFetch(pDataOut,pDes, lWidthOut,OVERLAP_WIDTH,0,0);
	//	OffsetFetch(pOutput,pMatchPatch, lWidthOut,OVERLAP_WIDTH,0,OffsetY);
	
	//fetch data from the input/output matrix to form pMatchPatch and candidate patch
	for (i=0;i<lWidthOut;i++)
	{
		for (int j=0;j<OVERLAP_WIDTH;j++)
		{
			pMatchPatch[i][j]=pOutput[j+OffsetY][i];
			pDes[i][j]=pDataOut[j][i];
		}
		
	}
	
	BOOL **pMark;
	//memory allocate for mark matrix
	pMark =new BOOL *[lWidthOut];
	for (i=0;i<lWidthOut;i++)
	{
		pMark[i]=new BOOL[OVERLAP_WIDTH];
	}
	
	//core for calculating the min-cut
	MinCutCore(pMatchPatch,pDes,pMark,OVERLAP_WIDTH,lWidthOut,NULL,NULL);
	
	//using data from input patches after cutting to replace the exist pixels in output image
	for ( i=0;i<OVERLAP_WIDTH;i++)
	{
		for (int j=0;j<lWidthOut;j++)
		{
			if (pMark[j][i])
				pOutput[i+OffsetY][j]=pDataOut[i][j];//pData[i+InOffset.y][InOffset.x+j];
		}
	}
	
	//////////////////////////////////////////////////////////////////////////
	//load the data which is not in the overlap area from the patch to output
	CString str,strOutput;
	for (i=OVERLAP_WIDTH; i<MIN_PATCH_SIZE;i++)
	{
		for (int j=0; j<lWidthOut; j++)
		{
			//	str.Format("%4d",pData[i+InOffset.y][InOffset.x+OVERLAP_WIDTH+j]);
			//	strOutput+=str;
			pOutput[i+OffsetY][j]=pDataOut[i][j];
		}
		//	strOutput+="\n";
	}
	//AfxMessageBox(strOutput);
	
	//clear data struct pMark and pDEs
	for (i=0;i<lWidthOut;i++)
	{
		delete [] 	pMark[i];
		delete [] 	pDes[i];
		delete [] 	pMatchPatch[i];
		
	}
	delete   []   pMark;
	delete   []   pDes;
	delete   []   pMatchPatch;
	
	return TRUE;
}


///////////////////////////////////////////////////////////////////////////
// TextureSynthesisDlg Functions
// Function name:		TextureSynthesisDlg::MinCutProcess()
// Function Description:process of min-cut
// Return Value:		BOOL 
// Rt Val Description:	whether the function has been successful execute
// Parameters:			 color3D  **pData
// Param Desription:	point of input image
// Parameters:			 color3D  **pDataOut
// Param Desription:	point of output image
// Parameters:			 color3D  ** pMatchPatch
// Param Desription:	point to Match Patch matrix
// Parameters:			OffsetPair InOffset
// Param Desription:	offset pair relate to the input image pData
// Parameters:			OffsetPair OutOffset
// Param Desription:	offset pair relate to the Output image pData(show in follow diagram)
// Notes:				the basic cut process diagram is as follow
//	-	-------------------------------------
//		|			    |       *outoffset	|
//	M	|				|		|			|
//	I	|	PatchA		|overlap|	PatchB	|
//	N	|				|		|			|
//	P	|				|		|			|
//	A	|-----------------------------------
//	TCH SIZE         |OVERLAP_WIDTH|
//////////////////////////////////////////////////////////////////////////
BOOL CTextureSynthesisDlg::MinCutProcess( color3D  **pData,OffsetPair InOffset,
												//		long nWidth, long nHeight,
												 color3D  **pDataOut, color3D  **pMatchPatch,OffsetPair OutOffset)
{
	 color3D  **pDes;
	//memory allocate for candidate patch matrix
	pDes =new  color3D  *[MIN_PATCH_SIZE];
	for (int i=0;i<MIN_PATCH_SIZE;i++)
	{
		pDes[i]=new  color3D [OVERLAP_WIDTH];
	}
	
	//fetch data from the input matrix
	OffsetFetch(pData,pDes,OVERLAP_WIDTH, MIN_PATCH_SIZE,InOffset.x,InOffset.y);
	
	BOOL **pMark;
	//memory allocate for mark matrix
	pMark =new BOOL *[MIN_PATCH_SIZE];
	for (i=0;i<MIN_PATCH_SIZE;i++)
	{
		pMark[i]=new BOOL[OVERLAP_WIDTH];
	}
	
	//core for calculating the min-cut
	MinCutCore(pMatchPatch,pDes,pMark,OVERLAP_WIDTH,MIN_PATCH_SIZE,NULL,NULL);
	
	//using data from input patches after cutting to replace the exist pixels in output image
	for ( i=0;i<MIN_PATCH_SIZE;i++)
	{
		for (int j=0;j<OVERLAP_WIDTH;j++)
		{
			if (pMark[i][j])
				pDataOut[i+OutOffset.y][j+OutOffset.x-OVERLAP_WIDTH]=pDes[i][j];//pData[i+InOffset.y][InOffset.x+j];
		}
	}
	
	//////////////////////////////////////////////////////////////////////////
	//load the data which is not in the overlap area from the patch to output
	CString str,strOutput;
	for (i=0; i<MIN_PATCH_SIZE;i++)
	{
		for (int j=0; j<MIN_PATCH_SIZE-OVERLAP_WIDTH; j++)
		{
			str.Format("%4d",pData[i+InOffset.y][InOffset.x+OVERLAP_WIDTH+j]);
			strOutput+=str;
			pDataOut[i+OutOffset.y][j+OutOffset.x]=pData[i+InOffset.y][InOffset.x+OVERLAP_WIDTH+j];
		}
		strOutput+="\n";
	}
	//AfxMessageBox(strOutput);
	
	//clear data struct pMark and pDEs
	for (i=0;i<MIN_PATCH_SIZE;i++)
	{
		delete [] 	pMark[i];
		delete [] 	pDes[i];
	}
	delete   []   pMark;
	delete   []   pDes;
	/*
	clear2DArray(MIN_PATCH_SIZE,pMark);
	clear2DArray(MIN_PATCH_SIZE,pDes);
	*/
	return TRUE;
}

///////////////////////////////////////////////////////////////////////////
// TextureSynthesisDlg Functions
// Function name:		TextureSynthesisDlg::MinCutCore()
// Function Description:the basic core process using min-cut in graph.h
// Return Value:		BOOL 
// Rt Val Description:	whether the function has been successful execute
// Parameters:			 color3D  **pDes
// Param Desription:	point to candidate matrix
// Parameters:			 color3D  ** pMatchPatch
// Param Desription:	point to Match Patch matrix
// Parameters:			 color3D  ** BOOL **pMark,
// Param Desription:	point to Mark data Matrix
// Parameters:			int nWidth,int nHeight
// Param Desription:	the size of match matrix
// Notes:				Using this function to construct a Graph and process the maxflow cut
//						then record the cut and use it for later pixel classify
///////////////////////////////////////////////////////////////////////////
float CTextureSynthesisDlg::MinCutCore( color3D  **pMatchPatch, color3D  **pDes,BOOL **pMark,int nWidth,int nHeight,CRect *rectIn,CRect *rectOut)
											 //	,Seam ** pSeams,OffsetPair ** pOffsets )
{
	typedef Graph<float,float,float> GraphType;
	GraphType *g = new GraphType(/*estimated # of nodes*/ nWidth*nHeight, 
		/*estimated # of edges*/ (nWidth)*(nHeight-1)+(nWidth-1)*(nHeight)); 
		
		g -> add_node(nWidth*nHeight); 
	
	//set the tweights to the graph, which means the nodes attach to PatchA and Patch B
	if (rectIn)
	{
		for (int i=0;i<nHeight;i++)
		{
			g -> add_tweights( i*nWidth,0, Max_MVaule);
			g -> add_tweights( (i+1)*nWidth-1, 0, Max_MVaule );
		}
		for ( i=0;i<nWidth;i++)
		{
			g -> add_tweights( i,0, Max_MVaule);
			g -> add_tweights( (nHeight-1)*nWidth+i, 0, Max_MVaule );
		}
		
		for (int x=rectIn->top;x<rectIn->bottom;x++)
		{
			for (int y=rectIn->left;y<rectIn->right;y++)
			{
				g -> add_tweights( x*nWidth+y, Max_MVaule,0);
			}
		}
		if (rectOut)
		{
			for (int x=rectOut->top;x<rectOut->bottom;x++)
			{
				for (int y=rectOut->left;y<rectOut->right;y++)
				{
					g -> add_tweights( x*nWidth+y,0, Max_MVaule);
				}
			}
		}
	}
	else
	{
		for (int i=0;i<nHeight;i++)
		{
	//		g -> add_tweights( i*nWidth, Max_MVaule, Max_MVaule*1000 );
	// 		g -> add_tweights( (i+1)*nWidth-1, Max_MVaule*1000, Max_MVaule );
			g -> add_tweights( i*nWidth,0, Max_MVaule);
			g -> add_tweights( (i+1)*nWidth-1, Max_MVaule, 0 );
		}
	}
	
	
	//set M value of nodes in horizonal
	float mValue=Max_MVaule;
	for (int  i=0;i<=nHeight-1;i++)
	{
		for (int j=0;j<nWidth-1;j++)
		{
			mValue=CalculateMValue(pMatchPatch[i][j],pMatchPatch[i][j+1],pDes[i][j],pDes[i][j+1]);
			g->add_edge(i*nWidth+j,i*nWidth+j+1,mValue,mValue);
		}
	}
	
	//set M value of nodes in vertical
	mValue=Max_MVaule;
	for ( i=0;i<nHeight-1;i++)
	{
		for (int j=0;j<=nWidth-1;j++)
		{
			mValue=CalculateMValue(pMatchPatch[i][j],pMatchPatch[i+1][j],pDes[i][j],pDes[i+1][j]);
			g->add_edge(i*nWidth+j,(i+1)*nWidth+j,mValue,mValue);
		}
	}
	//max flow process
	float flow = g -> maxflow();
	
	//record the result
	CString strOutput,str;
	for ( i=0;i<nHeight;i++)
	{
		for (int j=0;j<nWidth;j++)
		{
			if (g->what_segment(i*nWidth+j)== GraphType::SOURCE)
				pMark[i][j]=TRUE;//,str="1  ";
			else
				pMark[i][j]=FALSE;//,str="0  ";
//			strOutput+=str;
		}
//		strOutput+="\n";
	}
	//	AfxMessageBox(strOutput);
	
	//delete the graph
	delete g;
	
	return flow;
}

#include "math.h"
///////////////////////////////////////////////////////////////////////////
// TextureSynthesisDlg Functions
// Function name:		TextureSynthesisDlg::CalculateMValue()
// Function Description:the process of calculating MValue
// Return Value:		float  
// Rt Val Description:	MValue
// Parameters:			int vsPatchA, int vtPatchA
// Param Desription:	two pixels from A which is connected
// Parameters:			int vsPatchB, int vtPatchB
// Param Desription:	two pixels from B which is connected
// Notes:				the two function is the same target with different data type
//						the later one with struct color3D which hold true RGB color
///////////////////////////////////////////////////////////////////////////
float CTextureSynthesisDlg::CalculateMValue(int vsPatchA, int vtPatchA,int vsPatchB,int vtPatchB)
{
	//M value calculate using 2 norm
	return (float)abs(vsPatchA-vsPatchB)+abs(vtPatchA-vtPatchB);
}
float CTextureSynthesisDlg::CalculateMValue(color3D vsPatchA, color3D vtPatchA,color3D vsPatchB,color3D vtPatchB)
{
	//M value calculate using 2 norm
	double pt= sqrt((vsPatchA.r-vsPatchB.r)*(vsPatchA.r-vsPatchB.r)+
		(vsPatchA.g-vsPatchB.g)*(vsPatchA.g-vsPatchB.g)+
		(vsPatchA.b-vsPatchB.b)*(vsPatchA.b-vsPatchB.b))+
		sqrt((vtPatchA.r-vtPatchB.r)*(vtPatchA.r-vtPatchB.r)+
		(vtPatchA.g-vtPatchB.g)*(vtPatchA.g-vtPatchB.g)+
		(vtPatchA.b-vtPatchB.b)*(vtPatchA.b-vtPatchB.b));
	return (float)pt;
}


///////////////////////////////////////////////////////////////////////////
// TextureSynthesisDlg Functions
// Function name:		TextureSynthesisDlg::clear2DArray()
// Function Description:clear Array of 2D
// Return Value:		BOOL 
// Rt Val Description:	whether the function has been successful execute
// Parameters:			int size
// Param Desription:	height of the array
// Parameters:			 color3D **pSrc
// Param Desription:	point to the data
// Notes:				None
///////////////////////////////////////////////////////////////////////////
/*
inline BOOL CTextureSynthesisDlg::clear2DArray(int size, color3D **pSrc)
{
	for (int i=0;i<size;i++)
	{
		delete [] 	pSrc[i];
	}
	delete   []   pSrc;
	
	return TRUE;
}
*/

///////////////////////////////////////////////////////////////////////////
// TextureSynthesisDlg Functions
// Function name:		TextureSynthesisDlg::OutPutProcess()
// Function Description:construct the output Handle m_hOutDIB
// Return Value:		HDIB 
// Rt Val Description:	image handle of output image
// Parameters:			HDIB m_hDIB
// Param Desription:	image handle of input image	
// Parameters:			 color3D  ** pOutput
// Param Desription:	Output data Matrix
// Parameters:			long lWidthOut,long lHeightOut
// Param Desription:	the size of the image to be output
// Notes:				Using this function to form Handle for output. copy the headinfo from input file,
//						change some basic info, then write the data matrix into it.
///////////////////////////////////////////////////////////////////////////
HDIB  CTextureSynthesisDlg::OutPutProcess(HDIB m_hDIB, color3D  ** pOutput,long lWidthOut,long lHeightOut )
{
	//output
	HDIB m_hOutDIB;
	//initial the output image.
	// get the size of the image.

	//point to the input data
	LPSTR lpDIB;
	//lock DIB
	lpDIB = (LPSTR)::GlobalLock((HGLOBAL)m_hDIB);

	//get the output size
	//::PaletteSize(lpDIB)
	LONG lLineBytes = WIDTHBYTES(lWidthOut*3 * 8);
	DWORD OutSize=sizeof(BITMAPINFOHEADER)+0+lLineBytes*lHeightOut;
	//allocate memory space for output handle
	m_hOutDIB = (HDIB) ::GlobalAlloc(GMEM_MOVEABLE | GMEM_ZEROINIT, OutSize);
	if (m_hOutDIB == 0)
	{
		return NULL;
	}
	
	// lock
	LPSTR pOutputDIB = (LPSTR) ::GlobalLock((HGLOBAL) m_hOutDIB);
	DWORD CopySize=*(LPDWORD)lpDIB ;//+ ::PaletteSize(lpDIB);
	//copy file head and info head
	memcpy(pOutputDIB,lpDIB,CopySize);
	
	//change  width and height
	LPBITMAPINFOHEADER lpbmi;
	lpbmi=(LPBITMAPINFOHEADER)pOutputDIB;
	lpbmi->biWidth=lWidthOut;
	lpbmi->biHeight=lHeightOut;
	
	lpbmi->biClrUsed=0;
	lpbmi->biBitCount=24;	//true rgb color
	
	//offset change ,to point at true data
	LPSTR lpTemp=pOutputDIB+CopySize;
	
	//write data into handle
	for (int i=0;i<lHeightOut;i++)
	{
		for (int j=0;j<lWidthOut;j++)
		{
			color3D  temp=pOutput[i][j];
			*(lpTemp+i*lLineBytes+3*j)=temp.r;
			*(lpTemp+i*lLineBytes+3*j+1)=temp.g;
			*(lpTemp+i*lLineBytes+3*j+2)=temp.b;
		}
	}
/*	
	//save output image as bmp file
	if(!SaveOutputFile(m_output,m_hOutDIB))
	{
		AfxMessageBox("Save image error!");
	}
*/	
	return m_hOutDIB;
}





