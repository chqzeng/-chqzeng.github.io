// TextureSynthesis.h : main header file for the TEXTURESYNTHESIS application
//

#if !defined(AFX_TEXTURESYNTHESIS_H__1F349153_64AE_49F8_AD18_358B86A88575__INCLUDED_)
#define AFX_TEXTURESYNTHESIS_H__1F349153_64AE_49F8_AD18_358B86A88575__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CTextureSynthesisApp:
// See TextureSynthesis.cpp for the implementation of this class
//

class CTextureSynthesisApp : public CWinApp
{
public:
	CTextureSynthesisApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTextureSynthesisApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CTextureSynthesisApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TEXTURESYNTHESIS_H__1F349153_64AE_49F8_AD18_358B86A88575__INCLUDED_)
