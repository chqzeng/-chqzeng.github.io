// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#if !defined(AFX_STDAFX_H__46E7202C_CAB6_482A_8E2F_5DE46C5CB1DC__INCLUDED_)
#define AFX_STDAFX_H__46E7202C_CAB6_482A_8E2F_5DE46C5CB1DC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define VC_EXTRALEAN		// Exclude rarely-used stuff from Windows headers

#include <afxwin.h>         // MFC core and standard components
#include <afxext.h>         // MFC extensions
#include <afxdisp.h>        // MFC Automation classes
#include <afxdtctl.h>		// MFC support for Internet Explorer 4 Common Controls
#ifndef _AFX_NO_AFXCMN_SUPPORT
#include <afxcmn.h>			// MFC support for Windows Common Controls
#endif // _AFX_NO_AFXCMN_SUPPORT

#define IMAGE_MIN_SCALE 32	//THE min scale of the image (eg 32*32), which is the size of patches

#define MIN_PATCH_SIZE 32	//The min patch size for process.

#define OVERLAP_WIDTH  8	//The overlap width of patches.

#define IMAGE_EXTSCALE_W 2	//the extend scale from input to output in width

#define IMAGE_EXTSCALE_H 2	//the extend scale from input to output in height

#define K_VALUE 0.5			//set the k value as 0.5( k is 0.001---1.0)

#define Pi  3.1415926		//Pi value

#define Max_MVaule	10e5	//using Max_MVaule replace inf when record cost of M

#define MAX_OVERLAP_WIDTH 900
#define MAX_OVERLAP_HEIGHT 700

#define TOLERANCE_GAP 5		//if the rect region is short than TOLLERACE_GAP to edge of image,
							//then the rect region will extent to the edge
#define MY_SCALE		10e5
//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__46E7202C_CAB6_482A_8E2F_5DE46C5CB1DC__INCLUDED_)
