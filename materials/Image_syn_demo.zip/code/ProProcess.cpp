#include "stdafx.h"
#include "TextureSynthesisDlg.h"

void CTextureSynthesisDlg::GaussianKernelGenerate(int delta, int sigma, int nSize,float ** pGausKernel)
{
	int center=nSize/2;
	float Sum=0;
	
	//using the Gaussian kernel generate data
	for (int i=0;i<nSize;i++)
	{
		for (int j=0;j<nSize;j++)
		{
			//float tp=(float)exp(-1.0*(((i-center)*delta)^2+((j-center)*delta)^2)/(2.0*sigma^2));
			pGausKernel[i][j]=(float)exp(-1.0*(((i-center)*delta)*((i-center)*delta)+((j-center)*delta)*((j-center)*delta))/(2.0*sigma*sigma));
			Sum+=pGausKernel[i][j];
		}
	}
	
	//Normalize
	for (i=0;i<nSize;i++)
	{
		for (int j=0;j<nSize;j++)
		{
			pGausKernel[i][j]/=Sum;		///	;1.0/(nSize*nSize)
		}
	}
	
}

colorEx3D CTextureSynthesisDlg::GaussianConv(float ** pGausKernel, color3D  **pDataMatch,
										 int nWidth,int nHeight)
{
	colorEx3D sum(0,0,0);
	
	for (int i=0;i<nHeight;i++)
	{
		for (int j=0;j<nWidth;j++)
		{
			sum.r +=long(pDataMatch[i][j].r*pGausKernel[i][j]*MY_SCALE);
			sum.g +=long(pDataMatch[i][j].g*pGausKernel[i][j]*MY_SCALE);
			sum.b +=long(pDataMatch[i][j].b*pGausKernel[i][j]*MY_SCALE);
		}
	}
	
	return sum;
}

//offsetX and offsetY: the position to be feathered(modified)
//nSize :	the size of Gaussian Kernel size ,should be odd.
//nGap:		the size of Searching window ,should be odd
BOOL CTextureSynthesisDlg::SeamSearch(Seam **pSeams,OffsetPair** pOffsets,CArray<OffsetPair,OffsetPair>&OffsetList,
									  int lWidth,int lHeight,int offsetX,int offsetY,int nSize,int nGap)
{
	int center =nGap/2;
	OffsetPair temp;
	for (int i=offsetY-center;i<=offsetY+center;i++)
	{
		for (int j=offsetX-center;j<=offsetX+center;j++)
		{
			if (pSeams[i][j].vtc.bMark==true&&i<offsetY+center)
			{
		//		return FALSE;
				//one seam constructed by two nodes, so modify should involve both
				temp.x=pOffsets[i][j].x+offsetX-nSize/2-j;
				temp.y=pOffsets[i][j].y+offsetY-nSize/2-i;
				if (OffsetValid(temp,lWidth,lHeight,nSize)&&!OffsetExist(OffsetList,temp.x,temp.y))
				{
					OffsetList.Add(temp);
				}
				
				temp.x=pOffsets[i+1][j].x+offsetX-nSize/2-j;
				temp.y=pOffsets[i+1][j].y+offsetY-nSize/2-i-1;
				if (OffsetValid(temp,lWidth,lHeight,nSize)&&!OffsetExist(OffsetList,temp.x,temp.y))
				{
					OffsetList.Add(temp);
				}
			}
			if (pSeams[i][j].hrz.bMark==true&&j<offsetX+center)
			{
	//			return FALSE;
				//one seam constructed by two nodes, so modify should involve both
				
				if(pSeams[i][j].vtc.bMark==false)
				{
					temp.x=pOffsets[i][j].x+offsetX-nSize/2-j;
					temp.y=pOffsets[i][j].y+offsetY-nSize/2-i;
					if (OffsetValid(temp,lWidth,lHeight,nSize)&&!OffsetExist(OffsetList,temp.x,temp.y))
					{
						OffsetList.Add(temp);
					}
				}
				
				temp.x=pOffsets[i][j+1].x+offsetX-nSize/2-j-1;
				temp.y=pOffsets[i][j+1].y+offsetY-nSize/2-i;
				if (OffsetValid(temp,lWidth,lHeight,nSize)&&!OffsetExist(OffsetList,temp.x,temp.y))
				{
					OffsetList.Add(temp);
				}
			}
		}
	}
	return TRUE;
}

void CTextureSynthesisDlg::ProProcess(Seam **pSeams,OffsetPair** pOffsets,
									   color3D ** pData, long lWidth,long lHeight,
									   color3D ** pDataOut,long lWidthOut,long lHeightOut)
{
	int nSize=3;	//size of the window for Gaussian Kernel
	int nGap=3;		//size of the window for search seams
	
	//allocate space for Gaussian Kernel Matrix
	float **pGausKernel;
	pGausKernel =new float *[nSize];
	for (int i=0;i<nSize;i++)
	{
		pGausKernel[i]=new float[nSize];
	}
/*
	 color3D ** pCopyMatrix;
	pCopyMatrix =new  color3D  *[lHeightOut];
	for ( i=0;i<lHeightOut;i++)
	{
		pCopyMatrix[i]=new   color3D [lWidthOut];
	}
	//initialize
	for (i=0;i<lHeightOut;i++)
	{
		for (int j=0;j<lWidthOut;j++)
		{
			pCopyMatrix[i][j]=0;
		}
	}
*/
	 color3D  **pTemp;
	//allocate space for Gaussian Kernel Matrix
	pTemp =new  color3D  *[nSize];
	for (int index=0;index<nSize;index++)
	{
		pTemp[index]=new  color3D [nSize];
	}


	GaussianKernelGenerate(1,3,nSize,pGausKernel);
	
	//circulation to update the output image 
	for (i=0;i<lHeightOut-nGap;i++)
	{
		for (int j=0;j<lWidthOut-nGap;j++)
		{
			CArray<OffsetPair,OffsetPair> OffsetList;
			BOOL bMark=SeamSearch(pSeams,pOffsets,OffsetList,lWidth,lHeight,j+nGap/2,i+nGap/2,nSize,nGap);
			colorEx3D sum(0,0,0);

	//		if(bMark)continue;
			if (OffsetList.GetSize()==0)continue;
	/*
			OffsetFetch(pDataOut,pTemp,nSize,nSize,j,i);
			pCopyMatrix[i+nGap/2][j+nGap/2]=( color3D )GaussianConv(pGausKernel,pTemp,nSize,nSize);
	*/	
			for (index=0;index<OffsetList.GetSize();index++)
			{
				OffsetPair pt=OffsetList.GetAt(index);
				OffsetFetch(pData,pTemp,nSize,nSize,pt.x,pt.y);
				sum=sum+GaussianConv(pGausKernel,pTemp,nSize,nSize);	
			}
			pDataOut[i+nGap/2][j+nGap/2].r= (unsigned char)(sum.r /(OffsetList.GetSize()*MY_SCALE));					
			pDataOut[i+nGap/2][j+nGap/2].g= (unsigned char)(sum.g /(OffsetList.GetSize()*MY_SCALE));					
			pDataOut[i+nGap/2][j+nGap/2].b= (unsigned char)(sum.b /(OffsetList.GetSize()*MY_SCALE));					
		}
	}
/*	
	//copy data
	for (i=0;i<lHeightOut;i++)
	{
		for (int j=0;j<lWidthOut;j++)
		{
			if(pCopyMatrix[i][j]!=0)pDataOut[i][j]= pCopyMatrix[i][j];
		}
	}
	clear2DArray(lHeightOut,pCopyMatrix);
*/
	clear2DArray(nSize,pTemp);	
	clear2DArray(nSize,pGausKernel);
}