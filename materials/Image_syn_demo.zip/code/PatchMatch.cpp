#include "stdafx.h"
#include "TextureSynthesisDlg.h"

#include "graph.h"

#include "ArisImageRoutines1.h"

///////////////////////////////////////////////////////////////////////////
// TextureSynthesisDlg Functions
// Function name:		TextureSynthesisDlg::RetrieveDataMatrix()
// Function Description:Get the data matrix from image handle
// Return Value:		 color3D  **  
// Rt Val Description:	Point to the first byte of the data matrix
// Parameters:			HDIB m_hDataDIB
// Param Desription:	image handle for retrieving data
// Notes:				None
///////////////////////////////////////////////////////////////////////////
 color3D  ** CTextureSynthesisDlg::RetrieveDataMatrix(HDIB m_hDataDIB)
{
	//as return value
	color3D  **pData;
	
	LPSTR lpDIB;
	LPSTR lpDIBBits;
	
	long lWidth;                    //width and height of the image
	long lHeight;
	
	//lock DIB
	lpDIB = (LPSTR)::GlobalLock((HGLOBAL)m_hDataDIB);
	
	//Find beginning data position of the DIB
	lpDIBBits = ::FindDIBBits(lpDIB);
	
	lWidth = ::DIBWidth(lpDIB);   //DIB width
	lHeight = ::DIBHeight(lpDIB); //DIB Height
	
	//memory allocate
	pData =new  color3D  *[lHeight];
	for (int i=0;i<lHeight;i++)
	{
		pData[i]=new  color3D [lWidth];
	}
	
	//copy data
	LPSTR lpSrc;
	if (DIBBitCount(lpDIB)==8)			//256 colors
	{
		LONG lLineBytes = WIDTHBYTES(lWidth * 8);//lWidth;//
		//get color number
		WORD wNumColors = ::DIBNumColors(lpDIB);
		//  if is a WIN3.0 DIB
		BOOL bWinStyleDIB = IS_WIN30_DIB(lpDIB);
		
		// pointer to BITMAPINFO  Win3.0
		LPBITMAPINFO lpbmi = (LPBITMAPINFO)lpDIB;
		LPBITMAPCOREINFO lpbmc = (LPBITMAPCOREINFO)lpDIB;
		// Read palette
		color3D * colorTab;
		colorTab=new color3D[(int)wNumColors];
		for (i = 0; i < (int)wNumColors; i++)
		{
			if (bWinStyleDIB)
			{
				colorTab[i].b = (unsigned char)lpbmi->bmiColors[i].rgbRed;
				
				colorTab[i].g = (unsigned char)lpbmi->bmiColors[i].rgbGreen;
				
				colorTab[i].r = (unsigned char)lpbmi->bmiColors[i].rgbBlue;
			}
			else
			{
				colorTab[i].b = (unsigned char)lpbmc->bmciColors[i].rgbtRed;
				
				colorTab[i].g = (unsigned char)lpbmc->bmciColors[i].rgbtGreen;
				
				colorTab[i].r = (unsigned char)lpbmc->bmciColors[i].rgbtBlue;
			}
		}
		lpSrc = (char *)lpDIBBits;
		for (i=0; i<lHeight; i++)
		{
			for (int j=0; j<lWidth; j++)
			{
				lpSrc = (char *)lpDIBBits + lLineBytes * i + j;
				pData[i][j] = colorTab[(unsigned char)*lpSrc];	
			//	lpSrc++;
			}
		}
		
		//clear data
		delete colorTab;
	}
	else if (DIBBitCount(lpDIB)==24)		//true rgb color
	{
		LONG lLineBytes = WIDTHBYTES(lWidth*3 * 8);
		lpSrc = (char *)lpDIBBits;
		for (i=0; i<lHeight; i++)
		{
			for (int j=0; j<lWidth; j++)
			{
				lpSrc = (char *)lpDIBBits + lLineBytes * i + j*3;//(char *)
				pData[i][j].r = ( unsigned char )*lpSrc;//( unsigned char )
			//	lpSrc++;
				lpSrc = (char *)lpDIBBits + lLineBytes * i + j*3+1;//
				pData[i][j].g = ( unsigned char )*lpSrc;
			//	lpSrc++;
				lpSrc = (char *)lpDIBBits + lLineBytes * i + j*3+2;
				pData[i][j].b = ( unsigned char )*lpSrc;
			//	lpSrc++;
			}
		}
		
		
	}
	

	
	//unlock data
	::GlobalUnlock((HGLOBAL)m_hDataDIB);
	return pData;
}


///////////////////////////////////////////////////////////////////////////
// TextureSynthesisDlg Functions
// Function name:		TextureSynthesisDlg::OffsetFetch()
// Function Description:Fetch data from a large data matrix with a given offset
// Return Value:		BOOL 
// Rt Val Description:	whether the function has been successful execute
// Parameters:			 color3D  ** pSrc
// Param Desription:	image handle for retrieving data(data source)
// Parameters:			 color3D  ** pDes
// Param Desription:	image handle to retrieve data(data destination)
// Parameters:			long nWidth,long nHeight
// Param Desription:	size of the data which to be fetched
// Parameters:			long offsetx,long offsety
// Param Desription:	offset pair
// Notes:				None
///////////////////////////////////////////////////////////////////////////
BOOL CTextureSynthesisDlg::OffsetFetch( color3D  ** pSrc, color3D  **pDes, long nWidth,long nHeight, long offsetx,long offsety)
{
	for (int i=0; i<nHeight;i++)
	{
		for (int j=0; j<nWidth; j++)
		{
			pDes[i][j]=pSrc[offsety+i][offsetx+j];
		}
	}
	return TRUE;
}

///////////////////////////////////////////////////////////////////////////
// TextureSynthesisDlg Functions
// Function name:		TextureSynthesisDlg::PatchMatchProcess()
// Function Description:Method 1: random generate the candidate patch
// Return Value:		BOOL 
// Rt Val Description:	whether the function has been successful execute
// Parameters:			CArray<OffsetPair,OffsetPair>& OffsetArray 
// Param Desription:	the offset array to record the offsets
// Parameters:			long lWidth,long lHeight
// Param Desription:	the size of the image to be select
// Notes:				using this random method to generate an offset patch,
//						the only restriction is that the offset pair cannot to be same as previous pairs
///////////////////////////////////////////////////////////////////////////
BOOL CTextureSynthesisDlg::PatchMatchProcess(CArray<OffsetPair,OffsetPair>& OffsetArray ,long lWidth,long lHeight)
{	
	//offset pair elements
	long offsetx,offsety;
	
	//to find a pair of random offsets
	do
	{
		srand( (unsigned)time( NULL ) );
		//		srand(rand());
		//generate a random number
		rand();
		srand(rand());
		rand();
		
		float randW = (float)rand()/RAND_MAX ;
		float randH = (float)rand()/RAND_MAX ;
		
		
		offsetx=(long)(randW*(lWidth-MIN_PATCH_SIZE));
		offsety=(long)(randH*(lHeight-MIN_PATCH_SIZE));
	}
	
	while (OffsetExist(OffsetArray,offsetx,offsety));
	
	//add offset pair to the array
	OffsetPair firstOffset;
	firstOffset.x=offsetx;
	firstOffset.y=offsety;
	OffsetArray.Add(firstOffset);
	
	return TRUE;
}

///////////////////////////////////////////////////////////////////////////
// TextureSynthesisDlg Functions
// Function name:		TextureSynthesisDlg::PatchMatchProcess()
// Function Description:Method 2: Using the Entire Match process to generate the candidate patch
// Return Value:		BOOL 
// Rt Val Description:	whether the function has been successful execute	
// Parameters:			 color3D  ** pData
// Param Desription:	Point to the first byte of the input data matrix
// Parameters:			 color3D  **pMatchPatch
// Param Desription:	Point to the first byte of the Match Patch data matrix
// Parameters:			CArray<OffsetPair,OffsetPair>& OffsetArray
// Param Desription:	the offset array to record the offsets
// Parameters:			long lWidth,long lHeight
// Param Desription:	size of the image relate to pData
// Notes:				In this section ,we use the formulations and MRF relation functions
//						to generate a possibility similarity of Match Patch and the right candidate patch
//						after all offsets except the one has been used, has been calculate we use the max 
//						possibility offset for the new patch work.
///////////////////////////////////////////////////////////////////////////
#include "ArisImageRoutines1.h"
#include "math.h"
BOOL CTextureSynthesisDlg::PatchMatchProcess( color3D  ** pData,  color3D  **pMatchPatch, CArray<OffsetPair,OffsetPair>& OffsetArray 
											 ,long lWidth,long lHeight,long nWidth)
{
	//initialize
	double PVaule=-1;//*Max_MVaule*100;
	long offsetX,offsetY;
	offsetX=offsetY=-1;
	/*	
	*/	
	//////////////////////////////////////////////////////////////////////////
	//
	CString str,strOutput;
	CStdioFile pStream;
	CString pFileName;
	
	int nHeight=MIN_PATCH_SIZE;
	int nHeightOut,nWidthOut;
	nWidthOut=lWidth-MIN_PATCH_SIZE;
	nHeightOut=lHeight-nHeight;
	
	//////////////////////////////////////////////////////////////////////////
	int nflag=this->GetCheckedRadioButton(IDC_RADIO_FFT,IDC_RADIO_NAIVE);
	//////////////////////////////////////////////////////////////////////////
	//FFT acceleration
	if(nflag==IDC_RADIO_FFT)	
	{	
		CMatrix** ReOutOut=FFTConvolution(pData,lWidth,lHeight,pMatchPatch,nWidth,nHeight);
		//////////////////////////////////////////////////////////////////////////
		//calculate the S^2 of Match Patch
		double SumO=0;
		for (int i=0; i<nHeight;i++)
		{
			for (int j=0; j<nWidth;j++)
			{
				SumO+=pMatchPatch[i][j]*pMatchPatch[i][j];
			}
		}
		
		//	double PVaule=0;
		
		for (i=0;i<nHeightOut;i++)
		{
			for (int j=0;j<nWidthOut;j++)
			{
				//memory allocate for input candidate matrix
				color3D  ** pTemp;
				pTemp =new  color3D  *[MIN_PATCH_SIZE];
				for (int i=0;i<MIN_PATCH_SIZE;i++)
				{
					pTemp[i]=new  color3D [nWidth];
				}
				OffsetFetch(pData,pTemp,nWidth,MIN_PATCH_SIZE,j,i);	
				float temp1=CalculateEntirePt(pMatchPatch,pTemp,nWidth,MIN_PATCH_SIZE,lWidth,lHeight);
				clear2DArray(MIN_PATCH_SIZE,pTemp);

				if (OffsetExist(OffsetArray,j,i))continue;
				double sumIO=0;
				sumIO=ReOutOut[0]->GetElement(j+nWidth-1,i+nHeight-1)
					+ReOutOut[1]->GetElement(j+nWidth-1,i+nHeight-1)
					+ReOutOut[2]->GetElement(j+nWidth-1,i+nHeight-1);
				double temp=CalculateEntirePt(SumO,sumIO,nWidth,nHeight,lWidth*lHeight,j,i);
				if (temp>PVaule)
				{
					offsetX=j;
					offsetY=i;
					PVaule=temp;
				}
			}
		}
		for (i=0;i<3;i++)
		{
			delete ReOutOut[i];
		}
	}
	else if(nflag==IDC_RADIO_NAIVE)	//old method ,naive search
	{
		
		//memory allocate for input candidate matrix
		color3D  ** pTemp;
		pTemp =new  color3D  *[MIN_PATCH_SIZE];
		for (int i=0;i<MIN_PATCH_SIZE;i++)
		{
			pTemp[i]=new  color3D [nWidth];
		}
		
		//circulation to find the max possibility 
		for ( i=0; i<lHeight-MIN_PATCH_SIZE;i++)
		{
			for (int j=0; j<lWidth-MIN_PATCH_SIZE;j++)
			{
				//if current offset has even been insert into the output image
				if(OffsetExist(OffsetArray,j,i))continue;
				
				//fetch data with the current offset(i,j) from the input data matrix
				OffsetFetch(pData,pTemp,nWidth,MIN_PATCH_SIZE,j,i);
				
				//calculate the P(t) under Entire Patch Match method
				float temp=CalculateEntirePt(pMatchPatch,pTemp,nWidth,MIN_PATCH_SIZE,lWidth,lHeight);
				
				//if the p(t) is greater than all the former ones, record it and change the pValue
				if (temp>PVaule)
				{
					offsetX=j;
					offsetY=i;
					PVaule=temp;
				}
			}
		}
		
		//delete the data 
		clear2DArray(MIN_PATCH_SIZE,pTemp);
	}
	
	//record current offset pair
	if (offsetX>=0&&offsetY>=0)
	{
		OffsetPair tp;
		tp.x=offsetX;
		tp.y=offsetY;
		OffsetArray.Add(tp);
	}
	else
		return FALSE;
	
	return TRUE;
}


///////////////////////////////////////////////////////////////////////////
// TextureSynthesisDlg Functions
// Function name:		TextureSynthesisDlg::OffsetExist()
// Function Description:determine whether an offset has been used
// Return Value:		BOOL
// Rt Val Description:	If the pair has been used ,return TRUE
// Parameters:			CArray<OffsetPair,OffsetPair>& OffsetArray
// Param Desription:	offset pairs array
// Parameters:			long offsetx, long offsety
// Param Desription:	offset pair to be determined
// Notes:				None
///////////////////////////////////////////////////////////////////////////
BOOL CTextureSynthesisDlg::OffsetExist( CArray<OffsetPair,OffsetPair>& OffsetArray,long offsetx, long offsety)
{
	for (int i=0; i<OffsetArray.GetSize();i++)
	{
		if (OffsetArray.GetAt(i).x==(unsigned int)offsetx&&OffsetArray.GetAt(i).y==(unsigned int)offsety) return TRUE;
	}
	return FALSE;
}

#include "math.h"
///////////////////////////////////////////////////////////////////////////
// TextureSynthesisDlg Functions
// Function name:		TextureSynthesisDlg::CalculateEntirePt()
// Function Description:Calculate the P(t) value
// Return Value:		float 
// Rt Val Description:	P(t) value
// Parameters:			 color3D  **pCandiPatch
// Param Desription:	Point to the first byte of the Candidate Patch data matrix
// Parameters:			 color3D  **pMatchPatch
// Param Desription:	Point to the first byte of the Match Patch data matrix
// Parameters:			long nWidth,long nHeight
// Param Desription:	size of the match patch
// Parameters:			long lWidth,long lHeight
// Param Desription:	size of the image relate to input image(using to calculate Area)
// Notes:				In this section ,we use:
//								 C(t)=1/|At| * Sum(I(p)-O(p+t))^2		(1)
//							and  Deviation = E(X^2)- (E(x))^2			(2)
//							and  p(t) & exp(-1*C(t)/(k*dev))			(3)
//						where C(t) is the convolution of Match Patch and Candidate Patch, 
//						if the two image patches are the same ,then C(t)=0
//						we then using the C(t) to stochastically generate the possible translation 
//						according to the probability function (3)
///////////////////////////////////////////////////////////////////////////

float CTextureSynthesisDlg::CalculateEntirePt( color3D  **pMatchPatch, color3D  **pCandiPatch,
											  long nWidth,long nHeight,long lWidth,long lHeight)
{
/*	CMatrix ReIn(nWidth,nHeight);
CMatrix ImOut(nWidth,nHeight);
CMatrix ReOut(nWidth,nHeight);

  ArisImageRoutines fft;
  for (int i=0;i<nHeight;i++)
  {
		for (int j=0;j<nWidth;j++)
		{
		ReIn.SetElement(i,j,pMatchPatch[i][j]);
		}
		}
		fft.FFT(&ReIn,NULL,&ReOut,&ImOut);
	*/
	//variants
	double Sum,SumI,SumII,SumO,SumIO,tp;
	double SumR,SumG,SumB;
	SumII=SumI=SumO=SumIO=0;
	SumR=SumG=SumB=0;
	
	//calculate some mediate variants
	for (int i=0; i<nHeight;i++)
	{
		for (int j=0; j<nWidth;j++)
		{
			SumR+=pCandiPatch[i][j].r;
			SumG+=pCandiPatch[i][j].g;
			SumB+=pCandiPatch[i][j].b;

			SumO+=pMatchPatch[i][j]*pMatchPatch[i][j];
			SumI+=pCandiPatch[i][j]*pCandiPatch[i][j];
			SumIO+=pMatchPatch[i][j]*pCandiPatch[i][j];
		}
	}
	
	//using  (1) to calculate C(t)
	Sum= (SumI+SumO-2*SumIO)*(nHeight*nWidth)/(lWidth*lHeight*100);
	
	//using  (2) to get Deviation of the candidate image
	SumII=SumR*SumR+SumG*SumG+SumB*SumB;

	double Deviation = SumI/(nHeight*nWidth)-SumII/((nHeight*nWidth)*(nHeight*nWidth));
	
	
	//random K value generate (0.001---1)
	srand( (unsigned)time( NULL ) );
	//generate a random number
	rand();
	float kvalue = (float)rand()/RAND_MAX ;
	while (kvalue<0.001)
	{
		kvalue = (float)rand()/RAND_MAX ;
	}
	
	//using (2) to generate a possible value
	tp=(float)exp(-Sum/(kvalue*Deviation));
	
	/*	srand((unsigned)time(NULL));
	float sigma=1;
	p=(float) (sqrt(-2*log(rand()*1./RAND_MAX))*cos(2*Pi*rand()*1./RAND_MAX))*sigma+tp;
	*/	
	return (float)tp;
}

double CTextureSynthesisDlg::CalculateEntirePt(double SumO,double sumIO,int nWidth,int nHeight,long lArea,int offsetX,int offsetY)
{
	//variants
	double Sum,SumII,tp;
	SumII=0;
	colorEx3D A,B,C,D,SumI;
	colorEx3D tempzero(0,0,0);
	double  zero=0;

	offsetX=offsetX-1;
	offsetY=offsetY-1;
	A=offsetY>=0&&offsetX>=0 ? SummedTable[offsetY][offsetX] : tempzero;
	B=offsetY>=0 ?SummedTable[offsetY][offsetX+nWidth] :tempzero;
	C=offsetX>=0? SummedTable[offsetY+nHeight][offsetX]:tempzero;
	D=SummedTable[offsetY+nHeight][offsetX+nWidth];
	SumI=A+D-B-C;
	
	double a,b,c,d;
	a=offsetY>=0&&offsetX>=0 ? SummedTableEx[offsetY][offsetX] : zero;
	b=offsetY>=0 ?SummedTableEx[offsetY][offsetX+nWidth] :zero;
	c=offsetX>=0? SummedTableEx[offsetY+nHeight][offsetX]:zero;
	d=SummedTableEx[offsetY+nHeight][offsetX+nWidth];
	SumII=a+d-c-b;
	
	//using  (1) to calculate C(t)
	Sum= (SumII+SumO-2*sumIO)*(nHeight*nWidth)/(lArea*100);
	
	//using  (2) to get Deviation of the candidate image
	double SumTemp=(SumI.r*SumI.r+SumI.g*SumI.g+SumI.b*SumI.b)*1.0/(nHeight*nWidth*nHeight*nWidth);
	double Deviation = SumII/(nHeight*nWidth)-SumTemp;
	
	
	//random K value generate (0.001---1)
	srand( (unsigned)time( NULL ) );
	//generate a random number
	rand();
	float kvalue = (float)rand()/RAND_MAX ;
	while (kvalue<0.001)
	{
		kvalue = (float)rand()/RAND_MAX ;
	}
	
	//using (2) to generate a possible value
	tp=(float)exp(-Sum/(kvalue*Deviation));
	
	/*	srand((unsigned)time(NULL));
	float sigma=1;
	p=(float) (sqrt(-2*log(rand()*1./RAND_MAX))*cos(2*Pi*rand()*1./RAND_MAX))*sigma+tp;
	*/	
	return tp;
}

double CTextureSynthesisDlg::CalculateEntirePtEx(double SumOV,double sumIOV,int nWidthV,int nHeightV,
												 double SumOH,double sumIOH,int nWidthH,int nHeightH,
												 long lArea,int offsetX,int offsetY)
{
	//variants
	double Sum,SumII,tp;
	SumII=0;
	colorEx3D A,B,C,D,SumI,SumI1;
	colorEx3D tempzero(0,0,0);
	
	//vertical
	offsetX=offsetX-1;
	offsetY=offsetY-1;
	
	A=offsetY>=0&&offsetX>=0 ? SummedTable[offsetY][offsetX] : tempzero;
	B=offsetY>=0 ?SummedTable[offsetY][offsetX+nWidthV] :tempzero;
	C=offsetX>=0? SummedTable[offsetY+nHeightV][offsetX]:tempzero;
	D=SummedTable[offsetY+nHeightV][offsetX+nWidthV];
	SumI=A+D-B-C;
	
	double a,b,c,d;
	a=offsetY>=0&&offsetX>=0 ? SummedTableEx[offsetY][offsetX] : 0;
	b=offsetY>=0 ?SummedTableEx[offsetY][offsetX+nWidthV] :0;
	c=offsetX>=0? SummedTableEx[offsetY+nHeightV][offsetX]:0;
	d=SummedTableEx[offsetY+nHeightV][offsetX+nWidthV];
	SumII=a+d-b-c;
	
	//Horizonal
	offsetX+=OVERLAP_WIDTH;
	A=offsetY>=0&&offsetX>=0 ? SummedTable[offsetY][offsetX] : tempzero;
	B=offsetY>=0 ?SummedTable[offsetY][offsetX+nWidthH] :tempzero;
	C=offsetX>=0? SummedTable[offsetY+nHeightH][offsetX]:tempzero;
	D=SummedTable[offsetY+nHeightH][offsetX+nWidthH];
	SumI1=A+D-B-C;
	SumI=SumI+SumI1;
	
	a=offsetY>=0&&offsetX>=0 ? SummedTableEx[offsetY][offsetX] : 0;
	b=offsetY>=0 ?SummedTableEx[offsetY][offsetX+nWidthH] :0;
	c=offsetX>=0? SummedTableEx[offsetY+nHeightH][offsetX]:0;
	d=SummedTableEx[offsetY+nHeightH][offsetX+nWidthH];
	SumII+=a+d-b-c;
	
	
	//using  (1) to calculate C(t)
	long subArea=nHeightV*nWidthV+nHeightH*nWidthH;
	Sum= (SumII+SumOV+SumOH-2*sumIOV-2*sumIOH)*(subArea)/(lArea*100);
	
	double SumTemp=(SumI.r*SumI.r+SumI.g*SumI.g+SumI.b*SumI.b)*1.0/(subArea*subArea);

	//using  (2) to get Deviation of the candidate image
	double Deviation = SumII/(subArea)-SumTemp;//(SumI/(subArea))*(SumI/(subArea))
	
	
	//random K value generate (0.001---1)
	srand( (unsigned)time( NULL ) );
	//generate a random number
	rand();
	float kvalue = (float)rand()/RAND_MAX ;
	while (kvalue<0.001)
	{
		kvalue = (float)rand()/RAND_MAX ;
	}
	
	//using (2) to generate a possible value
	tp=(double)exp(-Sum/(kvalue*Deviation));	
	return tp;
}

