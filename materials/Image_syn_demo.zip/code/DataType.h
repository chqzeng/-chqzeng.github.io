//offset pair struct
struct OffsetPair 
{ 
	unsigned int x;	//x-offset
	unsigned int y;	//y-offset
};

//elements of a seam
struct SeamElem {
	bool bMark;
	float mValue;
};

//seam struct
struct Seam {
	SeamElem hrz;	//horizonal seam
	SeamElem vtc;	//vertical seam
};

//a node with RGB colors
class color3D
{
public:
	unsigned char r;
	unsigned char g;
	unsigned char b;
public:
	color3D()
	{
		r=0;
		g=0;
		b=0;
	};
	color3D(unsigned char R,unsigned char G,unsigned char B)
	{
		r=R;
		g=G;
		b=B;
	};
public:
	color3D& operator=(color3D &Inclr)
	{
//		color3D Outclr;
//		Outclr.r=Inclr.r;
//		Outclr.g=Inclr.g;
//		Outclr.b=Inclr.b;
//		return Outclr;
	
		this->r=Inclr.r;
		this->g=Inclr.g;
		this->b=Inclr.b;
		return *this;
	};
	long operator*(color3D &Inclr) const
	{
		long sum=0;
		sum=this->r*Inclr.r+this->g*Inclr.g+this->b*Inclr.b;
		return sum;
	};
};
class color3D;
class colorEx3D
{
public:
	long r;
	long g;
	long b;
public:
	colorEx3D()
	{
		r=0;
		g=0;
		b=0;
	};
	colorEx3D(long R,long G,long B)
	{
		r=R;
		g=G;
		b=B;
	};
public:
	colorEx3D& operator=(colorEx3D &Inclr)
	{
		this->r=Inclr.r;
		this->g=Inclr.g;
		this->b=Inclr.b;
		return *this;
//		colorEx3D Outclr;
//		Outclr.r=Inclr.r;
//		Outclr.g=Inclr.g;
//		Outclr.b=Inclr.b;
//		return Outclr;
	};
	colorEx3D operator+(color3D& Inclr) const
	{
		colorEx3D Outclr;
		Outclr.r=this->r+Inclr.r;
		Outclr.g=this->g+Inclr.g;
		Outclr.b=this->b+Inclr.b;
		return Outclr;
	};
	colorEx3D operator+(colorEx3D& Inclr) const
	{
		colorEx3D Outclr;
		Outclr.r=this->r+Inclr.r;
		Outclr.g=this->g+Inclr.g;
		Outclr.b=this->b+Inclr.b;
		return Outclr;
	};
	colorEx3D operator-(colorEx3D& Inclr) const
	{
		colorEx3D Outclr;
		Outclr.r=this->r-Inclr.r;
		Outclr.g=this->g-Inclr.g;
		Outclr.b=this->b-Inclr.b;
		return Outclr;
	};
};

typedef CMap<long,long&,int ,int&>   OffsetMap;
//typedef map<OffsetPair,int>   OffsetMap;
