#include "stdafx.h"
#include "TextureSynthesisDlg.h"

#include "graph.h"


//offsety = left-top conner of overlap region
BOOL CTextureSynthesisDlg::LaterMinCutEx( color3D  **pData, color3D  **pDataOut,
											long lWidth,long lHeight,OffsetPair Outoffset,
											Seam **pSeams, OffsetPair **pIndexOutput)
{
	//memory allocate for match patch matrix (vertical)
	 color3D  **pMatchPatchV;
	pMatchPatchV =new  color3D  *[MIN_PATCH_SIZE];
	for (int i=0;i<MIN_PATCH_SIZE;i++)
	{
		pMatchPatchV[i]=new  color3D [OVERLAP_WIDTH];
	}
		
	//memory allocate for match patch matrix (vertical)
	 color3D  **pMatchPatchH;
	pMatchPatchH =new  color3D  *[OVERLAP_WIDTH];
	for (i=0;i<OVERLAP_WIDTH;i++)
	{
		pMatchPatchH[i]=new  color3D [MIN_PATCH_SIZE-OVERLAP_WIDTH];
	}

	//fetch data from output image as Match Patch for V and H oriention
	OffsetFetch(pDataOut,pMatchPatchV,OVERLAP_WIDTH,MIN_PATCH_SIZE,Outoffset.x,Outoffset.y);
	OffsetFetch(pDataOut,pMatchPatchH,MIN_PATCH_SIZE-OVERLAP_WIDTH, OVERLAP_WIDTH,Outoffset.x+OVERLAP_WIDTH,Outoffset.y);

	//Patches Match Methods Select:
	//match the patch and find the right candidate patch from input image
	if(m_style.GetCurSel()==0) 
	{
		PatchMatchProcess(OffsetArray,lWidth,lHeight);
	}
	else
		if(!PatchMatchProcessEx(pData, pMatchPatchV,pMatchPatchH, OffsetArray,lWidth,lHeight))throw ;

	//construct the output offset which is at the left-up coner of region 
	//in Output data matrix which already has data coverage.
	
//	OffsetPair OutOffset;
//	OutOffset.y=OutoffsetY;
// 	OutOffset.x=0;
	
	//Using the max flow process to cut the image.
	MinCutProcessEx(pData,lWidth,lHeight,OffsetArray.GetAt(OffsetArray.GetSize()-1),
		pDataOut,pMatchPatchV,pMatchPatchH,Outoffset,pSeams,pIndexOutput);

	clear2DArray(OVERLAP_WIDTH,pMatchPatchH);
	clear2DArray(MIN_PATCH_SIZE,pMatchPatchV);

	return TRUE;
}


BOOL CTextureSynthesisDlg::MinCutProcessEx( color3D  **pData, unsigned int lWidth,unsigned int lHeight,OffsetPair InOffset, color3D  **pDataOut,
										    color3D  **pMatchPatchV,  color3D  **pMatchPatchH,OffsetPair OutOffset
										   ,Seam ** pSeams, OffsetPair ** pOffsets)
{
	 color3D  **pDesV,**pDesH;
	//memory allocate for candidate patch matrix
	pDesV =new  color3D  *[MIN_PATCH_SIZE];
	for (unsigned int i=0;i<MIN_PATCH_SIZE;i++)
	{
		pDesV[i]=new  color3D [OVERLAP_WIDTH];
	}
	pDesH =new  color3D  *[OVERLAP_WIDTH];
	for (i=0;i<OVERLAP_WIDTH;i++)
	{
		pDesH[i]=new  color3D [MIN_PATCH_SIZE-OVERLAP_WIDTH];
	}
	
	//fetch data from the input matrix
	OffsetFetch(pData,pDesV,OVERLAP_WIDTH, MIN_PATCH_SIZE,InOffset.x,InOffset.y);
	OffsetFetch(pData,pDesH,MIN_PATCH_SIZE-OVERLAP_WIDTH,OVERLAP_WIDTH,InOffset.x+OVERLAP_WIDTH,InOffset.y);

	BOOL **pMarkV,**pMarkH;
	//memory allocate for mark matrix
	pMarkV =new BOOL *[MIN_PATCH_SIZE];
	for (i=0;i<MIN_PATCH_SIZE;i++)
	{
		pMarkV[i]=new BOOL[OVERLAP_WIDTH];
	}

	pMarkH =new BOOL *[OVERLAP_WIDTH];
	for (i=0;i<OVERLAP_WIDTH;i++)
	{
		pMarkH[i]=new BOOL[MIN_PATCH_SIZE-OVERLAP_WIDTH];
	}

//////////////////////////////////////////////////////////////////////////
//Step 1: Vertical Cut Process

	MinCutCoreHrz(pData,pMatchPatchV,pDesV,pMarkV,OVERLAP_WIDTH,MIN_PATCH_SIZE,OutOffset,pSeams,pOffsets,0);
	
	//using data from input patches after cutting to replace the exist pixels in output image
//	CString str,strOutput;
	for (i=0;i<MIN_PATCH_SIZE;i++)
	{
		for (unsigned int j=0;j<OVERLAP_WIDTH;j++)
		{
			//update data
			if (pMarkV[i][j])//
			{
//				str.Format("1 ");strOutput+=str;
				
				pDataOut[i+OutOffset.y][j+OutOffset.x]=pDesV[i][j];//pData[i+InOffset.y][InOffset.x+j];//
				
				pOffsets[i+OutOffset.y][j+OutOffset.x].x=InOffset.x+j;
				pOffsets[i+OutOffset.y][j+OutOffset.x].y=InOffset.y+i;
			}
//			else
//				str.Format("0 ");strOutput+=str;
		}
//		strOutput+="\n";
	}
//	AfxMessageBox(strOutput);

	//record horizonal seams
	OffsetPair *ptempL,*ptempR;
	float mValue=Max_MVaule;
	for ( i=OutOffset.y;i<OutOffset.y+MIN_PATCH_SIZE;i++)
	{
		for (unsigned int j=OutOffset.x;j<OutOffset.x+OVERLAP_WIDTH-1;j++)
		{
			//no seams
			if (pOffsets[i][j].y==pOffsets[i][j+1].y && pOffsets[i][j].x==pOffsets[i][j+1].x-1)
			{
				pSeams[i][j].hrz.bMark=false;
			}
			else	//seams exist
			{
				pSeams[i][j].hrz.bMark=true;
				ptempL = &pOffsets[i][j];
				ptempR = &pOffsets[i][j+1];
				int s,t;
				s= ptempL->x >= lWidth ? lWidth :  ptempL->x+1;
				t= ptempR->x <= 0	? 0 :ptempR->x-1;			
				mValue=CalculateMValue(pData[ptempL->y][ptempL->x],pData[ptempL->y][s],
										pData[ptempR->y][t],pData[ptempR->y][ptempR->x]);
				
				pSeams[i][j].hrz.mValue=mValue;
			}
		}
	}

	//record vertical seams
	for (unsigned int j=OutOffset.x;j<OutOffset.x+OVERLAP_WIDTH;j++)
	{
		for (unsigned int i=OutOffset.y;i<OutOffset.y+MIN_PATCH_SIZE-1;i++)
		{
			//no seams
			if (pOffsets[i][j].x==pOffsets[i+1][j].x && pOffsets[i][j].y==pOffsets[i+1][j].y-1)
			{
				pSeams[i][j].vtc.bMark=false;
			}
			else	//seams exist
			{
				
				ptempL = &pOffsets[i][j];
				ptempR = &pOffsets[i+1][j];
				int s,t;
				s= ptempL->y >= lHeight ? lHeight :  ptempL->y+1;
				t= ptempR->y <= 0	? 0 :ptempR->y-1;
				mValue=CalculateMValue(pData[ptempL->y][ptempL->x],pData[s][ptempL->x],
										pData[t][ptempR->x],pData[ptempR->y][ptempR->x]);
				if (mValue>0)
				{
					pSeams[i][j].vtc.bMark=true;
					pSeams[i][j].vtc.mValue=mValue;
				}
				
			}
		}
	}

//////////////////////////////////////////////////////////////////////////
//Step 2: Horizonal Cut Process

	//core for calculating the min-cut
	OffsetPair OutOffsetH;
	OutOffsetH.x=OutOffset.x+OVERLAP_WIDTH;
	OutOffsetH.y=OutOffset.y;
	
	MinCutCoreHrz(pData,pMatchPatchH,pDesH,pMarkH,MIN_PATCH_SIZE-OVERLAP_WIDTH,OVERLAP_WIDTH,OutOffsetH,pSeams,pOffsets);	

	//using data from input patches after cutting to replace the exist pixels in output image
//	CString str,strOutput;
	for ( i=0;i<OVERLAP_WIDTH;i++)
	{
		for (int j=0;j<MIN_PATCH_SIZE-OVERLAP_WIDTH;j++)
		{
			//update data
			if (pMarkH[i][j])//
			{
//				str.Format("1 ");strOutput+=str;
				pDataOut[i+OutOffsetH.y][j+OutOffsetH.x]=pDesH[i][j];//pData[i+InOffset.y][InOffset.x+j];//
				pOffsets[i+OutOffsetH.y][j+OutOffsetH.x].x=InOffset.x+j+OVERLAP_WIDTH;
				pOffsets[i+OutOffsetH.y][j+OutOffsetH.x].y=InOffset.y+i;
			}
//			else
//				str.Format("0 ");strOutput+=str;
		}
//		strOutput+="\n";
	}
//	AfxMessageBox(strOutput);

	//record horizonal seams
//	OffsetPair *ptempL,*ptempR;
//	float mValue=Max_MVaule;
	for ( i=OutOffsetH.y;i<OutOffsetH.y+OVERLAP_WIDTH;i++)
	{
		for (unsigned int j=OutOffsetH.x;j<OutOffsetH.x+MIN_PATCH_SIZE-OVERLAP_WIDTH-1;j++)
		{
			//no seams
			if (pOffsets[i][j].y==pOffsets[i][j+1].y && pOffsets[i][j].x==pOffsets[i][j+1].x-1)
			{
				pSeams[i][j].hrz.bMark=false;
			}
			else	//seams exist
			{
				pSeams[i][j].hrz.bMark=true;
				ptempL = &pOffsets[i][j];
				ptempR = &pOffsets[i][j+1];
				int s,t;
				s= ptempL->x >= lWidth ? lWidth :  ptempL->x+1;
				t= ptempR->x <= 0	? 0 :ptempR->x-1;
				mValue=CalculateMValue(pData[ptempL->y][ptempL->x],pData[ptempL->y][s],
										pData[ptempR->y][t],pData[ptempR->y][ptempR->x]);
				
				pSeams[i][j].hrz.mValue=mValue;
			}
		}
	}

	//record vertical seams
	for ( j=OutOffsetH.x;j<OutOffsetH.x+MIN_PATCH_SIZE-OVERLAP_WIDTH;j++)
	{
		for (unsigned int i=OutOffsetH.y;i<OutOffsetH.y+OVERLAP_WIDTH-1;i++)
		{
			//no seams
			if (pOffsets[i][j].x==pOffsets[i+1][j].x && pOffsets[i][j].y==pOffsets[i+1][j].y-1)
			{
				pSeams[i][j].vtc.bMark=false;
			}
			else	//seams exist
			{
				
				ptempL = &pOffsets[i][j];
				ptempR = &pOffsets[i+1][j];
				int s,t;
				s= ptempL->y >= lHeight ? lHeight :  ptempL->y+1;
				t= ptempR->y <= 0	? 0 :ptempR->y-1;
				mValue=CalculateMValue(pData[ptempL->y][ptempL->x],pData[s][ptempL->x],
										pData[t][ptempR->x],pData[ptempR->y][ptempR->x]);
				if (mValue>0)
				{
					pSeams[i][j].vtc.bMark=true;
					pSeams[i][j].vtc.mValue=mValue;
				}
				
			}
		}
	}



//////////////////////////////////////////////////////////////////////////
//Step 3: Load the remind datas (size: (MIN_PATCH_SIZE-OVERLAP_WIDTH)*(MIN_PATCH_SIZE-OVERLAP_WIDTH))

	//////////////////////////////////////////////////////////////////////////
	//load the data which is not in the overlap area from the patch to output
	for (i=OVERLAP_WIDTH; i<MIN_PATCH_SIZE;i++)
	{
		for (int j=0; j<MIN_PATCH_SIZE-OVERLAP_WIDTH; j++)
		{
			pDataOut[i+OutOffsetH.y][j+OutOffsetH.x]=pData[i+InOffset.y][InOffset.x+OVERLAP_WIDTH+j];
			pOffsets[i+OutOffsetH.y][j+OutOffsetH.x].x=InOffset.x+j+OVERLAP_WIDTH;
			pOffsets[i+OutOffsetH.y][j+OutOffsetH.x].y=InOffset.y+i;
			
			//initialize seams
			if (i<MIN_PATCH_SIZE-1)
				pSeams[i+OutOffsetH.y][j+OutOffsetH.x].vtc.bMark=false;
		
			if (j<MIN_PATCH_SIZE-OVERLAP_WIDTH-1)
				pSeams[i+OutOffsetH.y][j+OutOffsetH.x].hrz.bMark=false;
		}
	}
/*	
	//clear data struct pMark and pDEs
	for (i=0;i<OVERLAP_WIDTH;i++)
	{
		delete [] 	pMarkH[i];
		delete [] 	pDesH[i];
	}
	for (i=0;i<MIN_PATCH_SIZE;i++)
	{
		delete [] 	pMarkV[i];
		delete [] 	pDesV[i];
	}
	delete   []   pMarkH;
	delete   []   pDesH;
	delete   []   pMarkV;
	delete   []   pDesV;
	/*
	clear2DArray(MIN_PATCH_SIZE,pMark);
	clear2DArray(MIN_PATCH_SIZE,pDes);
	*/
	return TRUE;
}

///////////////////////////////////////////////////////////////////////////
// TextureSynthesisDlg Functions
// Function name:		TextureSynthesisDlg::PatchMatchProcess()
// Function Description:Method 2: Using the Entire Match process to generate the candidate patch
// Return Value:		BOOL 
// Rt Val Description:	whether the function has been successful execute	
// Parameters:			 color3D  ** pData
// Param Desription:	Point to the first byte of the input data matrix
// Parameters:			 color3D  **pMatchPatch
// Param Desription:	Point to the first byte of the Match Patch data matrix
// Parameters:			CArray<OffsetPair,OffsetPair>& OffsetArray
// Param Desription:	the offset array to record the offsets
// Parameters:			long lWidth,long lHeight
// Param Desription:	size of the image relate to pData
// Notes:				In this section ,we use the formulations and MRF relation functions
//						to generate a possibility similarity of Match Patch and the right candidate patch
//						after all offsets except the one has been used, has been calculate we use the max 
//						possibility offset for the new patch work.
///////////////////////////////////////////////////////////////////////////

BOOL CTextureSynthesisDlg::PatchMatchProcessEx( color3D  ** pData,  color3D  **pMatchPatchV, color3D  **pMatchPatchH, 
											   CArray<OffsetPair,OffsetPair>& OffsetArray ,long lWidth,long lHeight)
{
	//initialize
	double PVaule=-1;//*Max_MVaule*100;
	long offsetX,offsetY;
	offsetX=offsetY=-1;

	int nflag=this->GetCheckedRadioButton(IDC_RADIO_FFT,IDC_RADIO_NAIVE);
//////////////////////////////////////////////////////////////////////////
//FFT acceleration
	if(nflag==IDC_RADIO_FFT)	
	{
	int nHeightOut,nWidthOut;
	nWidthOut=lWidth-MIN_PATCH_SIZE;
	nHeightOut=lHeight-MIN_PATCH_SIZE;
	
	int nHeightV=MIN_PATCH_SIZE;
	int nWidthV=OVERLAP_WIDTH;
	CMatrix** ReOutOutV=FFTConvolution(pData,lWidth,lHeight,pMatchPatchV,nWidthV,nHeightV);
	//////////////////////////////////////////////////////////////////////////
	//calculate the S^2 of Match Patch
	double SumOV=0;
	for (int i=0; i<nHeightV;i++)
	{
		for (int j=0; j<nWidthV;j++)
		{
			SumOV+=pMatchPatchV[i][j]*pMatchPatchV[i][j];
		}
	}

	//Horizonal
	int nHeightH=OVERLAP_WIDTH;
	int nWidthH=MIN_PATCH_SIZE-OVERLAP_WIDTH;
	CMatrix** ReOutOutH=FFTConvolution(pData,lWidth,lHeight,pMatchPatchH,nWidthH,nHeightH);
	//////////////////////////////////////////////////////////////////////////
	//calculate the S^2 of Match Patch
	double SumOH=0;
	for ( i=0; i<nHeightH;i++)
	{
		for (int j=0; j<nWidthH;j++)
		{
			SumOH+=pMatchPatchH[i][j]*pMatchPatchH[i][j];
		}
	}

	//circulation to find the max possibility 
	for (i=0;i<nHeightOut;i++)
	{
		for (int j=0;j<nWidthOut;j++)
		{
			if (OffsetExist(OffsetArray,j,i))continue;
			double sumIOV,sumIOH;
			sumIOV=ReOutOutV[0]->GetElement(j+nWidthV-1,i+nHeightV-1)
					+ReOutOutV[1]->GetElement(j+nWidthV-1,i+nHeightV-1)
					+ReOutOutV[2]->GetElement(j+nWidthV-1,i+nHeightV-1);
			sumIOH=ReOutOutH[0]->GetElement(j+nWidthH-1,i+nHeightH-1)
					+ReOutOutH[1]->GetElement(j+nWidthH-1,i+nHeightH-1)
					+ReOutOutH[2]->GetElement(j+nWidthH-1,i+nHeightH-1);
			double temp=CalculateEntirePtEx(SumOV,sumIOV,nWidthV,nHeightV,
											SumOH,sumIOV,nWidthH,nHeightH,
											lWidth*lHeight,j,i);
			if (temp>PVaule)
			{
				offsetX=j;
				offsetY=i;
				PVaule=temp;
			}
		}
	}

		for (i=0;i<3;i++)
		{
			delete ReOutOutV[i];
			delete ReOutOutH[i];//[]
		}
	}
//////////////////////////////////////////////////////////////////////////
//naive search
	else if(nflag==IDC_RADIO_NAIVE)
	{
	//memory allocate for input candidate matrix
	 color3D  ** pTempV,**pTempH;
	pTempV =new  color3D  *[MIN_PATCH_SIZE];
	for (int i=0;i<MIN_PATCH_SIZE;i++)
	{
		pTempV[i]=new  color3D [OVERLAP_WIDTH];
	}
	pTempH =new  color3D  *[OVERLAP_WIDTH];
	for (i=0;i<OVERLAP_WIDTH;i++)
	{
		pTempH[i]=new  color3D [MIN_PATCH_SIZE-OVERLAP_WIDTH];
	}

	//circulation to find the max possibility 
	for ( i=0; i<lHeight-MIN_PATCH_SIZE;i++)
	{
		for (int j=0; j<lWidth-MIN_PATCH_SIZE;j++)
		{
			//if current offset has even been insert into the output image
			if(OffsetExist(OffsetArray,j,i))continue;

			//fetch data with the current offset(i,j) from the input data matrix
			OffsetFetch(pData,pTempV,OVERLAP_WIDTH,MIN_PATCH_SIZE,j,i);
			OffsetFetch(pData,pTempH,MIN_PATCH_SIZE-OVERLAP_WIDTH,OVERLAP_WIDTH,j+OVERLAP_WIDTH,i);

			//calculate the P(t) under Entire Patch Match method
			float temp=CalculateEntirePtEx(pMatchPatchV,pMatchPatchH,pTempV,pTempH,lWidth,lHeight);
			
			//if the p(t) is greater than all the former ones, record it and change the pValue
			if (temp>PVaule)
			{
				offsetX=j;
				offsetY=i;
				PVaule=temp;
			}
		}
	}
	
	//delete the data 
	clear2DArray(MIN_PATCH_SIZE,pTempV);
	clear2DArray(OVERLAP_WIDTH,pTempH);
	}

//////////////////////////////////////////////////////////////////////////

	//record current offset pair
	if (offsetX>=0&&offsetY>=0)
	{
		OffsetPair tp;
		tp.x=offsetX;
		tp.y=offsetY;
		OffsetArray.Add(tp);
	}
	else
		return FALSE;
	
	return TRUE;
}
#include "math.h"
float CTextureSynthesisDlg::CalculateEntirePtEx( color3D  **pMatchPatchV, color3D  **pMatchPatchH,
												 color3D  **pCandiPatchV, color3D  **pCandiPatchH,
												long lWidth,long lHeight)
{
	float Area;
	int nWidth, nHeight;
	nWidth=OVERLAP_WIDTH;
	nHeight=MIN_PATCH_SIZE;
	Area=(float)nWidth*nHeight;
	
	//variants
	double Sum,SumII,SumI,SumO,SumIO,tp;
	double SumR,SumG,SumB;
	SumII=SumI=SumO=SumIO=0;
	SumR=SumG=SumB=0;


	//calculate some mediate variants
	for (int i=0; i<nHeight;i++)
	{
		for (int j=0; j<nWidth;j++)
		{
			SumR+=pCandiPatchV[i][j].r;
			SumG+=pCandiPatchV[i][j].g;
			SumB+=pCandiPatchV[i][j].b;
			
			SumO+=pMatchPatchV[i][j]*pMatchPatchV[i][j];
			SumI+=pCandiPatchV[i][j]*pCandiPatchV[i][j];
			SumIO+=pMatchPatchV[i][j]*pCandiPatchV[i][j];
		}
	}

	nWidth=MIN_PATCH_SIZE-OVERLAP_WIDTH;
	nHeight=OVERLAP_WIDTH;
	Area+=nWidth*nHeight;
	for (i=0; i<nHeight;i++)
	{
		for (int j=0; j<nWidth;j++)
		{
			SumR+=pCandiPatchH[i][j].r;
			SumG+=pCandiPatchH[i][j].g;
			SumB+=pCandiPatchH[i][j].b;

			SumO+=pMatchPatchH[i][j]*pMatchPatchH[i][j];
			SumI+=pCandiPatchH[i][j]*pCandiPatchH[i][j];
			SumIO+=pMatchPatchH[i][j]*pCandiPatchH[i][j];
		}
	}
	
	//using  (1) to calculate C(t)
	Sum= (SumI+SumO-2*SumIO)*Area/(lWidth*lHeight*Max_MVaule);
	
	SumII=SumR*SumR+SumG*SumG+SumB*SumB;

	//using  (2) to get Deviation of the candidate image
	double Deviation = SumI/Area-SumII/(Area*Area);
	

	//random K value generate (0.001---1)
	srand( (unsigned)time( NULL ) );
	//generate a random number
	rand();
	float kvalue = (float)rand()/RAND_MAX ;
	while (kvalue<0.001)
	{
		kvalue = (float)rand()/RAND_MAX ;
	}
	
	//using (2) to generate a possible value
	tp=(float)exp(-Sum/(kvalue*Deviation));
	
	/*	srand((unsigned)time(NULL));
	float sigma=1;
	p=(float) (sqrt(-2*log(rand()*1./RAND_MAX))*cos(2*Pi*rand()*1./RAND_MAX))*sigma+tp;
	*/	
	return (float)tp;
}


BOOL CTextureSynthesisDlg::LaterStripCreation( color3D  **pData, color3D  **pDataOut,
										 long lWidth,long lHeight,int xiterator,int OutoffsetY,
										 Seam **pSeams, OffsetPair **pIndexOutput)
{
/*	//memory allocate for match patch matrix (vertical)
	 color3D  **pMatchPatch;
	pMatchPatch =new  color3D  *[MIN_PATCH_SIZE];
	for (int i=0;i<MIN_PATCH_SIZE;i++)
	{
		pMatchPatch[i]=new  color3D [OVERLAP_WIDTH];
	}
	
	//memory allocate for match patch matrix (Horizonal)
	 color3D  **pMatchPatchHrz;
	pMatchPatchHrz =new  color3D  *[OVERLAP_WIDTH];
	for (i=0;i<OVERLAP_WIDTH;i++)
	{
		pMatchPatchHrz[i]=new  color3D [MIN_PATCH_SIZE-OVERLAP_WIDTH];
	}
*/
	//later strips --> generate first patch of the strip
	LaterStartMinCut(pData,pDataOut,lWidth,lHeight,OutoffsetY,pSeams,pIndexOutput);

	//circulation for generating a lot of Patches
	for (int i=0;i<xiterator;i++)
	{	
		//construct the output offset which is at the left-up coner of region 
		//in Output data matrix which already has data coverage.
		OffsetPair OutOffset;
		OutOffset.y=OutoffsetY;
		OutOffset.x=(MIN_PATCH_SIZE-OVERLAP_WIDTH)*(i+1);

		//patches generate
		LaterMinCutEx(pData,pDataOut,lWidth,lHeight,OutOffset,pSeams,pIndexOutput);						
	}
/*
	//clear data
	clear2DArray(MIN_PATCH_SIZE,pMatchPatch);
	clear2DArray(OVERLAP_WIDTH,pMatchPatchHrz);
*/	
	return TRUE;
}


//offsety = left-top conner of overlap region
BOOL CTextureSynthesisDlg::LaterStartMinCut( color3D  **pData, color3D  **pDataOut,
											long lWidth,long lHeight,int OutoffsetY,
											Seam **pSeams, OffsetPair **pIndexOutput)
{
	//memory allocate for match patch matrix (vertical)
/*	 color3D  **pMatchPatch;
	pMatchPatch =new  color3D  *[MIN_PATCH_SIZE];
	for (int i=0;i<MIN_PATCH_SIZE;i++)
	{
		pMatchPatch[i]=new  color3D [OVERLAP_WIDTH];
	}
*/
	//memory allocate for match patch matrix (Horizonal)
	 color3D  **pMatchPatchHrz;
	pMatchPatchHrz =new  color3D  *[OVERLAP_WIDTH];
	for (int i=0;i<OVERLAP_WIDTH;i++)
	{
		pMatchPatchHrz[i]=new  color3D [MIN_PATCH_SIZE];
	}
	
	//the first time to fetch data from output image as Match Patch
	OffsetFetch(pDataOut,pMatchPatchHrz,MIN_PATCH_SIZE,OVERLAP_WIDTH,0,OutoffsetY);
	
	//Patches Match Methods Select:
	//match the patch and find the right candidate patch from input image
	if(m_style.GetCurSel()==0) 
	{
		PatchMatchProcess(OffsetArray,lWidth,lHeight);
	}
	else
		if(!PatchMatchProcessHrz(pData, pMatchPatchHrz, OffsetArray,lWidth,lHeight))
		throw ;
	
	//construct the output offset which is at the left-up coner of region 
	//in Output data matrix which already has data coverage.
	OffsetPair OutOffset;
	OutOffset.y=OutoffsetY;
	OutOffset.x=0;
	
	//Using the max flow process to cut the image.
	MinCutProcessHrz(pData,lWidth,lHeight,OffsetArray.GetAt(OffsetArray.GetSize()-1),
		pDataOut,pMatchPatchHrz,OutOffset,pSeams,pIndexOutput);

	clear2DArray(OVERLAP_WIDTH,pMatchPatchHrz);
	return TRUE;
}

//Match size : OVERLAP_WIDTH*MIN_PATCH_SIZE
#include "Matrix.h"
BOOL CTextureSynthesisDlg::PatchMatchProcessHrz( color3D  ** pData,  color3D  **pMatchPatch, CArray<OffsetPair,OffsetPair>& OffsetArray 
											 ,long lWidth,long lHeight)
{
	//initialize
	double PVaule=-1;//*Max_MVaule*100;
	long offsetX,offsetY;
	offsetX=offsetY=-1;

	int nflag=this->GetCheckedRadioButton(IDC_RADIO_FFT,IDC_RADIO_NAIVE);
//////////////////////////////////////////////////////////////////////////
//FFT acceleration
	if(nflag==IDC_RADIO_FFT)	
	{
	
	int nHeight=OVERLAP_WIDTH;
	int nWidth=MIN_PATCH_SIZE;
	
	int nHeightOut,nWidthOut;
	nWidthOut=lWidth-MIN_PATCH_SIZE;
	nHeightOut=lHeight-MIN_PATCH_SIZE;
	
	CMatrix** ReOutOut=FFTConvolution(pData,lWidth,lHeight,pMatchPatch,nWidth,nHeight);
	//////////////////////////////////////////////////////////////////////////
	//calculate the S^2 of Match Patch
	double SumO=0;
	for (int i=0; i<nHeight;i++)
	{
		for (int j=0; j<nWidth;j++)
		{
			SumO+=pMatchPatch[i][j]*pMatchPatch[i][j];
		}
	}
	
	//	double PVaule=0;
	
	for (i=0;i<nHeightOut;i++)
	{
		for (int j=0;j<nWidthOut;j++)
		{
			if (OffsetExist(OffsetArray,j,i))continue;
			double sumIO=0;
			sumIO=ReOutOut[0]->GetElement(j+nWidth-1,i+nHeight-1)
			+ReOutOut[1]->GetElement(j+nWidth-1,i+nHeight-1)
			+ReOutOut[2]->GetElement(j+nWidth-1,i+nHeight-1);
			double temp=CalculateEntirePt(SumO,sumIO,nWidth,nHeight,lWidth*lHeight,j,i);
			if (temp>PVaule)
			{
				offsetX=j;
				offsetY=i;
				PVaule=temp;
			}
		}
	}
		for (i=0;i<3;i++)
		{
			delete ReOutOut[i];
		}
	}

//////////////////////////////////////////////////////////////////////////
//naive search
	else if(nflag==IDC_RADIO_NAIVE)
	{
	//memory allocate for input candidate matrix
	 color3D  ** pTemp;
	pTemp =new  color3D  *[OVERLAP_WIDTH];
	for (int i=0;i<OVERLAP_WIDTH;i++)
	{
		pTemp[i]=new  color3D [MIN_PATCH_SIZE];
	}
	
	//circulation to find the max possibility 
	for ( i=0; i<lHeight-MIN_PATCH_SIZE;i++)
	{
		for (int j=0; j<lWidth-MIN_PATCH_SIZE;j++)
		{
			//if current offset has even been insert into the output image
			if(OffsetExist(OffsetArray,j,i))continue;

			//fetch data with the current offset(i,j) from the input data matrix
			OffsetFetch(pData,pTemp,MIN_PATCH_SIZE,OVERLAP_WIDTH,j,i);

			//calculate the P(t) under Entire Patch Match method
			float temp=CalculateEntirePt(pMatchPatch,pTemp,MIN_PATCH_SIZE,OVERLAP_WIDTH,lWidth,lHeight);
			
			//if the p(t) is greater than all the former ones, record it and change the pValue
			if (temp>PVaule)
			{
				offsetX=j;
				offsetY=i;
				PVaule=temp;
			}
		}
	}

	}
//////////////////////////////////////////////////////////////////////////
	
	//record current offset pair
	if (offsetX>=0&&offsetY>=0)
	{
		OffsetPair tp;
		tp.x=offsetX;
		tp.y=offsetY;
		OffsetArray.Add(tp);
	}
	else
		return FALSE;
	
	return TRUE;
}

//out offset is point to the left-up coner.
//size :OVERLAP_WIDTH*MIN_PATCH_SIZE
BOOL CTextureSynthesisDlg::MinCutProcessHrz( color3D  **pData,unsigned int lWidth,unsigned int lHeight,OffsetPair InOffset,
						 color3D  **pDataOut, color3D  **pMatchPatch,OffsetPair OutOffset
						,Seam ** pSeams, OffsetPair ** pOffsets ,int nWidth)
{
	 color3D  **pDes;
	//memory allocate for candidate patch matrix
	pDes =new  color3D  *[nWidth];
	
		for ( int i=0;i<nWidth;i++)
		{
			pDes[i]=new  color3D [MIN_PATCH_SIZE];
		}
	
	
	
	//fetch data from the input matrix
	OffsetFetch(pData,pDes, MIN_PATCH_SIZE,nWidth,InOffset.x,InOffset.y);
	
	BOOL **pMark;
	//memory allocate for mark matrix
	pMark =new BOOL *[nWidth];
	for (i=0;i<nWidth;i++)
	{
		pMark[i]=new BOOL[MIN_PATCH_SIZE];
	}
	
	//core for calculating the min-cut
//	MinCutCore(pMatchPatch,pDes,pMark,MIN_PATCH_SIZE,OVERLAP_WIDTH);
	if (nWidth==MIN_PATCH_SIZE)
		{
			MinCutCoreHrz(pData,pMatchPatch,pDes,pMark,MIN_PATCH_SIZE,nWidth,OutOffset,pSeams,pOffsets,2);
		}
	else
	MinCutCoreHrz(pData,pMatchPatch,pDes,pMark,MIN_PATCH_SIZE,nWidth,OutOffset,pSeams,pOffsets);
	
	//using data from input patches after cutting to replace the exist pixels in output image
	CString str,strOutput;
	for ( i=0;i<nWidth;i++)
	{
		for (unsigned int j=0;j<MIN_PATCH_SIZE;j++)
		{
			
			//update data
			if (pMark[i][j])
			{
				str.Format("1 ");strOutput+=str;
				pDataOut[i+OutOffset.y][j+OutOffset.x]=pDes[i][j];//pData[i+InOffset.y][InOffset.x+j];
				pOffsets[i+OutOffset.y][j+OutOffset.x].x=InOffset.x+j;
				pOffsets[i+OutOffset.y][j+OutOffset.x].y=InOffset.y+i;
			}
			else
			{
				str.Format("0 ");strOutput+=str;
			}
		}
		strOutput+="\n";
	}
//	if (nWidth==MIN_PATCH_SIZE)	
//		AfxMessageBox(strOutput);

	//record horizonal seams
	OffsetPair *ptempL,*ptempR;
	float mValue=Max_MVaule;
	for (i=OutOffset.y;i<OutOffset.y+nWidth;i++)
	{
		for (unsigned int j=OutOffset.x;j<OutOffset.x+MIN_PATCH_SIZE-1;j++)
		{
			//no seams
			if (pOffsets[i][j].y==pOffsets[i][j+1].y && pOffsets[i][j].x==pOffsets[i][j+1].x-1)
			{
				pSeams[i][j].hrz.bMark=false;
			}
			else	//seams exist
			{
				pSeams[i][j].hrz.bMark=true;
				ptempL = &pOffsets[i][j];
				ptempR = &pOffsets[i][j+1];
				int s,t;
				s= ptempL->x >= lWidth ? lWidth :  ptempL->x+1;
				t= ptempR->x <= 0	? 0 :ptempR->x-1;
				mValue=CalculateMValue(pData[ptempL->y][ptempL->x],pData[ptempL->y][s],
										pData[ptempR->y][t],pData[ptempR->y][ptempR->x]);
				
				pSeams[i][j].hrz.mValue=mValue;
			}
		}
	}

	//record vertical seams
	for (unsigned int j=OutOffset.x;j<OutOffset.x+MIN_PATCH_SIZE;j++)
	{
		for (unsigned int i=OutOffset.y;i<OutOffset.y+nWidth-1;i++)
		{
			//no seams
			if (pOffsets[i][j].x==pOffsets[i+1][j].x && pOffsets[i][j].y==pOffsets[i+1][j].y-1)
			{
				pSeams[i][j].vtc.bMark=false;
			}
			else	//seams exist
			{
				
				ptempL = &pOffsets[i][j];
				ptempR = &pOffsets[i+1][j];
				int s,t;
				s= ptempL->y >= lHeight ? lHeight :  ptempL->y+1;
				t= ptempR->y <= 0	? 0 :ptempR->y-1;
				mValue=CalculateMValue(pData[ptempL->y][ptempL->x],pData[s][ptempL->x],
										pData[t][ptempR->x],pData[ptempR->y][ptempR->x]);
				if (mValue>0)
				{
					pSeams[i][j].vtc.bMark=true;
					pSeams[i][j].vtc.mValue=mValue;
				}
				
			}
		}
	}

	//////////////////////////////////////////////////////////////////////////
	//load the data which is not in the overlap area from the patch to output
	if (nWidth < MIN_PATCH_SIZE )
	{
	
//	CString str,strOutput;
	for (i=OVERLAP_WIDTH; i<MIN_PATCH_SIZE;i++)
	{
		for (int j=0; j<MIN_PATCH_SIZE; j++)
		{
//			str.Format("%4d",pData[i+InOffset.y][InOffset.x+OVERLAP_WIDTH+j]);
//			strOutput+=str;
			pDataOut[i+OutOffset.y][j+OutOffset.x]=pData[i+InOffset.y][InOffset.x+j];
			pOffsets[i+OutOffset.y][j+OutOffset.x].x=InOffset.x+j;
			pOffsets[i+OutOffset.y][j+OutOffset.x].y=InOffset.y+i;

			//initialize seams
			if (i<MIN_PATCH_SIZE-1)
				pSeams[i+OutOffset.y][j+OutOffset.x].vtc.bMark=false;
		
			if (j<MIN_PATCH_SIZE-1)
				pSeams[i+OutOffset.y][j+OutOffset.x].hrz.bMark=false;
		}
//		strOutput+="\n";
	}
	}
	//AfxMessageBox(strOutput);
	
	//clear data struct pMark and pDEs
	for (i=0;i<nWidth;i++)
	{
		delete [] 	pMark[i];
		delete [] 	pDes[i];
	}
	delete   []   pMark;
	delete   []   pDes;
	/*
	clear2DArray(MIN_PATCH_SIZE,pMark);
	clear2DArray(MIN_PATCH_SIZE,pDes);
	*/
	return TRUE;
}


BOOL CTextureSynthesisDlg::MinCutCoreHrz( color3D  **pData, color3D  **pMatchPatch, color3D  **pDes,BOOL **pMark,int nWidth,int nHeight,
											 OffsetPair OffsetOut,Seam ** pSeams, OffsetPair ** pOffsets, int bFlag)
{
	int nCount= CountSeams(pSeams,OffsetOut,nWidth, nHeight);

	typedef Graph<float,float,float> GraphType;
	GraphType *g = new GraphType(/*estimated # of nodes*/ nWidth*nHeight+nCount, 
		/*estimated # of edges*/ (nWidth)*(nHeight-1)+(nWidth-1)*(nHeight)+nCount); 
		
	g -> add_node(nWidth*nHeight+nCount); 
	
	//set the tweights to the graph, which means the nodes attach to PatchA and Patch B	
	if (bFlag==0)	//vertical cut
	{
		for (int i=0;i<nHeight;i++)
		{
//			g -> add_tweights( i*nWidth, Max_MVaule, Max_MVaule*1000 );
// 			g -> add_tweights( (i+1)*nWidth-1, Max_MVaule*1000, Max_MVaule );
			g -> add_tweights( i*nWidth, 0,Max_MVaule);
			g -> add_tweights( (i+1)*nWidth-1, Max_MVaule, 0 );
		}
	}
	else if (bFlag==1)	//if it's horizonal cut
	{
		for (int i=0;i<nWidth;i++)
		{
//			g -> add_tweights( i, Max_MVaule, Max_MVaule*1000 );
//			g -> add_tweights( (nHeight-1)*nWidth+i, Max_MVaule*1000, Max_MVaule );
			g -> add_tweights( i, 0,Max_MVaule );
			g -> add_tweights( (nHeight-1)*nWidth+i, Max_MVaule,0);
		}
	}
	else if (bFlag==2)	//Surround cut
	{
		for (int i=0;i<nWidth;i++)
		{
			g -> add_tweights( i, 0, Max_MVaule);
			g -> add_tweights( (nHeight-1)*nWidth+i, 0, Max_MVaule );
		}
		for (i=0;i<nHeight;i++)
		{
			g -> add_tweights( i*nWidth, 0, Max_MVaule);
			g -> add_tweights( (i+1)*nWidth-1, 0, Max_MVaule );
		}
	}
	

	//set the tweights of seams
	int nNodeIndex=nWidth*nHeight-1;
	//Seam array to record the position of seams
	OffsetMap pSeamArrayHrz,pSeamArrayVtc;
	for (int i=0;i<nHeight;i++)
	{
		for (int j=0;j<nWidth;j++)
		{
			if (j<nWidth-1)
			{
				if(pSeams[OffsetOut.y + i][OffsetOut.x + j].hrz.bMark ==true) 
				{
					nNodeIndex++;
					long  pt=OffsetOut.x + j+ (OffsetOut.y + i)*(nWidth-1);
					pSeamArrayHrz[pt]=nNodeIndex ;
					g -> add_tweights( nNodeIndex, Max_MVaule, pSeams[OffsetOut.y + i][OffsetOut.x + j].hrz.mValue );
				}
			}
			if (i<nHeight-1)
			{
				if(pSeams[OffsetOut.y + i][OffsetOut.x + j].vtc.bMark ==true) 
				{
					nNodeIndex++;
					long  pt=OffsetOut.x + j+ (OffsetOut.y + i)*(nWidth);
					pSeamArrayVtc[pt]=nNodeIndex ;
					g -> add_tweights( nNodeIndex, Max_MVaule, pSeams[OffsetOut.y + i][OffsetOut.x + j].vtc.mValue );
				}
			}
		}
	}
	
	//set M value of nodes in horizonal
	float mValue,mValueL,mValueR;
	OffsetPair *ptemp;
	 mValue=mValueL=mValueR=Max_MVaule;
	for ( i=0;i<=nHeight-1;i++)
	{
		for (int j=0;j<nWidth-1;j++)
		{
			if(pSeams[OffsetOut.y + i][OffsetOut.x + j].hrz.bMark ==true) 
			{
				//add L edge 
				ptemp = &pOffsets[OffsetOut.y + i][OffsetOut.x + j];
				mValueL=CalculateMValue(pData[ptemp->y][ptemp->x],pData[ptemp->y][ptemp->x+1],pDes[i][j],pDes[i][j+1]);
				long  pt=OffsetOut.x + j+ (OffsetOut.y + i)*(nWidth-1);
				g->add_edge(i*nWidth+j,pSeamArrayHrz[pt],mValueL,mValueL);
				
				//add R edge 
				ptemp = &pOffsets[OffsetOut.y + i][OffsetOut.x + j+1];
				mValueR=CalculateMValue(pDes[i][j],pDes[i][j+1],pData[ptemp->y][ptemp->x-1],pData[ptemp->y][ptemp->x]);
				//pt=OffsetOut.x + j+1+ (OffsetOut.y + i)*(nWidth-1);
				g->add_edge(pSeamArrayHrz[pt],i*nWidth+j+1,mValueR,mValueR);
			}
			else	//not seam nodes
			{
				mValue=CalculateMValue(pMatchPatch[i][j],pMatchPatch[i][j+1],pDes[i][j],pDes[i][j+1]);
				g->add_edge(i*nWidth+j,i*nWidth+j+1,mValue,mValue);
			}
		
		}
	}
	
	//set M value of nodes in vertical
	mValue=Max_MVaule;
	for ( i=0;i<nHeight-1;i++)
	{
		for (int j=0;j<=nWidth-1;j++)
		{
			if(pSeams[OffsetOut.y + i][OffsetOut.x + j].vtc.bMark ==true) 
			{
				//add Up edge
				ptemp = &pOffsets[OffsetOut.y + i][OffsetOut.x + j];
				mValueL=CalculateMValue(pData[ptemp->y][ptemp->x],pData[ptemp->y+1][ptemp->x],pDes[i][j],pDes[i+1][j]);
				long  pt=OffsetOut.x + j+ (OffsetOut.y + i)*(nWidth);
				g->add_edge(i*nWidth+j,pSeamArrayVtc[pt],mValueL,mValueL);
				
				//add Down edge 
				ptemp = &pOffsets[OffsetOut.y + i+1][OffsetOut.x + j];
				mValueR=CalculateMValue(pDes[i][j],pDes[i+1][j],pData[ptemp->y-1][ptemp->x],pData[ptemp->y][ptemp->x]);
				//pt=OffsetOut.x + j+1+ (OffsetOut.y + i)*(nWidth);
				g->add_edge(pSeamArrayVtc[pt],(i+1)*nWidth+j,mValueR,mValueR);
			}
			else	//not seam nodes
			{
				mValue=CalculateMValue(pMatchPatch[i][j],pMatchPatch[i+1][j],pDes[i][j],pDes[i+1][j]);
				g->add_edge(i*nWidth+j,(i+1)*nWidth+j,mValue,mValue);
			}
		}
	}

	//max flow process
	float flow = g -> maxflow();
	
	//record the result
	CString strOutput,str;
	for ( i=0;i<nHeight;i++)
	{
		for (int j=0;j<nWidth;j++)
		{
			if (g->what_segment(i*nWidth+j)== GraphType::SOURCE)
				pMark[i][j]=TRUE,str="1  ";
			else
				pMark[i][j]=FALSE,str="0  ";
//			strOutput+=str;
		}
//		strOutput+="\n";
	}
	//	AfxMessageBox(strOutput);
	
	//delete the graph
	delete g;
	
	return TRUE;
}


int  CTextureSynthesisDlg::CountSeams(Seam ** pSeams, OffsetPair OffsetOut,int nWidth,int nHeight)
{
//	CArray<OffsetPair, OffsetPair> pSeamArray;
	int nCount=0;
	for (int i=0;i<nHeight;i++)
	{
		for (int j=0;j<nWidth;j++)
		{
			if (j<nWidth-1)
			{
				if(pSeams[OffsetOut.y + i][OffsetOut.x + j].hrz.bMark ==true) nCount++;
			}
			if (i<nHeight-1)
			{
				if(pSeams[OffsetOut.y + i][OffsetOut.x + j].vtc.bMark ==true) nCount++;
			}
		}
	}
	
	return nCount;
}
