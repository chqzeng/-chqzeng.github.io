// TextureSynthesisDlg.cpp : implementation file
//

#include "stdafx.h"
#include "TextureSynthesis.h"
#include "TextureSynthesisDlg.h"

#include "OvelapSelectionDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();
	
	// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA
	
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL
	
	// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
//{{AFX_MSG_MAP(CAboutDlg)
// No message handlers
//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTextureSynthesisDlg dialog

CTextureSynthesisDlg::CTextureSynthesisDlg(CWnd* pParent /*=NULL*/)
: CDialog(CTextureSynthesisDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTextureSynthesisDlg)
	m_input = _T("");
	m_output = _T("");
	m_overlap = _T("");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CTextureSynthesisDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTextureSynthesisDlg)
	DDX_Control(pDX, IDC_CHECK_ProProcess, m_bPorprocess);
	DDX_Control(pDX, IDC_CHECK1, m_bOverlap);
	DDX_Control(pDX, IDC_COMBO1, m_style);
	DDX_Text(pDX, IDC_EDIT_INPUT, m_input);
	DDX_Text(pDX, IDC_EDIT_OUTPUT, m_output);
	DDX_Text(pDX, IDC_EDIT_OVERLAP, m_overlap);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CTextureSynthesisDlg, CDialog)
//{{AFX_MSG_MAP(CTextureSynthesisDlg)
ON_WM_SYSCOMMAND()
ON_WM_PAINT()
ON_WM_QUERYDRAGICON()
ON_BN_CLICKED(IDC_BUTTON_INPUT, OnButtonInput)
ON_BN_CLICKED(IDC_BUTTON_OUTPUT, OnButtonOutput)	
ON_WM_DESTROY()
ON_BN_CLICKED(IDC_CHECK1, OnCheck1)
ON_BN_CLICKED(IDC_BUTTON_OVERLAP, OnButtonOverlap)
//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTextureSynthesisDlg message handlers

BOOL CTextureSynthesisDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
	
	// Add "About..." menu item to system menu.
	
	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);
	
	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}
	
	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	((CButton*)GetDlgItem(IDC_RADIO_FFT))->SetCheck(1);
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CTextureSynthesisDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CTextureSynthesisDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting
		
		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);
		
		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;
		
		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CTextureSynthesisDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CTextureSynthesisDlg::OnButtonInput() 
{
	// TODO: Add your control notification handler code here
	CString m_Filter="BMP Files(*.bmp)|*.bmp|JPEG Files(*.jpg)|*.jpg|All Files (*.*)|*.*||";
	CFileDialog dlg(TRUE,NULL,NULL,OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT,m_Filter,NULL);
	if (dlg.DoModal()==IDOK)
	{
		m_input=dlg.GetPathName();
		
		/*		//open the input file
		HDIB tempDib=OpenInputFile(dlg.GetPathName());
		if (tempDib)
		{
		m_InputArray.Add(tempDib);
		}
		*/		
		UpdateData(FALSE);
	}
}

void CTextureSynthesisDlg::OnButtonOutput() 
{
	// TODO: Add your control notification handler code here
	CString m_Filter="BMP Files(*.bmp)|*.bmp|JPEG Files(*.jpg)|*.jpg|All Files (*.*)|*.*||";
	CFileDialog dlg(FALSE,NULL,NULL,OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT,m_Filter,NULL);
	if (dlg.DoModal()==IDOK)
	{
		m_output=dlg.GetPathName();
		UpdateData(FALSE);
	}
}

void CTextureSynthesisDlg::OnOK() 
{
	//release the data
	for (int i=0;i<m_InputArray.GetSize();i++)
	{
		::GlobalFree((HGLOBAL)m_InputArray.GetAt(i)) ;
	}
	m_InputArray.RemoveAll();
	::GlobalFree((HGLOBAL)m_hOutDIB) ;
	
	// TODO: Add extra validation here	
	UpdateData(TRUE);
	BeginWaitCursor();
	
	if (m_input.IsEmpty())
	{
		AfxMessageBox("Please First input a image for process!");
		return;
	}

	HDIB tempDib=OpenInputFile(m_input);
	if (tempDib)
	{
		m_InputArray.Add(tempDib);
	}
	else
	{
		AfxMessageBox("Input File Error!");
		return;
	}

	if (m_bOverlap.GetCheck())
	{
		if (m_overlap.IsEmpty())
		{
			AfxMessageBox("Please First input a overlap image for process!");
			return;
		}
		HDIB overlap=OpenInputFile(m_overlap);
		if (overlap)
		{
			m_InputArray.Add(overlap);
		}
		else
		{
			AfxMessageBox("Overlap File Error!");
			return;
		}
	}
	
	//give a path if needed.
	if (m_output.IsEmpty())
	{
		m_output="D:\\zeng\\result.bmp";
	}

	
	if (m_bOverlap.GetCheck())	//multi images synthesis process
	{
		//Image 1
		m_hInDIB=m_InputArray.GetAt(0);
		LPSTR pData= (LPSTR) ::GlobalLock((HGLOBAL)m_hInDIB);
		int Width,Height;
		Width=::DIBWidth(pData);
		Height=::DIBHeight(pData);

		//Image 2
		m_hOverDIB=OpenInputFile(m_overlap);
		pData= (LPSTR) ::GlobalLock((HGLOBAL)m_hOverDIB);
		int nWidth,nHeight;
		nWidth=::DIBWidth(pData);
		nHeight=::DIBHeight(pData);
		
//		//memory allocate for Match matrix
//		color3D  **pIn;
//		pIn =RetrieveDataMatrix(m_hOverDIB);			
//		//memory allocate for Model matrix
//		 color3D  **pModel;
//		pModel=RetrieveDataMatrix(m_hInDIB);
//		m_hOutDIB=OutPutProcess(m_hInDIB,pIn,Width,Height);
//		SaveOutputFile("d:\\zeng\\image_overlap.bmp",m_hOutDIB);
//		GlobalFree((HGLOBAL)m_hOutDIB);
//		m_hOutDIB=OutPutProcess(m_hOverDIB,pModel,nWidth,nHeight);
//		SaveOutputFile("d:\\zeng\\image_model.bmp",m_hOutDIB);
//	//	GlobalFree((HGLOBAL)m_hOutDIB);
//		clear2DArray(Height,pIn);
//		clear2DArray(nHeight,pModel);
//		return;


		bool bVertical,bLeftMin;
		//determine the longer part of the image
		bVertical= (max(Width,nWidth)>=max(Height,nHeight))?false: true;
		bLeftMin= Height<=nHeight&&Width<=nWidth?true: false;

		if ((nWidth+Width)>MAX_OVERLAP_WIDTH||max(Height,nHeight)>MAX_OVERLAP_HEIGHT)
		{
			AfxMessageBox("The Given two images are too large to show together,choose smaller one!");
			return;
		}

		// Initialize interactive dialog 
/*		COvelapSelectionDlg *pDlg=new COvelapSelectionDlg();
		
		if (bLeftMin)	//make sure the left image is much shorter
		{
			pDlg->ImgL.cx=Width;
			pDlg->ImgL.cy=Height;
			pDlg->ImgR.cx=nWidth;
			pDlg->ImgR.cy=nHeight;
			pDlg->m_hDIBL=m_hInDIB;
			pDlg->m_hDIBR=m_hOverDIB;
		}
		else
		{
			pDlg->ImgL.cx=Width;
			pDlg->ImgL.cy=Height;
			pDlg->ImgR.cx=nWidth;
			pDlg->ImgR.cy=nHeight;
			pDlg->m_hDIBR=m_hInDIB;
			pDlg->m_hDIBL=m_hOverDIB;
		}
		pDlg->Create(IDD_DIALOG_OVERLAP);
		pDlg->ShowWindow(SW_SHOW);
	*/	
		COvelapSelectionDlg dlg;
		
		if (bLeftMin)	//make sure the left image is much shorter
		{
			dlg.ImgL.cx=Width;
			dlg.ImgL.cy=Height;
			dlg.ImgR.cx=nWidth;
			dlg.ImgR.cy=nHeight;
			dlg.m_hDIBL=m_hInDIB;
			dlg.m_hDIBR=m_hOverDIB;
		}
		else
		{
			dlg.ImgL.cx=nWidth;
			dlg.ImgL.cy=nHeight;
			dlg.ImgR.cx=Width;
			dlg.ImgR.cy=Height;
			dlg.m_hDIBR=m_hInDIB;
			dlg.m_hDIBL=m_hOverDIB;
		}
		if(dlg.DoModal()==IDOK)
		{
			CArray<CRect,CRect>RectList;
			RectList.Add(dlg.TrueInRect);
			RectList.Add(dlg.TrueOutRect);
			RectList.Add(dlg.TrueOverRect);

			//determine which is the smaller image height
			if (bLeftMin)
			{
				m_hOutDIB=TextureOverlap(m_hInDIB,m_hOverDIB,RectList);
			}
			else
			{
				m_hOutDIB=TextureOverlap(m_hOverDIB,m_hInDIB,RectList);
			}
		}
		else
		{
			return;
		}
		
	}
	else	//single image synthesis process
	{
		m_hInDIB= m_InputArray.GetAt(0);
		m_hOutDIB=TextureSynthesis(m_hInDIB);
	}
	
	//save output file
	if(m_hOutDIB&&!SaveOutputFile(m_output,m_hOutDIB))
	{
		AfxMessageBox("Save image error!");
	}
	else
		AfxMessageBox("Operation success!\n"+strTime);
	
		try
	{}
	
	catch (...) 
	{
		AfxMessageBox("Operation error!");
		return;
	}
	EndWaitCursor();


//	CDialog::OnOK();
}

void CTextureSynthesisDlg::OnDestroy() 
{
	CDialog::OnDestroy();
	
	// TODO: Add your message handler code here
	
	//release the data
	for (int i=0;i<m_InputArray.GetSize();i++)
	{
		::GlobalFree((HGLOBAL)m_InputArray.GetAt(i)) ;
	}
	
	::GlobalFree((HGLOBAL)m_hOutDIB) ;
	::GlobalFree((HGLOBAL)m_hOverDIB) ;
	
}

void CTextureSynthesisDlg::OnCheck1() 
{
	// TODO: Add your control notification handler code here
	(CEdit *)GetDlgItem(IDC_EDIT_OVERLAP)->EnableWindow(m_bOverlap.GetCheck());
	(CButton *)GetDlgItem(IDC_BUTTON_OVERLAP)->EnableWindow(m_bOverlap.GetCheck());
}

void CTextureSynthesisDlg::OnButtonOverlap() 
{
	// TODO: Add your control notification handler code here
	CString m_Filter="BMP Files(*.bmp)|*.bmp|JPEG Files(*.jpg)|*.jpg|All Files (*.*)|*.*||";
	CFileDialog dlg(TRUE,NULL,NULL,OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT,m_Filter,NULL);
	if (dlg.DoModal()==IDOK)
	{
		m_overlap=dlg.GetPathName();
		UpdateData(FALSE);
	}
}
