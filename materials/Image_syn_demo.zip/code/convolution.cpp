#include "stdafx.h"
#include "TextureSynthesisDlg.h"

#include "graph.h"

#include "ArisImageRoutines1.h"

CMatrix** CTextureSynthesisDlg::FFTConvolution( color3D  ** pData,long lWidth,long lHeight,
					 color3D  **pMatchPatch, long nWidth,long nHeight)//,CMatrix &ReOutOut)
{
	//define the new size of the FFT construction
	int newWidth,newHeight;
	newWidth=lWidth+nWidth;
	newHeight=lHeight+nHeight;
	
	//set the new width and height as 2^n > Ma +Mb -1
	for (int i=0;;i++)
	{
		if ((newWidth>>i)&&!(newWidth>>(i+1)))break;
	}
	newWidth=(int)pow(2,i+1);
	
	for (i=0;;i++)
	{
		if ((newHeight>>i)&&!(newHeight>>(i+1)))break;
	}
	newHeight=(int)pow(2,i+1);
	
	//record the whole size
	long size=newWidth*newHeight;

	CMatrix **ReOutOut;
	ReOutOut=new CMatrix*[3];
	InitMatrix(ReOutOut,newWidth,newHeight);
	
	//set value with pdata
	for ( i=0;i<3;i++)
	{
		CMatrix ReIn(newWidth,newHeight);
		CMatrix ReInMatch(newWidth,newHeight);
		for(int x=0;x<lHeight;x++)
		{
			for(int y=0;y<lWidth;y++)
			{
				switch(i) 
				{
				case 0:
					ReIn.SetElement(y,x,pData[x][y].r);	
					break;
				case 1:
					ReIn.SetElement(y,x,pData[x][y].g);	
					break;
				case 2:
					ReIn.SetElement(y,x,pData[x][y].b);	
					break;
				}
			}
		}
		for(x=0;x<nHeight;x++)
		{
			for(int y=0;y<nWidth;y++)
			{
				switch(i) 
				{
				case 0:
					ReInMatch.SetElement(y,x,pMatchPatch[nHeight-x-1][nWidth-y-1].r);
					break;
				case 1:
					ReInMatch.SetElement(y,x,pMatchPatch[nHeight-x-1][nWidth-y-1].g);
					break;
				case 2:
					ReInMatch.SetElement(y,x,pMatchPatch[nHeight-x-1][nWidth-y-1].b);
					break;
				}
			}
		}
		
		ReOutOut[i]=FFTConvolutionCore(ReIn, ReInMatch,newWidth,newHeight);
	}
	
	return ReOutOut;
/*
//////////////////////////////////////////////////////////////////////////
//step 1: FFT for the Input Data

	//create structures for operation
	CMatrix *ReIn[3],*ReOut[3],*ImOut[3];
	InitMatrix(ReIn,newWidth,newHeight);
	InitMatrix(ReOut,newWidth,newHeight);
	InitMatrix(ImOut,newWidth,newHeight);
//	CMatrix ReIn(newWidth,newHeight);
//	CMatrix ReOut(newWidth,newHeight);
//	CMatrix ImOut(newWidth,newHeight);
	
	
		for(int x=0;x<lHeight;x++)
		{
			for(int y=0;y<lWidth;y++)
			{
			
					ReIn[0].SetElement(y,x,pData[x][y].r);	
					
					ReIn[1].SetElement(y,x,pData[x][y].g);	
				
					ReIn[2].SetElement(y,x,pData[x][y].b);	
				}
			}
		}
	//FFT 
	ArisImageRoutines fft;
	for (i=0;i<3;i++)
	{
		if (!fft.FFT(ReIn[i], //input Real
		NULL, //input Imaginary
		ReOut[i], //output Real
		ImOut[i], //output Imaginary
		1)) return NULL;
	}
	
	
//////////////////////////////////////////////////////////////////////////
//step 2:  FFT for Match Patch from output image

	CMatrix *ReInMatch[3],*ReOutMatch[3],*ImOutMatch[3];
	InitMatrix(ReInMatch,newWidth,newHeight);
	InitMatrix(ReOutMatch,newWidth,newHeight);
	InitMatrix(ImOutMatch,newWidth,newHeight);	
	//set value
	for(x=0;x<nHeight;x++)
	{
		for(int y=0;y<nWidth;y++)
		{
			ReInMatch[0]->SetElement(y,x,pMatchPatch[nHeight-x-1][nWidth-y-1].r);
			ReInMatch[1]->SetElement(y,x,pMatchPatch[nHeight-x-1][nWidth-y-1].g);
			ReInMatch[2]->SetElement(y,x,pMatchPatch[nHeight-x-1][nWidth-y-1].b);
		}
	}
	
	ArisImageRoutines fftMatch;
	for (i=0;i<3;i++)
	{
	if (!fftMatch.FFT(ReInMatch[i], //input Real
		NULL, //input Imaginary
		ReOutMatch[i], //output Real
		ImOutMatch[i], //output Imaginary
		1)) return NULL;
	}
	
//////////////////////////////////////////////////////////////////////////
//step 3: IFFT (A'.*B')

	CMatrix *ReInOut[3],**ReOutOut,*ImInOut[3],*ImOutOut[3];
	ReOutOut=new CMatrix* [3];
	InitMatrix(ReInOut,newWidth,newHeight);
	InitMatrix(ReOutOut,newWidth,newHeight);
	InitMatrix(ImInOut,newWidth,newHeight);
	InitMatrix(ImOutOut,newWidth,newHeight);	
	
	//circulation
	for(x=0;x<newHeight;x++)
	{
		for(int y=0;y<newWidth;y++)
		{
			ComplexMulti(ReOut[0],ImOut[0],ReOutMatch[0],ImOutMatch[0],x,y,ReInOut[0],ImInOut[0],size);
			ComplexMulti(ReOut[1],ImOut[1],ReOutMatch[1],ImOutMatch[1],x,y,ReInOut[1],ImInOut[1],size);
			ComplexMulti(ReOut[2],ImOut[2],ReOutMatch[2],ImOutMatch[2],x,y,ReInOut[2],ImInOut[2],size);

//			a=ReOut.GetElement(x,y);
//			b=ImOut.GetElement(x,y);
//			c=ReOutMatch.GetElement(x,y);
//			d=ImOutMatch.GetElement(x,y);
//			ReInOut.SetElement(x,y,(a*c-b*d)*size);
//			ImInOut.SetElement(x,y,(a*d+b*c)*size);
		}
	}
	
	ArisImageRoutines fftOut;
	for (i=0;i<3;i++)
	{
	if (!fftOut.FFT(ReInOut[i], //input Real
		ImInOut[i], //input Imaginary
		ReOutOut[i], //output Real
		ImOutOut[i], //output Imaginary
		-1)) return NULL;
	}

	//clear data;
	for (i=0;i<3;i++)
	{
		delete ReIn[i];
		delete ReOut[i];
		delete ImOut[i];
		delete ReInMatch[i];
		delete ReOutMatch[i];
		delete ImOutMatch[i];
		delete ReInOut[i];
		delete ImInOut[i];
		delete ImOutOut[i];
	}

	return ReOutOut;
	*/
}

CMatrix* CTextureSynthesisDlg::FFTConvolutionCore(CMatrix& ReIn,CMatrix &ReInMatch,long newWidth,long newHeight)//,CMatrix &ReOutOut)
{
	//define the new size of the FFT construction
	
	//record the whole size
	long size=newWidth*newHeight;

//////////////////////////////////////////////////////////////////////////
//step 1: FFT for the Input Data

	//create structures for operation
//	CMatrix ReIn(newWidth,newHeight);
	CMatrix ReOut(newWidth,newHeight);
	CMatrix ImOut(newWidth,newHeight);
	
	//FFT 
	ArisImageRoutines fft;
	if (!fft.FFT(&ReIn, //input Real
		NULL, //input Imaginary
		&ReOut, //output Real
		&ImOut, //output Imaginary
		1)) return NULL;
	
//////////////////////////////////////////////////////////////////////////
//step 2:  FFT for Match Patch from output image

//	CMatrix ReInMatch(newWidth,newHeight);
	CMatrix ReOutMatch(newWidth,newHeight);
	CMatrix ImOutMatch(newWidth,newHeight);
	
	ArisImageRoutines fftMatch;
	if (!fftMatch.FFT(&ReInMatch, //input Real
		NULL, //input Imaginary
		&ReOutMatch, //output Real
		&ImOutMatch, //output Imaginary
		1)) return NULL;
	
//////////////////////////////////////////////////////////////////////////
//step 3: IFFT (A'.*B')

	//data input
	CMatrix ReInOut(newWidth,newHeight);
	CMatrix ImInOut(newWidth,newHeight); 
	CMatrix ImOutOut(newWidth,newHeight);
	
	CMatrix *ReOutOut;//(newWidth,newHeight);
	ReOutOut=new CMatrix(newWidth,newHeight);

	double a,b,c,d;
	
	//circulation
	for(int x=0;x<newHeight;x++)
	{
		for(int y=0;y<newWidth;y++)
		{
			//(a+bi)*(c+di)=(ac-bd)+(ad+bc)i
			a=ReOut.GetElement(x,y);
			b=ImOut.GetElement(x,y);
			c=ReOutMatch.GetElement(x,y);
			d=ImOutMatch.GetElement(x,y);
			ReInOut.SetElement(x,y,(a*c-b*d)*size);
			ImInOut.SetElement(x,y,(a*d+b*c)*size);
		}
	}
	
	ArisImageRoutines fftOut;
	if (!fftOut.FFT(&ReInOut, //input Real
		&ImInOut, //input Imaginary
		ReOutOut, //output Real
		&ImOutOut, //output Imaginary
		-1)) return NULL;

	return ReOutOut;
}


/*		
for(x=0;x<nHeightOut;x++)
{
for(int y=0;y<nWidthOut;y++)
{
int offsetx=x+nHeight-1;
int offsety=y+nWidth-1;
a=ReOut.GetElement(offsetx,offsety);
b=ImOut.GetElement(offsetx,offsety);
c=ReOutMatch.GetElement(offsetx,offsety);
d=ImOutMatch.GetElement(offsetx,offsety);
ReInOut.SetElement(offsetx,offsety,(a*c-b*d)*size);
ImInOut.SetElement(offsetx,offsety,(a*d+b*c)*size);
}
}
*/		
/*		

		CMatrix ReIn(newWidth,newHeight);
		CMatrix ReOut(newWidth,newHeight);
		//CMatrix ImIn(512,512); we currently don��t need it
		CMatrix ImOut(newWidth,newHeight);
		
		  //		strOutput="";
		  for(int x=0;x<lHeight;x++)
		  {
		  for(int y=0;y<lWidth;y++)
		  {
		  ReIn.SetElement(y,x,pData[x][y]);
		  //				str.Format("%d ",pData[x][y]);
		  //				strOutput+=str;
		  }
		  //			strOutput+="\n";
		  }
		  
			//			pFileName="D:\\zeng\\test_pData.txt";
			//			pStream.Open( pFileName, CFile::modeCreate | CFile::modeWrite );
			//			pStream.WriteHuge(strOutput.GetBuffer(0),strOutput.GetLength());
			//			pStream.Close();
			
			  ArisImageRoutines fft;
			  
				if (!fft.FFT(&ReIn, //input Real
				NULL, //input Imaginary
				&ReOut, //output Real
				&ImOut, //output Imaginary
				1)) return FALSE;
				
				  int nHeight=MIN_PATCH_SIZE;
				  CMatrix ReInMatch(newWidth,newHeight);
				  CMatrix ReOutMatch(newWidth,newHeight);
				  //CMatrix ImIn(512,512); we currently don��t need it
				  CMatrix ImOutMatch(newWidth,newHeight);
				  
					strOutput="";
					for(x=0;x<nHeight;x++)
					{
					for(int y=0;y<nWidth;y++)
					{
					ReInMatch.SetElement(y,x,pMatchPatch[nHeight-x-1][nWidth-y-1]);
					str.Format("%d ",pMatchPatch[nHeight-x-1][nWidth-y-1]);
					strOutput+=str;
					}
					strOutput+="\n";
					}
					
					  pFileName="D:\\zeng\\test_pMatch.txt";
					  pStream.Open( pFileName, CFile::modeCreate | CFile::modeWrite );
					  pStream.WriteHuge(strOutput.GetBuffer(0),strOutput.GetLength());
					  pStream.Close();
					  
						
						  ArisImageRoutines fftMatch;
						  
							if (!fftMatch.FFT(&ReInMatch, //input Real
							NULL, //input Imaginary
							&ReOutMatch, //output Real
							&ImOutMatch, //output Imaginary
							1)) return FALSE;
							
							  ArisImageRoutines fftOut;
							  int nHeightOut,nWidthOut;
							  nWidthOut=lWidth-max(nWidth,MIN_PATCH_SIZE);
							  nHeightOut=lHeight-nHeight;
							  CMatrix ReInOut(newWidth,newHeight);
							  CMatrix ReOutPut(newWidth,newHeight);
							  CMatrix ImInOut(newWidth,newHeight);
							  CMatrix ImOutPut(newWidth,newHeight);
							  
								strOutput="";
								for (i=0;i<newHeight;i++)
								{
								for (int j=0;j<newWidth;j++)
								{
								double a,b,c,d;//(a+bi) * (c+di) =ac-bd +(ad+bc)i
								a=ReOut.GetElement(j,i);
								b=ImOut.GetElement(j,i);//(j+nWidth-1,i+nHeight-1);
								c=ReOutMatch.GetElement(j,i);
								d=ImOutMatch.GetElement(j,i);
								//set value as input
								ReInOut.SetElement(j,i,(a*c-b*d)*size);
								ImInOut.SetElement(j,i,(a*d+b*c)*size);
								if (i>10||j>10)continue;
								str.Format("%lf \t",ReInOut.GetElement(j,i));
								strOutput+=str;
								}
								if (i<=10)strOutput+="\n";
								}
								pFileName="D:\\zeng\\test_conv.txt";
								pStream.Open( pFileName, CFile::modeCreate | CFile::modeWrite );
								pStream.WriteHuge(strOutput.GetBuffer(0),strOutput.GetLength());
								pStream.Close();
								
								  
									if (!fftOut.FFT(&ReInOut, //input Real
									&ImInOut, //input Imaginary
									&ReOutPut, //output Real
									&ImOutPut, //output Imaginary
									-1)) return FALSE;
									
									  strOutput="";
									  for (i=0;i<10;i++)
									  {
									  for (int j=0;j<10;j++)
									  {
									  str.Format("%8.f ",ReOutPut.GetElement(j,i));
									  strOutput+=str;
									  }
									  strOutput+="\n";
									  }
									  
										
										  pFileName="D:\\zeng\\test_result.txt";
										  pStream.Open( pFileName, CFile::modeCreate | CFile::modeWrite );
										  pStream.WriteHuge(strOutput.GetBuffer(0),strOutput.GetLength());
										  pStream.Close();
*/

/*				
				//memory allocate for input candidate matrix
				 color3D  ** pTemp;
				pTemp =new  color3D  *[MIN_PATCH_SIZE];
				for (int i=0;i<MIN_PATCH_SIZE;i++)
				{
					pTemp[i]=new  color3D [nWidth];
				}
				//fetch data with the current offset(i,j) from the input data matrix
				OffsetFetch(pData,pTemp,nWidth,MIN_PATCH_SIZE,j,i);
				
				//calculate the P(t) under Entire Patch Match method
				float temp1=CalculateEntirePt(pMatchPatch,pTemp,nWidth,MIN_PATCH_SIZE,lWidth,lHeight);
				clear2DArray(MIN_PATCH_SIZE,pTemp);
*/