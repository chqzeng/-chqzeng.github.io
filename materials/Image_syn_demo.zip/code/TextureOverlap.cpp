#include "stdafx.h"
#include "TextureSynthesisDlg.h"

///////////////////////////////////////////////////////////////////////////
// TextureSynthesisDlg Functions
// Function name:		TextureSynthesisDlg::TextureSynthesis()
// Function Description:the whole process of TextureSynthesis
// Return Value:		HDIB 
// Rt Val Description:	image handle of output image
// Parameters:			HDIB m_hDIB
// Param Desription:	image handle of input image
// Notes:				The outline function to call other functions in order to implement Texture Synthesis 
///////////////////////////////////////////////////////////////////////////
HDIB CTextureSynthesisDlg::TextureOverlap(HDIB m_hOverDIB,HDIB m_hModelDIB,CArray<CRect,CRect>&RectList)
{
	//output
	if (m_hModelDIB==NULL||m_hOverDIB==NULL)return NULL;
	HDIB m_hOutDIB;
	
	LPSTR pData,pDataOut;
	pData=(LPSTR) ::GlobalLock((HGLOBAL)m_hOverDIB);
	pDataOut=(LPSTR) ::GlobalLock((HGLOBAL)m_hModelDIB);
	
	int nWidth,nHeight;
	nWidth=::DIBWidth(pData);
	nHeight=::DIBHeight(pData);
	
	int nWidthOut,nHeightOut;
	nWidthOut=::DIBWidth(pDataOut);
	nHeightOut=::DIBHeight(pDataOut);
	
	//memory allocate for Match matrix
	 color3D  **pIn;
	pIn =RetrieveDataMatrix(m_hOverDIB);
		
	//memory allocate for Model matrix
	 color3D  **pModel;
	pModel=RetrieveDataMatrix(m_hModelDIB);

//	m_hOutDIB=OutPutProcess(m_hModelDIB,pIn,nWidthOut,nHeightOut);
//	SaveOutputFile("d:\\zeng\\image_overlap.bmp",m_hOutDIB);
//	GlobalFree((HGLOBAL)m_hOutDIB);
//	m_hOutDIB=OutPutProcess(m_hModelDIB,pModel,nWidthOut,nHeightOut);
//	SaveOutputFile("d:\\zeng\\image_model.bmp",m_hOutDIB);
//	GlobalFree((HGLOBAL)m_hOutDIB);

	//memory allocate for output matrix
	 color3D  **pOut;
	pOut =new  color3D  *[nHeight];
	for (int i=0;i<nHeight;i++)
	{
		pOut[i]=new  color3D [nWidth];
	}	

	BOOL **pMark;
	//memory allocate for mark matrix
	pMark =new BOOL *[nHeight];
	for (i=0;i<nHeight;i++)
	{
		pMark[i]=new BOOL[nWidth];
	}

	int startX,startY;
	startX=max(0,RectList.GetAt(2).right-nWidth);
	startY=max(0,RectList.GetAt(2).bottom-nHeight);
		
	int stepX,stepY,nGap=5;
	stepX=abs(nWidth-RectList.GetAt(2).Width())/nGap;
	stepY=abs(nHeight-RectList.GetAt(2).Height())/nGap;
	
	CRect rectIn,rectOut;
	//tolerance of edge
	rectIn.top =RectList.GetAt(0).top>TOLERANCE_GAP? RectList.GetAt(0).top:0;
	rectIn.left =RectList.GetAt(0).left>TOLERANCE_GAP? RectList.GetAt(0).left:0;
	rectIn.bottom=(nHeight-RectList.GetAt(0).bottom)>TOLERANCE_GAP? RectList.GetAt(0).bottom:nHeight;
	rectIn.right=(nWidth-RectList.GetAt(0).right)>TOLERANCE_GAP? RectList.GetAt(0).right:nWidth;
	
	//find the optimal min-cut result
	int offsetX,offsetY;
	float flow,pVaule=-1;
	int OptX,OptY;
	OptX=OptY=-1;
/*	for (i=0;i<nGap;i++)
	{
		for (int j=0;j<nGap;j++)
		{
			offsetX=startX+j*stepX;
			offsetY=startY+i*stepX;
			OffsetFetch(pModel,pOut,nWidth,nHeight,offsetX,offsetY);

			//region in Model image for operation
			CRect tempRC;
			tempRC.top=offsetY;
			tempRC.left=offsetX;
			tempRC.bottom=offsetY+nHeight;
			tempRC.right=offsetX+nWidth;

			if(rectOut.IntersectRect(tempRC,RectList.GetAt(1)))
			{
//				rectOut.top=max(tempRC.top,RectList.GetAt(1).top);
//				rectOut.bottom=max(tempRC.bottom,RectList.GetAt(1).bottom);
//				rectOut.left=max(tempRC.left,RectList.GetAt(1).left);
//				rectOut.right=max(tempRC.right,RectList.GetAt(1).right);
						
				flow =MinCutCore(pOut,pIn,pMark,nWidth,nHeight,rectIn,rectOut);
			}
			else		//no intersection area
			{
				flow =MinCutCore(pOut,pIn,pMark,nWidth,nHeight,rectIn);
			}
			if (flow<pVaule||pVaule<0)	//pVaule<0  which stands for it is the first time
			{
				OptX=offsetX;
				OptY=offsetY;
				pVaule =flow;
			}
		}
	}
*/	OffsetFetch(pModel,pOut,nWidth,nHeight,startX,startY);//OptX,OptY);

	//region in Model image for operation
	CRect tempRC;
	CPoint pt;
	
	pt.x=startX;
	pt.y=startY;
	tempRC=RectList.GetAt(1)-pt;
	CRect rc(0,0,nWidth,nHeight);

//	tempRC.top=startY;
//	tempRC.left=startX;
//	tempRC.bottom=startY+nHeight;
//	tempRC.right=startX+nWidth;
	
	if(rectOut.IntersectRect(tempRC,rc))
	{		
		flow =MinCutCore(pOut,pIn,pMark,nWidth,nHeight,&rectIn,&rectOut);
	}
	else		//no intersection area
	{
		flow =MinCutCore(pOut,pIn,pMark,nWidth,nHeight,&rectIn,NULL);
	}
	
	//using data from input patches after cutting to replace the exist pixels in output image
	CString str,strOutput;
	for ( i=0;i<nHeight;i++)
	{
		for (int j=0;j<nWidth;j++)
		{
			if (pMark[i][j]==TRUE)
			{
				pModel[i+startY][j+startX]=pIn[i][j];
//				strOutput+="1 ";
			}
//			else 
//				strOutput+="0 ";
		}
//		strOutput+="\n";
	}
//		
//	for ( i=0;i<nHeight;i++)
//	{
//		for (int j=0;j<nWidth;j++)
//		{
//			str.Format("%d %d %d ",(int)pModel[i][j].r,(int)pModel[i][j].g,(int)pModel[i][j].b );
//			strOutput+=str;
//		}
//		strOutput+="\n";
//	}
//	CStdioFile pStream;
//	CString pFileName="d:\\zeng\\test.txt";
//	pStream.Open( pFileName, CFile::modeCreate | CFile::modeWrite );
//	pStream.WriteHuge(strOutput.GetBuffer(0),strOutput.GetLength());
//	pStream.Close();


	m_hOutDIB=OutPutProcess(m_hModelDIB,pModel,nWidthOut,nHeightOut);
	
	//unlock data
	::GlobalUnlock((HGLOBAL)m_hModelDIB);
	::GlobalUnlock((HGLOBAL)m_hOverDIB);

	clear2DArray(nHeight,pMark);
	clear2DArray(nHeight,pIn);
	clear2DArray(nHeight,pOut);
	clear2DArray(nHeightOut,pModel);

	return m_hOutDIB;
}
