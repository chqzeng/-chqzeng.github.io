// TextureSynthesisDlg.h : header file
//

#if !defined(AFX_TEXTURESYNTHESISDLG_H__2885CE25_91CB_4F3E_950B_FE148D2C07E6__INCLUDED_)
#define AFX_TEXTURESYNTHESISDLG_H__2885CE25_91CB_4F3E_950B_FE148D2C07E6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CTextureSynthesisDlg dialog
#include "resource.h"
#include "dibapi.h"
#include <afxtempl.h>	

//#include "InLineFunc.h"
class CMatrix;
#include "ArisImageRoutines1.h"

#include "DataType.h"

class CTextureSynthesisDlg : public CDialog
{
	// Construction
public:
	CTextureSynthesisDlg(CWnd* pParent = NULL);	// standard constructor
	
public:
	CFile m_InFile,m_OutFile;
	HDIB m_hInDIB,m_hOverDIB, m_hOutDIB;
	CString strTime;
	CSize m_sizeDoc;
	CArray<HDIB,HDIB> m_InputArray;
	CArray<OffsetPair,OffsetPair> OffsetArray;
	CArray<OffsetPair ,OffsetPair >EROffsetArray;
	long **SummedTableEx;	//used to store the Sum Value of input image
	colorEx3D **SummedTable;
public:
	//////////////////////////////////////////////////////////////////////////
	//Functions of file operation --> FileInput.cpp
	void InitDIBData(HDIB m_hInDIB);
	HDIB OpenInputFile(CString strPathName);
	BOOL SaveOutputFile(CString strPathName, HDIB m_hOutputDIB);
	
	//////////////////////////////////////////////////////////////////////////
	//Functions of Match Patch  --> PatchMatch.cpp
	 color3D  ** RetrieveDataMatrix(HDIB m_hDataDIB);
	OffsetPair FirstPatchInsert( color3D  ** pData, color3D  **pDataOut,long lWidth,long lHeight);
	BOOL OffsetFetch( color3D  ** pSrc, color3D  **pDes, long nWidth,long nHeight, long offsetx,long offsety);
	BOOL OffsetExist(CArray<OffsetPair,OffsetPair> &OffsetArray,long offsetx, long offsety);
	float CalculateEntirePt( color3D  **pMatchPatch, color3D  **pCandiPatch,
		long nWidth,long nHeight,long lWidth,long lHeight);
	double CalculateEntirePt(double SumO,double sumIO,int nWidth,int nHeight,long lArea,int offsetX,int offsetY);
	
	BOOL PatchMatchProcess( color3D  ** pData,  color3D  ** pMatchPatch, CArray<OffsetPair,OffsetPair>& OffsetArray,long lWidth,long lHeight,long nWidth=OVERLAP_WIDTH);
	BOOL PatchMatchProcess(CArray<OffsetPair,OffsetPair>& OffsetArray ,long lWidth,long lHeight);
	
	//////////////////////////////////////////////////////////////////////////
	//Functions of Graphic Cut  --> GraphCut.cpp
	HDIB TextureSynthesis(HDIB m_hDIB);
	BOOL GenerateSummedTable(int lWidth,int lHeight, color3D  ** pData,colorEx3D **SummedTable ,long **SummedTableEx);
	BOOL StripCreation( color3D  **pData, color3D  **pDataOut,long lWidth,long lHeight,int xiterator);
	BOOL StripUnion( color3D  **pOutput, color3D  **pDataOut,int OffsetY,long lWidthOut);
	
	inline	 BOOL MinCutProcess( color3D  **pData,OffsetPair InOffset,
		//		long nWidth, long nHeight,
								 color3D  **pDataOut, color3D  **pMatchPatch,OffsetPair OutOffset);
	float MinCutCore( color3D  **pMatchPatch, color3D  **pDes,BOOL **pMark,int nWidth,int nHeight,CRect *rectIn,CRect *rectOut);
	float CalculateMValue(int vsPatchA, int vtPatchA,int vsPatchB,int vtPatchB);
	float CalculateMValue(color3D vsPatchA, color3D vtPatchA,color3D vsPatchB,color3D vtPatchB);
	//	inline BOOL clear2DArray(int size, color3D **pSrc);	
	HDIB OutPutProcess(HDIB m_hDIB,  color3D  ** pOutput,long lWidthOut,long lHeightOut );
	
	//////////////////////////////////////////////////////////////////////////
	//inline functions 
	// a template is urgently needed
	inline BOOL CTextureSynthesisDlg::clear2DArray(int size, color3D **pSrc)
	{
		for (int i=0;i<size;i++)
		{
			delete [] 	pSrc[i];
		}
		delete   []   pSrc;
		
		return TRUE;
	}
	inline BOOL CTextureSynthesisDlg::clear2DArray(int size, colorEx3D **pSrc)
	{
		for (int i=0;i<size;i++)
		{
			delete [] 	pSrc[i];
		}
		delete   []   pSrc;
		
		return TRUE;
	}
	inline BOOL CTextureSynthesisDlg::clear2DArray(int size,BOOL**pSrc)
	{
		for (int i=0;i<size;i++)
		{
			delete [] 	pSrc[i];
		}
		delete   []   pSrc;
		
		return TRUE;
	}
	inline BOOL CTextureSynthesisDlg::clear2DArray(int size,float**pSrc)
	{
		for (int i=0;i<size;i++)
		{
			delete [] 	pSrc[i];
		}
		delete   []   pSrc;
		
		return TRUE;
	}
	
	inline BOOL CTextureSynthesisDlg::OffsetValid(OffsetPair temp,int lWidth,int lHeight,int nSize)
	{
		if (temp.x>=0&&temp.y>=0&&temp.x<lWidth-nSize&&temp.y<lHeight-nSize )
			return TRUE;
		else
			return FALSE;
	}
	
	//////////////////////////////////////////////////////////////////////////
	//function for seams		---> FirststripCreation.cpp
	BOOL FirstMinCutProcess( color3D  **pData,OffsetPair InOffset,
								 color3D  **pDataOut, color3D  **pMatchPatch,OffsetPair OutOffset
								,Seam ** pSeams, OffsetPair ** pOffsets );
	BOOL FirstStripCreation( color3D  **pData, color3D  **pDataOut,
		long lWidth,long lHeight,int xiterator,
		Seam **pSeams, OffsetPair **pIndexOutput);
	BOOL PatchMatchProcessHrz( color3D  ** pData,  color3D  **pMatchPatch, CArray<OffsetPair,OffsetPair>& OffsetArray 
		,long lWidth,long lHeight);
	BOOL MinCutProcessHrz( color3D  **pData,unsigned int lWidth,unsigned int lHeight,OffsetPair InOffset,
		 color3D  **pDataOut, color3D  **pMatchPatch,OffsetPair OutOffset
		,Seam ** pSeams, OffsetPair ** pOffsets ,int nWidth=OVERLAP_WIDTH);
	
	//////////////////////////////////////////////////////////////////////////
	//function for seams  --> LaterStripCreation.cpp
	BOOL LaterStripCreation( color3D  **pData, color3D  **pDataOut,
		long lWidth,long lHeight,int xiterator,int OutoffsetY,
		Seam **pSeams, OffsetPair **pIndexOutput);
	inline	BOOL LaterStartMinCut( color3D  **pData, color3D  **pDataOut,
		long lWidth,long lHeight,int OutoffsetY,
		Seam **pSeams, OffsetPair **pIndexOutput);
	inline	BOOL MinCutCoreHrz( color3D  **pData, color3D  **pMatchPatch, color3D  **pDes,BOOL **pMark,int nWidth,int nHeight,
		OffsetPair OffsetOut,Seam ** pSeams, OffsetPair ** pOffsets , int bFlag=1);
	
	inline	int CountSeams(Seam ** pSeams, OffsetPair pOffsets,int nWidth,int nHeight);
	
	void DetectOutput(Seam** pSeams,long lWidth,long lHeight);
	
	float CalculateEntirePtEx( color3D  **pMatchPatchV, color3D  **pMatchPatchH,
		 color3D  **pCandiPatchV, color3D  **pCandiPatchH,
		long lWidth,long lHeight);
	double CalculateEntirePtEx(double SumOV,double sumIOV,int nWidthV,int nHeightV,
		double SumOH,double sumIOH,int nWidthH,int nHeightH,
		long lArea,int offsetX,int offsetY);
	
	inline	BOOL PatchMatchProcessEx( color3D  ** pData,  color3D  **pMatchPatchV, color3D  **pMatchPatchH, 
		CArray<OffsetPair,OffsetPair>& OffsetArray ,long lWidth,long lHeight);
	inline	BOOL MinCutProcessEx( color3D  **pData,unsigned int  lWidth,unsigned int lHeight,OffsetPair InOffset, color3D  **pDataOut,
		 color3D  **pMatchPatchV,  color3D  **pMatchPatchH,OffsetPair OutOffset
		,Seam ** pSeams, OffsetPair ** pOffsets);
	inline	BOOL LaterMinCutEx( color3D  **pData, color3D  **pDataOut,
		long lWidth,long lHeight,OffsetPair Outoffset,
		Seam **pSeams, OffsetPair **pIndexOutput);
	
	//////////////////////////////////////////////////////////////////////////
	//surrounded Regions Patch Functions --> SurroundPatch.cpp
	BOOL FindErrorRegion(Seam **pSeams,long lWidthOut,long lHeightOut,  CArray<OffsetPair ,OffsetPair >&EROffsetArray0);//OffsetPair& EROffset);
	BOOL SurroundPatch( color3D  **pData,long lWidth,long lHeight,
		 color3D  **pDataOut,long lWidthOut,long lHeightOut,
		Seam **pSeams, OffsetPair **pIndexOutput,CArray<OffsetPair,OffsetPair>& OffsetArray);
	
	//////////////////////////////////////////////////////////////////////////
	//FFT convolution operations  --> convolution.cpp
	CMatrix* FFTConvolutionCore(CMatrix& ReIn,CMatrix &ReInMatch,long newWidth,long newHeight);

	CMatrix** FFTConvolution( color3D  ** pData,long lWidth,long lHeight,
		 color3D  **pMatchPatch, long nWidth,long nHeight);//,CMatrix &ReOutOut)
	void InitMatrix(CMatrix *pMatrix[3],int newWidth,int newHeight)
	{
		pMatrix[1]=new CMatrix(newWidth,newHeight);
		pMatrix[2]=new CMatrix(newWidth,newHeight);
		pMatrix[0]=new CMatrix(newWidth,newHeight);
	}
	//(a+bi)*(c+di)=(ac-bd)+(ad+bc)i
	void ComplexMulti(CMatrix * ReMatrix,CMatrix * ImMatrix,CMatrix * ReMatrix2,CMatrix * ImMatrix2,
						int index,int indey,CMatrix *pReOut,CMatrix *pImOut,long size)
	{
		double a,b,c,d;
		a=ReMatrix->GetElement(index,indey);
		b=ImMatrix->GetElement(index,indey);
		c=ReMatrix2->GetElement(index,indey);
		d=ReMatrix2->GetElement(index,indey);
		pReOut->SetElement(index,indey,(a*c-b*d)*size);
		pImOut->SetElement(index,indey,(a*d+b*c)*size);
	}
	
	//////////////////////////////////////////////////////////////////////////
	//Pro Process operations  --> ProProcess.cpp
	inline	void GaussianKernelGenerate(int delta, int sigma, int nSize,float ** pGausKernel);
	inline	colorEx3D GaussianConv(float ** pGausKernel, color3D  **pDataMatch,int nWidth,int nHeight);
	inline	BOOL SeamSearch(Seam **pSeams,OffsetPair** pOffsets,CArray<OffsetPair,OffsetPair>&OffsetList,
		int lWidth,int lHeight,int offsetX,int offsetY,int nSize,int nGap);
	void ProProcess(Seam **pSeams,OffsetPair** pOffsets,
		 color3D ** pData, long lWidth,long lHeight,
		 color3D ** pDataOut,long lWidthOut,long lHeightOut);
	
	//////////////////////////////////////////////////////////////////////////
	//Overlap of multi images  ---> TextureOverlap.cpp
	HDIB TextureOverlap(HDIB m_hOverDIB,HDIB m_hModelDIB,CArray<CRect,CRect>&RectList);
	// Dialog Data
	//{{AFX_DATA(CTextureSynthesisDlg)
	enum { IDD = IDD_TEXTURESYNTHESIS_DIALOG };
	CButton	m_bPorprocess;
	CButton	m_bOverlap;
	CComboBox	m_style;
	CString	m_input;
	CString	m_output;
	CString	m_overlap;
	//}}AFX_DATA
	
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTextureSynthesisDlg)
protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL
	
	// Implementation
protected:
	HICON m_hIcon;
	
	// Generated message map functions
	//{{AFX_MSG(CTextureSynthesisDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnButtonInput();
	afx_msg void OnButtonOutput();
	virtual void OnOK();
	afx_msg void OnDestroy();
	afx_msg void OnCheck1();
	afx_msg void OnButtonOverlap();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TEXTURESYNTHESISDLG_H__2885CE25_91CB_4F3E_950B_FE148D2C07E6__INCLUDED_)
