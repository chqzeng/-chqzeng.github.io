// ArisImageRoutines1.h: interface for the ArisImageRoutines class.
//
// Author: Aris Adrianto S
// email: arisitb@yahoo.com
// home: http://arisitb.cjb.net
// 
// "free is free, modify it as u like to suit your needs"
//
// I will really appreciate if you mention me on the credits
// 
//
// please notify me if:
// 1. there is a bug or there are bugs :-)
// there is an addition request (i'll do it if i have time)
// u find this useful (and have use it in you program)
// u modify or add the code to be more efficient
// 
//////////////////////////////////////////////////////////////////////

// this is a helper class for doing FFT and such
// specifically designed for image processing

// the matrix class used is authored by:
// R.I.Allen
// note :	there are 2 CMatrix class in CodeProject,
//			you'd better pay attention with it.

// the original c code
// was taken from:
// yikes!, i can't find it in the original source !
// i guess it doesn't matter since it was free ( what a devil !)

#if !defined(AFX_ARISIMAGEROUTINES1_H__235C55BE_6EF0_488E_8410_6687170F32E8__INCLUDED_)
#define AFX_ARISIMAGEROUTINES1_H__235C55BE_6EF0_488E_8410_6687170F32E8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Matrix.h"

class ArisImageRoutines  
{
public:
	__declspec(dllexport) ArisImageRoutines();
	__declspec(dllexport) virtual ~ArisImageRoutines();
	
	/*
		********************************************************************
		FUNCTIONS = FFT (...) and DCT (...)

		DESCRIPTION:
		  
		2D FFT (I design this for image processing)
		input must have a symetrical 2^n dimension
		if u have an image/matrix which are not qualified (hint: use bicubic scaling)
				
		INPUT:

		if one of the input is NULL (you cannot have both input zero!) 
		then it will do an in-place transform

		OUTPUT:

		if ONE of the output matrix is NULL,
			the process will replace the input matrix,
			
			if the imaginary input is NULL,
				the process will count the absolute result,
				and place it to the Real Input
			else if the imaginary input is NOT NULL,
				the process will count complex result,
				and place it to the Real Input and Imaginary Input, respectively

		else if BOTH of the output matrix are NOT NULL
			the process will set the output matrix as the result

		
		RETURN VALUE

			TRUE if succeed
			FALSE if failed

		SCALING

			No Scaling is performed,
			you have to scale it first if you want to view it (note RGB value is in BYTE)

		VARIABLE TYPE

			All process use "double", so you'd better be aware of truncation if you use floats
		

		DIRECTION
			
			  1 for forward transform
			  -1 for reverse transform
			  (other value will do nothing except FALSE in return value)

		********************************************************************
	*/

	//direct Functions

	__declspec(dllexport) BOOL FFT(CMatrix *ReInput, CMatrix *ImInput = NULL, CMatrix *ReOutput = NULL, CMatrix *ImOutput = NULL,int dir = 1);

	__declspec(dllexport) BOOL DCT(CMatrix *Source, CMatrix *Destination = NULL, int dir = 1);
	
	
	//helper
	
	__declspec(dllexport) bool IsPowerOfTwo (unsigned int x);

	

	//image processing functions

	//true color FFT (uses parallel processing, use with care)

	//you may fill the Matrix Array with RGB Matrix
	//position in RGB affects nothing
	//
	
	
	/*	for example

		//assumed that u have 3 matrix Red, Green, Blue;

		extern CMatrix Red;
		extern CMatrix Green;
		extern CMatrix Blue;
	
		CMatrix MyImageArray[3];

		MyImageArray[0] = Red;
		MyImageArray[1] = Green;
		MyImageArray[2] = Blue;

		//just do it!
		TRUEFFT(&MyImageArray.NULL,NULL.NULL);

		//here MyImageArray contains magnitude value for Red. Green, Blue,
		//respectively (sounds like a text book :-)
	*/
	
		

	__declspec(dllexport) BOOL TRUEFFT
	(
		CMatrix *ReInput[3], 
		CMatrix *ImInput[3] = NULL, 
		CMatrix *ReOutput[3] = NULL, 
		CMatrix *ImOutput[3] = NULL,
		int dir = 1
	);

	__declspec(dllexport) BOOL TRUEDCT
	(
		CMatrix *Source[3], 
		CMatrix *Destination[3] = NULL,
		int dir = 1
	);
		
	
};

#endif // !defined(AFX_ARISIMAGEROUTINES1_H__235C55BE_6EF0_488E_8410_6687170F32E8__INCLUDED_)
