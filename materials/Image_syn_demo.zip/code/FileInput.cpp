#include "stdafx.h"
#include "TextureSynthesisDlg.h"

///////////////////////////////////////////////////////////////////////////
// TextureSynthesisDlg Functions
// Function name:	TextureSynthesisDlg::InitDIBData()
// Function role:	Initialize DIB objects 
// Return Value:	void 
// Parameters:		HDIB m_hInDIB
// Param Desribe:	the Handle to be initialized
// Notes:			None
///////////////////////////////////////////////////////////////////////////
void CTextureSynthesisDlg::InitDIBData(HDIB m_hInDIB)
{
  
	// Initialize DIB objects 

	// if DIB objects is empty ,return
	if (m_hInDIB == NULL)
	{
		return;
	}
	LPSTR lpDIB = (LPSTR) ::GlobalLock((HGLOBAL) m_hInDIB);
	
	// determine whether the image is too big
	if (::DIBWidth(lpDIB) > INT_MAX ||::DIBHeight(lpDIB) > INT_MAX||
		::DIBWidth(lpDIB) < IMAGE_MIN_SCALE ||::DIBHeight(lpDIB) < IMAGE_MIN_SCALE)
	{
		::GlobalUnlock((HGLOBAL) m_hInDIB);
		
		// release DIB objects 
		::GlobalFree((HGLOBAL) m_hInDIB);
		
		// set DIB to be empty
		m_hInDIB = NULL;
		
		CString strMsg;
		strMsg = "BMP Image is too big or too small for loading";
		
		// message report
		MessageBox(strMsg, "System Message", MB_ICONINFORMATION | MB_OK);
		
		return;
	}
	
	// set the size of the Doc
	m_sizeDoc = CSize((int) ::DIBWidth(lpDIB), (int) ::DIBHeight(lpDIB));
	
	::GlobalUnlock((HGLOBAL) m_hInDIB);
}

///////////////////////////////////////////////////////////////////////////
// TextureSynthesisDlg Functions
// Function name:	TextureSynthesisDlg::OpenInputFile()
// Function role:	Open the input images 
// Return Value:	HDIB 
// Parameters:		CString strPathName
// Param Desribe:	Input file name
// Notes:			None
///////////////////////////////////////////////////////////////////////////
HDIB CTextureSynthesisDlg::OpenInputFile(CString strPathName)
{	
	CFileException fe;
	
	//define current HDIB to store the file
	HDIB m_hCurDIB ;

 	// open the file
 	if (!m_InFile.Open(strPathName, CFile::modeRead | CFile::shareDenyWrite, &fe))
 	{	
 		return NULL;
 	}
 	
 	// change the style of cursor
 	BeginWaitCursor();
 	
 	// ReadDIBFile
 	TRY
 	{
 		m_hCurDIB = ::ReadDIBFile(m_InFile);
 	}
 	CATCH (CFileException, eLoad)
 	{
 		// Read fail
 		m_InFile.Abort();
 		
 		// recover the cursor state
 		EndWaitCursor();
 			
 		// set DIB as empty
 		m_hCurDIB = NULL;
 		
 		// return
 		return m_hCurDIB;
 	}
 	END_CATCH
 	
 	// Initialize DIB
 	InitDIBData(m_hCurDIB);
 	
 	// whether the HDIB is successfully initialized?
 	if (m_hCurDIB == NULL)
 	{
 		// fail
 		CString strMsg;
 		strMsg = "Reading Image error!\n Maybe the type is not supported!";
 		
 		// throw message
 		MessageBox(strMsg, "System Message", MB_ICONINFORMATION | MB_OK);
  		
 		// recover the state of cursor
 		EndWaitCursor();
 		
 		return m_hCurDIB;
 	}
 		
 	// recover the state of cursor
 	EndWaitCursor();

	return m_hCurDIB;
}

///////////////////////////////////////////////////////////////////////////
// TextureSynthesisDlg Functions
// Function name:	TextureSynthesisDlg::InitDIBData()
// Function role:	Save the output image as file
// Return Value:	BOOL 
// RtVal Description:	whether the function been successful execute
// Parameters:			CString strPathName
// Param Desription:	Output file name
// Parameters:			HDIB m_hOutputDIB
// Param Desription:	output image handle
// Notes:			None
///////////////////////////////////////////////////////////////////////////
BOOL CTextureSynthesisDlg::SaveOutputFile(CString strPathName, HDIB m_hOutputDIB)
{
	CFile file;
	CFileException fe;

	// open file
	if (!file.Open(strPathName, CFile::modeCreate |
	  CFile::modeReadWrite | CFile::shareExclusive, &fe))
	{
		return FALSE;
	}

	// using function SaveDIB to save image
	BOOL bSuccess = FALSE;
	TRY
	{
		// change states of the cursor
		BeginWaitCursor();

		// try to save the image
		bSuccess = ::SaveDIB(m_hOutputDIB, file);
		// close file
		file.Close();
	}
	CATCH (CException, eSave)
	{
		// if fail
		file.Abort();
		
		// recover the state of cursor
		EndWaitCursor();
		
		// return FALSE
		return FALSE;
	}
	END_CATCH

	// recover the state of cursor
	EndWaitCursor();

	if (!bSuccess)
	{
		CString strMsg;
		strMsg = "Cannot save BMP Image!";
		
		// message report
		MessageBox(strMsg, "System Message", MB_ICONINFORMATION | MB_OK);
		
		return FALSE;
	}
	
	return TRUE;
}