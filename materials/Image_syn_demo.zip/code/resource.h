//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by TextureSynthesis.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_TEXTURESYNTHESIS_DIALOG     102
#define IDR_MAINFRAME                   128
#define IDD_DIALOG_OVERLAP              131
#define IDC_BUTTON_INPUT                1000
#define IDC_BUTTON_OUTPUT               1001
#define IDC_EDIT_INPUT                  1002
#define IDC_EDIT_OUTPUT                 1003
#define IDC_BUTTON_OVERLAP              1004
#define IDC_COMBO1                      1005
#define IDC_EDIT_OVERLAP                1006
#define IDC_CHECK1                      1007
#define IDC_RADIO_FFT                   1008
#define IDC_RADIO_NAIVE                 1009
#define IDC_STATIC_INPUT                1009
#define IDC_STATIC_OUTPUT               1010
#define IDC_BUTTON_SELIN                1011
#define IDC_BUTTON_SELOUT               1012
#define IDC_CHECK_ProProcess            1012
#define IDC_BUTTON_SELOVER              1013

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        135
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1013
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
