#include "stdafx.h"
#include "TextureSynthesisDlg.h"

#include "graph.h"

//offsety = left-top conner of overlap region
BOOL CTextureSynthesisDlg::SurroundPatch( color3D  **pData,long lWidth,long lHeight,
										  color3D  **pDataOut,long lWidthOut,long lHeightOut,
										 Seam **pSeams, OffsetPair **pIndexOutput,CArray<OffsetPair,OffsetPair>& OffsetArray)
{
	//memory allocate for match patch matrix (vertical)
	 color3D  **pMatchPatch;
	pMatchPatch =new  color3D  *[MIN_PATCH_SIZE];
	for (int i=0;i<MIN_PATCH_SIZE;i++)
	{
		pMatchPatch[i]=new  color3D [MIN_PATCH_SIZE];
	}
	

//	DetectOutput(pSeams,MIN_PATCH_SIZE*3,MIN_PATCH_SIZE*3);

	OffsetPair EROffset;
	FindErrorRegion(pSeams,lWidthOut,lHeightOut, EROffsetArray);
	EROffset=EROffsetArray.GetAt(EROffsetArray.GetSize()-1);
	//fetch data from output image as Match Patch for V and H oriention
	OffsetFetch(pDataOut,pMatchPatch,MIN_PATCH_SIZE,MIN_PATCH_SIZE,EROffset.x,EROffset.y);

	//match the patch and find the right candidate patch from input image
	if(m_style.GetCurSel()==0) 
		PatchMatchProcess(OffsetArray,lWidth,lHeight);
	else
		if(!PatchMatchProcess(pData, pMatchPatch, OffsetArray,lWidth,lHeight))throw ;
		
	//construct the output offset which is at the left-up coner of region 
	//in Output data matrix which already has data coverage.
	
//	OffsetPair OutOffset;
//	OutOffset.y=OutoffsetY;
// 	OutOffset.x=0;
	
	//Using the max flow process to cut the image.
	MinCutProcessHrz(pData,lWidth,lHeight,OffsetArray.GetAt(OffsetArray.GetSize()-1),
		pDataOut,pMatchPatch,EROffset,pSeams,pIndexOutput,MIN_PATCH_SIZE);

	clear2DArray(MIN_PATCH_SIZE,pMatchPatch);

	return TRUE;

}

BOOL CTextureSynthesisDlg::FindErrorRegion(Seam **pSeams,long lWidthOut,long lHeightOut, CArray<OffsetPair ,OffsetPair >&EROffsetArray)//OffsetPair& EROffset)
{
	//circulation to find the max sum of seam value 
	OffsetPair EROffset;
	float sum=0;
	for ( int i=0; i<lHeightOut-MIN_PATCH_SIZE;i++)
	{
		for (int j=0; j<lWidthOut-MIN_PATCH_SIZE;j++)
		{
			if (OffsetExist(EROffsetArray,j,i))continue;

			float temp=0;
			for (int k=0;k<MIN_PATCH_SIZE;k++)
			{
				for (int m=0;m<MIN_PATCH_SIZE;m++)
				{
					//edge seams : horizonal
					if (k<MIN_PATCH_SIZE-1)
						if(pSeams[i+k][j+m].vtc.bMark==true)temp+=pSeams[i+k][j+m].vtc.mValue;
					//edge seams : vertical
					if (m<MIN_PATCH_SIZE-1)
						if(pSeams[i+k][j+m].hrz.bMark==true)temp+=pSeams[i+k][j+m].hrz.mValue;
				}
			}
			if (temp>sum)
			{
				EROffset.x=j;
				EROffset.y=i;
				sum=temp;
			}
		}
	}
	EROffsetArray.Add(EROffset);

	return TRUE;
}

