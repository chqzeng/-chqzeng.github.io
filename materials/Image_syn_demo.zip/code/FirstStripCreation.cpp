#include "stdafx.h"
#include "TextureSynthesisDlg.h"

#include "graph.h"

void CTextureSynthesisDlg::DetectOutput(Seam** pSeams,long lWidth,long lHeight)	
{
	//detect code for errors
	CString strOutput,str;
	for (int i=0;i<lHeight;i++)
	{
		for (int j=0;j<lWidth;j++)
		{
			if (pSeams[i][j].hrz.bMark==true)
			{
				str.Format(" %3d ",(int)pSeams[i][j].hrz.mValue);
			}
			else
				str.Format("  0  ");
			
			strOutput+=str;
		}
		strOutput+="\n";
		for (j=0;j<lWidth;j++)
		{
			if (pSeams[i][j].vtc.bMark==true)
			{
				str.Format("%3d  ",(int)pSeams[i][j].vtc.mValue);
			}
			else
				str.Format("0    ");
			
			strOutput+=str;
		}
		strOutput+="\n";
	}

//	AfxMessageBox(strOutput);
// 	return;

	CStdioFile pStream;
	CString pFileName="..\\tutordata\\test.txt";
	pStream.Open( pFileName, CFile::modeCreate | CFile::modeWrite );
	pStream.WriteHuge(strOutput.GetBuffer(0),strOutput.GetLength());
	pStream.Close();
}

BOOL CTextureSynthesisDlg::FirstStripCreation( color3D  **pData, color3D  **pDataOut,
										 long lWidth,long lHeight,int xiterator,
										 Seam **pSeams, OffsetPair **pIndexOutput)
{
	//determine whether is the first time of strip creation
//	int OutoffsetY==MIN_PATCH_SIZE-OVERLAP_WIDTH;

	//memory allocate for match patch matrix
	color3D  **pMatchPatch;
	pMatchPatch =new  color3D  *[MIN_PATCH_SIZE];
	for (int i=0;i<MIN_PATCH_SIZE;i++)
	{
		pMatchPatch[i]=new  color3D [OVERLAP_WIDTH];
	}
	
	//insert the first patch
	OffsetPair firstPair=FirstPatchInsert(pData,pDataOut,lWidth,lHeight);
	
	//record offset pair index
	for (i=0; i<MIN_PATCH_SIZE;i++)
	{
		for (int j=0;j<MIN_PATCH_SIZE;j++)
		{
			pIndexOutput[i][j].x=firstPair.x+j;
			pIndexOutput[i][j].y=firstPair.y+i;
			pSeams[i][j].hrz.bMark =false;
			pSeams[i][j].vtc.bMark =false;
		}
	}
	
	//circulation for generating a lot of Patches
	for (i=0;i<xiterator;i++)
	{
		int InOffsetX;
		InOffsetX=(MIN_PATCH_SIZE-OVERLAP_WIDTH)*(i+1);
		//the first time to fetch data from output image as Match Patch
		OffsetFetch(pDataOut,pMatchPatch,OVERLAP_WIDTH,MIN_PATCH_SIZE,InOffsetX,0);
		//	OffsetArray.GetAt(0).x+MIN_PATCH_SIZE-OVERLAP_WIDTH,OffsetArray.GetAt(0).y);
		
		//Patches Match Methods Select:
		//match the patch and find the right candidate patch from input image
		if(m_style.GetCurSel()==0) 
			PatchMatchProcess(OffsetArray,lWidth,lHeight);
		else
			if(!PatchMatchProcess(pData, pMatchPatch, OffsetArray,lWidth,lHeight))throw ;
			
		
		//construct the output offset which is at the left-up coner of region 
		//in Output data matrix which already has data coverage.
		OffsetPair OutOffset;
		OutOffset.y=0;
		OutOffset.x=InOffsetX;

		//Using the max flow process to cut the image.
		FirstMinCutProcess(pData,OffsetArray.GetAt(OffsetArray.GetSize()-1),
			pDataOut,pMatchPatch,OutOffset,pSeams,pIndexOutput);					
	}
	
	//clear data
	clear2DArray(MIN_PATCH_SIZE,pMatchPatch);
	
	return TRUE;
}


///////////////////////////////////////////////////////////////////////////
// TextureSynthesisDlg Functions
// Function name:		TextureSynthesisDlg::FirstPatchInsert()
// Function Description:First time to select a patch from the input image
// Return Value:		BOOL 
// Rt Val Description:	whether the function has been successful execute
// Parameters:			 color3D  ** pData
// Param Desription:	image handle of input image
// Parameters:			 color3D  ** pDataOut
// Param Desription:	image handle of Output image
// Parameters:			long lWidth,long lHeight
// Param Desription:	size of the input image
// Notes:				In this section, we use random selection a patch from the input image,
//						then we insert selected data into the output as the beginning
///////////////////////////////////////////////////////////////////////////
OffsetPair CTextureSynthesisDlg::FirstPatchInsert( color3D  ** pData, color3D  **pDataOut,long lWidth,long lHeight)
{	
	// Seed the random-number generator with current time so that
	// the numbers will be different every time we run.
	srand( (unsigned)time( NULL ) );
	rand();
	rand();
	srand( rand());
	rand();
	
	//generate two random numbers between 0 and 1
	float randW = (float)rand()/RAND_MAX ;
	float randH = (float)rand()/RAND_MAX ;
	
	long offsetx,offsety;
	//using two random numbers to calculate width and height offset
	offsetx=(long)(randW*(lWidth-MIN_PATCH_SIZE));
	offsety=(long)(randH*(lHeight-MIN_PATCH_SIZE));
	
	//add offset pair to the array
	OffsetPair firstOffset;
	firstOffset.x=offsetx;
	firstOffset.y=offsety;
	OffsetArray.Add(firstOffset);
	

//	CString str,strOutput;
	//copy data from input to output image
	for (int i=0; i<MIN_PATCH_SIZE;i++)
	{
		for (int j=0; j<MIN_PATCH_SIZE; j++)
		{
//			str.Format("%4d",pData[offsety+i][offsetx+j]);
//			strOutput+=str;
			pDataOut[i][j]=pData[offsety+i][offsetx+j];
		}
//		strOutput+="\n";
	}
	//	AfxMessageBox(strOutput);
	
	return firstOffset;
}

//out offset is point to the left-up coner.
BOOL CTextureSynthesisDlg::FirstMinCutProcess( color3D  **pData,OffsetPair InOffset,
												 color3D  **pDataOut, color3D  **pMatchPatch,OffsetPair OutOffset
												,Seam ** pSeams, OffsetPair ** pOffsets )
{
	 color3D  **pDes;
	//memory allocate for candidate patch matrix
	pDes =new  color3D  *[MIN_PATCH_SIZE];
	for (int i=0;i<MIN_PATCH_SIZE;i++)
	{
		pDes[i]=new  color3D [OVERLAP_WIDTH];
	}
	
	//fetch data from the input matrix
	OffsetFetch(pData,pDes,OVERLAP_WIDTH, MIN_PATCH_SIZE,InOffset.x,InOffset.y);
	
	BOOL **pMark;
	//memory allocate for mark matrix
	pMark =new BOOL *[MIN_PATCH_SIZE];
	for (i=0;i<MIN_PATCH_SIZE;i++)
	{
		pMark[i]=new BOOL[OVERLAP_WIDTH];
	}
	
	//core for calculating the min-cut
	MinCutCore(pMatchPatch,pDes,pMark,OVERLAP_WIDTH,MIN_PATCH_SIZE,NULL,NULL);
	
	//using data from input patches after cutting to replace the exist pixels in output image
	for ( i=0;i<MIN_PATCH_SIZE;i++)
	{
		for (int j=0;j<OVERLAP_WIDTH;j++)
		{
			//update data
			if (pMark[i][j])
			{
				pDataOut[i+OutOffset.y][j+OutOffset.x]=pDes[i][j];//pData[i+InOffset.y][InOffset.x+j];
				pOffsets[i+OutOffset.y][j+OutOffset.x].x=InOffset.x+j;
				pOffsets[i+OutOffset.y][j+OutOffset.x].y=InOffset.y+i;
			}

			//record horizonal seams
			if (j==0)continue;
			if (pMark[i][j-1]!=pMark[i][j])
			{		
				OffsetPair* ptempL = &pOffsets[i+OutOffset.y][OutOffset.x+j-1];
				float mVal=CalculateMValue(pData[ptempL->y][ptempL->x],pData[ptempL->y][ptempL->x+1],
											pDes[i][j-1],pDes[i][j]);
				if (mVal>0)
				{
					pSeams[i+OutOffset.y][j+OutOffset.x-1].hrz.bMark=true;
					pSeams[i+OutOffset.y][j+OutOffset.x-1].hrz.mValue=mVal;
				}

				
			//	break;
			}
		}
	}
	
	//record vertical seams
	for ( int j=0;j<OVERLAP_WIDTH;j++)
	{
		for (int i=1;i<MIN_PATCH_SIZE;i++)
		{
			if (pMark[i-1][j]!=pMark[i][j])
			{
			
				OffsetPair* ptempL = &pOffsets[i+OutOffset.y-1][j+OutOffset.x];
				float mVal=CalculateMValue(pData[ptempL->y][ptempL->x],pData[ptempL->y+1][ptempL->x],
											pDes[i-1][j],pDes[i][j]);
				if(mVal>0)
				{
					pSeams[i+OutOffset.y-1][j+OutOffset.x].vtc.bMark=true;
					pSeams[i+OutOffset.y-1][j+OutOffset.x].vtc.mValue=mVal;
				}
			}	
		}
	}
	//////////////////////////////////////////////////////////////////////////
	//load the data which is not in the overlap area from the patch to output
//	CString str,strOutput;
	for (i=0; i<MIN_PATCH_SIZE;i++)
	{
		for (int j=0; j<MIN_PATCH_SIZE-OVERLAP_WIDTH; j++)
		{
//			str.Format("%4d",pData[i+InOffset.y][InOffset.x+OVERLAP_WIDTH+j]);
//			strOutput+=str;
			pDataOut[i+OutOffset.y][j+OVERLAP_WIDTH+OutOffset.x]=pData[i+InOffset.y][InOffset.x+OVERLAP_WIDTH+j];
			pOffsets[i+OutOffset.y][j+OVERLAP_WIDTH+OutOffset.x].x=InOffset.x+j+OVERLAP_WIDTH;
			pOffsets[i+OutOffset.y][j+OVERLAP_WIDTH+OutOffset.x].y=InOffset.y+i;

			if (i<MIN_PATCH_SIZE-1)
				pSeams[i+OutOffset.y][j+OVERLAP_WIDTH+OutOffset.x].vtc.bMark=false;
		
			if (j<MIN_PATCH_SIZE-OVERLAP_WIDTH-1)
				pSeams[i+OutOffset.y][j+OVERLAP_WIDTH+OutOffset.x].hrz.bMark=false;
		}
//		strOutput+="\n";
	}
	//AfxMessageBox(strOutput);
	
	//clear data struct pMark and pDEs
	for (i=0;i<MIN_PATCH_SIZE;i++)
	{
		delete [] 	pMark[i];
		delete [] 	pDes[i];
	}
	delete   []   pMark;
	delete   []   pDes;
	/*
	clear2DArray(MIN_PATCH_SIZE,pMark);
	clear2DArray(MIN_PATCH_SIZE,pDes);
	*/
	return TRUE;
}