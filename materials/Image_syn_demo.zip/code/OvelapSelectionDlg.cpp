// OvelapSelectionDlg.cpp : implementation file
//

#include "stdafx.h"
#include "texturesynthesis.h"
#include "OvelapSelectionDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COvelapSelectionDlg dialog


COvelapSelectionDlg::COvelapSelectionDlg(CWnd* pParent /*=NULL*/)
	: CDialog(COvelapSelectionDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(COvelapSelectionDlg)
	//}}AFX_DATA_INIT
}


void COvelapSelectionDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(COvelapSelectionDlg)
	DDX_Control(pDX, IDOK, m_ok);
	DDX_Control(pDX, IDC_BUTTON_SELOVER, m_OverlapSel);
	DDX_Control(pDX, IDC_BUTTON_SELOUT, m_OutSel);
	DDX_Control(pDX, IDC_BUTTON_SELIN, m_InSel);
	DDX_Control(pDX, IDC_STATIC_OUTPUT, m_OutputBox);
	DDX_Control(pDX, IDC_STATIC_INPUT, m_InputBox);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(COvelapSelectionDlg, CDialog)
	//{{AFX_MSG_MAP(COvelapSelectionDlg)
	ON_BN_CLICKED(IDC_BUTTON_SELIN, OnButtonSelin)
	ON_BN_CLICKED(IDC_BUTTON_SELOUT, OnButtonSelout)
	ON_BN_CLICKED(IDC_BUTTON_SELOVER, OnButtonSelover)
	ON_WM_LBUTTONDOWN()
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// COvelapSelectionDlg message handlers

BOOL COvelapSelectionDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here

	//initial
	bIn=bOut=bOver=false;
	nFlag=-1;
	InRect.left=0;
	InRect.right=0;
	InRect.top=0;
	InRect.bottom=0;
	OutRect=InRect;
	OverRect=InRect;
//////////////////////////////////////////////////////////////////////////
//layout of Buttons 

	//whole window
	CSize WindowSize;
	m_InSel.GetWindowRect(&rcButton);
	m_ok.GetWindowRect(&rcOK);
	WindowSize.cx=max((3*rcButton.Width()+rcOK.Width()+5*GAP_COMPONENT),(ImgL.cx+ImgR.cx+5*GAP_COMPONENT));
	WindowSize.cy=max(ImgL.cy,ImgR.cy)+10*GAP_COMPONENT+rcButton.Height();
	SetWindowPos(NULL,0,0,WindowSize.cx,WindowSize.cy,SWP_NOMOVE|SWP_SHOWWINDOW);

	//buttons
	m_InSel.SetWindowPos(NULL,GAP_COMPONENT,GAP_COMPONENT,rcButton.Width(),rcButton.Height(),SWP_SHOWWINDOW);
	m_OutSel.SetWindowPos(NULL,GAP_COMPONENT+(GAP_COMPONENT+rcButton.Width()),GAP_COMPONENT,rcButton.Width(),rcButton.Height(),SWP_SHOWWINDOW);
	m_OverlapSel.SetWindowPos(NULL,GAP_COMPONENT+(GAP_COMPONENT+rcButton.Width())*2,GAP_COMPONENT,rcButton.Width(),rcButton.Height(),SWP_SHOWWINDOW);
	m_ok.SetWindowPos(NULL,GAP_COMPONENT+(GAP_COMPONENT+rcButton.Width())*3,GAP_COMPONENT,rcOK.Width(),rcOK.Height(),SWP_SHOWWINDOW);
	
	//Image Boxs
	m_InputBox.SetWindowPos(NULL,GAP_COMPONENT,GAP_COMPONENT*2+rcButton.Height(),ImgL.cx+GAP_COMPONENT,ImgL.cy+GAP_COMPONENT,SWP_SHOWWINDOW);
	m_OutputBox.SetWindowPos(NULL,GAP_COMPONENT*3+ImgL.cx,GAP_COMPONENT*2+rcButton.Height(),ImgR.cx+GAP_COMPONENT,ImgR.cy+GAP_COMPONENT,SWP_SHOWWINDOW);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

BOOL COvelapSelectionDlg::PreCreateWindow(CREATESTRUCT& cs) 
{
	// TODO: Add your specialized code here and/or call the base class
	
	return CDialog::PreCreateWindow(cs);
}

void COvelapSelectionDlg::OnButtonSelin() 
{
	// TODO: Add your control notification handler code here
	nFlag=1;
}

void COvelapSelectionDlg::OnButtonSelout() 
{
	// TODO: Add your control notification handler code here
	nFlag=2;
}

void COvelapSelectionDlg::OnButtonSelover() 
{
	// TODO: Add your control notification handler code here
	nFlag=3;
}

void COvelapSelectionDlg::OnOK() 
{
	// TODO: Add extra validation here
	TrueInRect=InRect-rectDesL.TopLeft();
	TrueOutRect=OutRect-rectDesR.TopLeft();
	TrueOverRect=OverRect-rectDesR.TopLeft();

	//coordinates change
	int temp;
	int H=rectDesL.Height();
	temp=TrueInRect.top;
	TrueInRect.top=H-TrueInRect.bottom;
	TrueInRect.bottom=H-temp;

	H=rectDesR.Height();
	temp=TrueOutRect.top;
	TrueOutRect.top=H-TrueOutRect.bottom;
	TrueOutRect.bottom=H-temp;

	temp=TrueOverRect.top;
	TrueOverRect.top=H-TrueOverRect.bottom;
	TrueOverRect.bottom=H-temp;

	CDialog::OnOK();
}

void COvelapSelectionDlg::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	CRectTracker tracker;
	if (tracker.TrackRubberBand(this, point))
	{
		tracker.m_rect.NormalizeRect(); // so intersect rect works
	}
	switch(nFlag) {
	case 1:
		tracker.GetTrueRect(&InRect);
		break;
	case 2:
		tracker.GetTrueRect(&OutRect);
		break;
	case 3:
		tracker.GetTrueRect(&OverRect);
		break;
	default:
		break;
	}

	Invalidate();
	UpdateData();
	
	CDialog::OnLButtonDown(nFlags, point);
}

void COvelapSelectionDlg::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	// TODO: Add your message handler code here
//////////////////////////////////////////////////////////////////////////
//Image Rendering

	//Input image
	CPalette pPal;
	CreateDIBPalette(m_hDIBL, &pPal);
	CRect rectBmp;
	rectBmp.top=GAP_COMPONENT*3+rcButton.Height();
	rectBmp.left=GAP_COMPONENT*2;
	rectBmp.right=ImgL.cx+GAP_COMPONENT*2;
	rectBmp.bottom=ImgL.cy+GAP_COMPONENT*3+rcButton.Height();
//	rectBmp=rectBmp+GAP_COMPONENT;
	rectDesL=rectBmp;
	PaintDIB( GetDC()->m_hDC,&rectDesL, m_hDIBL, &rectBmp, &pPal);

	//Output image
	CPalette pPalR;
	CreateDIBPalette(m_hDIBR, &pPalR);
//	CRect rectBmp,rectDes;
	rectBmp.top=GAP_COMPONENT*3+rcButton.Height();
	rectBmp.left=GAP_COMPONENT*4+ImgL.cx;
	rectBmp.right=ImgR.cx+GAP_COMPONENT*4+ImgL.cx;
	rectBmp.bottom=ImgR.cy+GAP_COMPONENT*3+rcButton.Height();
//	rectBmp=rectBmp+GAP_COMPONENT;
	rectDesR=rectBmp;
	PaintDIB( GetDC()->m_hDC,&rectDesR, m_hDIBR, &rectBmp, &pPal);

//////////////////////////////////////////////////////////////////////////
//rendering the Rects
	CDC *pDC=GetDC();
	if (IsRectValid(InRect,rectDesL))
	{
		//modify the rect
		InRect=RectTolerance(InRect,rectDesL);

		CPen pen(PS_SOLID,1,RGB(0,255,0));
		CPen *pOldpen=pDC->SelectObject(&pen);
		pDC->MoveTo(InRect.TopLeft());
		pDC->LineTo(InRect.right,InRect.top);
		pDC->LineTo(InRect.BottomRight());
		pDC->LineTo(InRect.left,InRect.bottom);
		pDC->LineTo(InRect.TopLeft());
		pDC->SelectObject(pOldpen);
		bIn=true;
	}

	if (IsRectValid(OutRect,rectDesR))
	{
		//modify the rect
		OutRect=RectTolerance(OutRect,rectDesR);

		CPen pen(PS_SOLID,1,RGB(0,0,255));
		CPen *pOldpen=pDC->SelectObject(&pen);
		pDC->MoveTo(OutRect.TopLeft());
		pDC->LineTo(OutRect.right,OutRect.top);
		pDC->LineTo(OutRect.BottomRight());
		pDC->LineTo(OutRect.left,OutRect.bottom);
		pDC->LineTo(OutRect.TopLeft());
		pDC->SelectObject(pOldpen);
		bOut=true;
	}

	if (IsRectValid(OverRect,rectDesR))
	{
		//modify the rect
		OverRect=RectTolerance(OverRect,rectDesR);

		CPen pen(PS_SOLID,1,RGB(255,0,0));
		CPen *pOldpen=pDC->SelectObject(&pen);
		pDC->MoveTo(OverRect.TopLeft());
		pDC->LineTo(OverRect.right,OverRect.top);
		pDC->LineTo(OverRect.BottomRight());
		pDC->LineTo(OverRect.left,OverRect.bottom);
		pDC->LineTo(OverRect.TopLeft());
		pDC->SelectObject(pOldpen);
		bOver=true;
	}
	if (bIn&&bOut&&bOver) m_ok.EnableWindow(TRUE);
	// Do not call CDialog::OnPaint() for painting messages
}

bool COvelapSelectionDlg::IsRectValid(CRect& rectDes, CRect rectBox)
{
	rectDes.top=max(rectBox.top,rectDes.top);
	rectDes.top=min(rectBox.bottom,rectDes.top);

	rectDes.bottom=max(rectBox.top,rectDes.bottom);
	rectDes.bottom=min(rectBox.bottom,rectDes.bottom);

	rectDes.left=max(rectBox.left,rectDes.left);
	rectDes.left=min(rectBox.right,rectDes.left);

	rectDes.right=max(rectBox.left,rectDes.right);
	rectDes.right=min(rectBox.right,rectDes.right);
		
	if (rectDes.top>=rectBox.top&&rectDes.top<=rectBox.bottom
		&&rectDes.bottom>=rectBox.top&&rectDes.bottom<=rectBox.bottom
		&&rectDes.left>=rectBox.left&&rectDes.left<=rectBox.right
		&&rectDes.right>=rectBox.left&&rectDes.right<=rectBox.right)
		return true;
	else
		return false;
}

CRect COvelapSelectionDlg::RectTolerance(CRect pDes,CRect pMatch)
{
	CRect rectIn;
	//tolerance of edge
	rectIn.top =pDes.top> pMatch.top+ TOLERANCE_GAP? pDes.top:pMatch.top;
	rectIn.left =pDes.left>pMatch.left+ TOLERANCE_GAP? pDes.left:pMatch.left;
	rectIn.bottom=pMatch.bottom>pDes.bottom+TOLERANCE_GAP? pDes.bottom:pMatch.bottom;
	rectIn.right=pMatch.right>pDes.right+TOLERANCE_GAP? pDes.right:pMatch.right;
	
	return rectIn;
}